import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 0, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color7 = java.awt.Color.getColor("hi!", (int) (short) 10);
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape4, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test005");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) 1.0d, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = java.awt.Color.lightGray;
        float[] floatArray3 = new float[] { '#', (byte) 1 };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = java.awt.Color.blue;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 0 };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) 1, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, (float) 'a', (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2103967) + "'", int3 == (-2103967));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        try {
            categoryPlot4.setRangeAxisLocation((int) (short) -1, axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name UnitType.ABSOLUTE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        java.awt.image.BufferedImage bufferedImage8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = defaultShadowGenerator7.createDropShadow(bufferedImage8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int3 = java.awt.Color.HSBtoRGB((float) 10L, (float) 'a', (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10485856) + "'", int3 == (-10485856));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity5.setArea(shape6);
        java.awt.Paint paint8 = null;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "hi!", "", shape6, paint8, stroke9, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray4 = new float[] { 1, (byte) 0, 100L };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject((-4144960));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -4144960");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot4.addDomainMarker((-65536), categoryMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.Paint paint12 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getRangeMarkers((int) '#', layer19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot17.setRangeAxis(0, valueAxis22, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot17.setDomainAxis(10, categoryAxis26, true);
        java.awt.Stroke stroke29 = categoryPlot17.getRangeZeroBaselineStroke();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape31);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity32.setArea(shape33);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset35 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot39.getRangeMarkers((int) '#', layer41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        categoryPlot39.setRangeAxis(0, valueAxis44, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot39.setDomainAxis(10, categoryAxis48, true);
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setOutlineStroke(stroke51);
        java.awt.Color color53 = java.awt.Color.white;
        try {
            org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", true, shape7, false, (java.awt.Paint) color10, false, paint12, stroke29, false, shape33, stroke51, (java.awt.Paint) color53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot4.getBackgroundPaint();
        java.util.List list15 = null;
        try {
            categoryPlot4.mapDatasetToDomainAxes((int) (byte) 10, list15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Marker marker13 = null;
        try {
            categoryPlot4.addRangeMarker(marker13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (10.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable4 = null;
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) (short) 10, comparable4, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-1.0d));
        double double4 = rectangleInsets0.calculateLeftOutset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.0d + "'", double2 == 15.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12, false);
        boolean boolean15 = categoryPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        try {
            boolean boolean5 = defaultCategoryDataset0.isSelected(10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PlotOrientation.HORIZONTAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (100) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Font font7 = categoryAxis0.getTickLabelFont(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.setAnchorValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            categoryPlot4.setInsets(rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 0.0d);
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (-1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot4.handleClick((-2103967), (int) (short) 100, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 100, (int) (short) 100, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.removeRow(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        try {
            defaultCategoryDataset0.setSelected((int) (short) -1, (int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setToolTipText("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) 10, (-2103967));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        try {
            double double25 = categoryAxis13.getCategoryJava2DCoordinate(categoryAnchor20, (-2103967), (int) (short) 10, rectangle2D23, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -2103967");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(categoryAnchor20);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean3 = gradientPaintTransformType0.equals((java.lang.Object) color2);
        java.lang.String str4 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str4.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot22.getRangeMarkers((int) '#', layer24);
        categoryPlot22.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot22.getRangeAxis((int) 'a');
        java.util.List list31 = categoryPlot22.getAnnotations();
        try {
            categoryPlot4.mapDatasetToRangeAxes((int) '4', list31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo6 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) gradientPaintTransformType0, (org.jfree.data.general.Dataset) defaultCategoryDataset1, datasetChangeInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color1 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            boolean boolean6 = defaultCategoryDataset0.isSelected((-10485856), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape9, (java.awt.Paint) color10);
        java.awt.Paint paint13 = null;
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        int int16 = color15.getRGB();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        java.awt.Stroke stroke19 = defaultDrawingSupplier17.getNextStroke();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint23 = null;
        try {
            org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", "org.jfree.chart.event.ChartChangeEvent[source=10]", "CategoryAnchor.MIDDLE", "GradientPaintTransformType.CENTER_HORIZONTAL", false, shape9, true, paint13, true, (java.awt.Paint) color15, stroke19, true, shape21, stroke22, paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4144960) + "'", int16 == (-4144960));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        boolean boolean3 = plotOrientation0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setOutlineStroke(stroke16);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        int int21 = defaultCategoryDataset19.getRowIndex((java.lang.Comparable) (-4144962.0d));
        java.util.List list22 = defaultCategoryDataset19.getColumnKeys();
        try {
            categoryPlot4.mapDatasetToDomainAxes(3, list22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Paint paint22 = null;
        try {
            categoryAxis13.setTickMarkPaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 15.0d);
        try {
            keyedObjects2D0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", "", "", "CategoryAnchor.MIDDLE", shape4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = null;
        try {
            legendItem6.setOutlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint8 = null;
        try {
            categoryAxis0.setAxisLinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets6.createOutsetRectangle(rectangle2D8, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) 10, true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        java.awt.Stroke stroke17 = categoryPlot4.getDomainCrosshairStroke();
        boolean boolean18 = categoryPlot4.isDomainPannable();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            categoryPlot4.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        java.lang.Object obj15 = categoryPlot4.clone();
        boolean boolean16 = categoryPlot4.isRangeZoomable();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer(categoryItemRenderer10);
        categoryPlot4.setRangeCrosshairValue((double) 10, false);
        boolean boolean15 = categoryPlot4.isRangeZoomable();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.setAnchorValue(0.0d);
        java.awt.Stroke stroke19 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot4.removeChangeListener(plotChangeListener20);
        categoryPlot4.setWeight(0);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (-1.0d));
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        try {
            defaultCategoryDataset23.removeRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot4.markerChanged(markerChangeEvent15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot4.removeAnnotation(categoryAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) (short) 100, axisLocation22, false);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = categoryPlot4.removeRangeMarker((int) 'a', marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            categoryPlot4.setRangeAxisLocation((-10485856), axisLocation22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator2 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator3 = null;
        java.lang.String str4 = chartEntity1.getImageMapAreaTag(toolTipTagFragmentGenerator2, uRLTagFragmentGenerator3);
        java.lang.Object obj5 = chartEntity1.clone();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        chartEntity1.setArea(shape6);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        boolean boolean16 = categoryPlot4.isRangeMinorGridlinesVisible();
        java.awt.Paint paint17 = categoryPlot4.getRangeCrosshairPaint();
        boolean boolean18 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot4.setRangeZeroBaselineStroke(stroke8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot4.removeAnnotation(categoryAnnotation10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot4.setRangeZeroBaselineStroke(stroke8);
        java.awt.Stroke stroke10 = null;
        try {
            categoryPlot4.setDomainGridlineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        float float8 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean13 = categoryPlot4.removeDomainMarker((int) (short) 100, marker10, layer11, false);
        org.jfree.chart.plot.Marker marker14 = null;
        try {
            boolean boolean15 = categoryPlot4.removeRangeMarker(marker14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.lang.Object obj5 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1, obj1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) (short) 10);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        java.lang.String str20 = categoryAxis13.getLabel();
        java.lang.Comparable comparable21 = null;
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape26, (java.awt.Paint) color27);
        legendItem28.setShapeVisible(true);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem28.setLabelFont(font31);
        try {
            categoryAxis13.setTickLabelFont(comparable21, font31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        keyedObjects2D0.addObject((java.lang.Object) 100.0f, (java.lang.Comparable) 0, (java.lang.Comparable) (short) -1);
        try {
            java.lang.Object obj9 = keyedObjects2D0.getObject((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        try {
            defaultCategoryDataset23.removeRow((java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, (double) 10L, (double) 0, (double) 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape6, (java.awt.Paint) color7);
        legendItem8.setDescription("PlotOrientation.HORIZONTAL");
        java.awt.Paint paint11 = legendItem8.getFillPaint();
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) paint11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis0.setLabelAngle(15.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color8 = java.awt.Color.black;
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color8);
        java.lang.Comparable comparable10 = null;
        try {
            java.awt.Paint paint11 = categoryAxis0.getTickLabelPaint(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        categoryAxis0.setLowerMargin(15.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            categoryPlot4.addRangeMarker(0, marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        keyedObjects2D0.addObject((java.lang.Object) textAnchor3, (java.lang.Comparable) "java.awt.Color[r=128,g=0,b=128]", (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        try {
            categoryPlot4.setRangeAxis((-1), valueAxis18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        categoryPlot4.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke19 = null;
        try {
            categoryPlot4.setRangeZeroBaselineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        boolean boolean8 = categoryAxis0.isVisible();
        java.awt.Font font9 = null;
        try {
            categoryAxis0.setLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot4.notifyListeners(plotChangeEvent13);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            categoryPlot4.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setCategoryMargin((double) '4');
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot30.getRangeMarkers((int) '#', layer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        categoryPlot30.setRangeAxis(0, valueAxis35, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot30.setDomainAxis(10, categoryAxis39, true);
        java.awt.Stroke stroke42 = categoryPlot30.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot30.getDataset((int) (short) 1);
        int int45 = categoryPlot30.getWeight();
        boolean boolean46 = categoryPlot30.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setRangeAxisLocation((int) (short) 100, axisLocation48, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str52 = plotOrientation51.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation48, plotOrientation51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        try {
            org.jfree.chart.axis.AxisState axisState55 = categoryAxis13.draw(graphics2D22, (double) 1L, rectangle2D24, rectangle2D25, rectangleEdge53, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str52.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.setSelected((-4144960), (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = chartChangeEvent1.toString();
        java.lang.String str3 = chartChangeEvent1.toString();
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent1.getChart();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent(obj0, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setCategoryMargin((double) '4');
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot27.getRangeMarkers((int) '#', layer29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot27.setRangeAxis(0, valueAxis32, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot27.setDomainAxis(10, categoryAxis36, true);
        java.awt.Stroke stroke39 = categoryPlot27.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot27.getDataset((int) (short) 1);
        int int42 = categoryPlot27.getWeight();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = categoryPlot48.getRangeMarkers((int) '#', layer50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        categoryPlot48.setRangeAxis(0, valueAxis53, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        categoryPlot48.setDomainAxis(10, categoryAxis57, true);
        java.awt.Stroke stroke60 = categoryPlot48.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset62 = categoryPlot48.getDataset((int) (short) 1);
        int int63 = categoryPlot48.getWeight();
        boolean boolean64 = categoryPlot48.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot48.setRangeAxisLocation((int) (short) 100, axisLocation66, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation69 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str70 = plotOrientation69.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation66, plotOrientation69);
        org.jfree.chart.axis.AxisSpace axisSpace72 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace73 = categoryAxis13.reserveSpace(graphics2D22, (org.jfree.chart.plot.Plot) categoryPlot27, rectangle2D43, rectangleEdge71, axisSpace72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(categoryDataset62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(plotOrientation69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str70.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.setAnchorValue(0.0d);
        java.awt.Stroke stroke19 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        try {
            categoryPlot4.setDomainAxisLocation(axisLocation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str1.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color1 = java.awt.Color.PINK;
        float[] floatArray8 = new float[] { 10.0f, 100.0f, (byte) -1, (short) 100, 100, 100 };
        float[] floatArray9 = color1.getRGBComponents(floatArray8);
        java.awt.Color color10 = java.awt.Color.getColor("CategoryAnchor.MIDDLE", color1);
        int int11 = color10.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.util.List list12 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation13, false);
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.awt.Color color30 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator34 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color30, 0.0f, 0, (double) (byte) 10);
        int int35 = defaultShadowGenerator34.getShadowSize();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        chartEntity37.setURLText("hi!");
        boolean boolean40 = defaultShadowGenerator34.equals((java.lang.Object) chartEntity37);
        categoryPlot4.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator34);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        try {
            categoryPlot4.addRangeMarker(255, marker43, layer44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        try {
            categoryPlot4.setRenderer((-1), categoryItemRenderer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        java.awt.Stroke stroke6 = null;
        try {
            categoryAxis0.setTickMarkStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 0.0d);
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) false, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (false) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        java.awt.Paint[] paintArray4 = null;
        java.awt.Color color5 = java.awt.Color.BLACK;
        java.awt.Color color6 = java.awt.Color.PINK;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor8);
        boolean boolean10 = color6.equals((java.lang.Object) textAnchor8);
        java.awt.color.ColorSpace colorSpace11 = color6.getColorSpace();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color5, color6, color12, color13, paint20 };
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray21, paintArray22, strokeArray23, strokeArray24, shapeArray25);
        boolean boolean27 = itemLabelPosition2.equals((java.lang.Object) strokeArray24);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean2 = datasetGroup0.equals((java.lang.Object) itemLabelAnchor1);
        java.lang.Object obj3 = null;
        boolean boolean4 = datasetGroup0.equals(obj3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean6 = datasetGroup0.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean8 = itemLabelAnchor5.equals((java.lang.Object) textAnchor7);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100.0d);
        try {
            keyedObjects2D0.removeRow((-10485856));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Paint paint8 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        try {
            categoryPlot4.setRenderer((int) (byte) -1, categoryItemRenderer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator2 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator3 = null;
        java.lang.String str4 = chartEntity1.getImageMapAreaTag(toolTipTagFragmentGenerator2, uRLTagFragmentGenerator3);
        chartEntity1.setToolTipText("hi!");
        java.lang.Object obj7 = chartEntity1.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot4.setRangeZeroBaselineStroke(stroke8);
        java.lang.String str10 = categoryPlot4.getPlotType();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getRangeMarkers((int) '#', layer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis19.getCategoryEnd(1, 0, rectangle2D22, rectangleEdge23);
        java.util.List list25 = categoryPlot10.getCategoriesForAxis(categoryAxis19);
        categoryAxis19.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Font font28 = categoryAxis19.getTickLabelFont();
        categoryAxis0.setLabelFont(font28);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) (-1.0d));
        double double4 = rectangleInsets0.extendWidth(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.0d + "'", double4 == 11.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) (short) 1);
        double double3 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        int int13 = categoryPlot4.getRendererCount();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        try {
            categoryPlot4.setRangeAxis((-2103967), valueAxis16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (true) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        int int8 = defaultShadowGenerator7.getShadowSize();
        int int9 = defaultShadowGenerator7.calculateOffsetY();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        try {
            lineAndShapeRenderer34.setSeriesToolTipGenerator((-2103967), categoryToolTipGenerator37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.lang.Object obj5 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.validateObject();
        try {
            defaultCategoryDataset0.removeRow((-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getRangeMarkers((int) '#', layer16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot14.setRangeAxis(0, valueAxis19, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot14.setDomainAxis(10, categoryAxis23, true);
        java.awt.Stroke stroke26 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot14.getDataset((int) (short) 1);
        int int29 = categoryPlot14.getWeight();
        boolean boolean30 = categoryPlot14.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) (short) 100, axisLocation32, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str36 = plotOrientation35.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation32, plotOrientation35);
        try {
            double double38 = categoryAxis0.getCategoryEnd((int) (byte) 1, (int) '#', rectangle2D9, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str36.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        try {
            lineAndShapeRenderer34.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        try {
            defaultCategoryDataset23.setSelected(3, (-10485856), false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-4144960));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setDomainCrosshairPaint((java.awt.Paint) color15);
        boolean boolean17 = categoryPlot4.canSelectByRegion();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot5.setDomainAxis(10, categoryAxis14, true);
        categoryPlot5.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.Plot plot20 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape0, plot20, "PlotOrientation.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        int int7 = defaultCategoryDataset5.getRowIndex((java.lang.Comparable) (-4144962.0d));
        defaultCategoryDataset5.addValue((java.lang.Number) 10, (java.lang.Comparable) true, (java.lang.Comparable) (-4144962.0d));
        int int12 = defaultCategoryDataset5.getColumnCount();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        int int15 = defaultCategoryDataset13.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset13.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot21.getRangeMarkers((int) '#', layer23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        categoryPlot21.setRangeAxis(0, valueAxis26, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = null;
        categoryPlot21.axisChanged(axisChangeEvent34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis36.getCategoryEnd(1, 0, rectangle2D39, rectangleEdge40);
        categoryAxis36.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot21.setDomainAxis(categoryAxis36);
        double double45 = categoryAxis36.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, categoryAxis36, valueAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer47);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot54.getRangeMarkers((int) '#', layer56);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        categoryPlot54.setRangeAxis(0, valueAxis59, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        categoryPlot54.setDomainAxis(10, categoryAxis63, true);
        java.awt.Stroke stroke66 = categoryPlot54.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset68 = categoryPlot54.getDataset((int) (short) 1);
        int int69 = categoryPlot54.getWeight();
        boolean boolean70 = categoryPlot54.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot54.setRangeAxisLocation((int) (short) 100, axisLocation72, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str76 = plotOrientation75.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation72, plotOrientation75);
        try {
            double double78 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) (byte) 0, (java.lang.Comparable) (byte) 0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis36, rectangle2D49, rectangleEdge77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(categoryDataset68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str76.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        legendItem6.setShape(shape11);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot28.getRangeMarkers((int) '#', layer30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        categoryPlot28.setRangeAxis(0, valueAxis33, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        categoryPlot28.setDomainAxis(10, categoryAxis37, true);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot28.setOutlineStroke(stroke40);
        java.awt.Color color42 = java.awt.Color.white;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=0,b=128]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=10]", "PlotOrientation.HORIZONTAL", shape23, stroke40, (java.awt.Paint) color42);
        java.awt.Color color45 = java.awt.Color.BLUE;
        java.awt.Color color47 = java.awt.Color.gray;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset48 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = categoryPlot52.getRangeMarkers((int) '#', layer54);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot52.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo58, point2D59);
        org.jfree.chart.util.Layer layer61 = null;
        java.util.Collection collection62 = categoryPlot52.getDomainMarkers(layer61);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset63 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset63, categoryAxis64, valueAxis65, categoryItemRenderer66);
        org.jfree.chart.util.Layer layer69 = null;
        java.util.Collection collection70 = categoryPlot67.getRangeMarkers((int) '#', layer69);
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        categoryPlot67.setRangeAxis(0, valueAxis72, false);
        java.awt.Stroke stroke75 = categoryPlot67.getOutlineStroke();
        categoryPlot52.setRangeGridlineStroke(stroke75);
        java.awt.Shape shape78 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset79 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        org.jfree.chart.axis.ValueAxis valueAxis81 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset79, categoryAxis80, valueAxis81, categoryItemRenderer82);
        org.jfree.chart.util.Layer layer85 = null;
        java.util.Collection collection86 = categoryPlot83.getRangeMarkers((int) '#', layer85);
        org.jfree.chart.axis.ValueAxis valueAxis88 = null;
        categoryPlot83.setRangeAxis(0, valueAxis88, false);
        boolean boolean91 = categoryPlot83.getDrawSharedDomainAxis();
        int int92 = categoryPlot83.getRendererCount();
        categoryPlot83.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder95 = categoryPlot83.getRowRenderingOrder();
        java.awt.Stroke stroke96 = categoryPlot83.getRangeZeroBaselineStroke();
        java.awt.Paint paint97 = null;
        org.jfree.chart.LegendItem legendItem98 = new org.jfree.chart.LegendItem("ChartChangeEventType.DATASET_UPDATED", "TextAnchor.CENTER_RIGHT", "ChartChangeEventType.DATASET_UPDATED", "UnitType.ABSOLUTE", false, shape23, false, (java.awt.Paint) color45, false, (java.awt.Paint) color47, stroke75, false, shape78, stroke96, paint97);
        legendItem6.setShape(shape78);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNull(collection70);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNull(collection86);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(sortOrder95);
        org.junit.Assert.assertNotNull(stroke96);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        categoryPlot4.clearSelection();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers((int) '#', layer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot18.setRangeAxis(0, valueAxis23, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot18.setDomainAxis(10, categoryAxis27, true);
        java.awt.Stroke stroke30 = categoryPlot18.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot18.getDataset((int) (short) 1);
        int int33 = categoryPlot18.getWeight();
        boolean boolean34 = categoryPlot18.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot18.setRangeAxisLocation((int) (short) 100, axisLocation36, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str40 = plotOrientation39.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation39);
        try {
            double double42 = categoryAxis0.getCategorySeriesMiddle((int) (short) 0, (int) (short) 100, 3, (int) (short) 10, (double) 0.5f, rectangle2D13, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str40.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100.0d);
        java.lang.Comparable comparable9 = null;
        try {
            int int10 = keyedObjects2D0.getRowIndex(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        categoryPlot5.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean16 = categoryPlot5.equals((java.lang.Object) strokeArray15);
        boolean boolean17 = textAnchor0.equals((java.lang.Object) strokeArray15);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        try {
            categoryPlot4.zoom((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        java.awt.Font font19 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextOutlineStroke();
        java.awt.Stroke stroke22 = defaultDrawingSupplier20.getNextStroke();
        java.awt.Stroke stroke23 = defaultDrawingSupplier20.getNextOutlineStroke();
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot4.getRendererForDataset(categoryDataset25);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(categoryItemRenderer26);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot4.removeRangeMarker((int) (byte) 100, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        categoryPlot7.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis((int) 'a');
        java.util.List list16 = categoryPlot7.getAnnotations();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape21, (java.awt.Paint) color22);
        legendItem23.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset26);
        java.util.List list28 = defaultCategoryDataset26.getRowKeys();
        categoryPlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.Range range30 = lineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        java.awt.Paint paint32 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Paint paint34 = null;
        lineAndShapeRenderer0.setSeriesFillPaint(255, paint34);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        int int19 = defaultCategoryDataset17.getRowIndex((java.lang.Comparable) (-4144962.0d));
        int int20 = categoryPlot4.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        java.lang.Object obj21 = defaultCategoryDataset17.clone();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateBottomInset((double) (-4144960));
        double double12 = rectangleInsets8.calculateTopOutset((double) 0);
        boolean boolean13 = defaultShadowGenerator7.equals((java.lang.Object) double12);
        int int14 = defaultShadowGenerator7.getDistance();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '#', layer8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot6.setRangeAxis(0, valueAxis11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot6.setDomainAxis(10, categoryAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeZeroBaselineStroke();
        categoryPlot6.clearDomainAxes();
        keyedObjects0.addObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot6);
        java.lang.Object obj21 = keyedObjects0.clone();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        float float8 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean13 = categoryPlot4.removeDomainMarker((int) (short) 100, marker10, layer11, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot4.setRenderer(categoryItemRenderer14, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(1, 0, rectangle2D20, rectangleEdge21);
        float float23 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets24.extendWidth((-1.0d));
        categoryAxis17.setLabelInsets(rectangleInsets24, false);
        categoryPlot4.setInsets(rectangleInsets24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 15.0d + "'", double26 == 15.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 100, false);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font5, false);
        java.awt.Font font8 = null;
        try {
            lineAndShapeRenderer0.setBaseItemLabelFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot42.getRangeMarkers((int) '#', layer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot42.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo48, point2D49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = categoryAxis51.getCategoryEnd(1, 0, rectangle2D54, rectangleEdge55);
        java.util.List list57 = categoryPlot42.getCategoriesForAxis(categoryAxis51);
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape62, (java.awt.Paint) color63);
        legendItem64.setShapeVisible(true);
        java.awt.Font font67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem64.setLabelFont(font67);
        categoryAxis51.setLabelFont(font67);
        lineAndShapeRenderer34.setBaseLegendTextFont(font67);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset72 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset72, categoryAxis73, valueAxis74, categoryItemRenderer75);
        org.jfree.chart.util.Layer layer78 = null;
        java.util.Collection collection79 = categoryPlot76.getRangeMarkers((int) '#', layer78);
        org.jfree.chart.axis.ValueAxis valueAxis81 = null;
        categoryPlot76.setRangeAxis(0, valueAxis81, false);
        java.awt.Stroke stroke84 = categoryPlot76.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray85 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot76.setRenderers(categoryItemRendererArray85);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        java.awt.Color color89 = java.awt.Color.LIGHT_GRAY;
        int int90 = color89.getAlpha();
        java.awt.Stroke stroke91 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            lineAndShapeRenderer34.drawDomainLine(graphics2D71, categoryPlot76, rectangle2D87, 3.0d, (java.awt.Paint) color89, stroke91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNull(collection79);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(categoryItemRendererArray85);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 255 + "'", int90 == 255);
        org.junit.Assert.assertNotNull(stroke91);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke21);
        categoryPlot4.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = keyedObjects2D0.getRowIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        categoryPlot7.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis((int) 'a');
        java.util.List list16 = categoryPlot7.getAnnotations();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape21, (java.awt.Paint) color22);
        legendItem23.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset26);
        java.util.List list28 = defaultCategoryDataset26.getRowKeys();
        categoryPlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.Range range30 = lineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        boolean boolean33 = lineAndShapeRenderer0.isSeriesVisibleInLegend((-10485856));
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-1.0d));
        double double4 = rectangleInsets0.calculateRightOutset((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.0d + "'", double2 == 15.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        defaultCategoryDataset9.clear();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getRangeMarkers((int) '#', layer19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot17.setRangeAxis(0, valueAxis22, false);
        java.awt.Stroke stroke25 = categoryPlot17.getOutlineStroke();
        categoryPlot17.setNoDataMessage("hi!");
        defaultCategoryDataset9.removeChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot17);
        categoryPlot17.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue(number0, true);
        boolean boolean3 = selectableValue2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        categoryPlot4.setNoDataMessagePaint(paint17);
        java.awt.Color color19 = java.awt.Color.cyan;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.RenderingSource renderingSource24 = null;
        try {
            categoryPlot4.select((double) 100, (-6.0d), rectangle2D23, renderingSource24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot43.getRangeMarkers((int) '#', layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot43.setRangeAxis(0, valueAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot43.setDomainAxis(10, categoryAxis52, true);
        categoryPlot43.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity57 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) categoryPlot43);
        lineAndShapeRenderer34.setBaseLegendShape(shape38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = categoryPlot64.getRangeMarkers((int) '#', layer66);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        categoryPlot64.setRangeAxis(0, valueAxis69, false);
        org.jfree.chart.util.Layer layer72 = null;
        java.util.Collection collection73 = categoryPlot64.getDomainMarkers(layer72);
        java.awt.Color color76 = java.awt.Color.getColor("hi!", (int) (short) 10);
        categoryPlot64.setBackgroundPaint((java.awt.Paint) color76);
        try {
            lineAndShapeRenderer34.setSeriesPaint((-2103967), (java.awt.Paint) color76, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertNotNull(color76);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot4.addRangeMarker((int) 'a', marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        lineAndShapeRenderer34.setDrawOutlines(false);
        boolean boolean41 = lineAndShapeRenderer34.isItemLabelVisible((int) '#', 10, false);
        try {
            lineAndShapeRenderer34.setSeriesVisible((-2103967), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(true);
        java.awt.Paint paint17 = legendItem14.getOutlinePaint();
        boolean boolean18 = keyedObjects2D0.equals((java.lang.Object) legendItem14);
        java.lang.Comparable comparable19 = null;
        try {
            keyedObjects2D0.removeColumn(comparable19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot4.markerChanged(markerChangeEvent15);
        double double17 = categoryPlot4.getRangeCrosshairValue();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 100, false);
        int int5 = lineAndShapeRenderer0.getPassCount();
        java.awt.Stroke stroke6 = null;
        try {
            lineAndShapeRenderer0.setBaseStroke(stroke6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.Number number5 = defaultCategoryDataset0.getValue(comparable3, (java.lang.Comparable) (-6.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(true);
        java.awt.Paint paint17 = legendItem14.getOutlinePaint();
        boolean boolean18 = keyedObjects2D0.equals((java.lang.Object) legendItem14);
        int int19 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-1.0d));
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.0d + "'", double2 == 15.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        categoryPlot4.setNoDataMessagePaint(paint17);
        java.awt.Color color19 = java.awt.Color.cyan;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = null;
        try {
            categoryPlot4.setRangeCrosshairStroke(stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot4.notifyListeners(plotChangeEvent5);
        java.awt.Stroke stroke7 = categoryPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot43.getRangeMarkers((int) '#', layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot43.setRangeAxis(0, valueAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot43.setDomainAxis(10, categoryAxis52, true);
        categoryPlot43.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity57 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) categoryPlot43);
        lineAndShapeRenderer34.setBaseLegendShape(shape38);
        lineAndShapeRenderer34.setSeriesShapesVisible((int) (byte) 1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor63 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor64 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor63, textAnchor64);
        double double66 = itemLabelPosition65.getAngle();
        lineAndShapeRenderer34.setSeriesPositiveItemLabelPosition(15, itemLabelPosition65, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(itemLabelAnchor63);
        org.junit.Assert.assertNotNull(textAnchor64);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeColumn((-10485856));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        defaultCategoryDataset0.addValue((java.lang.Number) 10, (java.lang.Comparable) true, (java.lang.Comparable) (-4144962.0d));
        int int7 = defaultCategoryDataset0.getColumnCount();
        try {
            defaultCategoryDataset0.incrementValue((-6.0d), (java.lang.Comparable) (short) 10, (java.lang.Comparable) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (10) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot4.setRangeAxis(10, valueAxis13, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot4.addChangeListener(plotChangeListener16);
        try {
            categoryPlot4.setBackgroundImageAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 8.0d);
        boolean boolean2 = selectableValue1.isSelected();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Color color22 = java.awt.Color.black;
        categoryAxis13.setTickMarkPaint((java.awt.Paint) color22);
        float float24 = categoryAxis13.getMinorTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers((int) '#', layer34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot32.setRangeAxis(0, valueAxis37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        categoryPlot32.setDomainAxis(10, categoryAxis41, true);
        java.awt.Stroke stroke44 = categoryPlot32.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot32.getDataset((int) (short) 1);
        int int47 = categoryPlot32.getWeight();
        boolean boolean48 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot32.setRangeAxisLocation((int) (short) 100, axisLocation50, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str54 = plotOrientation53.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation53);
        try {
            double double56 = categoryAxis13.getCategoryMiddle(0, (int) '4', rectangle2D27, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str54.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.KeyedObjects2D keyedObjects2D1 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) 'a');
        keyedObjects2D1.setObject((java.lang.Object) textAnchor2, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        int int9 = keyedObjects2D1.getColumnIndex((java.lang.Comparable) 100.0d);
        boolean boolean10 = itemLabelAnchor0.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        categoryPlot4.clearDomainMarkers((-10485856));
        java.lang.Comparable comparable18 = categoryPlot4.getDomainCrosshairRowKey();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(comparable18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Comparable comparable2 = null;
        java.awt.Color color6 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color6);
        org.jfree.data.KeyedObject keyedObject8 = new org.jfree.data.KeyedObject(comparable2, (java.lang.Object) legendItem7);
        boolean boolean9 = standardGradientPaintTransformer1.equals((java.lang.Object) legendItem7);
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        int int11 = legendItem7.getSeriesIndex();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            lineAndShapeRenderer0.addChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = null;
        try {
            renderAttributes0.setDefaultPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        keyedObjects0.insertValue(0, (java.lang.Comparable) (short) 10, (java.lang.Object) strokeArray4);
        org.jfree.chart.util.SortOrder sortOrder6 = null;
        try {
            keyedObjects0.sortByObjects(sortOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        java.lang.Comparable comparable20 = null;
        try {
            categoryAxis13.removeCategoryLabelToolTip(comparable20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "UnitType.RELATIVE", "Category Plot", categoryDataset3, comparable4, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12, false);
        java.awt.Stroke stroke15 = null;
        try {
            categoryPlot4.setRangeGridlineStroke(stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers((int) '#', layer13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot11.setRangeAxis(0, valueAxis16, false);
        boolean boolean19 = categoryPlot11.getDrawSharedDomainAxis();
        int int20 = categoryPlot11.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot11.getOrientation();
        categoryPlot11.setRangeCrosshairValue((double) 10.0f);
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint24);
        categoryAxis0.setLabelPaint(paint24);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers((int) '#', layer34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot32.setRangeAxis(0, valueAxis37, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot32.zoomDomainAxes((double) 10.0f, plotRenderingInfo41, point2D42, false);
        categoryPlot32.setAnchorValue((double) (short) -1, false);
        java.awt.Paint paint48 = categoryPlot32.getRangeZeroBaselinePaint();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot54.getRangeMarkers((int) '#', layer56);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        categoryPlot54.setRangeAxis(0, valueAxis59, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        categoryPlot54.setDomainAxis(10, categoryAxis63, true);
        java.awt.Stroke stroke66 = categoryPlot54.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset68 = categoryPlot54.getDataset((int) (short) 1);
        int int69 = categoryPlot54.getWeight();
        boolean boolean70 = categoryPlot54.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot54.setRangeAxisLocation((int) (short) 100, axisLocation72, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str76 = plotOrientation75.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation72, plotOrientation75);
        org.jfree.chart.axis.AxisSpace axisSpace78 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace79 = categoryAxis0.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot32, rectangle2D49, rectangleEdge77, axisSpace78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(categoryDataset68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str76.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        categoryAxis13.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot4.setDomainAxisLocation((int) 'a', axisLocation14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot4.getDataRange(valueAxis16);
        categoryPlot4.setForegroundAlpha((float) 1);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.awt.Color color30 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator34 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color30, 0.0f, 0, (double) (byte) 10);
        int int35 = defaultShadowGenerator34.getShadowSize();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        chartEntity37.setURLText("hi!");
        boolean boolean40 = defaultShadowGenerator34.equals((java.lang.Object) chartEntity37);
        categoryPlot4.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator34);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot46.getRangeMarkers((int) '#', layer48);
        categoryPlot46.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot46.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean56 = categoryPlot46.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent57 = null;
        categoryPlot46.markerChanged(markerChangeEvent57);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot46.setRangeAxes(valueAxisArray59);
        categoryPlot4.setRangeAxes(valueAxisArray59);
        categoryPlot4.setRangeCrosshairVisible(true);
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color64);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        float float8 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean13 = categoryPlot4.removeDomainMarker((int) (short) 100, marker10, layer11, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot4.setRenderer(categoryItemRenderer14, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(1, 0, rectangle2D20, rectangleEdge21);
        float float23 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets24.extendWidth((-1.0d));
        categoryAxis17.setLabelInsets(rectangleInsets24, false);
        categoryPlot4.setInsets(rectangleInsets24);
        double double31 = rectangleInsets24.calculateRightOutset(3.0d);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 15.0d + "'", double26 == 15.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 15.0d);
        try {
            java.lang.Object obj5 = keyedObjects2D0.getObject(3, (-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        float float2 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint(100, (int) (short) 0, true);
        boolean boolean9 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        int int10 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = null;
        try {
            categoryAxis13.setLabelInsets(rectangleInsets23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEvent3);
        java.lang.String str6 = chartChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 0 + "'", obj4.equals((short) 0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=org.jfree.chart.event.ChartChangeEvent[source=0]]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=org.jfree.chart.event.ChartChangeEvent[source=0]]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot4.addRangeMarker((-10485856), marker20, layer21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '#', layer8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot6.setRangeAxis(0, valueAxis11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot6.setDomainAxis(10, categoryAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeZeroBaselineStroke();
        categoryPlot6.clearDomainAxes();
        keyedObjects0.addObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset21.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getRangeMarkers((int) '#', layer31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        categoryPlot29.setRangeAxis(0, valueAxis34, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot29.zoomDomainAxes((double) 10.0f, plotRenderingInfo38, point2D39, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = null;
        categoryPlot29.axisChanged(axisChangeEvent42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(1, 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot29.setDomainAxis(categoryAxis44);
        double double53 = categoryAxis44.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, categoryAxis44, valueAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55);
        java.awt.Shape shape58 = lineAndShapeRenderer55.getSeriesShape(0);
        java.awt.Paint paint62 = lineAndShapeRenderer55.getItemPaint(15, (int) '#', true);
        boolean boolean63 = lineAndShapeRenderer55.getAutoPopulateSeriesStroke();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55, false);
        lineAndShapeRenderer55.setUseFillPaint(false);
        lineAndShapeRenderer55.setUseFillPaint(false);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(shape58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        legendItem6.setSeriesKey((java.lang.Comparable) (-1.0d));
        java.awt.Shape shape13 = legendItem6.getLine();
        java.lang.String str14 = legendItem6.getURLText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnitType.ABSOLUTE" + "'", str14.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setDomainCrosshairPaint((java.awt.Paint) color15);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot4.getDomainMarkers(layer20);
        java.awt.Paint paint22 = categoryPlot4.getRangeMinorGridlinePaint();
        try {
            categoryPlot4.mapDatasetToRangeAxis((-10485856), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            boolean boolean23 = categoryPlot4.removeAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setOutlineStroke(stroke16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation18, true);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType1);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer2.getType();
        boolean boolean4 = textAnchor0.equals((java.lang.Object) standardGradientPaintTransformer2);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2);
        double double4 = itemLabelPosition3.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition3.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor5, textAnchor6, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 100, false);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font5, false);
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers((int) '#', layer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot15.setRangeAxis(0, valueAxis20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot15.setDomainAxis(10, categoryAxis24, true);
        java.awt.Stroke stroke27 = categoryPlot15.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis28.getCategoryEnd(1, 0, rectangle2D31, rectangleEdge32);
        categoryAxis28.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis28.setLabelPaint((java.awt.Paint) color36);
        categoryPlot15.setDomainAxis(categoryAxis28);
        boolean boolean39 = lineAndShapeRenderer10.hasListener((java.util.EventListener) categoryPlot15);
        java.awt.Shape shape43 = lineAndShapeRenderer10.getItemShape((-1), (int) (byte) 1, false);
        lineAndShapeRenderer0.setBaseShape(shape43);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape47 = lineAndShapeRenderer46.getBaseShape();
        lineAndShapeRenderer0.setSeriesShape(0, shape47);
        java.awt.Paint paint52 = lineAndShapeRenderer0.getItemPaint(1, (int) (short) -1, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setBaseShapesVisible(true);
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) lineAndShapeRenderer1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = lineAndShapeRenderer1.getItemLabelGenerator((-4144960), (-2103967), true);
        lineAndShapeRenderer1.setSeriesVisibleInLegend(255, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator2 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator3 = null;
        java.lang.String str4 = chartEntity1.getImageMapAreaTag(toolTipTagFragmentGenerator2, uRLTagFragmentGenerator3);
        java.lang.String str5 = chartEntity1.getToolTipText();
        java.lang.String str6 = chartEntity1.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        java.awt.Shape shape5 = lineAndShapeRenderer0.getLegendShape((int) (byte) 1);
        boolean boolean6 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setDomainCrosshairPaint((java.awt.Paint) color15);
        categoryPlot4.clearDomainMarkers((int) '4');
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape12, (java.awt.Paint) color13);
        legendItem14.setShapeVisible(true);
        java.awt.Paint paint17 = legendItem14.getOutlinePaint();
        boolean boolean18 = keyedObjects2D0.equals((java.lang.Object) legendItem14);
        try {
            java.lang.Comparable comparable20 = keyedObjects2D0.getRowKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendItem4.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.pink;
        legendItem4.setLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        java.awt.Stroke stroke8 = null;
        try {
            categoryAxis0.setTickMarkStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.util.List list12 = categoryPlot4.getCategories();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getRangeMarkers((int) '#', layer19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot17.setRangeAxis(0, valueAxis22, false);
        boolean boolean25 = categoryPlot17.getDrawSharedDomainAxis();
        int int26 = categoryPlot17.getRendererCount();
        categoryPlot17.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke30 = categoryPlot17.getRangeZeroBaselineStroke();
        categoryPlot4.setDomainGridlineStroke(stroke30);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.util.List list12 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation13.getOpposite();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers((int) '#', layer34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot32.setRangeAxis(0, valueAxis37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        categoryPlot32.setDomainAxis(10, categoryAxis41, true);
        java.awt.Stroke stroke44 = categoryPlot32.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot32.getDataset((int) (short) 1);
        int int47 = categoryPlot32.getWeight();
        boolean boolean48 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot32.setRangeAxisLocation((int) (short) 100, axisLocation50, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str54 = plotOrientation53.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation53);
        try {
            double double56 = categoryAxis13.getCategoryMiddle(100, (int) (byte) 100, rectangle2D27, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str54.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        java.awt.Paint paint2 = categoryAxis0.getLabelPaint();
        java.lang.Comparable comparable3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot12.getRangeMarkers((int) '#', layer14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot12.setRangeAxis(0, valueAxis17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot12.setDomainAxis(10, categoryAxis21, true);
        java.awt.Stroke stroke24 = categoryPlot12.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot12.getDataset((int) (short) 1);
        int int27 = categoryPlot12.getWeight();
        boolean boolean28 = categoryPlot12.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setRangeAxisLocation((int) (short) 100, axisLocation30, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str34 = plotOrientation33.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation33);
        try {
            double double36 = categoryAxis0.getCategorySeriesMiddle(comparable3, (java.lang.Comparable) 0.05d, categoryDataset5, 10.0d, rectangle2D7, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str34.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 100.0d);
        try {
            keyedObjects2D0.removeColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) (short) 100, axisLocation22, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot4.getRangeAxisForDataset((int) (byte) 1);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", (int) '#');
        int int3 = color2.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot4.notifyListeners(plotChangeEvent5);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        java.awt.Font font19 = categoryPlot4.getNoDataMessageFont();
        java.lang.Comparable comparable20 = null;
        categoryPlot4.setDomainCrosshairColumnKey(comparable20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace22);
        int int24 = categoryPlot4.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            categoryPlot4.drawBackground(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Comparable comparable2 = null;
        java.awt.Color color6 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color6);
        org.jfree.data.KeyedObject keyedObject8 = new org.jfree.data.KeyedObject(comparable2, (java.lang.Object) legendItem7);
        boolean boolean9 = standardGradientPaintTransformer1.equals((java.lang.Object) legendItem7);
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        legendItem7.setToolTipText("java.awt.Color[r=128,g=0,b=128]");
        org.jfree.data.general.Dataset dataset13 = legendItem7.getDataset();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNull(dataset13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Paint paint22 = categoryAxis13.getTickMarkPaint();
        categoryAxis13.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        java.awt.Font font42 = lineAndShapeRenderer34.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(font42);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        categoryPlot4.clearDomainMarkers((-10485856));
        boolean boolean18 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot4.panRangeAxes(100.0d, plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot4.isRangeZoomable();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '#', layer8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot6.setRangeAxis(0, valueAxis11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot6.setDomainAxis(10, categoryAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeZeroBaselineStroke();
        categoryPlot6.clearDomainAxes();
        keyedObjects0.addObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot6);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot6.removeDomainMarker(0, marker22, layer23);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double20 = rectangleInsets19.getBottom();
        categoryPlot4.setInsets(rectangleInsets19);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '#', layer15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        categoryPlot13.setRangeAxis(0, valueAxis18, false);
        boolean boolean21 = categoryPlot13.getDrawSharedDomainAxis();
        int int22 = categoryPlot13.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot13.getOrientation();
        categoryPlot13.setRangeCrosshairValue((double) 10.0f);
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        categoryPlot13.setNoDataMessagePaint(paint26);
        legendItem6.setOutlinePaint(paint26);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape33, (java.awt.Paint) color34);
        legendItem35.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem35.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset38);
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity(shape40);
        legendItem35.setShape(shape40);
        legendItem6.setShape(shape40);
        boolean boolean44 = legendItem6.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot4.axisChanged(axisChangeEvent17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.plot.Plot plot20 = plotChangeEvent19.getPlot();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(plot20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        double double8 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.util.List list12 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot4.getLegendItems();
        int int17 = legendItemCollection16.getItemCount();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4, "UnitType.ABSOLUTE", "hi!");
        java.lang.String str10 = chartEntity9.getShapeType();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "rect" + "'", str10.equals("rect"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers((int) '#', layer11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot9.setRangeAxis(0, valueAxis14, false);
        java.awt.Stroke stroke17 = categoryPlot9.getOutlineStroke();
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke17);
        java.awt.Shape shape20 = lineAndShapeRenderer0.getLegendShape(10);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(shape20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '#', layer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot13.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo19, point2D20);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        categoryPlot13.setWeight((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint4 = lineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot4.getDomainMarkers(layer13);
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot20.getRangeMarkers((int) '#', layer22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot20.setRangeAxis(0, valueAxis25, false);
        boolean boolean28 = categoryPlot20.getDrawSharedDomainAxis();
        java.awt.Paint paint29 = categoryPlot20.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot20.zoomRangeAxes((double) (short) 10, plotRenderingInfo31, point2D32, false);
        categoryPlot20.setAnchorValue((double) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot20.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder37);
        java.awt.Paint paint39 = categoryPlot4.getOutlinePaint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("UnitType.ABSOLUTE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        defaultCategoryDataset0.addValue((java.lang.Number) 10, (java.lang.Comparable) true, (java.lang.Comparable) (-4144962.0d));
        int int7 = defaultCategoryDataset0.getColumnCount();
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets6);
        double double9 = rectangleInsets6.calculateRightOutset((-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Paint paint8 = categoryPlot4.getDomainGridlinePaint();
        categoryPlot4.setDomainCrosshairVisible(false);
        categoryPlot4.configureRangeAxes();
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot4.panDomainAxes((-4144962.0d), plotRenderingInfo14, point2D15);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(datasetGroup12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getRangeMarkers((int) '#', layer31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        categoryPlot29.setRangeAxis(0, valueAxis34, false);
        boolean boolean37 = categoryPlot29.getDrawSharedDomainAxis();
        java.awt.Paint paint38 = categoryPlot29.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot29.zoomRangeAxes((double) (short) 10, plotRenderingInfo40, point2D41, false);
        categoryPlot29.setAnchorValue((double) (byte) 0);
        categoryAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot29);
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = null;
        org.jfree.chart.util.Layer layer49 = null;
        try {
            categoryPlot29.addDomainMarker(255, categoryMarker48, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity5.setArea(shape6);
        java.awt.Paint paint8 = null;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "", "ChartChangeEventType.DATASET_UPDATED", "ChartChangeEventType.DATASET_UPDATED", shape6, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-4144960));
        double double4 = rectangleInsets0.calculateTopOutset((double) 0);
        double double5 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean2 = datasetGroup0.equals((java.lang.Object) itemLabelAnchor1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean4 = datasetGroup0.equals((java.lang.Object) color3);
        java.lang.Object obj5 = datasetGroup0.clone();
        java.lang.String str6 = datasetGroup0.getID();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NOID" + "'", str6.equals("NOID"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 3, 0.2d, 0.0d, (double) (-4144960));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '#', layer15);
        categoryPlot13.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean23 = categoryPlot13.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot13.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot13.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo27, point2D28);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot13.setRangeCrosshairStroke(stroke30);
        boolean boolean32 = categoryAxis0.equals((java.lang.Object) categoryPlot13);
        java.awt.Paint paint33 = categoryPlot13.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        java.util.EventListener eventListener42 = null;
        boolean boolean43 = lineAndShapeRenderer34.hasListener(eventListener42);
        try {
            lineAndShapeRenderer34.setItemMargin((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = categoryPlot4.canSelectByPoint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) (-10485856), (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-10485856) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        legendItem6.setSeriesKey((java.lang.Comparable) (-1.0d));
        java.awt.Shape shape13 = legendItem6.getLine();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers((int) '#', layer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot18.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo24, point2D25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(1, 0, rectangle2D30, rectangleEdge31);
        java.util.List list33 = categoryPlot18.getCategoriesForAxis(categoryAxis27);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape38, (java.awt.Paint) color39);
        legendItem40.setShapeVisible(true);
        java.awt.Font font43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem40.setLabelFont(font43);
        categoryAxis27.setLabelFont(font43);
        legendItem6.setLabelFont(font43);
        java.awt.Paint paint47 = legendItem6.getLinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("UnitType.RELATIVE");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        legendItem1.setLabelPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.util.StrokeList strokeList16 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj17 = strokeList16.clone();
        boolean boolean18 = datasetRenderingOrder15.equals(obj17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.trimHeight((-1.0d));
        boolean boolean22 = datasetRenderingOrder15.equals((java.lang.Object) rectangleInsets19);
        java.lang.String str23 = rectangleInsets19.toString();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str23.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        legendItem6.setShape(shape11);
        java.lang.String str14 = legendItem6.getURLText();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape19, (java.awt.Paint) color20);
        legendItem21.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem21.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset24);
        legendItem21.setSeriesKey((java.lang.Comparable) (-1.0d));
        java.awt.Color color28 = java.awt.Color.magenta;
        legendItem21.setOutlinePaint((java.awt.Paint) color28);
        legendItem6.setFillPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnitType.ABSOLUTE" + "'", str14.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        categoryPlot4.setWeight((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot4.getDomainAxisLocation((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            boolean boolean26 = categoryPlot4.removeAnnotation(categoryAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.Marker marker15 = null;
        try {
            categoryPlot4.addRangeMarker(marker15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot4.getDomainMarkers(layer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot4.setOutlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        boolean boolean13 = categoryPlot5.getDrawSharedDomainAxis();
        int int14 = categoryPlot5.getRendererCount();
        categoryPlot5.setForegroundAlpha(0.0f);
        boolean boolean17 = keyedObjects0.equals((java.lang.Object) 0.0f);
        java.lang.Object obj20 = null;
        try {
            keyedObjects0.insertValue(10, (java.lang.Comparable) "UnitType.ABSOLUTE", obj20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot4.addDomainMarker((int) (byte) 1, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color8 = java.awt.Color.black;
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = null;
        try {
            categoryAxis0.setAxisLineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition7);
        java.lang.Object obj9 = lineAndShapeRenderer0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getRangeMarkers((int) '#', layer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot17.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis26.getCategoryEnd(1, 0, rectangle2D29, rectangleEdge30);
        java.util.List list32 = categoryPlot17.getCategoriesForAxis(categoryAxis26);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot38.getRangeMarkers((int) '#', layer40);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        categoryPlot38.setRangeAxis(0, valueAxis43, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot38.setDomainAxis(10, categoryAxis47, true);
        java.awt.Stroke stroke50 = categoryPlot38.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset52 = categoryPlot38.getDataset((int) (short) 1);
        int int53 = categoryPlot38.getWeight();
        boolean boolean54 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot38.setRangeAxisLocation((int) (short) 100, axisLocation56, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation59 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str60 = plotOrientation59.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation56, plotOrientation59);
        try {
            double double62 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) "rect", (java.lang.Comparable) ' ', (org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis26, rectangle2D33, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(categoryDataset52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(plotOrientation59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str60.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) itemLabelAnchor2);
        java.lang.Object obj4 = null;
        boolean boolean5 = datasetGroup1.equals(obj4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10);
        org.jfree.chart.JFreeChart jFreeChart8 = chartChangeEvent7.getChart();
        boolean boolean9 = datasetGroup1.equals((java.lang.Object) chartChangeEvent7);
        boolean boolean10 = sortOrder0.equals((java.lang.Object) datasetGroup1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jFreeChart8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Color color22 = java.awt.Color.black;
        categoryAxis13.setTickMarkPaint((java.awt.Paint) color22);
        java.lang.String str25 = categoryAxis13.getCategoryLabelToolTip((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemFillPaint(2, 0, false);
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        int int8 = defaultShadowGenerator7.getShadowSize();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        chartEntity10.setURLText("hi!");
        boolean boolean13 = defaultShadowGenerator7.equals((java.lang.Object) chartEntity10);
        float float14 = defaultShadowGenerator7.getShadowOpacity();
        int int15 = defaultShadowGenerator7.calculateOffsetY();
        int int16 = defaultShadowGenerator7.getShadowSize();
        java.awt.image.BufferedImage bufferedImage17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = defaultShadowGenerator7.createDropShadow(bufferedImage17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot4.getDomainMarkers(layer13);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getRangeMarkers((int) '#', layer21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        categoryPlot19.setRangeAxis(0, valueAxis24, false);
        java.awt.Stroke stroke27 = categoryPlot19.getOutlineStroke();
        categoryPlot4.setRangeGridlineStroke(stroke27);
        int int29 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot4.getOrientation();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(plotOrientation30);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        defaultCategoryDataset0.addValue((java.lang.Number) 10, (java.lang.Comparable) true, (java.lang.Comparable) (-4144962.0d));
        try {
            java.lang.Number number9 = defaultCategoryDataset0.getValue((int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot4.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.setOutlineVisible(true);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        categoryAxis23.setLabelAngle(0.0d);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot43.getRangeMarkers((int) '#', layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot43.setRangeAxis(0, valueAxis48, false);
        java.awt.Stroke stroke51 = categoryPlot43.getOutlineStroke();
        categoryPlot43.setNoDataMessage("hi!");
        java.awt.Image image54 = categoryPlot43.getBackgroundImage();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56, categoryAxis57, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.util.Layer layer62 = null;
        java.util.Collection collection63 = categoryPlot60.getRangeMarkers((int) '#', layer62);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        categoryPlot60.setRangeAxis(0, valueAxis65, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        categoryPlot60.setDomainAxis(10, categoryAxis69, true);
        java.awt.Stroke stroke72 = categoryPlot60.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset74 = categoryPlot60.getDataset((int) (short) 1);
        int int75 = categoryPlot60.getWeight();
        boolean boolean76 = categoryPlot60.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation78 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot60.setRangeAxisLocation((int) (short) 100, axisLocation78, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation81 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str82 = plotOrientation81.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation78, plotOrientation81);
        org.jfree.chart.axis.AxisSpace axisSpace84 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace85 = categoryAxis23.reserveSpace(graphics2D38, (org.jfree.chart.plot.Plot) categoryPlot43, rectangle2D55, rectangleEdge83, axisSpace84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(image54);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNull(categoryDataset74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertNotNull(plotOrientation81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str82.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge83);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        lineAndShapeRenderer34.setUseSeriesOffset(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot4.getInsets();
        double double15 = rectangleInsets13.trimWidth(0.0d);
        double double17 = rectangleInsets13.calculateTopInset((double) 0.0f);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-16.0d) + "'", double15 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        java.util.List list13 = categoryPlot4.getAnnotations();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape18, (java.awt.Paint) color19);
        legendItem20.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem20.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.awt.Color color30 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator34 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color30, 0.0f, 0, (double) (byte) 10);
        int int35 = defaultShadowGenerator34.getShadowSize();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        chartEntity37.setURLText("hi!");
        boolean boolean40 = defaultShadowGenerator34.equals((java.lang.Object) chartEntity37);
        categoryPlot4.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator34);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        categoryPlot4.setRangeAxis((int) (short) 0, valueAxis43);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot4.getRangeMarkers(0, layer46);
        categoryPlot4.setForegroundAlpha((float) (-2103967));
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot5.setDomainAxis(10, categoryAxis14, true);
        categoryPlot5.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.Plot plot20 = plotEntity19.getPlot();
        java.lang.String str21 = plotEntity19.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PlotEntity: tooltip = null" + "'", str21.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '#', layer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot13.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo19, point2D20);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            categoryPlot13.addAnnotation(categoryAnnotation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot4.getRowRenderingOrder();
        boolean boolean17 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        legendItem6.setSeriesKey((java.lang.Comparable) (-1.0d));
        java.awt.Shape shape13 = legendItem6.getLine();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers((int) '#', layer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot18.setRangeAxis(0, valueAxis23, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot18.setDomainAxis(10, categoryAxis27, true);
        java.awt.Stroke stroke30 = categoryPlot18.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot18.getDataset((int) (short) 1);
        int int33 = categoryPlot18.getWeight();
        boolean boolean34 = categoryPlot18.isRangeCrosshairVisible();
        categoryPlot18.setBackgroundAlpha((float) '#');
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        categoryPlot18.removeChangeListener(plotChangeListener37);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot18);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Font font2 = lineAndShapeRenderer0.lookupLegendTextFont(8);
        try {
            lineAndShapeRenderer0.setItemMargin((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        legendItem6.setDescription("UnitType.ABSOLUTE");
        java.lang.String str13 = legendItem6.getDescription();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendItem6.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setURLText("hi!");
        java.lang.String str4 = chartEntity1.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot4.setDomainAxisLocation((int) 'a', axisLocation14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.lang.Object obj5 = categoryPlot4.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot4.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem8 = legendItemCollection6.get(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (-1.0d));
        try {
            keyedObjects2D0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.incrementValue(3.0d, (java.lang.Comparable) 9.0d, (java.lang.Comparable) (-16.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (9.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot4.markerChanged(markerChangeEvent15);
        double double17 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot4.removeDomainMarker((-65536), marker19, layer20);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color4 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color4);
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject(comparable0, (java.lang.Object) legendItem5);
        org.jfree.data.general.Dataset dataset7 = legendItem5.getDataset();
        int int8 = legendItem5.getDatasetIndex();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.String str9 = legendItem6.getToolTipText();
        java.lang.String str10 = legendItem6.getLabel();
        legendItem6.setURLText("");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.ABSOLUTE" + "'", str9.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean2 = datasetGroup0.equals((java.lang.Object) itemLabelAnchor1);
        java.lang.String str3 = datasetGroup0.getID();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOID" + "'", str3.equals("NOID"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("NOID", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        java.lang.Comparable comparable7 = legendItem6.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(comparable7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        defaultCategoryDataset0.clearSelection();
        try {
            defaultCategoryDataset0.removeValue((java.lang.Comparable) 100, (java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        boolean boolean8 = categoryPlot4.isRangePannable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot4.setRenderer((int) '4', categoryItemRenderer10, true);
        boolean boolean13 = categoryPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemLabelPaint(100, (-4144960), true);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getLegendTextPaint((-10485856));
        double double10 = lineAndShapeRenderer0.getItemMargin();
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        lineAndShapeRenderer34.setDrawOutlines(false);
        java.awt.Paint paint39 = lineAndShapeRenderer34.lookupSeriesOutlinePaint((int) (short) 0);
        boolean boolean40 = lineAndShapeRenderer34.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color4 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color4);
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject(comparable0, (java.lang.Object) legendItem5);
        java.lang.Object obj7 = keyedObject6.getObject();
        java.lang.Object obj8 = keyedObject6.getObject();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.String str9 = legendItem6.getURLText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.ABSOLUTE" + "'", str9.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint(100, (int) (short) 0, true);
        boolean boolean9 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers((int) '#', layer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot15.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis24.getCategoryEnd(1, 0, rectangle2D27, rectangleEdge28);
        java.util.List list30 = categoryPlot15.getCategoriesForAxis(categoryAxis24);
        categoryAxis24.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Color color33 = java.awt.Color.black;
        categoryAxis24.setTickMarkPaint((java.awt.Paint) color33);
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color33);
        java.awt.Paint paint39 = lineAndShapeRenderer0.getItemFillPaint(0, 8, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator40, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = null;
        try {
            lineAndShapeRenderer0.setSeriesURLGenerator((-2103967), categoryURLGenerator44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition7);
        java.lang.Object obj9 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape17, (java.awt.Paint) color18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape17, "UnitType.ABSOLUTE", "hi!");
        lineAndShapeRenderer0.setSeriesShape(15, shape17, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator25, false);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        java.awt.Font font8 = categoryAxis0.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot20.getRangeMarkers((int) '#', layer22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot20.setRangeAxis(0, valueAxis25, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot20.setDomainAxis(10, categoryAxis29, true);
        java.awt.Stroke stroke32 = categoryPlot20.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot20.getDataset((int) (short) 1);
        int int35 = categoryPlot20.getWeight();
        boolean boolean36 = categoryPlot20.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot20.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str42 = plotOrientation41.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation38, plotOrientation41);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = categoryAxis0.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) categoryPlot14, rectangle2D15, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str42.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        java.lang.Comparable comparable2 = null;
        try {
            java.awt.Font font3 = categoryAxis0.getTickLabelFont(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot4.getDomainAxisLocation((int) (byte) -1);
        categoryPlot4.setRangePannable(true);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        legendItem6.setDescription("UnitType.ABSOLUTE");
        legendItem6.setShapeVisible(false);
        legendItem6.setDatasetIndex(100);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int3 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape4 = lineAndShapeRenderer3.getBaseShape();
        lineAndShapeRenderer3.clearSeriesPaints(true);
        java.awt.Paint paint10 = lineAndShapeRenderer3.getItemLabelPaint(100, (-4144960), true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot16.getRangeMarkers((int) '#', layer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot16.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis25.getCategoryEnd(1, 0, rectangle2D28, rectangleEdge29);
        java.util.List list31 = categoryPlot16.getCategoriesForAxis(categoryAxis25);
        categoryAxis25.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Font font34 = categoryAxis25.getTickLabelFont();
        lineAndShapeRenderer3.setLegendTextFont((int) (byte) 0, font34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.awt.Stroke stroke12 = categoryPlot4.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray13);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        categoryPlot4.setNoDataMessagePaint(paint17);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape24, (java.awt.Paint) color25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset29);
        java.util.List list31 = defaultCategoryDataset29.getRowKeys();
        try {
            categoryPlot4.mapDatasetToRangeAxes((int) (short) -1, list31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot4.setRangeZeroBaselineStroke(stroke8);
        boolean boolean10 = categoryPlot4.isDomainZoomable();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateBottomInset((double) (-4144960));
        double double12 = rectangleInsets8.calculateTopOutset((double) 0);
        boolean boolean13 = defaultShadowGenerator7.equals((java.lang.Object) double12);
        int int14 = defaultShadowGenerator7.calculateOffsetX();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        int int2 = strokeList0.size();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot7.setRangeAxis(0, valueAxis12, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        categoryPlot7.axisChanged(axisChangeEvent20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(1, 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot7.setDomainAxis(categoryAxis22);
        double double31 = categoryAxis22.getFixedDimension();
        java.awt.Paint paint32 = categoryAxis22.getAxisLinePaint();
        boolean boolean33 = strokeList0.equals((java.lang.Object) categoryAxis22);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape8, (java.awt.Paint) color9);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape8, "UnitType.ABSOLUTE", "hi!");
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot23.getRangeMarkers((int) '#', layer25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        categoryPlot23.setRangeAxis(0, valueAxis28, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot23.setDomainAxis(10, categoryAxis32, true);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot23.setOutlineStroke(stroke35);
        java.awt.Color color37 = java.awt.Color.white;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=0,b=128]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=10]", "PlotOrientation.HORIZONTAL", shape18, stroke35, (java.awt.Paint) color37);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType39 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer40 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean42 = gradientPaintTransformType39.equals((java.lang.Object) color41);
        try {
            org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem(attributedString0, "PlotEntity: tooltip = null", "org.jfree.chart.event.ChartChangeEvent[source=org.jfree.chart.event.ChartChangeEvent[source=0]]", "", shape8, stroke35, (java.awt.Paint) color41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(gradientPaintTransformType39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot4.setRangeAxis(valueAxis22);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup12 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean14 = datasetGroup12.equals((java.lang.Object) itemLabelAnchor13);
        java.lang.Object obj15 = null;
        boolean boolean16 = datasetGroup12.equals(obj15);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean18 = datasetGroup12.equals((java.lang.Object) itemLabelAnchor17);
        defaultCategoryDataset9.setGroup(datasetGroup12);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot4.getRangeAxisLocation((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot4.setRangeAxisLocation(255, axisLocation18);
        categoryPlot4.setRangePannable(false);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) (-4144960));
        double double4 = rectangleInsets0.calculateRightInset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4144962.0d) + "'", double2 == (-4144962.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean15 = categoryPlot4.removeAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setLabelURL("java.awt.Color[r=128,g=0,b=128]");
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) (short) 1);
        double double4 = rectangleInsets0.calculateLeftInset((-4144962.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        java.lang.String str3 = gradientPaintTransformType2.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str3.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot4.getRangeMarkers((int) (short) 10, layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot4.getDomainAxisLocation(100);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-8.0d) + "'", double5 == (-8.0d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '#', layer8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot6.setRangeAxis(0, valueAxis11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot6.setDomainAxis(10, categoryAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeZeroBaselineStroke();
        categoryPlot6.clearDomainAxes();
        keyedObjects0.addObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset21.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getRangeMarkers((int) '#', layer31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        categoryPlot29.setRangeAxis(0, valueAxis34, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot29.zoomDomainAxes((double) 10.0f, plotRenderingInfo38, point2D39, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = null;
        categoryPlot29.axisChanged(axisChangeEvent42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(1, 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot29.setDomainAxis(categoryAxis44);
        double double53 = categoryAxis44.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, categoryAxis44, valueAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55);
        java.awt.Shape shape58 = lineAndShapeRenderer55.getSeriesShape(0);
        java.awt.Paint paint62 = lineAndShapeRenderer55.getItemPaint(15, (int) '#', true);
        boolean boolean63 = lineAndShapeRenderer55.getAutoPopulateSeriesStroke();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55, false);
        java.awt.Color color67 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer55.setSeriesOutlinePaint(15, (java.awt.Paint) color67);
        java.awt.Paint paint70 = lineAndShapeRenderer55.getSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(shape58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(paint70);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double9 = rectangleInsets7.extendWidth((-1.0d));
        categoryAxis0.setLabelInsets(rectangleInsets7, false);
        double double12 = rectangleInsets7.getTop();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 15.0d + "'", double9 == 15.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        double double25 = rectangleInsets24.getBottom();
        org.jfree.data.KeyedObjects keyedObjects26 = new org.jfree.data.KeyedObjects();
        keyedObjects26.clear();
        java.awt.Stroke[] strokeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        keyedObjects26.insertValue(0, (java.lang.Comparable) (short) 10, (java.lang.Object) strokeArray30);
        int int33 = keyedObjects26.getIndex((java.lang.Comparable) 1.0f);
        boolean boolean34 = rectangleInsets24.equals((java.lang.Object) keyedObjects26);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset35 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot39.getRangeMarkers((int) '#', layer41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        categoryPlot39.setRangeAxis(0, valueAxis44, false);
        boolean boolean47 = categoryPlot39.getDrawSharedDomainAxis();
        int int48 = categoryPlot39.getRendererCount();
        categoryPlot39.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder51 = categoryPlot39.getRowRenderingOrder();
        keyedObjects26.sortByObjects(sortOrder51);
        try {
            java.lang.Object obj54 = keyedObjects26.getObject((java.lang.Comparable) "UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (UnitType.ABSOLUTE) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(sortOrder51);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=0,g=255,b=255]"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        lineAndShapeRenderer34.setDrawOutlines(false);
        java.awt.Paint paint39 = lineAndShapeRenderer34.lookupSeriesOutlinePaint((int) (short) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer34.setSeriesURLGenerator((int) (short) 100, categoryURLGenerator41, true);
        java.awt.Stroke stroke44 = null;
        try {
            lineAndShapeRenderer34.setBaseOutlineStroke(stroke44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.configure();
        categoryAxis13.setCategoryLabelPositionOffset((int) ' ');
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        categoryPlot7.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis((int) 'a');
        java.util.List list16 = categoryPlot7.getAnnotations();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape21, (java.awt.Paint) color22);
        legendItem23.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset26);
        java.util.List list28 = defaultCategoryDataset26.getRowKeys();
        categoryPlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.Range range30 = lineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = null;
        try {
            lineAndShapeRenderer0.setSeriesToolTipGenerator((-4144960), categoryToolTipGenerator33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        java.util.List list12 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomRangeAxes((-6.0d), plotRenderingInfo17, point2D18, false);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        java.awt.Font font19 = categoryPlot4.getNoDataMessageFont();
        categoryPlot4.setBackgroundImageAlignment((int) (short) 100);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot27.getRangeMarkers((int) '#', layer29);
        categoryPlot27.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot27.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean37 = categoryPlot27.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot27.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo41, point2D42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace44, false);
        categoryPlot27.setOutlineVisible(false);
        java.util.List list49 = categoryPlot27.getCategories();
        try {
            categoryPlot4.mapDatasetToRangeAxes(100, list49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(list49);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 100, plotRenderingInfo17, point2D18, false);
        java.awt.Stroke stroke21 = categoryPlot4.getOutlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot4.getRangeAxisForDataset((int) (byte) 0);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        boolean boolean42 = lineAndShapeRenderer34.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor43 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor43, textAnchor44);
        double double46 = itemLabelPosition45.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor47 = itemLabelPosition45.getRotationAnchor();
        lineAndShapeRenderer34.setBasePositiveItemLabelPosition(itemLabelPosition45, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation50 = null;
        org.jfree.chart.util.Layer layer51 = null;
        try {
            lineAndShapeRenderer34.addAnnotation(categoryAnnotation50, layer51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemLabelPaint(100, (-4144960), true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer0.getSeriesCreateEntities(2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getRangeMarkers((int) '#', layer16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot14.setRangeAxis(0, valueAxis19, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot14.setDomainAxis(10, categoryAxis23, true);
        java.awt.Stroke stroke26 = categoryPlot14.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setBaseStroke(stroke26, false);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = lineAndShapeRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(legendItemCollection29);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot12.getRangeMarkers((int) '#', layer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot12.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo18, point2D19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot12.getDomainMarkers(layer21);
        double double23 = categoryPlot12.getAnchorValue();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot28.getRangeMarkers((int) '#', layer30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        categoryPlot28.setRangeAxis(0, valueAxis33, false);
        boolean boolean36 = categoryPlot28.getDrawSharedDomainAxis();
        java.awt.Paint paint37 = categoryPlot28.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot28.zoomRangeAxes((double) (short) 10, plotRenderingInfo39, point2D40, false);
        categoryPlot28.setAnchorValue((double) (byte) 0);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot28.getRowRenderingOrder();
        categoryPlot12.setColumnRenderingOrder(sortOrder45);
        org.jfree.data.KeyedObject keyedObject47 = new org.jfree.data.KeyedObject((java.lang.Comparable) "TextAnchor.CENTER_RIGHT", (java.lang.Object) categoryPlot12);
        keyedObjects2D0.setObject((java.lang.Object) categoryPlot12, (java.lang.Comparable) (-2103967), (java.lang.Comparable) 8);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(sortOrder45);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        categoryPlot7.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis((int) 'a');
        java.util.List list16 = categoryPlot7.getAnnotations();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape21, (java.awt.Paint) color22);
        legendItem23.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset26);
        java.util.List list28 = defaultCategoryDataset26.getRowKeys();
        categoryPlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.Range range30 = lineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        java.awt.Paint paint32 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke34 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(100);
        boolean boolean38 = lineAndShapeRenderer0.getItemCreateEntity((int) '#', (int) (byte) 0, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer0.getNegativeItemLabelPosition(8, (int) (byte) 100, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = categoryPlot48.getRangeMarkers((int) '#', layer50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        categoryPlot48.setRangeAxis(0, valueAxis53, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        categoryPlot48.setDomainAxis(10, categoryAxis57, true);
        java.awt.Stroke stroke60 = categoryPlot48.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        double double66 = categoryAxis61.getCategoryEnd(1, 0, rectangle2D64, rectangleEdge65);
        categoryAxis61.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis61.setLabelPaint((java.awt.Paint) color69);
        categoryPlot48.setDomainAxis(categoryAxis61);
        boolean boolean72 = lineAndShapeRenderer43.hasListener((java.util.EventListener) categoryPlot48);
        java.awt.Shape shape76 = lineAndShapeRenderer43.getItemShape((-1), (int) (byte) 1, false);
        boolean boolean77 = itemLabelPosition42.equals((java.lang.Object) lineAndShapeRenderer43);
        double double78 = itemLabelPosition42.getAngle();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color1 = java.awt.Color.getColor("NOID");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.clearDomainAxes();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot23.getRangeMarkers((int) '#', layer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot23.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis32.getCategoryEnd(1, 0, rectangle2D35, rectangleEdge36);
        java.util.List list38 = categoryPlot23.getCategoriesForAxis(categoryAxis32);
        categoryAxis32.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Font font41 = categoryAxis32.getTickLabelFont();
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis32);
        java.awt.Stroke stroke43 = null;
        try {
            categoryAxis32.setAxisLineStroke(stroke43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Paint paint13 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 10, plotRenderingInfo15, point2D16, false);
        categoryPlot4.setAnchorValue((double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType21 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer22.setBaseShapesVisible(true);
        boolean boolean25 = gradientPaintTransformType21.equals((java.lang.Object) lineAndShapeRenderer22);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        lineAndShapeRenderer22.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator28);
        try {
            lineAndShapeRenderer22.setSeriesShapesVisible((-65536), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(gradientPaintTransformType21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot4.getDomainMarkers(layer13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = categoryPlot4.removeRangeMarker(4, marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNull(datasetGroup15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        try {
            java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getLegendItems();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.awt.Shape[] shapeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean3 = unitType0.equals((java.lang.Object) shapeArray2);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType0, (-8.0d), (-4144962.0d), 3.0d, (double) (short) -1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(shapeArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot4.setDomainAxisLocation((int) 'a', axisLocation14);
        categoryPlot4.setForegroundAlpha((float) (byte) -1);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) 'a');
        keyedObjects2D0.setObject((java.lang.Object) textAnchor1, (java.lang.Comparable) "", (java.lang.Comparable) 100.0d);
        try {
            java.lang.Object obj9 = keyedObjects2D0.getObject((java.lang.Comparable) 1, (java.lang.Comparable) 15.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickMarkOutsideLength((float) (byte) -1);
        java.awt.Font font22 = categoryAxis13.getTickLabelFont();
        categoryAxis13.setLowerMargin(0.05d);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke5 = renderAttributes2.getItemStroke((-14336), (int) (short) -1);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape10, (java.awt.Paint) color11);
        legendItem12.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem12.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset15);
        legendItem12.setSeriesKey((java.lang.Comparable) (-1.0d));
        java.awt.Shape shape19 = legendItem12.getLine();
        renderAttributes2.setDefaultShape(shape19);
        try {
            renderAttributes0.setSeriesShape((-65536), shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", "", "", "CategoryAnchor.MIDDLE", shape4, (java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendItem6.setOutlinePaint((java.awt.Paint) color7);
        java.lang.Object obj9 = legendItem6.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '#', layer9);
        categoryPlot7.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis((int) 'a');
        java.util.List list16 = categoryPlot7.getAnnotations();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape21, (java.awt.Paint) color22);
        legendItem23.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem23.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset26);
        java.util.List list28 = defaultCategoryDataset26.getRowKeys();
        categoryPlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.Range range30 = lineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        java.awt.Stroke stroke33 = lineAndShapeRenderer0.lookupSeriesStroke((int) '#');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", "", "", "CategoryAnchor.MIDDLE", shape4, (java.awt.Paint) color5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem6.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        lineAndShapeRenderer0.clearSeriesPaints(true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemLabelPaint(100, (-4144960), true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer0.getSeriesCreateEntities(2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getRangeMarkers((int) '#', layer16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot14.setRangeAxis(0, valueAxis19, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot14.setDomainAxis(10, categoryAxis23, true);
        java.awt.Stroke stroke26 = categoryPlot14.getRangeZeroBaselineStroke();
        lineAndShapeRenderer0.setBaseStroke(stroke26, false);
        try {
            lineAndShapeRenderer0.setSeriesItemLabelsVisible((-20561), (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        java.awt.Font font19 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextOutlineStroke();
        java.awt.Stroke stroke22 = defaultDrawingSupplier20.getNextStroke();
        java.awt.Stroke stroke23 = defaultDrawingSupplier20.getNextOutlineStroke();
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace25);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets24.createInsetRectangle(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers((int) '#', layer13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot11.setRangeAxis(0, valueAxis16, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot11.setDomainAxis(10, categoryAxis20, true);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot11.setOutlineStroke(stroke23);
        java.awt.Color color25 = java.awt.Color.white;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=0,b=128]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=10]", "PlotOrientation.HORIZONTAL", shape6, stroke23, (java.awt.Paint) color25);
        boolean boolean27 = paintList0.equals((java.lang.Object) shape6);
        java.awt.Paint paint29 = paintList0.getPaint((int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint29, jFreeChart30, chartChangeEventType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 1, color3, 0.0f, 0, (double) (byte) 10);
        int int8 = defaultShadowGenerator7.getShadowSize();
        float float9 = defaultShadowGenerator7.getShadowOpacity();
        java.awt.Color color10 = defaultShadowGenerator7.getShadowColor();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str1.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(1, 0, rectangle2D16, rectangleEdge17);
        java.util.List list19 = categoryPlot4.getCategoriesForAxis(categoryAxis13);
        categoryAxis13.setTickLabelsVisible(false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        java.awt.Paint paint26 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) (byte) 10);
        categoryAxis13.setMinorTickMarkOutsideLength((float) (-1));
        categoryAxis13.setVisible(false);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        categoryPlot5.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean15 = categoryPlot5.canSelectByRegion();
        boolean boolean16 = categoryPlot5.isDomainGridlinesVisible();
        boolean boolean17 = categoryPlot5.getDrawSharedDomainAxis();
        abstractCategoryDataset0.removeChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot5);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = categoryPlot5.removeRangeMarker(1, marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color3 = java.awt.Color.getColor("hi!", (int) (short) 10);
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        org.jfree.data.general.Dataset dataset5 = legendItem4.getDataset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(dataset5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        boolean boolean3 = keyedObjects0.equals((java.lang.Object) objectList2);
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape8, (java.awt.Paint) color9);
        legendItem10.setShapeVisible(true);
        java.awt.Paint paint13 = legendItem10.getOutlinePaint();
        int int14 = objectList2.indexOf((java.lang.Object) paint13);
        java.lang.Object obj16 = objectList2.get((-4144960));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot5.setDomainAxis(10, categoryAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis18.getCategoryEnd(1, 0, rectangle2D21, rectangleEdge22);
        categoryAxis18.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis18.setLabelPaint((java.awt.Paint) color26);
        categoryPlot5.setDomainAxis(categoryAxis18);
        boolean boolean29 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot5);
        boolean boolean30 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint32 = lineAndShapeRenderer0.lookupSeriesOutlinePaint((int) (byte) 10);
        boolean boolean33 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryPlot4.markerChanged(markerChangeEvent15);
        double double17 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot4.removeDomainMarker((-20561), marker19, layer20);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Paint paint16 = categoryPlot4.getRangeGridlinePaint();
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (-10485856));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRenderer((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot4.removeAnnotation(categoryAnnotation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem6.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        legendItem6.setShape(shape11);
        legendItem6.setURLText("org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis((int) 'a');
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean17 = categoryPlot4.removeRangeMarker((int) ' ', marker14, layer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot42.getRangeMarkers((int) '#', layer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot42.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo48, point2D49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = categoryAxis51.getCategoryEnd(1, 0, rectangle2D54, rectangleEdge55);
        java.util.List list57 = categoryPlot42.getCategoriesForAxis(categoryAxis51);
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape62, (java.awt.Paint) color63);
        legendItem64.setShapeVisible(true);
        java.awt.Font font67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem64.setLabelFont(font67);
        categoryAxis51.setLabelFont(font67);
        lineAndShapeRenderer34.setBaseLegendTextFont(font67);
        java.awt.Paint paint74 = lineAndShapeRenderer34.getItemLabelPaint((int) (short) 100, (int) (short) 100, false);
        boolean boolean75 = lineAndShapeRenderer34.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape1 = lineAndShapeRenderer0.getBaseShape();
        boolean boolean2 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        int int5 = lineAndShapeRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        boolean boolean42 = lineAndShapeRenderer34.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor43 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor43, textAnchor44);
        double double46 = itemLabelPosition45.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor47 = itemLabelPosition45.getRotationAnchor();
        lineAndShapeRenderer34.setBasePositiveItemLabelPosition(itemLabelPosition45, true);
        lineAndShapeRenderer34.setAutoPopulateSeriesShape(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator53 = null;
        lineAndShapeRenderer34.setSeriesURLGenerator(15, categoryURLGenerator53, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 100, false);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font5, false);
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer0.isSeriesVisibleInLegend(2);
        java.awt.Shape shape13 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape13, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot5.setDomainAxis(10, categoryAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis18.getCategoryEnd(1, 0, rectangle2D21, rectangleEdge22);
        categoryAxis18.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis18.setLabelPaint((java.awt.Paint) color26);
        categoryPlot5.setDomainAxis(categoryAxis18);
        boolean boolean29 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Shape shape33 = lineAndShapeRenderer0.getItemShape((-1), (int) (byte) 1, false);
        lineAndShapeRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.JFreeChart jFreeChart37 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10);
        java.lang.String str40 = chartChangeEvent39.toString();
        java.lang.String str41 = chartChangeEvent39.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType42 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent39.setType(chartChangeEventType42);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart37, chartChangeEventType42);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str40.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str41.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
        org.junit.Assert.assertNotNull(chartChangeEventType42);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Paint paint8 = categoryPlot4.getDomainGridlinePaint();
        boolean boolean9 = categoryPlot4.canSelectByRegion();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor8);
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition9);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition9);
        boolean boolean12 = lineAndShapeRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '#', layer8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot6.setRangeAxis(0, valueAxis11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot6.setDomainAxis(10, categoryAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot6.getRangeZeroBaselineStroke();
        categoryPlot6.clearDomainAxes();
        keyedObjects0.addObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset21.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getRangeMarkers((int) '#', layer31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        categoryPlot29.setRangeAxis(0, valueAxis34, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot29.zoomDomainAxes((double) 10.0f, plotRenderingInfo38, point2D39, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = null;
        categoryPlot29.axisChanged(axisChangeEvent42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(1, 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot29.setDomainAxis(categoryAxis44);
        double double53 = categoryAxis44.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, categoryAxis44, valueAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55);
        java.awt.Shape shape58 = lineAndShapeRenderer55.getSeriesShape(0);
        java.awt.Paint paint62 = lineAndShapeRenderer55.getItemPaint(15, (int) '#', true);
        boolean boolean63 = lineAndShapeRenderer55.getAutoPopulateSeriesStroke();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55, false);
        lineAndShapeRenderer55.setUseFillPaint(false);
        java.awt.Color color68 = java.awt.Color.GRAY;
        lineAndShapeRenderer55.setBaseFillPaint((java.awt.Paint) color68);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(shape58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(color68);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean3 = strokeList0.equals((java.lang.Object) rectangleInsets2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator4 = new org.jfree.chart.util.DefaultShadowGenerator();
        boolean boolean5 = strokeList0.equals((java.lang.Object) defaultShadowGenerator4);
        java.lang.Object obj6 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 0, (double) (byte) 0, 0.2d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setDomainCrosshairPaint((java.awt.Paint) color15);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot4.getDomainMarkers(layer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            categoryPlot4.drawOutline(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(8, (-4144960), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Font font2 = lineAndShapeRenderer0.lookupLegendTextFont(8);
        boolean boolean6 = lineAndShapeRenderer0.getItemCreateEntity((int) (short) -1, (int) (short) 1, true);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot43.getRangeMarkers((int) '#', layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot43.setRangeAxis(0, valueAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot43.setDomainAxis(10, categoryAxis52, true);
        categoryPlot43.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity57 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) categoryPlot43);
        lineAndShapeRenderer34.setBaseLegendShape(shape38);
        lineAndShapeRenderer34.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis0.getFixedDimension();
        java.lang.Object obj7 = categoryAxis0.clone();
        boolean boolean8 = categoryAxis0.isVisible();
        java.util.List list10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot16.getRangeMarkers((int) '#', layer18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot16.setRangeAxis(0, valueAxis21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot16.setDomainAxis(10, categoryAxis25, true);
        java.awt.Stroke stroke28 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot16.getDataset((int) (short) 1);
        int int31 = categoryPlot16.getWeight();
        boolean boolean32 = categoryPlot16.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot16.setRangeAxisLocation((int) (short) 100, axisLocation34, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str38 = plotOrientation37.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation34, plotOrientation37);
        try {
            double double40 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) "{0}", list10, rectangle2D11, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str38.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint(100, (int) (short) 0, true);
        boolean boolean9 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesVisible((-14336));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getLegendItems();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent22);
        boolean boolean24 = categoryPlot4.canSelectByPoint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) strokeArray14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) (byte) -1, (double) 10L, plotRenderingInfo18, point2D19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(legendItemCollection21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        boolean boolean38 = lineAndShapeRenderer34.getAutoPopulateSeriesOutlineStroke();
        java.lang.Object obj39 = lineAndShapeRenderer34.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("AxisLocation.TOP_OR_RIGHT");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        categoryPlot4.setAnchorValue(0.0d);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot4.getRowRenderingOrder();
        boolean boolean20 = categoryPlot4.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '#', layer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(0, valueAxis10, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot5.setDomainAxis(10, categoryAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis18.getCategoryEnd(1, 0, rectangle2D21, rectangleEdge22);
        categoryAxis18.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis18.setLabelPaint((java.awt.Paint) color26);
        categoryPlot5.setDomainAxis(categoryAxis18);
        boolean boolean29 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Shape shape33 = lineAndShapeRenderer0.getItemShape((-1), (int) (byte) 1, false);
        lineAndShapeRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setItemLabelAnchorOffset(1.0d);
        java.awt.Paint paint40 = lineAndShapeRenderer0.getLegendTextPaint((-14336));
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(paint40);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot42.getRangeMarkers((int) '#', layer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot42.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo48, point2D49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = categoryAxis51.getCategoryEnd(1, 0, rectangle2D54, rectangleEdge55);
        java.util.List list57 = categoryPlot42.getCategoriesForAxis(categoryAxis51);
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape62, (java.awt.Paint) color63);
        legendItem64.setShapeVisible(true);
        java.awt.Font font67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem64.setLabelFont(font67);
        categoryAxis51.setLabelFont(font67);
        lineAndShapeRenderer34.setBaseLegendTextFont(font67);
        try {
            java.awt.Stroke stroke72 = lineAndShapeRenderer34.lookupSeriesStroke((-2103967));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(font67);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot43.getRangeMarkers((int) '#', layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot43.setRangeAxis(0, valueAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot43.setDomainAxis(10, categoryAxis52, true);
        categoryPlot43.setNotify(true);
        org.jfree.chart.entity.PlotEntity plotEntity57 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) categoryPlot43);
        lineAndShapeRenderer34.setBaseLegendShape(shape38);
        java.awt.Paint paint59 = lineAndShapeRenderer34.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Category Plot");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        java.lang.Object obj3 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxis();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers((int) '#', layer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot15.setRangeAxis(0, valueAxis20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot15.setDomainAxis(10, categoryAxis24, true);
        java.awt.Stroke stroke27 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot15.setAnchorValue(0.0d);
        java.awt.Stroke stroke30 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot4.getRangeAxis();
        boolean boolean33 = categoryPlot4.isDomainPannable();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer34.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = lineAndShapeRenderer34.getLegendItemLabelGenerator();
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemFillPaint(2, 0, false);
        categoryPlot4.setRangeMinorGridlinePaint(paint41);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent1.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent1.setChart(jFreeChart5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxis();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers((int) '#', layer17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot15.setRangeAxis(0, valueAxis20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot15.setDomainAxis(10, categoryAxis24, true);
        java.awt.Stroke stroke27 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot15.setAnchorValue(0.0d);
        java.awt.Stroke stroke30 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot4.setRangeGridlineStroke(stroke30);
        boolean boolean32 = categoryPlot4.canSelectByRegion();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        lineAndShapeRenderer34.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke3 = renderAttributes0.getItemStroke((-14336), (int) (short) -1);
        java.awt.Shape shape6 = renderAttributes0.getItemShape((int) '#', (int) (byte) 10);
        java.awt.Font font7 = renderAttributes0.getDefaultLabelFont();
        java.awt.Paint paint9 = renderAttributes0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        defaultCategoryDataset0.addValue((java.lang.Number) 10, (java.lang.Comparable) true, (java.lang.Comparable) (-4144962.0d));
        int int7 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean14 = categoryPlot4.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo18, point2D19);
        categoryPlot4.setAnchorValue((double) (byte) 0, true);
        int int24 = categoryPlot4.getRendererCount();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        boolean boolean42 = lineAndShapeRenderer34.getAutoPopulateSeriesStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = categoryPlot48.getRangeMarkers((int) '#', layer50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        categoryPlot48.setRangeAxis(0, valueAxis53, false);
        boolean boolean56 = categoryPlot48.getDrawSharedDomainAxis();
        int int57 = categoryPlot48.getRendererCount();
        categoryPlot48.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder60 = categoryPlot48.getRowRenderingOrder();
        java.awt.Stroke stroke61 = categoryPlot48.getRangeZeroBaselineStroke();
        lineAndShapeRenderer34.setSeriesOutlineStroke(100, stroke61);
        lineAndShapeRenderer34.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator66 = lineAndShapeRenderer34.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(sortOrder60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNull(categoryURLGenerator66);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot16.getRangeMarkers((int) '#', layer18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot16.setRangeAxis(0, valueAxis21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot16.setDomainAxis(10, categoryAxis25, true);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setOutlineStroke(stroke28);
        java.awt.Color color30 = java.awt.Color.white;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=0,b=128]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=10]", "PlotOrientation.HORIZONTAL", shape11, stroke28, (java.awt.Paint) color30);
        java.awt.Color color33 = java.awt.Color.BLUE;
        java.awt.Color color35 = java.awt.Color.gray;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot40.getRangeMarkers((int) '#', layer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot40.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo46, point2D47);
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = categoryPlot40.getDomainMarkers(layer49);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset51 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        org.jfree.chart.util.Layer layer57 = null;
        java.util.Collection collection58 = categoryPlot55.getRangeMarkers((int) '#', layer57);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        categoryPlot55.setRangeAxis(0, valueAxis60, false);
        java.awt.Stroke stroke63 = categoryPlot55.getOutlineStroke();
        categoryPlot40.setRangeGridlineStroke(stroke63);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset67 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset67, categoryAxis68, valueAxis69, categoryItemRenderer70);
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = categoryPlot71.getRangeMarkers((int) '#', layer73);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        categoryPlot71.setRangeAxis(0, valueAxis76, false);
        boolean boolean79 = categoryPlot71.getDrawSharedDomainAxis();
        int int80 = categoryPlot71.getRendererCount();
        categoryPlot71.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.SortOrder sortOrder83 = categoryPlot71.getRowRenderingOrder();
        java.awt.Stroke stroke84 = categoryPlot71.getRangeZeroBaselineStroke();
        java.awt.Paint paint85 = null;
        org.jfree.chart.LegendItem legendItem86 = new org.jfree.chart.LegendItem("ChartChangeEventType.DATASET_UPDATED", "TextAnchor.CENTER_RIGHT", "ChartChangeEventType.DATASET_UPDATED", "UnitType.ABSOLUTE", false, shape11, false, (java.awt.Paint) color33, false, (java.awt.Paint) color35, stroke63, false, shape66, stroke84, paint85);
        java.awt.Color color87 = java.awt.Color.getColor("", color33);
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("org.jfree.data.UnknownKeyException: hi!", (java.awt.Paint) color87);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(sortOrder83);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(color87);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) -1);
        defaultCategoryDataset0.fireSelectionEvent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '#', layer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot8.setRangeAxis(0, valueAxis13, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot8.axisChanged(axisChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis23.getCategoryEnd(1, 0, rectangle2D26, rectangleEdge27);
        categoryAxis23.setMaximumCategoryLabelLines((int) (short) -1);
        categoryPlot8.setDomainAxis(categoryAxis23);
        double double32 = categoryAxis23.getFixedDimension();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis23, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        java.awt.Shape shape37 = lineAndShapeRenderer34.getSeriesShape(0);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getItemPaint(15, (int) '#', true);
        boolean boolean42 = lineAndShapeRenderer34.getAutoPopulateSeriesStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = null;
        try {
            lineAndShapeRenderer34.setSeriesURLGenerator((int) (short) -1, categoryURLGenerator44, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        java.awt.Paint paint8 = categoryPlot4.getDomainGridlinePaint();
        categoryPlot4.setDomainCrosshairVisible(false);
        categoryPlot4.configureRangeAxes();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot16.getRangeMarkers((int) '#', layer18);
        categoryPlot16.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean26 = categoryPlot16.canSelectByRegion();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        categoryPlot16.markerChanged(markerChangeEvent27);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot16.setRangeAxes(valueAxisArray29);
        categoryPlot4.setRangeAxes(valueAxisArray29);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        boolean boolean12 = categoryPlot4.getDrawSharedDomainAxis();
        int int13 = categoryPlot4.getRendererCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue((double) 10.0f);
        double double17 = categoryPlot4.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace18, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot4.getRangeAxis();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape4, (java.awt.Paint) color5);
        legendItem6.setShapeVisible(true);
        java.awt.Paint paint9 = legendItem6.getOutlinePaint();
        java.lang.String str10 = legendItem6.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers((int) '#', layer17);
        categoryPlot15.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        boolean boolean25 = categoryPlot15.canSelectByRegion();
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setDomainCrosshairPaint((java.awt.Paint) color26);
        categoryPlot15.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot15.getDomainMarkers(layer31);
        java.awt.Paint paint33 = categoryPlot15.getRangeMinorGridlinePaint();
        legendItem6.setLabelPaint(paint33);
        org.jfree.data.general.Dataset dataset35 = legendItem6.getDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot40.getRangeMarkers((int) '#', layer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot40.zoomRangeAxes((double) '4', (double) (byte) 1, plotRenderingInfo46, point2D47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis49.getCategoryEnd(1, 0, rectangle2D52, rectangleEdge53);
        java.util.List list55 = categoryPlot40.getCategoriesForAxis(categoryAxis49);
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color61 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape60, (java.awt.Paint) color61);
        legendItem62.setShapeVisible(true);
        java.awt.Font font65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendItem62.setLabelFont(font65);
        categoryAxis49.setLabelFont(font65);
        legendItem6.setLabelFont(font65);
        java.awt.Color color69 = java.awt.Color.CYAN;
        legendItem6.setOutlinePaint((java.awt.Paint) color69);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(dataset35);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(color69);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        float float8 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.clearRangeMarkers(8);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot4.getLegendItems();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "", "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", shape16, (java.awt.Paint) color17);
        legendItem18.setDescription("PlotOrientation.HORIZONTAL");
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color21.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        legendItem18.setFillPaint((java.awt.Paint) color21);
        java.awt.Font font29 = legendItem18.getLabelFont();
        legendItemCollection11.add(legendItem18);
        legendItem18.setShapeVisible(false);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNull(font29);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) (byte) -1, (double) 2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        categoryPlot4.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.05d, false);
        categoryPlot4.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot4.setRangeAxis(255, valueAxis17, true);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4144962.0d));
        java.util.List list3 = defaultCategoryDataset0.getColumnKeys();
        int int4 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        java.awt.Font font19 = categoryPlot4.getNoDataMessageFont();
        java.util.List list20 = categoryPlot4.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot4.getRenderer(0);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot4.getDomainAxisLocation((int) '#');
        categoryPlot4.setNotify(true);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis0.getCategoryEnd(1, 0, rectangle2D3, rectangleEdge4);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setLabelPaint((java.awt.Paint) color8);
        categoryAxis0.setLabelURL("java.awt.Color[r=0,g=255,b=255]");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset((int) (short) 1);
        int int19 = categoryPlot4.getWeight();
        boolean boolean20 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers((int) '#', layer28);
        float float30 = categoryPlot26.getBackgroundAlpha();
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean35 = categoryPlot26.removeDomainMarker((int) (short) 100, marker32, layer33, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot26.setRenderer(categoryItemRenderer36, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = categoryPlot26.getDrawingSupplier();
        categoryPlot4.setDrawingSupplier(drawingSupplier39);
        java.awt.Stroke stroke41 = null;
        try {
            categoryPlot4.setDomainGridlineStroke(stroke41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(drawingSupplier39);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '#', layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot4.setRangeAxis(0, valueAxis9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot4.setDomainAxis(10, categoryAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(1, 0, rectangle2D20, rectangleEdge21);
        categoryAxis17.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis17.setLabelPaint((java.awt.Paint) color25);
        categoryPlot4.setDomainAxis(categoryAxis17);
        boolean boolean28 = categoryAxis17.isAxisLineVisible();
        double double29 = categoryAxis17.getFixedDimension();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }
}

