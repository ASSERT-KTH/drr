import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection6.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection6.getDomainOrder();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection9.getDomainOrder();
        java.util.List list11 = timeSeriesCollection9.getSeries();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list11, true);
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryAxis1, (org.jfree.data.general.Dataset) timeSeriesCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) '4', textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = null;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, (float) 100L, (float) 1, textBlockAnchor12, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape16, "hi!");
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        chartEntity18.setArea(shape19);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator21 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator22 = null;
        try {
            java.lang.String str23 = chartEntity18.getImageMapAreaTag(toolTipTagFragmentGenerator21, uRLTagFragmentGenerator22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer1.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke4 = xYStepRenderer1.getBaseOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot0.getAxis();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        java.lang.String str2 = standardXYToolTipGenerator0.getFormatString();
        java.text.DateFormat dateFormat3 = standardXYToolTipGenerator0.getXDateFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-16646144));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("1969", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "", textAnchor3, textAnchor4, 0.0d);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        org.jfree.data.DomainOrder domainOrder16 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.time.TimeSeries timeSeries17 = null;
        try {
            int int18 = timeSeriesCollection0.indexOf(timeSeries17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(domainOrder16);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomDomainAxes((double) 31, plotRenderingInfo3, point2D4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        java.lang.String str4 = polarPlot0.getNoDataMessage();
        java.awt.Image image5 = polarPlot0.getBackgroundImage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot0.zoomDomainAxes(0.05d, plotRenderingInfo7, point2D8, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        categoryPlot16.setNoDataMessagePaint(paint23);
        polarPlot0.setRadiusGridlinePaint(paint23);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYDataItem xYDataItem42 = null;
        try {
            xYSeries3.add(xYDataItem42, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.centerRange((double) (-1));
        java.awt.Shape shape5 = dateAxis2.getRightArrow();
        dateAxis2.setTickLabelsVisible(false);
        boolean boolean8 = dateAxis2.isVisible();
        boolean boolean9 = piePlot3D0.equals((java.lang.Object) dateAxis2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        polarPlot10.rendererChanged(rendererChangeEvent12);
        polarPlot10.setRadiusGridlinesVisible(false);
        java.awt.Paint paint16 = polarPlot10.getBackgroundPaint();
        piePlot3D0.setLabelBackgroundPaint(paint16);
        double double18 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.12d + "'", double18 == 0.12d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) 1560409200000L, (double) (short) 0, 0.12d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.lang.String str2 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getDomainAxisEdge((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedDomainXYPlot0.panRangeAxes(3.0d, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined_Domain_XYPlot" + "'", str2.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (byte) -1;
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(100.0d, 0.0d, 0.0d);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        boolean boolean6 = polarPlot4.isRangeZoomable();
        boolean boolean7 = gradientXYBarPainter3.equals((java.lang.Object) polarPlot4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Font font6 = xYStepRenderer0.getItemLabelFont((int) (short) 1, 0, true);
        xYStepRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        dateAxis0.zoomRange(0.0d, 0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7);
        java.util.TimeZone timeZone9 = null;
        try {
            dateAxis0.setTimeZone(timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset0.removeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = null;
        defaultXYDataset0.seriesChanged(seriesChangeEvent3);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState5 = defaultXYDataset0.getSelectionState();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection6.getDomainOrder();
        java.util.List list8 = timeSeriesCollection6.getSeries();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, list8, false);
        org.junit.Assert.assertNull(xYDatasetSelectionState5);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) (-1));
        java.awt.Shape shape3 = dateAxis0.getRightArrow();
        dateAxis0.setTickLabelsVisible(false);
        boolean boolean6 = dateAxis0.isVisible();
        java.awt.Color color8 = org.jfree.chart.util.PaintUtilities.stringToColor("October");
        dateAxis0.setTickMarkPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color11 = color10.darker();
        float[] floatArray16 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray17 = color11.getComponents(floatArray16);
        float[] floatArray18 = color8.getComponents(floatArray17);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator(0, (int) (byte) 100, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer3D0.setSeriesToolTipGenerator(4, categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.clearSectionOutlineStrokes(false);
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionPaint();
        java.awt.Paint paint18 = piePlot3D0.getShadowPaint();
        double double19 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-5d + "'", double19 == 1.0E-5d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer1.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke4 = xYStepRenderer1.getBaseOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke4);
        java.awt.Paint paint6 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot0.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) 6, "{0}: ({1}, {2})", "Other", true);
        boolean boolean9 = rectangleAnchor3.equals((java.lang.Object) "{0}: ({1}, {2})");
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (byte) 0, "", false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(0.05d, (java.text.NumberFormat) logFormat6, (int) (byte) 10);
        try {
            java.lang.Number number9 = defaultPieDataset0.getValue((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(128, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font13 = polarPlot12.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot12.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = polarPlot12.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        java.awt.Stroke stroke24 = dateAxis19.getAxisLineStroke();
        polarPlot12.setAngleGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font11, (org.jfree.chart.plot.Plot) polarPlot12, false);
        boolean boolean28 = jFreeChart27.isNotify();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        textTitle29.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart27.setTitle(textTitle29);
        boolean boolean34 = jFreeChart27.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart27, "", "13-June-2019");
        int int38 = jFreeChart27.getSubtitleCount();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        combinedDomainXYPlot24.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot5.removeDomainMarker((-16646144), marker9, layer10);
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer1.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke4 = xYStepRenderer1.getBaseOutlineStroke();
        polarPlot0.setAngleGridlineStroke(stroke4);
        java.awt.Paint paint6 = polarPlot0.getRadiusGridlinePaint();
        boolean boolean7 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        java.util.Date date2 = dateRange1.getLowerDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color5 = java.awt.Color.darkGray;
        boolean boolean6 = plotOrientation4.equals((java.lang.Object) color5);
        int int7 = year3.compareTo((java.lang.Object) plotOrientation4);
        java.util.Date date8 = year3.getStart();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.setAnchorY((double) (-2208927600000L));
        double double4 = crosshairState1.getAnchorY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.2089276E12d) + "'", double4 == (-2.2089276E12d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 10L, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (-2208927599993L));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairX((double) 60000L, (-16646144));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape1 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = xYStepRenderer0.getLegendItemToolTipGenerator();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder4 = timeSeriesCollection3.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        java.awt.Paint paint11 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot10.setBackgroundPaint(paint11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot10.zoomRangeAxes((double) 10.0f, plotRenderingInfo14, point2D15, false);
        boolean boolean18 = timeSeriesCollection3.hasListener((java.util.EventListener) categoryPlot10);
        float float19 = categoryPlot10.getBackgroundImageAlpha();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot10.removeDomainMarker(marker22, layer23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot10.getDomainMarkers(layer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot10.getRangeAxisEdge(7);
        boolean boolean29 = xYStepRenderer0.hasListener((java.util.EventListener) categoryPlot10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator2);
        org.junit.Assert.assertNotNull(domainOrder4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 644288400000L, "DateTickUnit[DateTickUnitType.DAY, 1]", textAnchor3, textAnchor4, (double) 100L);
        java.lang.String str7 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MINOR" + "'", str7.equals("MINOR"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("#020000");
        boolean boolean2 = periodAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter1 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double4 = barRenderer3D3.getUpperClip();
        boolean boolean6 = barRenderer3D3.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer3D3.getLegendItems();
        boolean boolean8 = barRenderer3D3.getAutoPopulateSeriesPaint();
        barRenderer3D3.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj15 = textTitle14.clone();
        textTitle14.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str18 = textTitle14.getURLText();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        gradientBarPainter1.paintBar(graphics2D2, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D3, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D19, rectangleEdge20);
        try {
            boolean boolean22 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        java.lang.String str2 = standardXYToolTipGenerator0.getFormatString();
        java.lang.Object obj3 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange1);
        java.util.Date date3 = dateRange2.getLowerDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) date3);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font13 = polarPlot12.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot12.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = polarPlot12.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        java.awt.Stroke stroke24 = dateAxis19.getAxisLineStroke();
        polarPlot12.setAngleGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font11, (org.jfree.chart.plot.Plot) polarPlot12, false);
        boolean boolean28 = jFreeChart27.isNotify();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        textTitle29.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart27.setTitle(textTitle29);
        boolean boolean34 = jFreeChart27.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart27, "", "13-June-2019");
        org.jfree.chart.title.Title title38 = null;
        try {
            jFreeChart27.addSubtitle(title38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setVersion("");
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        piePlot3D0.setLabelLinkMargin((double) 1560495599999L);
        piePlot3D0.setMaximumLabelWidth((double) '4');
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Stroke stroke7 = piePlot3D0.getSectionOutlineStroke(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Comparable comparable2 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Comparable comparable5 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) comparable5, seriesChangeInfo6);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Other" + "'", comparable2.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double8 = barRenderer3D7.getUpperClip();
        boolean boolean10 = barRenderer3D7.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer3D7.getLegendItems();
        boolean boolean12 = barRenderer3D7.getAutoPopulateSeriesPaint();
        barRenderer3D7.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj19 = textTitle18.clone();
        textTitle18.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str22 = textTitle18.getURLText();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        gradientBarPainter5.paintBar(graphics2D6, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D7, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D23, rectangleEdge24);
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            piePlot3D0.draw(graphics2D4, rectangle2D23, point2D26, plotState27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        timeSeriesCollection8.validateObject();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer14.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean18 = xYStepRenderer14.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange19);
        boolean boolean21 = xYStepRenderer14.equals((java.lang.Object) dateRange20);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer22.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean26 = xYStepRenderer22.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange27);
        boolean boolean29 = xYStepRenderer22.equals((java.lang.Object) dateRange28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange20, (org.jfree.data.Range) dateRange28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint30.toUnconstrainedHeight();
        boolean boolean32 = timeSeriesCollection8.equals((java.lang.Object) rectangleConstraint31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Boolean boolean2 = barRenderer3D0.getSeriesVisibleInLegend((-16646144));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator3);
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) barRenderer3D0);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D0.setSeriesFillPaint(0, (java.awt.Paint) color7);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = combinedDomainXYPlot0.getRangeAxis();
        boolean boolean35 = combinedDomainXYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedDomainXYPlot36.getRangeAxisLocation();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color39 = color38.darker();
        float[] floatArray44 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray45 = color39.getComponents(floatArray44);
        combinedDomainXYPlot36.setDomainMinorGridlinePaint((java.awt.Paint) color39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = combinedDomainXYPlot36.getDatasetRenderingOrder();
        combinedDomainXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.StandardChartTheme standardChartTheme20 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean23 = xYStepRenderer21.equals((java.lang.Object) 0.0f);
        java.awt.Font font27 = xYStepRenderer21.getItemLabelFont((int) (short) 1, 0, true);
        standardChartTheme20.setSmallFont(font27);
        java.awt.Font font29 = standardChartTheme20.getRegularFont();
        dateAxis11.setTickLabelFont(font29);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color4 = java.awt.Color.BLUE;
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        boolean boolean6 = legendTitle1.isVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font1 = xYStepRenderer0.getBaseItemLabelFont();
        java.awt.Shape shape2 = xYStepRenderer0.getLegendLine();
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean19 = combinedDomainXYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot4.getPieChart();
        multiplePiePlot4.setLimit((double) (short) 10);
        boolean boolean8 = timeSeriesCollection0.hasListener((java.util.EventListener) multiplePiePlot4);
        java.lang.Comparable comparable9 = multiplePiePlot4.getAggregatedItemsKey();
        java.awt.Shape shape10 = multiplePiePlot4.getLegendItemShape();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot21.getRangeAxisEdge(28);
        java.lang.String str40 = combinedRangeXYPlot21.getPlotType();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Combined Range XYPlot" + "'", str40.equals("Combined Range XYPlot"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        dateAxis0.setRange((org.jfree.data.Range) dateRange6, false, true);
        boolean boolean10 = dateAxis0.isTickMarksVisible();
        double double11 = dateAxis0.getAutoRangeMinimumSize();
        java.util.Date date12 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer3D0.getLegendItems();
        java.lang.Object obj5 = legendItemCollection4.clone();
        int int6 = legendItemCollection4.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem8 = legendItemCollection4.get(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(0.12d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean5 = legendTitle1.equals((java.lang.Object) paint4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle1.getWrapper();
        legendTitle1.setPadding((double) (short) 100, (double) 6, (double) 1969, (double) '4');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        combinedDomainXYPlot0.clearRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            combinedDomainXYPlot0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder12 = timeSeriesCollection11.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot18.setBackgroundPaint(paint19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot18.zoomRangeAxes((double) 10.0f, plotRenderingInfo22, point2D23, false);
        boolean boolean26 = timeSeriesCollection11.hasListener((java.util.EventListener) categoryPlot18);
        combinedDomainXYPlot0.setDataset(6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeriesCollection11.clearSelection();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(domainOrder12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke6 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double8 = barRenderer3D7.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D9.getLegendItemLabelGenerator();
        barRenderer3D7.setLegendItemToolTipGenerator(categorySeriesLabelGenerator10);
        barRenderer3D7.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer3D7.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer3D0.setSeriesToolTipGenerator(15, categoryToolTipGenerator19, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) dateRange6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean12 = xYStepRenderer8.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        boolean boolean15 = xYStepRenderer8.equals((java.lang.Object) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder();
        boolean boolean21 = dateRange18.equals((java.lang.Object) blockBorder20);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer22.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean26 = xYStepRenderer22.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange27);
        boolean boolean29 = xYStepRenderer22.equals((java.lang.Object) dateRange28);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer30.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean34 = xYStepRenderer30.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange35);
        boolean boolean37 = xYStepRenderer30.equals((java.lang.Object) dateRange36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, (org.jfree.data.Range) dateRange36);
        boolean boolean39 = dateRange18.intersects((org.jfree.data.Range) dateRange28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint16.toRangeHeight((org.jfree.data.Range) dateRange18);
        double double41 = dateRange18.getCentralValue();
        boolean boolean43 = dateRange18.contains(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.5d + "'", double41 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        boolean boolean1 = numberFormat0.isGroupingUsed();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        int int2 = defaultPieDataset0.getIndex((java.lang.Comparable) 10.0d);
        try {
            defaultPieDataset0.remove((java.lang.Comparable) "DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (DatasetRenderingOrder.REVERSE) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape5 = xYStepRenderer4.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke9 = xYStepRenderer6.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape5, stroke9, paint16);
        java.text.AttributedString attributedString18 = legendItem17.getAttributedLabel();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder20 = timeSeriesCollection19.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder21 = timeSeriesCollection19.getDomainOrder();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder23 = timeSeriesCollection22.getDomainOrder();
        java.util.List list24 = timeSeriesCollection22.getSeries();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, list24, true);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, true);
        legendItem17.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection19);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(domainOrder20);
        org.junit.Assert.assertNotNull(domainOrder21);
        org.junit.Assert.assertNotNull(domainOrder23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(range28);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("#020000");
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color3 = java.awt.Color.darkGray;
        boolean boolean4 = plotOrientation2.equals((java.lang.Object) color3);
        periodAxis1.setMinorTickMarkPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) 2958465, plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        java.awt.Image image10 = categoryPlot5.getBackgroundImage();
        boolean boolean11 = categoryPlot5.isRangeCrosshairLockedOnData();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 0);
        categoryPlot5.zoom((double) (byte) -1);
        org.jfree.chart.plot.Plot plot16 = categoryPlot5.getParent();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(plot16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 100, 28, (-16777216));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3D0);
        piePlot3D0.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) dateRange6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean12 = xYStepRenderer8.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        boolean boolean15 = xYStepRenderer8.equals((java.lang.Object) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth(4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D2.getSeriesURLGenerator(5);
        double double5 = barRenderer3D2.getXOffset();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Paint paint13 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot12.setBackgroundPaint(paint13);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer15.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean19 = xYStepRenderer15.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange20);
        boolean boolean22 = xYStepRenderer15.equals((java.lang.Object) dateRange21);
        xYStepRenderer15.setSeriesLinesVisible(100, false);
        java.lang.Object obj26 = xYStepRenderer15.clone();
        boolean boolean27 = categoryPlot12.equals((java.lang.Object) xYStepRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        double double31 = dateAxis30.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D32 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D32);
        java.awt.Paint paint34 = dateAxis30.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType36 = dateTickUnit35.getRollUnitType();
        dateAxis30.setTickUnit(dateTickUnit35, true, false);
        org.jfree.chart.axis.Timeline timeline40 = dateAxis30.getTimeline();
        dateAxis30.centerRange((double) 1L);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean46 = xYStepRenderer44.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke47 = xYStepRenderer44.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator49 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer44.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator49);
        xYStepRenderer44.setBaseCreateEntities(true);
        boolean boolean54 = xYStepRenderer44.isSeriesVisibleInLegend((int) (short) -1);
        boolean boolean55 = xYStepRenderer44.getDrawSeriesLineAsPath();
        java.awt.Paint paint59 = xYStepRenderer44.getItemFillPaint(7, 500, true);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter61 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D63 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double64 = barRenderer3D63.getUpperClip();
        boolean boolean66 = barRenderer3D63.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = barRenderer3D63.getLegendItems();
        boolean boolean68 = barRenderer3D63.getAutoPopulateSeriesPaint();
        barRenderer3D63.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj75 = textTitle74.clone();
        textTitle74.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str78 = textTitle74.getURLText();
        java.awt.geom.Rectangle2D rectangle2D79 = textTitle74.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = null;
        gradientBarPainter61.paintBar(graphics2D62, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D63, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D79, rectangleEdge80);
        org.jfree.chart.plot.XYPlot xYPlot82 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset83 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number84 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState86 = xYStepRenderer44.initialise(graphics2D60, rectangle2D79, xYPlot82, (org.jfree.data.xy.XYDataset) defaultXYDataset83, plotRenderingInfo85);
        barRenderer3D2.drawRangeMarker(graphics2D6, categoryPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis30, marker43, rectangle2D79);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 12.0d + "'", double5 == 12.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(dateTickUnitType36);
        org.junit.Assert.assertNotNull(timeline40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNull(number84);
        org.junit.Assert.assertNotNull(xYItemRendererState86);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        java.awt.Paint paint3 = piePlot3D0.getShadowPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean2 = paintList0.equals((java.lang.Object) dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.data.Range range38 = combinedRangeXYPlot21.getDataRange(valueAxis37);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(range38);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape16 = textBlock0.calculateBounds(graphics2D9, (float) 1, (float) 1560409200000L, textBlockAnchor12, (float) (short) -1, (float) (byte) 0, (double) 40);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity22 = new org.jfree.chart.entity.XYItemEntity(shape16, xYDataset17, (int) '#', (-16646144), "", "");
        xYItemEntity22.setSeriesIndex(3);
        org.jfree.data.xy.XYDataset xYDataset25 = xYItemEntity22.getDataset();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(xYDataset25);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double4 = barRenderer3D3.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D5.getLegendItemLabelGenerator();
        barRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        barRenderer3D3.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer3D3.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition11.getRotationAnchor();
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition11, false);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer3D0.setSeriesStroke(128, stroke16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke16);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getFirstMillisecond();
//        int int3 = day1.getYear();
//        java.lang.String str4 = day1.toString();
//        long long5 = day1.getLastMillisecond();
//        long long6 = day1.getFirstMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getFirstMillisecond();
//        int int9 = day7.getYear();
//        java.lang.String str10 = day7.toString();
//        long long11 = day7.getLastMillisecond();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day7);
//        periodAxis13.setUpperMargin((double) (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getFirstMillisecond();
//        int int3 = day1.getYear();
//        java.lang.String str4 = day1.toString();
//        long long5 = day1.getLastMillisecond();
//        long long6 = day1.getFirstMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getFirstMillisecond();
//        int int9 = day7.getYear();
//        java.lang.String str10 = day7.toString();
//        long long11 = day7.getLastMillisecond();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day7);
//        java.lang.Class class14 = periodAxis13.getMajorTickTimePeriodClass();
//        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class14);
//        java.util.ResourceBundle.clearCache(classLoader15);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(classLoader15);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection42, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 100L, "", false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Paint paint6 = null;
        xYStepRenderer0.setSeriesPaint((int) (short) 10, paint6, true);
        java.awt.Paint paint9 = xYStepRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.setPieIndex(5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle4.getSources();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle4.getBounds();
        combinedDomainXYPlot0.drawBackgroundImage(graphics2D2, rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getLegendItemGraphicPadding();
        double double4 = legendTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer2.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean6 = xYStepRenderer2.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange7);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) dateRange8);
        java.awt.Paint paint11 = xYStepRenderer2.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font1, paint11);
        java.lang.String str13 = labelBlock12.getURLText();
        java.awt.Font font14 = labelBlock12.getFont();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Other");
        java.lang.Object obj17 = standardPieSectionLabelGenerator16.clone();
        boolean boolean18 = labelBlock12.equals((java.lang.Object) standardPieSectionLabelGenerator16);
        labelBlock12.setURLText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) dateRange6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean12 = xYStepRenderer8.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        boolean boolean15 = xYStepRenderer8.equals((java.lang.Object) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer17.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean21 = xYStepRenderer17.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange22);
        boolean boolean24 = xYStepRenderer17.equals((java.lang.Object) dateRange23);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer25.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean29 = xYStepRenderer25.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange30);
        boolean boolean32 = xYStepRenderer25.equals((java.lang.Object) dateRange31);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange23, (org.jfree.data.Range) dateRange31);
        org.jfree.data.Range range34 = rectangleConstraint33.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, range34);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer36.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean40 = xYStepRenderer36.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange41 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange41);
        boolean boolean43 = xYStepRenderer36.equals((java.lang.Object) dateRange42);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer44.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean48 = xYStepRenderer44.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange49);
        boolean boolean51 = xYStepRenderer44.equals((java.lang.Object) dateRange50);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange42, (org.jfree.data.Range) dateRange50);
        org.jfree.data.Range range53 = rectangleConstraint52.getWidthRange();
        org.jfree.data.Range range54 = rectangleConstraint52.getWidthRange();
        org.jfree.data.Range range57 = org.jfree.data.Range.expand(range54, (double) 10, (double) (-1));
        org.jfree.data.Range range58 = org.jfree.data.Range.combine(range34, range57);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range58);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke6 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double8 = barRenderer3D7.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D9.getLegendItemLabelGenerator();
        barRenderer3D7.setLegendItemToolTipGenerator(categorySeriesLabelGenerator10);
        barRenderer3D7.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer3D7.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getRangeAxisEdge((int) (byte) 0);
        categoryPlot24.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.centerRange((double) 7);
        java.awt.Stroke stroke32 = dateAxis29.getTickMarkStroke();
        boolean boolean33 = dateAxis29.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange34);
        dateAxis29.setRange((org.jfree.data.Range) dateRange35, false, true);
        boolean boolean39 = dateAxis29.isTickMarksVisible();
        double double40 = dateAxis29.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            barRenderer3D0.drawRangeGridline(graphics2D18, categoryPlot24, (org.jfree.chart.axis.ValueAxis) dateAxis29, rectangle2D41, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot37 = combinedDomainXYPlot0.findSubplot(plotRenderingInfo35, point2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(valueAxis34);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder38 = timeSeriesCollection37.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        double double42 = dateAxis41.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D43 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D43);
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot44.setBackgroundPaint(paint45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot44.zoomRangeAxes((double) 10.0f, plotRenderingInfo48, point2D49, false);
        boolean boolean52 = timeSeriesCollection37.hasListener((java.util.EventListener) categoryPlot44);
        float float53 = categoryPlot44.getBackgroundImageAlpha();
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot44.setBackgroundPaint((java.awt.Paint) color54);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot44);
        combinedRangeXYPlot21.plotChanged(plotChangeEvent56);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(domainOrder38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = xYStepRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYURLGenerator3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerMargin();
        dateAxis0.setLabelAngle(100.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = xYStepRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = xYStepRenderer0.getSeriesToolTipGenerator((int) (byte) 10);
        xYStepRenderer0.setSeriesLinesVisible((int) (short) 1, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepRenderer0.getToolTipGenerator(12, (int) (byte) -1, true);
        try {
            xYStepRenderer0.setStepPoint((double) (-2208927599993L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires stepPoint in [0.0;1.0]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator2);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) '4', textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = null;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, (float) 100L, (float) 1, textBlockAnchor12, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        boolean boolean23 = categoryPlot22.isNotify();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle25.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getLegendItemGraphicPadding();
        double double28 = rectangleInsets27.getRight();
        double double30 = rectangleInsets27.extendHeight(Double.NaN);
        categoryPlot22.setAxisOffset(rectangleInsets27);
        boolean boolean32 = textBlock8.equals((java.lang.Object) categoryPlot22);
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) (-1.0d), false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        double double8 = dateAxis3.getLowerBound();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.5d + "'", double8 == 6.5d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 10, "{0}: ({1}, {2})", true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        java.util.Date date2 = dateRange1.getLowerDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        java.lang.Object obj5 = null;
        boolean boolean6 = polarPlot0.equals(obj5);
        java.lang.Object obj7 = polarPlot0.clone();
        boolean boolean8 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot5.removeDomainMarker((-16646144), marker9, layer10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double2 = logAxis0.calculateLog((double) (short) -1);
        logAxis0.zoomRange((double) 0L, (double) 6);
        java.awt.Stroke stroke6 = logAxis0.getTickMarkStroke();
        logAxis0.setSmallestValue((double) 1900);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.lang.String str2 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D3.setLabelPadding(rectangleInsets4);
        boolean boolean6 = piePlot3D3.getSectionOutlinesVisible();
        java.awt.Paint paint7 = piePlot3D3.getLabelPaint();
        combinedDomainXYPlot0.setDomainMinorGridlinePaint(paint7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined_Domain_XYPlot" + "'", str2.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        int int5 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 96 + "'", int5 == 96);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer3D0.getLegendItems();
        boolean boolean5 = barRenderer3D0.getAutoPopulateSeriesPaint();
        double double6 = barRenderer3D0.getBase();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener7 = null;
        try {
            barRenderer3D0.addChangeListener(rendererChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot21.getRangeAxisEdge(28);
        combinedRangeXYPlot21.mapDatasetToDomainAxis(3, 255);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        boolean boolean2 = polarPlot0.isRangeZoomable();
        java.lang.String str3 = polarPlot0.getPlotType();
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Polar Plot" + "'", str3.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        java.util.Date date3 = segmentedTimeline0.getDate((long) 255);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange8);
        java.util.Date date10 = dateRange9.getLowerDate();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color13 = java.awt.Color.darkGray;
        boolean boolean14 = plotOrientation12.equals((java.lang.Object) color13);
        int int15 = year11.compareTo((java.lang.Object) plotOrientation12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation7, plotOrientation12);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection42.setIntervalWidth((double) 100);
        int int46 = xYSeriesCollection42.getItemCount(0);
        try {
            org.jfree.data.xy.XYSeries xYSeries48 = xYSeriesCollection42.getSeries((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.block.BlockFrame blockFrame4 = legendTitle1.getFrame();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle7.getSources();
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle7.getBounds();
        try {
            legendTitle1.draw(graphics2D5, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getFirstMillisecond();
//        int int3 = day1.getYear();
//        java.lang.String str4 = day1.toString();
//        long long5 = day1.getLastMillisecond();
//        long long6 = day1.getFirstMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getFirstMillisecond();
//        int int9 = day7.getYear();
//        java.lang.String str10 = day7.toString();
//        long long11 = day7.getLastMillisecond();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day7);
//        java.lang.Class class14 = periodAxis13.getMajorTickTimePeriodClass();
//        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class14);
//        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class14);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(classLoader15);
//        org.junit.Assert.assertNotNull(classLoader16);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getFirstMillisecond();
//        int int3 = day1.getYear();
//        java.lang.String str4 = day1.toString();
//        long long5 = day1.getLastMillisecond();
//        long long6 = day1.getFirstMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getFirstMillisecond();
//        int int9 = day7.getYear();
//        java.lang.String str10 = day7.toString();
//        long long11 = day7.getLastMillisecond();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day7);
//        java.lang.Class class14 = periodAxis13.getMajorTickTimePeriodClass();
//        java.awt.Stroke stroke15 = null;
//        try {
//            periodAxis13.setMinorTickMarkStroke(stroke15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer27.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean31 = xYStepRenderer27.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange32);
        boolean boolean34 = xYStepRenderer27.equals((java.lang.Object) dateRange33);
        java.awt.Paint paint36 = xYStepRenderer27.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font26, paint36);
        java.lang.String str38 = labelBlock37.getURLText();
        java.awt.Font font39 = labelBlock37.getFont();
        textTitle20.setFont(font39);
        java.lang.String str41 = textTitle20.getToolTipText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("1.2.0-pre", font26, paint27);
        java.awt.Font font30 = null;
        java.awt.Color color34 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font30, (java.awt.Paint) color34, (float) '4', textMeasurer36);
        org.jfree.chart.text.TextLine textLine38 = null;
        textBlock37.addLine(textLine38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textBlock37.getLineAlignment();
        textBlock28.setLineAlignment(horizontalAlignment40);
        boolean boolean42 = textTitle20.equals((java.lang.Object) horizontalAlignment40);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            double double3 = defaultXYDataset0.getYValue(4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
//        double double5 = dateAxis4.getLowerMargin();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
//        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
//        categoryPlot7.setBackgroundPaint(paint8);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        java.awt.geom.Point2D point2D12 = null;
//        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
//        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
//        float float16 = categoryPlot7.getBackgroundImageAlpha();
//        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19, false);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getFirstMillisecond();
//        int int26 = day24.getYear();
//        java.lang.String str27 = day24.toString();
//        long long28 = day24.getLastMillisecond();
//        long long29 = day24.getFirstMillisecond();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getFirstMillisecond();
//        int int32 = day30.getYear();
//        java.lang.String str33 = day30.toString();
//        long long34 = day30.getLastMillisecond();
//        long long35 = day30.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.Class class37 = periodAxis36.getMajorTickTimePeriodClass();
//        categoryPlot7.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) periodAxis36);
//        float float39 = periodAxis36.getMinorTickMarkOutsideLength();
//        org.junit.Assert.assertNotNull(domainOrder1);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot11 = categoryPlot8.getParent();
        java.awt.Paint paint12 = categoryPlot8.getDomainCrosshairPaint();
        piePlot3D2.setLabelShadowPaint(paint12);
        piePlot3D1.setLabelShadowPaint(paint12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getAnchorY();
        int int3 = crosshairState1.getDomainAxisIndex();
        crosshairState1.setCrosshairX((double) '#');
        crosshairState1.updateCrosshairY(0.0d);
        int int8 = crosshairState1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        categoryPlot5.setForegroundAlpha((float) (byte) 100);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange10);
        java.util.Date date12 = dateRange11.getLowerDate();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color15 = java.awt.Color.darkGray;
        boolean boolean16 = plotOrientation14.equals((java.lang.Object) color15);
        int int17 = year13.compareTo((java.lang.Object) plotOrientation14);
        categoryPlot5.setOrientation(plotOrientation14);
        java.lang.String str19 = plotOrientation14.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1900, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Shape shape4 = xYAreaRenderer3.getLegendArea();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint2 = combinedDomainXYPlot0.getRangeGridlinePaint();
        boolean boolean3 = combinedDomainXYPlot0.isRangePannable();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation27);
        boolean boolean42 = combinedDomainXYPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
//        boolean boolean1 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
//        piePlot3D0.setLabelLinkMargin((double) 1560495599999L);
//        piePlot3D0.setMaximumLabelWidth((double) '4');
//        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//        boolean boolean9 = xYStepRenderer7.equals((java.lang.Object) 0.0f);
//        java.awt.Font font13 = xYStepRenderer7.getItemLabelFont((int) (short) 1, 0, true);
//        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        double double17 = dateAxis16.getLowerMargin();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
//        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D18);
//        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getRangeAxisLocation(0);
//        org.jfree.chart.plot.Plot plot22 = categoryPlot19.getParent();
//        java.awt.Paint paint23 = categoryPlot19.getDomainCrosshairPaint();
//        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("index.html", font13, paint23);
//        piePlot3D0.setNoDataMessagePaint(paint23);
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator27 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Other");
//        java.lang.Object obj28 = standardPieSectionLabelGenerator27.clone();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getFirstMillisecond();
//        int int31 = day29.getYear();
//        java.lang.String str32 = day29.toString();
//        boolean boolean33 = standardPieSectionLabelGenerator27.equals((java.lang.Object) str32);
//        piePlot3D0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator27);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
//        org.junit.Assert.assertNotNull(axisLocation21);
//        org.junit.Assert.assertNull(plot22);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10.0f, 0.0d, (double) (short) 1, (double) 100, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomRangeAxes((double) 10.0f, plotRenderingInfo9, point2D10, false);
        int int13 = categoryPlot5.getRendererCount();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder16 = timeSeriesCollection15.getDomainOrder();
        java.util.List list17 = timeSeriesCollection15.getSeries();
        try {
            categoryPlot5.mapDatasetToRangeAxes((int) ' ', list17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(domainOrder16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("{0}: ({1}, {2})");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Other", "12/31/69 4:00 PM", "Combined_Domain_XYPlot", "hi!", "PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint2 = combinedDomainXYPlot0.getRangeGridlinePaint();
        boolean boolean3 = combinedDomainXYPlot0.isRangePannable();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation27);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color43 = color42.darker();
        float[] floatArray48 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray49 = color43.getComponents(floatArray48);
        combinedDomainXYPlot0.setDomainCrosshairPaint((java.awt.Paint) color43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str2 = standardXYToolTipGenerator1.getFormatString();
        java.lang.String str3 = standardXYToolTipGenerator1.getFormatString();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator4);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator6);
        java.text.NumberFormat numberFormat8 = standardXYToolTipGenerator1.getXFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}: ({1}, {2})" + "'", str3.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font1 = xYStepRenderer0.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 1, xYURLGenerator3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj6 = textTitle5.clone();
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) textTitle5);
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle5.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(blockBorder8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        textTitle20.setText("");
        double double27 = textTitle20.getWidth();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        java.lang.String str10 = xYSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean5 = legendTitle1.equals((java.lang.Object) paint4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle1.getWrapper();
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, (float) 900000L, (float) 1900, textBlockAnchor11, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font18 = polarPlot17.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font18, (org.jfree.chart.plot.Plot) polarPlot19, false);
        boolean boolean35 = jFreeChart34.isNotify();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj37 = textTitle36.clone();
        textTitle36.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart34.setTitle(textTitle36);
        boolean boolean41 = jFreeChart34.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity44 = new org.jfree.chart.entity.JFreeChartEntity(shape15, jFreeChart34, "", "13-June-2019");
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart34);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(blockContainer6);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font13 = polarPlot12.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot12.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = polarPlot12.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        java.awt.Stroke stroke24 = dateAxis19.getAxisLineStroke();
        polarPlot12.setAngleGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font11, (org.jfree.chart.plot.Plot) polarPlot12, false);
        boolean boolean28 = jFreeChart27.isNotify();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        textTitle29.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart27.setTitle(textTitle29);
        boolean boolean34 = jFreeChart27.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart27, "", "13-June-2019");
        jFreeChart27.removeLegend();
        org.jfree.chart.title.LegendTitle legendTitle39 = jFreeChart27.getLegend();
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj41 = textTitle40.clone();
        textTitle40.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str44 = textTitle40.getText();
        java.awt.Font font45 = textTitle40.getFont();
        jFreeChart27.setTitle(textTitle40);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(legendTitle39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(font45);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        java.awt.Paint paint4 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1, 10.0d);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle9.getSources();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets7.createOutsetRectangle(rectangle2D11, false, false);
        try {
            barRenderer3D2.setLegendShape((int) (short) -1, (java.awt.Shape) rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) -1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) (short) -1, 1.0d);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) 4, 0.0f, (float) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = xYStepRenderer0.getSeriesToolTipGenerator((int) (byte) 10);
        xYStepRenderer0.setDefaultEntityRadius(0);
        boolean boolean6 = xYStepRenderer0.isSeriesItemLabelsVisible(28);
        org.junit.Assert.assertNull(xYToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        int int1 = xYStepRenderer0.getPassCount();
        xYStepRenderer0.setDrawSeriesLineAsPath(true);
        xYStepRenderer0.setSeriesShapesVisible(1900, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraintType.RANGE");
        categoryAxis3D1.setUpperMargin((double) 1.0f);
        categoryAxis3D1.setTickMarkInsideLength((float) (byte) 100);
        categoryAxis3D1.configure();
        java.lang.Object obj7 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.setMaximumLabelWidth((double) 12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape5 = xYStepRenderer4.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke9 = xYStepRenderer6.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape5, stroke9, paint16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.text.AttributedString attributedString19 = legendItem17.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(attributedString19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        java.awt.Paint paint15 = null;
        try {
            piePlot3D0.setLabelPaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setFixedDimension(0.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = dateAxis0.getStandardTickUnits();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = dateTickUnit7.getRollUnitType();
        dateAxis2.setTickUnit(dateTickUnit7, true, false);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis2.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis2.setTickUnit(dateTickUnit13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        java.util.Date date17 = dateRange16.getLowerDate();
        java.util.Date date18 = dateTickUnit13.rollDate(date17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertNotNull(timeline12);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = legendTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot9 = categoryPlot6.getParent();
        java.awt.Paint paint10 = categoryPlot6.getDomainCrosshairPaint();
        piePlot3D0.setLabelShadowPaint(paint10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color13 = color12.darker();
        float[] floatArray18 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray19 = color13.getComponents(floatArray18);
        piePlot3D0.setLabelBackgroundPaint((java.awt.Paint) color13);
        double double21 = piePlot3D0.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.14d + "'", double21 == 0.14d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) dateRange6);
        xYStepRenderer0.setSeriesLinesVisible(100, false);
        boolean boolean14 = xYStepRenderer0.getItemCreateEntity(1969, (int) (short) 100, false);
        xYStepRenderer0.setSeriesShapesVisible(500, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange3);
        java.util.Date date5 = dateRange4.getLowerDate();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color8 = java.awt.Color.darkGray;
        boolean boolean9 = plotOrientation7.equals((java.lang.Object) color8);
        int int10 = year6.compareTo((java.lang.Object) plotOrientation7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] { (-2208927600000L), 0.0d, (byte) 0, int10, regularTimePeriod16, 0.14d };
        java.lang.Class class19 = null;
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange20);
        java.util.Date date22 = dateRange21.getLowerDate();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date22, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Year year28 = month26.getYear();
        java.lang.Class class29 = null;
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange30);
        java.util.Date date32 = dateRange31.getLowerDate();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date32, timeZone34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year37 = month36.getYear();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        dateAxis39.centerRange((double) 7);
        java.awt.Stroke stroke42 = dateAxis39.getTickMarkStroke();
        dateAxis39.zoomRange(0.0d, 0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis39.setTickUnit(dateTickUnit46);
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange48);
        java.util.Date date50 = dateRange49.getLowerDate();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        java.lang.Class class52 = null;
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange54 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange53);
        java.util.Date date55 = dateRange54.getLowerDate();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date55);
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date55, timeZone57);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date55);
        org.jfree.data.xy.XYSeries xYSeries60 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) date55);
        java.lang.Comparable[] comparableArray61 = new java.lang.Comparable[] { year28, year37, (byte) 0, dateTickUnit46, year51, date55 };
        double[] doubleArray66 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray69 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray72 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray75 = new double[] { (-2208927600000L), (short) 1 };
        double[][] doubleArray76 = new double[][] { doubleArray66, doubleArray69, doubleArray72, doubleArray75 };
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("1969", "index.html", doubleArray76);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray18, comparableArray61, doubleArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'columnKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(comparableArray18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(comparableArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLowerMargin();
        dateAxis0.setRange((-1.0d), (double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font1 = xYStepRenderer0.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 1, xYURLGenerator3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj6 = textTitle5.clone();
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) textTitle5);
        org.jfree.chart.plot.XYPlot xYPlot8 = xYStepRenderer0.getPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean12 = xYStepRenderer10.equals((java.lang.Object) 0.0f);
        java.awt.Font font16 = xYStepRenderer10.getItemLabelFont((int) (short) 1, 0, true);
        boolean boolean17 = xYStepRenderer10.getDrawOutlines();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double20 = barRenderer3D19.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer3D21.getLegendItemLabelGenerator();
        barRenderer3D19.setLegendItemToolTipGenerator(categorySeriesLabelGenerator22);
        barRenderer3D19.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer3D19.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        xYStepRenderer10.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition27, false);
        org.jfree.chart.text.TextAnchor textAnchor30 = itemLabelPosition27.getRotationAnchor();
        try {
            xYStepRenderer0.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYPlot8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor30);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        int int2 = defaultPieDataset0.getIndex((java.lang.Comparable) 10.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer27.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean31 = xYStepRenderer27.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange32);
        boolean boolean34 = xYStepRenderer27.equals((java.lang.Object) dateRange33);
        java.awt.Paint paint36 = xYStepRenderer27.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font26, paint36);
        java.lang.String str38 = labelBlock37.getURLText();
        java.awt.Font font39 = labelBlock37.getFont();
        textTitle20.setFont(font39);
        boolean boolean41 = textTitle20.getNotify();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        xYPlot0.setRangeGridlinesVisible(false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) (byte) 0);
        java.lang.String str6 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        blockContainer3.clear();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(blockContainer3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D20.setLabelPadding(rectangleInsets21);
        boolean boolean23 = piePlot3D20.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = piePlot3D20.getURLGenerator();
        java.awt.Paint paint25 = piePlot3D20.getBaseSectionPaint();
        jFreeChart18.setBackgroundPaint(paint25);
        int int27 = jFreeChart18.getSubtitleCount();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(pieURLGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = color2.darker();
        float[] floatArray8 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray9 = color3.getComponents(floatArray8);
        combinedDomainXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        java.util.List list12 = combinedDomainXYPlot0.getSubplots();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double2 = barRenderer3D1.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = barRenderer3D3.getLegendItemLabelGenerator();
        barRenderer3D1.setLegendItemToolTipGenerator(categorySeriesLabelGenerator4);
        barRenderer3D1.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer3D1.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition9);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D11.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = barRenderer3D11.getURLGenerator((int) (short) 100, (int) (short) 10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = barRenderer3D11.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Shape shape21 = null;
        barRenderer3D0.setSeriesShape(4, shape21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        dateAxis2.setFixedDimension(0.05d);
        dateAxis2.setLabel("");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomRangeAxes((double) 10.0f, plotRenderingInfo9, point2D10, false);
        int int13 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace14, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape5 = xYStepRenderer4.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke9 = xYStepRenderer6.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape5, stroke9, paint16);
        int int18 = legendItem17.getDatasetIndex();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color20 = color19.darker();
        legendItem17.setOutlinePaint((java.awt.Paint) color20);
        int int22 = legendItem17.getSeriesIndex();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        dateAxis23.centerRange((double) (-1));
        java.awt.Shape shape26 = dateAxis23.getRightArrow();
        legendItem17.setLine(shape26);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getLegendItemGraphicPadding();
        double double11 = rectangleInsets10.getRight();
        double double13 = rectangleInsets10.extendHeight(Double.NaN);
        categoryPlot5.setAxisOffset(rectangleInsets10);
        categoryPlot5.setDrawSharedDomainAxis(true);
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot5.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(datasetGroup17);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (short) 100);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Paint paint6 = null;
        xYStepRenderer0.setSeriesPaint((int) (short) 10, paint6, true);
        int int9 = xYStepRenderer0.getPassCount();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYStepRenderer0.getURLGenerator((int) (byte) 1, 2, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double16 = barRenderer3D15.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = barRenderer3D17.getLegendItemLabelGenerator();
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        barRenderer3D15.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer3D15.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = itemLabelPosition23.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = itemLabelPosition23.getItemLabelAnchor();
        xYStepRenderer0.setSeriesNegativeItemLabelPosition(96, itemLabelPosition23, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean4 = xYStepRenderer2.equals((java.lang.Object) 0.0f);
        java.awt.Font font8 = xYStepRenderer2.getItemLabelFont((int) (short) 1, 0, true);
        standardChartTheme1.setSmallFont(font8);
        java.awt.Paint paint10 = standardChartTheme1.getItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        dateAxis0.setRange((org.jfree.data.Range) dateRange6, false, true);
        boolean boolean10 = dateAxis0.isTickMarksVisible();
        boolean boolean11 = dateAxis0.isNegativeArrowVisible();
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color10 = java.awt.Color.darkGray;
        boolean boolean11 = plotOrientation9.equals((java.lang.Object) color10);
        java.awt.Color color12 = java.awt.Color.getColor("hi!", color10);
        java.awt.Color color13 = color12.darker();
        categoryPlot5.setRangeMinorGridlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
//        double double5 = dateAxis4.getLowerMargin();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
//        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
//        categoryPlot7.setBackgroundPaint(paint8);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        java.awt.geom.Point2D point2D12 = null;
//        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
//        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
//        float float16 = categoryPlot7.getBackgroundImageAlpha();
//        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19, false);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getFirstMillisecond();
//        int int26 = day24.getYear();
//        java.lang.String str27 = day24.toString();
//        long long28 = day24.getLastMillisecond();
//        long long29 = day24.getFirstMillisecond();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getFirstMillisecond();
//        int int32 = day30.getYear();
//        java.lang.String str33 = day30.toString();
//        long long34 = day30.getLastMillisecond();
//        long long35 = day30.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.Class class37 = periodAxis36.getMajorTickTimePeriodClass();
//        categoryPlot7.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) periodAxis36);
//        java.awt.Shape shape39 = periodAxis36.getRightArrow();
//        org.junit.Assert.assertNotNull(domainOrder1);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(shape39);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3D0.getURLGenerator();
        org.jfree.chart.util.Rotation rotation5 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str6 = rotation5.toString();
        piePlot3D0.setDirection(rotation5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Rotation.CLOCKWISE" + "'", str6.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean12 = xYStepRenderer10.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke13 = xYStepRenderer10.getBaseOutlineStroke();
        xYStepRenderer0.setSeriesStroke(2, stroke13, false);
        xYStepRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getLegendItemGraphicPadding();
        double double8 = rectangleInsets7.getRight();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean11 = xYStepRenderer9.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke12 = xYStepRenderer9.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer9.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        xYStepRenderer9.setBaseCreateEntities(true);
        boolean boolean19 = xYStepRenderer9.isSeriesVisibleInLegend((int) (short) -1);
        boolean boolean20 = xYStepRenderer9.getDrawSeriesLineAsPath();
        java.awt.Paint paint24 = xYStepRenderer9.getItemFillPaint(7, 500, true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter26 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double29 = barRenderer3D28.getUpperClip();
        boolean boolean31 = barRenderer3D28.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = barRenderer3D28.getLegendItems();
        boolean boolean33 = barRenderer3D28.getAutoPopulateSeriesPaint();
        barRenderer3D28.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj40 = textTitle39.clone();
        textTitle39.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str43 = textTitle39.getURLText();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        gradientBarPainter26.paintBar(graphics2D27, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D28, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D44, rectangleEdge45);
        org.jfree.chart.plot.XYPlot xYPlot47 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset48 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer9.initialise(graphics2D25, rectangle2D44, xYPlot47, (org.jfree.data.xy.XYDataset) defaultXYDataset48, plotRenderingInfo50);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets7.createOutsetRectangle(rectangle2D44);
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer54 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean56 = xYStepRenderer54.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke57 = xYStepRenderer54.getBaseOutlineStroke();
        polarPlot53.setAngleGridlineStroke(stroke57);
        java.awt.Paint paint59 = polarPlot53.getRadiusGridlinePaint();
        java.awt.Stroke stroke60 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color63 = java.awt.Color.darkGray;
        boolean boolean64 = plotOrientation62.equals((java.lang.Object) color63);
        java.awt.Color color65 = java.awt.Color.getColor("hi!", color63);
        try {
            org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem(attributedString0, "MINOR", "", "DateTickUnit[DateTickUnitType.DAY, 1]", (java.awt.Shape) rectangle2D44, paint59, stroke60, (java.awt.Paint) color63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(plotOrientation62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle2.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle2.getItemContainer();
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean6 = legendTitle2.equals((java.lang.Object) paint5);
        boolean boolean7 = color0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.title.Title title9 = titleChangeEvent8.getTitle();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(title9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot7.removeDomainMarker(marker19, layer20);
        java.awt.Color color22 = java.awt.Color.BLUE;
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color22);
        double[] doubleArray28 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray31 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray34 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray37 = new double[] { (-2208927600000L), (short) 1 };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("1969", "index.html", doubleArray38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot7.getRendererForDataset(categoryDataset39);
        try {
            org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (java.lang.Comparable) 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNull(categoryItemRenderer40);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        xYSeries3.setDescription("Other");
        xYSeries3.add((double) (short) -1, (java.lang.Number) 4.0d, true);
        xYSeries3.fireSeriesChanged();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer3D0.getLegendItems();
        java.lang.Object obj5 = legendItemCollection4.clone();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape11 = xYStepRenderer10.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean14 = xYStepRenderer12.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke15 = xYStepRenderer12.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D20);
        java.awt.Paint paint22 = dateAxis18.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape11, stroke15, paint22);
        boolean boolean24 = legendItem23.isShapeVisible();
        legendItemCollection4.add(legendItem23);
        java.awt.Font font27 = null;
        java.awt.Color color31 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) '4', textMeasurer33);
        java.awt.color.ColorSpace colorSpace35 = color31.getColorSpace();
        legendItem23.setLinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNotNull(colorSpace35);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = barRenderer3D0.getBasePaint();
        barRenderer3D0.setSeriesItemLabelsVisible(40, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(itemLabelPosition7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        java.util.List list43 = xYSeriesCollection42.getSeries();
        try {
            double double46 = xYSeriesCollection42.getStartXValue((int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        java.lang.String str4 = polarPlot0.getNoDataMessage();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot0.getAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long7 = segmentedTimeline0.getTimeFromLong((long) (short) -1);
        segmentedTimeline0.setStartTime((long) (short) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape5 = xYStepRenderer4.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke9 = xYStepRenderer6.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape5, stroke9, paint16);
        java.text.AttributedString attributedString18 = legendItem17.getAttributedLabel();
        java.awt.Stroke stroke19 = legendItem17.getOutlineStroke();
        java.awt.Stroke stroke20 = legendItem17.getLineStroke();
        java.awt.Shape shape21 = legendItem17.getShape();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Font font12 = xYStepRenderer6.getItemLabelFont((int) (short) 1, 0, true);
        boolean boolean13 = xYStepRenderer6.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepRenderer6.getNegativeItemLabelPosition(1, (int) (short) 10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYStepRenderer6.getNegativeItemLabelPosition(4, 0, false);
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Class class0 = null;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange1);
        java.util.Date date3 = dateRange2.getLowerDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int11 = month7.compareTo((java.lang.Object) segmentedTimeline10);
        java.util.Date date12 = month7.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(segmentedTimeline10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        java.lang.Comparable comparable10 = categoryPlot7.getDomainCrosshairRowKey();
        boolean boolean11 = unitType0.equals((java.lang.Object) comparable10);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D10);
        java.awt.Paint paint12 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot11.setBackgroundPaint(paint12);
        boolean boolean14 = barRenderer3D4.equals((java.lang.Object) paint12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("1969");
        projectInfo0.setName("1.2.0-pre");
        java.lang.String str5 = projectInfo0.getLicenceText();
        java.lang.String str6 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        dateAxis0.setTickMarksVisible(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle22.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getLegendItemGraphicPadding();
        java.awt.Color color25 = java.awt.Color.BLUE;
        legendTitle22.setItemPaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getLegendItemGraphicPadding();
        logAxis1.setTickLabelInsets(rectangleInsets27);
        logAxis1.setMinorTickMarkInsideLength((float) (-2208927599993L));
        logAxis1.resizeRange((double) 900000L, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean6 = standardXYToolTipGenerator4.equals((java.lang.Object) textAnchor5);
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.text.TextUtilities.drawAlignedString("{0}: ({1}, {2})", graphics2D1, (float) (byte) 10, (float) ' ', textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        standardChartTheme1.setCrosshairPaint(paint3);
        java.awt.Font font5 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint2 = combinedDomainXYPlot0.getRangeGridlinePaint();
        boolean boolean3 = combinedDomainXYPlot0.isRangePannable();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = combinedDomainXYPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(xYItemRenderer42);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        piePlot3D0.setLabelLinkMargin((double) 1560495599999L);
        piePlot3D0.setMaximumLabelWidth((double) '4');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D0.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        java.awt.Stroke stroke4 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.setAnchorY((double) (-2208927600000L));
        crosshairState1.setDatasetIndex(0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        java.awt.geom.Point2D point2D2 = crosshairState1.getAnchor();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange9);
        java.util.Date date11 = dateRange10.getLowerDate();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color14 = java.awt.Color.darkGray;
        boolean boolean15 = plotOrientation13.equals((java.lang.Object) color14);
        int int16 = year12.compareTo((java.lang.Object) plotOrientation13);
        crosshairState1.updateCrosshairPoint(Double.NaN, (double) 1900, (int) (byte) 100, (-16646144), (double) 1L, 0.0d, plotOrientation13);
        org.junit.Assert.assertNull(point2D2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getRangeAxisLocation(0);
        categoryPlot5.setRangeAxisLocation((int) ' ', axisLocation17);
        boolean boolean19 = categoryPlot5.isDomainPannable();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getLegendItemGraphicPadding();
        double double4 = rectangleInsets3.getRight();
        double double6 = rectangleInsets3.extendHeight(Double.NaN);
        double double7 = rectangleInsets3.getBottom();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray11 = legendTitle10.getSources();
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean15 = rectangleEdge13.equals((java.lang.Object) lengthAdjustmentType14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType14, lengthAdjustmentType16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle20.getSources();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle20.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean25 = rectangleEdge23.equals((java.lang.Object) lengthAdjustmentType24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets18.createAdjustedRectangle(rectangle2D22, lengthAdjustmentType24, lengthAdjustmentType26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean30 = rectangleEdge28.equals((java.lang.Object) lengthAdjustmentType29);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets3.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType24, lengthAdjustmentType29);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(legendItemSourceArray11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setShadowYOffset((double) 28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.clearSectionOutlineStrokes(false);
        double double17 = piePlot3D0.getDepthFactor();
        piePlot3D0.setLabelGap((double) 100L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.12d + "'", double17 == 0.12d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedDomainXYPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.centerRange((double) 7);
        java.awt.Stroke stroke17 = dateAxis14.getTickMarkStroke();
        combinedDomainXYPlot11.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        combinedDomainXYPlot11.setFixedDomainAxisSpace(axisSpace19);
        combinedDomainXYPlot11.setDomainGridlinesVisible(false);
        int int23 = combinedDomainXYPlot11.getWeight();
        combinedDomainXYPlot11.mapDatasetToRangeAxis(28, (-16777216));
        org.jfree.data.xy.XYSeries xYSeries30 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        xYSeries30.setDescription("Other");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection33 = new org.jfree.data.xy.XYSeriesCollection(xYSeries30);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.centerRange((double) 7);
        java.awt.Stroke stroke38 = dateAxis35.getTickMarkStroke();
        dateAxis35.zoomRange(0.0d, 0.0d);
        double double42 = dateAxis35.getUpperMargin();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, polarItemRenderer43);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation47 = combinedDomainXYPlot46.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.centerRange((double) 7);
        java.awt.Stroke stroke52 = dateAxis49.getTickMarkStroke();
        combinedDomainXYPlot46.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis49);
        combinedDomainXYPlot46.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        dateAxis57.centerRange((double) 7);
        java.awt.Stroke stroke60 = dateAxis57.getTickMarkStroke();
        dateAxis57.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot46.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.jfree.chart.plot.PolarPlot polarPlot65 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font66 = polarPlot65.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        polarPlot65.rendererChanged(rendererChangeEvent67);
        java.lang.String str69 = polarPlot65.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = null;
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        double double73 = dateAxis72.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D74 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset70, categoryAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis72, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D74);
        java.awt.Paint paint76 = dateAxis72.getAxisLinePaint();
        java.awt.Stroke stroke77 = dateAxis72.getAxisLineStroke();
        polarPlot65.setAngleGridlineStroke(stroke77);
        combinedDomainXYPlot46.setRangeMinorGridlineStroke(stroke77);
        org.jfree.chart.axis.ValueAxis valueAxis80 = combinedDomainXYPlot46.getRangeAxis();
        boolean boolean81 = combinedDomainXYPlot46.isRangeZeroBaselineVisible();
        org.jfree.chart.entity.EntityCollection entityCollection84 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo85 = new org.jfree.chart.ChartRenderingInfo(entityCollection84);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo85);
        combinedDomainXYPlot46.handleClick(31, 1969, plotRenderingInfo86);
        java.awt.geom.Point2D point2D88 = null;
        polarPlot44.zoomDomainAxes((double) (-1), plotRenderingInfo86, point2D88, false);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState91 = xYStepRenderer0.initialise(graphics2D9, rectangle2D10, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, (org.jfree.data.xy.XYDataset) xYSeriesCollection33, plotRenderingInfo86);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(valueAxis80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState91);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        java.awt.Image image10 = categoryPlot5.getBackgroundImage();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot5.addRangeMarker(marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        projectInfo0.setName("Polar Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("1.2.0-pre", font2, paint3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("MINOR", font2, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart18.createBufferedImage(15, (int) (short) 1, (double) 2, 3.0d, chartRenderingInfo30);
        jFreeChart18.setBackgroundImageAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(bufferedImage31);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape13 = textBlock5.calculateBounds(graphics2D6, (float) 900000L, (float) 1900, textBlockAnchor9, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape21 = textBlock5.calculateBounds(graphics2D14, (float) 1, (float) 1560409200000L, textBlockAnchor17, (float) (short) -1, (float) (byte) 0, (double) 40);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity27 = new org.jfree.chart.entity.XYItemEntity(shape21, xYDataset22, (int) '#', (-16646144), "", "");
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Color color31 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.centerRange((double) 7);
        java.awt.Stroke stroke35 = dateAxis32.getTickMarkStroke();
        org.jfree.chart.text.TextBlock textBlock37 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape45 = textBlock37.calculateBounds(graphics2D38, (float) 900000L, (float) 1900, textBlockAnchor41, 0.5f, (-1.0f), (double) 2);
        java.awt.Stroke stroke46 = null;
        java.awt.Paint paint47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = October", "TextAnchor.CENTER", "#020000", "", false, shape21, false, paint29, false, (java.awt.Paint) color31, stroke35, false, shape45, stroke46, paint47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle20.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle20.getItemContainer();
        java.awt.Paint paint23 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean24 = legendTitle20.equals((java.lang.Object) paint23);
        org.jfree.chart.block.BlockContainer blockContainer25 = legendTitle20.getWrapper();
        jFreeChart18.addLegend(legendTitle20);
        java.lang.Object obj27 = jFreeChart18.getTextAntiAlias();
        java.awt.Stroke stroke28 = jFreeChart18.getBorderStroke();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(blockContainer25);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo5, point2D6, false);
        java.lang.String str9 = polarPlot0.getPlotType();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator(0, (int) (byte) 100, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range12 = barRenderer3D0.findRangeBounds(categoryDataset11);
        barRenderer3D0.setShadowVisible(true);
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean19 = xYStepRenderer17.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke20 = xYStepRenderer17.getBaseOutlineStroke();
        polarPlot16.setAngleGridlineStroke(stroke20);
        java.awt.Paint paint22 = polarPlot16.getRadiusGridlinePaint();
        barRenderer3D0.setSeriesPaint((int) 'a', paint22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer3D0.getBaseNegativeItemLabelPosition();
        double double25 = itemLabelPosition24.getAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        xYStepRenderer0.setAutoPopulateSeriesShape(false);
        boolean boolean18 = xYStepRenderer0.getItemCreateEntity(0, 40, true);
        java.awt.Paint paint22 = xYStepRenderer0.getItemPaint(7, (int) ' ', true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = combinedDomainXYPlot23.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.centerRange((double) 7);
        java.awt.Stroke stroke29 = dateAxis26.getTickMarkStroke();
        combinedDomainXYPlot23.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        combinedDomainXYPlot23.setDomainZeroBaselineVisible(false);
        xYStepRenderer0.setPlot((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color1 = java.awt.Color.red;
        boolean boolean2 = pieLabelLinkStyle0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font1 = xYStepRenderer0.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 1, xYURLGenerator3);
        java.awt.Shape shape5 = xYStepRenderer0.getLegendLine();
        java.awt.Paint paint6 = null;
        xYStepRenderer0.setBasePaint(paint6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot7.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D22.setAutoPopulateSeriesStroke(true);
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D22, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double29 = barRenderer3D28.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D30 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = barRenderer3D30.getLegendItemLabelGenerator();
        barRenderer3D28.setLegendItemToolTipGenerator(categorySeriesLabelGenerator31);
        categoryPlot7.setRenderer(7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint35 = barRenderer3D28.lookupSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraintType.RANGE");
        categoryAxis3D1.setUpperMargin((double) 1.0f);
        categoryAxis3D1.setTickMarkInsideLength((float) (byte) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        java.awt.Paint paint4 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint5 = standardChartTheme1.getDomainGridlinePaint();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean12 = xYStepRenderer8.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        boolean boolean15 = xYStepRenderer8.equals((java.lang.Object) dateRange14);
        java.awt.Paint paint17 = xYStepRenderer8.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("", font7, paint17);
        java.awt.Font font19 = labelBlock18.getFont();
        standardChartTheme1.setRegularFont(font19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        xYSeries3.setDescription("Other");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double8 = xYSeriesCollection6.getDomainUpperBound(true);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState13 = null;
        xYItemRendererState12.setCrosshairState(xYCrosshairState13);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState15 = null;
        xYItemRendererState12.setCrosshairState(xYCrosshairState15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYItemRendererState12.endSeriesPass(xYDataset17, 0, 15, 40, (int) (short) 100, 128);
        boolean boolean24 = xYItemRendererState12.getProcessVisibleItemsOnly();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedDomainXYPlot7.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.centerRange((double) 7);
        java.awt.Stroke stroke13 = dateAxis10.getTickMarkStroke();
        combinedDomainXYPlot7.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedDomainXYPlot7.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder19 = timeSeriesCollection18.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot25.setBackgroundPaint(paint26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot25.zoomRangeAxes((double) 10.0f, plotRenderingInfo29, point2D30, false);
        boolean boolean33 = timeSeriesCollection18.hasListener((java.util.EventListener) categoryPlot25);
        combinedDomainXYPlot7.setDataset(6, (org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        timeSeriesCollection18.removeAllSeries();
        java.util.List list36 = timeSeriesCollection18.getSeries();
        try {
            java.lang.String str38 = standardXYSeriesLabelGenerator5.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection18, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(domainOrder19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot11 = categoryPlot8.getParent();
        java.awt.Paint paint12 = categoryPlot8.getDomainCrosshairPaint();
        piePlot3D2.setLabelShadowPaint(paint12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color15 = color14.darker();
        float[] floatArray20 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray21 = color15.getComponents(floatArray20);
        piePlot3D2.setLabelBackgroundPaint((java.awt.Paint) color15);
        boolean boolean23 = strokeMap0.equals((java.lang.Object) piePlot3D2);
        java.lang.Comparable comparable24 = null;
        try {
            java.awt.Stroke stroke25 = strokeMap0.getStroke(comparable24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        int int1 = polarPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis();
        logAxis3.configure();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        java.util.Date date15 = dateRange14.getLowerDate();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color18 = java.awt.Color.darkGray;
        boolean boolean19 = plotOrientation17.equals((java.lang.Object) color18);
        int int20 = year16.compareTo((java.lang.Object) plotOrientation17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation12, plotOrientation17);
        axisCollection2.add((org.jfree.chart.axis.Axis) logAxis3, rectangleEdge21);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) logAxis3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.centerRange((double) (-1));
        categoryPlot5.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace13, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setBaseShapesVisible(true);
        java.awt.Font font10 = null;
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color14, (float) '4', textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = null;
        java.awt.Shape shape25 = textBlock17.calculateBounds(graphics2D18, (float) 100L, (float) 1, textBlockAnchor21, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape25, "hi!");
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, (-1.0d), (double) 5);
        boolean boolean31 = xYStepRenderer0.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.addException((long) 2);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange9);
        java.util.Date date11 = dateRange10.getLowerDate();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        java.util.Date date17 = dateRange16.getLowerDate();
        boolean boolean18 = segmentedTimeline8.containsDomainRange(date14, date17);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segmentedTimeline0.getSegment(date17);
        boolean boolean22 = segment19.contained((long) 31, (long) (byte) 10);
        long long23 = segment19.getSegmentEnd();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(segment19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 899999L + "'", long23 == 899999L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        xYSeries3.clear();
        double double5 = xYSeries3.getMinX();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19, false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setPlotArea(false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle18.getPadding();
        categoryPlot7.setInsets(rectangleInsets19, true);
        java.lang.Object obj22 = categoryPlot7.clone();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot7.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection42.setIntervalWidth((double) 100);
        int int46 = xYSeriesCollection42.getItemCount(0);
        int int48 = xYSeriesCollection42.indexOf((java.lang.Comparable) "Combined_Domain_XYPlot");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        polarPlot0.setRadiusGridlinesVisible(false);
        java.awt.Paint paint6 = polarPlot0.getBackgroundPaint();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection7.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D13);
        java.awt.Paint paint15 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot14.setBackgroundPaint(paint15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.zoomRangeAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        boolean boolean22 = timeSeriesCollection7.hasListener((java.util.EventListener) categoryPlot14);
        float float23 = categoryPlot14.getBackgroundImageAlpha();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26, false);
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26, true);
        java.awt.Stroke stroke31 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        java.awt.Paint paint4 = piePlot3D0.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        piePlot3D0.setDataset(pieDataset5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1900, xYToolTipGenerator8, xYURLGenerator9);
        boolean boolean11 = xYAreaRenderer10.getPlotArea();
        java.lang.Object obj12 = null;
        boolean boolean13 = xYAreaRenderer10.equals(obj12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.centerRange((double) 7);
        java.awt.Stroke stroke18 = dateAxis15.getTickMarkStroke();
        boolean boolean19 = dateAxis15.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange20);
        dateAxis15.setRange((org.jfree.data.Range) dateRange21);
        org.jfree.data.Range range23 = dateAxis15.getDefaultAutoRange();
        java.awt.Paint paint24 = dateAxis15.getTickLabelPaint();
        xYAreaRenderer10.setLegendTextPaint((int) (short) 0, paint24);
        piePlot3D0.setBackgroundPaint(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedDomainXYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedDomainXYPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.centerRange((double) 7);
        java.awt.Stroke stroke17 = dateAxis14.getTickMarkStroke();
        combinedDomainXYPlot11.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        combinedDomainXYPlot11.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.centerRange((double) 7);
        java.awt.Stroke stroke25 = dateAxis22.getTickMarkStroke();
        dateAxis22.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot11.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font31 = polarPlot30.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        polarPlot30.rendererChanged(rendererChangeEvent32);
        java.lang.String str34 = polarPlot30.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D39 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D39);
        java.awt.Paint paint41 = dateAxis37.getAxisLinePaint();
        java.awt.Stroke stroke42 = dateAxis37.getAxisLineStroke();
        polarPlot30.setAngleGridlineStroke(stroke42);
        combinedDomainXYPlot11.setRangeMinorGridlineStroke(stroke42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        combinedDomainXYPlot11.panDomainAxes((double) (byte) 1, plotRenderingInfo46, point2D47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot11.setDomainAxisLocation(1900, axisLocation50);
        boolean boolean52 = combinedDomainXYPlot0.equals((java.lang.Object) axisLocation50);
        java.awt.Paint paint53 = combinedDomainXYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot5.getRendererForDataset(categoryDataset6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation(0);
        categoryPlot5.setDomainAxisLocation(axisLocation15, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        int int7 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge((int) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        java.lang.String str2 = standardXYToolTipGenerator0.getFormatString();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, xYURLGenerator3);
        boolean boolean7 = xYStepRenderer4.getItemShapeVisible(1, 2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardXYToolTipGenerator0.getXDateFormat();
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        piePlot3D0.setLabelLinkMargin((double) 1560495599999L);
        piePlot3D0.setMaximumLabelWidth((double) '4');
        piePlot3D0.setSimpleLabels(true);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot17 = categoryPlot14.getParent();
        java.awt.Paint paint18 = categoryPlot14.getDomainCrosshairPaint();
        piePlot3D8.setLabelShadowPaint(paint18);
        org.jfree.chart.StandardChartTheme standardChartTheme21 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle22 = standardChartTheme21.getLabelLinkStyle();
        piePlot3D8.setLabelLinkStyle(pieLabelLinkStyle22);
        piePlot3D0.setLabelLinkStyle(pieLabelLinkStyle22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        dateAxis0.setRange((org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = dateAxis0.getDefaultAutoRange();
        dateAxis0.setRangeAboutValue((double) 43629L, 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        boolean boolean10 = combinedDomainXYPlot0.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double44 = xYSeriesCollection42.getRangeLowerBound(false);
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange45);
        java.util.Date date47 = dateRange46.getLowerDate();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color50 = java.awt.Color.darkGray;
        boolean boolean51 = plotOrientation49.equals((java.lang.Object) color50);
        int int52 = year48.compareTo((java.lang.Object) plotOrientation49);
        int int53 = xYSeriesCollection42.indexOf((java.lang.Comparable) year48);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        java.awt.geom.Point2D point2D2 = crosshairState1.getAnchor();
        crosshairState1.setCrosshairDistance((double) (-2208927600000L));
        org.junit.Assert.assertNull(point2D2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape16 = textBlock0.calculateBounds(graphics2D9, (float) 1, (float) 1560409200000L, textBlockAnchor12, (float) (short) -1, (float) (byte) 0, (double) 40);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font18 = xYStepRenderer17.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYStepRenderer17.setSeriesURLGenerator((int) (short) 1, xYURLGenerator20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj23 = textTitle22.clone();
        boolean boolean24 = xYStepRenderer17.equals((java.lang.Object) textTitle22);
        org.jfree.chart.plot.XYPlot xYPlot25 = xYStepRenderer17.getPlot();
        boolean boolean26 = textBlock0.equals((java.lang.Object) xYPlot25);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYPlot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer3D0.getSeriesURLGenerator(5);
        barRenderer3D0.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Font font12 = xYStepRenderer6.getItemLabelFont((int) (short) 1, 0, true);
        boolean boolean13 = xYStepRenderer6.getDrawOutlines();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double16 = barRenderer3D15.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = barRenderer3D17.getLegendItemLabelGenerator();
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        barRenderer3D15.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer3D15.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        xYStepRenderer6.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition23, false);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.Object obj27 = null;
        boolean boolean28 = textAnchor26.equals(obj27);
        boolean boolean29 = itemLabelPosition23.equals((java.lang.Object) boolean28);
        barRenderer3D0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition23, false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection42.setIntervalWidth((double) 100);
        try {
            int[] intArray48 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection42, (int) (short) 1, 0.08d, (double) (-2208927600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        boolean boolean25 = jFreeChart18.isBorderVisible();
        jFreeChart18.setBackgroundImageAlpha((float) (byte) 0);
        java.util.List list28 = jFreeChart18.getSubtitles();
        jFreeChart18.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D10);
        java.awt.Paint paint12 = dateAxis8.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = dateTickUnit13.getRollUnitType();
        dateAxis8.setTickUnit(dateTickUnit13, true, false);
        org.jfree.chart.axis.Timeline timeline18 = dateAxis8.getTimeline();
        dateAxis8.centerRange((double) 1L);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.centerRange((double) 7);
        java.awt.Stroke stroke24 = dateAxis21.getTickMarkStroke();
        dateAxis21.zoomRange(0.0d, 0.0d);
        double double28 = dateAxis21.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D33);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot34.getRowRenderingOrder();
        dateAxis21.setPlot((org.jfree.chart.plot.Plot) categoryPlot34);
        dateAxis21.setLowerBound((double) 1.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str41 = dateTickUnit39.valueToString((double) 2);
        java.util.Date date42 = dateAxis21.calculateLowestVisibleTickValue(dateTickUnit39);
        java.util.Date date43 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit39);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment44 = segmentedTimeline0.getSegment(date43);
        segment44.moveIndexToStart();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertNotNull(timeline18);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "12/31/69 4:00 PM" + "'", str41.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(segment44);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.addException((long) 2);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange9);
        java.util.Date date11 = dateRange10.getLowerDate();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        java.util.Date date17 = dateRange16.getLowerDate();
        boolean boolean18 = segmentedTimeline8.containsDomainRange(date14, date17);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segmentedTimeline0.getSegment(date17);
        boolean boolean22 = segment19.contained((long) 31, (long) (byte) 10);
        boolean boolean23 = segment19.inExcludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(segment19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double44 = xYSeriesCollection42.getRangeLowerBound(false);
        double double46 = xYSeriesCollection42.getDomainLowerBound(true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener47 = null;
        xYSeriesCollection42.removeChangeListener(datasetChangeListener47);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 9.5d + "'", double46 == 9.5d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset(0.12d);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        boolean boolean8 = categoryPlot7.isNotify();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getLegendItemGraphicPadding();
        double double13 = rectangleInsets12.getRight();
        double double15 = rectangleInsets12.extendHeight(Double.NaN);
        categoryPlot7.setAxisOffset(rectangleInsets12);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        boolean boolean6 = categoryPlot5.isNotify();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.centerRange((double) (-1));
        categoryPlot5.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer13.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean17 = xYStepRenderer13.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange18);
        boolean boolean20 = xYStepRenderer13.equals((java.lang.Object) dateRange19);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer21.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean25 = xYStepRenderer21.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange26);
        boolean boolean28 = xYStepRenderer21.equals((java.lang.Object) dateRange27);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange19, (org.jfree.data.Range) dateRange27);
        java.lang.Object obj30 = null;
        boolean boolean31 = dateRange27.equals(obj30);
        dateAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange27, false, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font13 = polarPlot12.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot12.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = polarPlot12.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        java.awt.Stroke stroke24 = dateAxis19.getAxisLineStroke();
        polarPlot12.setAngleGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font11, (org.jfree.chart.plot.Plot) polarPlot12, false);
        boolean boolean28 = jFreeChart27.isNotify();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        textTitle29.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart27.setTitle(textTitle29);
        boolean boolean34 = jFreeChart27.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart27, "", "13-June-2019");
        java.awt.Color color41 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        jFreeChart27.setBorderPaint((java.awt.Paint) color41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            jFreeChart27.draw(graphics2D43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle18.getPadding();
        categoryPlot7.setInsets(rectangleInsets19, true);
        java.lang.Object obj22 = categoryPlot7.clone();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font25 = xYStepRenderer24.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = null;
        xYStepRenderer24.setSeriesURLGenerator((int) (short) 1, xYURLGenerator27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        boolean boolean31 = xYStepRenderer24.equals((java.lang.Object) textTitle29);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray35 = legendTitle34.getSources();
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle34.getBounds();
        java.lang.Object obj37 = null;
        java.lang.Object obj38 = textTitle29.draw(graphics2D32, rectangle2D36, obj37);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        categoryPlot7.draw(graphics2D23, rectangle2D36, point2D39, plotState40, plotRenderingInfo41);
        java.awt.Paint paint43 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic44 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D36, paint43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, (double) (short) 0, plotRenderingInfo12, point2D13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot20.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange23);
        java.util.Date date25 = dateRange24.getLowerDate();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color28 = java.awt.Color.darkGray;
        boolean boolean29 = plotOrientation27.equals((java.lang.Object) color28);
        int int30 = year26.compareTo((java.lang.Object) plotOrientation27);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation27);
        categoryPlot5.setRangeAxisLocation(axisLocation22, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder35 = timeSeriesCollection34.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D40 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D40);
        java.awt.Paint paint42 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot41.setBackgroundPaint(paint42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot41.zoomRangeAxes((double) 10.0f, plotRenderingInfo45, point2D46, false);
        boolean boolean49 = timeSeriesCollection34.hasListener((java.util.EventListener) categoryPlot41);
        float float50 = categoryPlot41.getBackgroundImageAlpha();
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot41.setBackgroundPaint((java.awt.Paint) color51);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis53 };
        categoryPlot41.setDomainAxes(categoryAxisArray54);
        java.awt.Stroke stroke56 = categoryPlot41.getDomainCrosshairStroke();
        categoryPlot5.setRangeZeroBaselineStroke(stroke56);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(domainOrder35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.5f + "'", float50 == 0.5f);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1900, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getPlotArea();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYAreaRenderer3.equals(obj5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = xYAreaRenderer3.getGradientTransformer();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot15.getRowRenderingOrder();
        categoryPlot5.setRowRenderingOrder(sortOrder16);
        int int18 = categoryPlot5.getRendererCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("#020000");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        periodAxis1.setRange((org.jfree.data.Range) dateRange2, false, false);
        periodAxis1.setMinorTickMarkOutsideLength(10.0f);
        periodAxis1.setMinorTickMarkOutsideLength((float) 0L);
        boolean boolean11 = periodAxis1.equals((java.lang.Object) 60000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("October", "#020000", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer2.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean6 = xYStepRenderer2.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange7);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) dateRange8);
        java.awt.Paint paint11 = xYStepRenderer2.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font1, paint11);
        java.lang.String str13 = labelBlock12.getURLText();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer15.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean19 = xYStepRenderer15.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange20);
        boolean boolean22 = xYStepRenderer15.equals((java.lang.Object) dateRange21);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer23 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer23.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean27 = xYStepRenderer23.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        boolean boolean30 = xYStepRenderer23.equals((java.lang.Object) dateRange29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (org.jfree.data.Range) dateRange29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint31.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint31.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D34 = labelBlock12.arrange(graphics2D14, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        xYSeries3.setDescription("Other");
        xYSeries3.add((double) (short) -1, (java.lang.Number) 4.0d, true);
        xYSeries3.add(0.0d, (double) (short) 1, false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        jFreeChart18.setTextAntiAlias(true);
        try {
            org.jfree.chart.title.Title title22 = jFreeChart18.getSubtitle((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = dateTickUnit7.getRollUnitType();
        dateAxis2.setTickUnit(dateTickUnit7, true, false);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis2.getTimeline();
        try {
            dateAxis2.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertNotNull(timeline12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot7.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D22.setAutoPopulateSeriesStroke(true);
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D22, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = null;
        try {
            categoryPlot7.setDomainGridlinePosition(categoryAnchor27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer3D0.getSeriesURLGenerator(5);
        barRenderer3D0.setBaseSeriesVisible(false);
        double double5 = barRenderer3D0.getLowerClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer3D0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = dateTickUnit4.getRollUnitType();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) dateTickUnit4, "13-June-2019", "UnitType.RELATIVE");
        int int9 = timeSeriesCollection2.indexOf(timeSeries8);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot3D1.getURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.lang.String str2 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getDomainAxisEdge((-1));
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedDomainXYPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined_Domain_XYPlot" + "'", str2.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape16 = textBlock0.calculateBounds(graphics2D9, (float) 1, (float) 1560409200000L, textBlockAnchor12, (float) (short) -1, (float) (byte) 0, (double) 40);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange((double) 7);
        java.awt.Stroke stroke20 = dateAxis17.getTickMarkStroke();
        dateAxis17.zoomRange(0.0d, 0.0d);
        double double24 = dateAxis17.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        double double28 = dateAxis27.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D29 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot30.getRowRenderingOrder();
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) categoryPlot30);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot30.getLegendItems();
        boolean boolean34 = textBlockAnchor12.equals((java.lang.Object) categoryPlot30);
        categoryPlot30.clearRangeAxes();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (byte) 1, plotRenderingInfo35, point2D36);
        boolean boolean38 = combinedDomainXYPlot0.isDomainPannable();
        int int39 = combinedDomainXYPlot0.getWeight();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setSeriesLinesVisible(0, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        try {
            xYStepRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = combinedDomainXYPlot0.getDomainMarkers(layer2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.add(xYPlot4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder43 = timeSeriesCollection42.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        double double47 = dateAxis46.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D48 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D48);
        java.awt.Paint paint50 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot49.setBackgroundPaint(paint50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot49.zoomRangeAxes((double) 10.0f, plotRenderingInfo53, point2D54, false);
        boolean boolean57 = timeSeriesCollection42.hasListener((java.util.EventListener) categoryPlot49);
        float float58 = categoryPlot49.getBackgroundImageAlpha();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot49.setBackgroundPaint((java.awt.Paint) color59);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent61 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot49);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot49.getDomainAxisLocation();
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation62);
        boolean boolean64 = combinedDomainXYPlot0.isNotify();
        boolean boolean65 = combinedDomainXYPlot0.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(domainOrder43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean4 = xYStepRenderer2.equals((java.lang.Object) 0.0f);
        java.awt.Font font8 = xYStepRenderer2.getItemLabelFont((int) (short) 1, 0, true);
        boolean boolean9 = xYStepRenderer2.getDrawOutlines();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double12 = barRenderer3D11.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer3D13.getLegendItemLabelGenerator();
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        barRenderer3D11.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer3D11.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        xYStepRenderer2.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition19, false);
        org.jfree.chart.text.TextAnchor textAnchor22 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.axis.TickType tickType23 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick29 = new org.jfree.chart.axis.NumberTick(tickType23, (double) 644288400000L, "DateTickUnit[DateTickUnitType.DAY, 1]", textAnchor26, textAnchor27, (double) 100L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor22, textAnchor26, (-2.2089276E12d));
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE10" + "'", str1.equals("ItemLabelAnchor.OUTSIDE10"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(tickType23);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        categoryPlot7.mapDatasetToDomainAxis(1, (-16646144));
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) axisCollection0, jFreeChart2, (int) (short) 1, 28);
        chartProgressEvent5.setPercent(0);
        java.lang.Object obj8 = chartProgressEvent5.getSource();
        int int9 = chartProgressEvent5.getPercent();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        boolean boolean2 = polarPlot0.isRangeZoomable();
        boolean boolean3 = polarPlot0.isAngleLabelsVisible();
        polarPlot0.setAngleGridlinesVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getLegendItemGraphicPadding();
        double double11 = rectangleInsets10.getRight();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean14 = xYStepRenderer12.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke15 = xYStepRenderer12.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator17 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer12.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator17);
        xYStepRenderer12.setBaseCreateEntities(true);
        boolean boolean22 = xYStepRenderer12.isSeriesVisibleInLegend((int) (short) -1);
        boolean boolean23 = xYStepRenderer12.getDrawSeriesLineAsPath();
        java.awt.Paint paint27 = xYStepRenderer12.getItemFillPaint(7, 500, true);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter29 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D31 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double32 = barRenderer3D31.getUpperClip();
        boolean boolean34 = barRenderer3D31.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = barRenderer3D31.getLegendItems();
        boolean boolean36 = barRenderer3D31.getAutoPopulateSeriesPaint();
        barRenderer3D31.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj43 = textTitle42.clone();
        textTitle42.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str46 = textTitle42.getURLText();
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle42.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        gradientBarPainter29.paintBar(graphics2D30, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D31, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D47, rectangleEdge48);
        org.jfree.chart.plot.XYPlot xYPlot50 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset51 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState54 = xYStepRenderer12.initialise(graphics2D28, rectangle2D47, xYPlot50, (org.jfree.data.xy.XYDataset) defaultXYDataset51, plotRenderingInfo53);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets10.createOutsetRectangle(rectangle2D47);
        try {
            polarPlot0.drawBackground(graphics2D6, rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNotNull(xYItemRendererState54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = dateTickUnit7.getRollUnitType();
        dateAxis2.setTickUnit(dateTickUnit7, true, false);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis2.getTimeline();
        dateAxis2.configure();
        java.awt.Paint paint14 = dateAxis2.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertNotNull(timeline12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        xYStepRenderer0.setAutoPopulateSeriesShape(false);
        try {
            xYStepRenderer0.setSeriesLinesVisible((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.clearSectionOutlineStrokes(false);
        piePlot3D0.setLabelLinkMargin((double) 500);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.clearSectionOutlineStrokes(false);
        double double17 = piePlot3D0.getDepthFactor();
        boolean boolean18 = piePlot3D0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.12d + "'", double17 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Combined_Domain_XYPlot");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.centerRange((double) 7);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        boolean boolean5 = dateAxis1.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange6);
        dateAxis1.setRange((org.jfree.data.Range) dateRange7, false, true);
        long long11 = dateRange7.getLowerMillis();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer12.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean16 = xYStepRenderer12.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange17);
        boolean boolean19 = xYStepRenderer12.equals((java.lang.Object) dateRange18);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer20.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean24 = xYStepRenderer20.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange25);
        boolean boolean27 = xYStepRenderer20.equals((java.lang.Object) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, (org.jfree.data.Range) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint28.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = rectangleConstraint28.getHeightConstraintType();
        java.lang.String str31 = lengthConstraintType30.toString();
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("#020000");
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange();
        periodAxis34.setRange((org.jfree.data.Range) dateRange35, false, false);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer39.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean43 = xYStepRenderer39.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange44 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange44);
        boolean boolean46 = xYStepRenderer39.equals((java.lang.Object) dateRange45);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer47 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer47.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean51 = xYStepRenderer47.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange52 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange52);
        boolean boolean54 = xYStepRenderer47.equals((java.lang.Object) dateRange53);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange45, (org.jfree.data.Range) dateRange53);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = rectangleConstraint55.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType57 = rectangleConstraint55.getHeightConstraintType();
        java.lang.String str58 = lengthConstraintType57.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange7, lengthConstraintType30, (double) (-31507200000L), (org.jfree.data.Range) dateRange35, lengthConstraintType57);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleConstraintType.RANGE" + "'", str31.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint56);
        org.junit.Assert.assertNotNull(lengthConstraintType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RectangleConstraintType.RANGE" + "'", str58.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) (-1));
        java.awt.Shape shape3 = dateAxis0.getRightArrow();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setAutoRangeMinimumSize((double) 12);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis0.getTimeline();
        dateAxis0.setTickMarkOutsideLength((float) (-2649600000L));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeline7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 6, "{0}: ({1}, {2})", "Other", true);
        logFormat5.setMinimumIntegerDigits((int) (byte) 10);
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Number number10 = logFormat5.parse("October", parsePosition9);
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat5, dateFormat11);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        dateAxis0.zoomRange(0.0d, 0.0d);
        double double7 = dateAxis0.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot13.getRowRenderingOrder();
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraintType.RANGE");
        categoryAxis3D18.setUpperMargin((double) 1.0f);
        categoryAxis3D18.setTickMarkInsideLength((float) (byte) 100);
        categoryPlot13.setDomainAxis(100, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18);
        categoryAxis3D18.clearCategoryLabelToolTips();
        java.awt.Font font26 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) (-16777216));
        int int27 = categoryAxis3D18.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("October", "#020000", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.KeyToGroupMap keyToGroupMap17 = null;
        try {
            org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, keyToGroupMap17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        int int2 = defaultPieDataset0.getIndex((java.lang.Comparable) 10.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) 10.0d, 0.0d);
        try {
            defaultPieDataset0.insertValue((int) 'a', (java.lang.Comparable) "MINOR", (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Comparable comparable2 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Comparable comparable5 = multiplePiePlot1.getAggregatedItemsKey();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 15, 1.0E-5d };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray12, numberArray16, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("October", "#020000", numberArray21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset22);
        multiplePiePlot1.setDataset(categoryDataset22);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Other" + "'", comparable2.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("DatasetRenderingOrder.REVERSE", "UnitType.ABSOLUTE", "Combined_Domain_XYPlot", "1969");
        boolean boolean6 = library4.equals((java.lang.Object) 28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection42.setIntervalWidth((double) 100);
        int int46 = xYSeriesCollection42.getItemCount(0);
        double double48 = xYSeriesCollection42.getRangeLowerBound(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        boolean boolean2 = textBlock0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer38 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font39 = xYStepRenderer38.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = null;
        xYStepRenderer38.setSeriesURLGenerator((int) (short) 1, xYURLGenerator41);
        java.awt.Shape shape43 = xYStepRenderer38.getLegendLine();
        combinedRangeXYPlot21.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        combinedRangeXYPlot21.setFixedRangeAxisSpace(axisSpace45, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder49 = timeSeriesCollection48.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        double double53 = dateAxis52.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D54 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D54);
        java.awt.Paint paint56 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot55.setBackgroundPaint(paint56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot55.zoomRangeAxes((double) 10.0f, plotRenderingInfo59, point2D60, false);
        boolean boolean63 = timeSeriesCollection48.hasListener((java.util.EventListener) categoryPlot55);
        float float64 = categoryPlot55.getBackgroundImageAlpha();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot55.setBackgroundPaint((java.awt.Paint) color65);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot55);
        combinedRangeXYPlot21.plotChanged(plotChangeEvent67);
        double double69 = combinedRangeXYPlot21.getGap();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(domainOrder49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.5f + "'", float64 == 0.5f);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 5.0d + "'", double69 == 5.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean9 = combinedDomainXYPlot8.isRangeGridlinesVisible();
        java.awt.Stroke stroke10 = combinedDomainXYPlot8.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) dateRange6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer8.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean12 = xYStepRenderer8.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange13);
        boolean boolean15 = xYStepRenderer8.equals((java.lang.Object) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder();
        boolean boolean21 = dateRange18.equals((java.lang.Object) blockBorder20);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer22.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean26 = xYStepRenderer22.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange27);
        boolean boolean29 = xYStepRenderer22.equals((java.lang.Object) dateRange28);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer30.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean34 = xYStepRenderer30.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange35);
        boolean boolean37 = xYStepRenderer30.equals((java.lang.Object) dateRange36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, (org.jfree.data.Range) dateRange36);
        boolean boolean39 = dateRange18.intersects((org.jfree.data.Range) dateRange28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint16.toRangeHeight((org.jfree.data.Range) dateRange18);
        java.lang.String str41 = dateRange18.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str41.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        piePlot3D0.setCircular(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedDomainXYPlot0.getRangeAxisEdge();
        java.lang.String str11 = rectangleEdge10.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.LEFT" + "'", str11.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        combinedRangeXYPlot21.setGap(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        boolean boolean7 = categoryPlot6.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker((-16646144), marker10, layer11);
        java.awt.Paint paint13 = categoryPlot6.getRangeGridlinePaint();
        piePlot3D0.setLabelOutlinePaint(paint13);
        piePlot3D0.clearSectionOutlineStrokes(false);
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionPaint();
        java.awt.Paint paint18 = piePlot3D0.getShadowPaint();
        boolean boolean19 = piePlot3D0.isNotify();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = dateTickUnit0.getRollUnitType();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) dateTickUnit0, "13-June-2019", "UnitType.RELATIVE");
        java.lang.Object obj5 = timeSeries4.clone();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (byte) 1, plotRenderingInfo35, point2D36);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = combinedDomainXYPlot0.removeDomainMarker(marker38, layer39);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.lang.String str2 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getDomainAxisEdge((-1));
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation(0);
        combinedDomainXYPlot0.setDomainAxisLocation((int) 'a', axisLocation13, true);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedDomainXYPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined_Domain_XYPlot" + "'", str2.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(legendItemCollection16);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.configure();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font3 = polarPlot2.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        polarPlot2.rendererChanged(rendererChangeEvent4);
        polarPlot2.setRadiusGridlinesVisible(false);
        polarPlot2.setForegroundAlpha((float) (-16646144));
        boolean boolean10 = logAxis0.hasListener((java.util.EventListener) polarPlot2);
        java.lang.Object obj11 = polarPlot2.clone();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape17 = xYStepRenderer16.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean20 = xYStepRenderer18.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke21 = xYStepRenderer18.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D26 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D26);
        java.awt.Paint paint28 = dateAxis24.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape17, stroke21, paint28);
        java.text.AttributedString attributedString30 = legendItem29.getAttributedLabel();
        java.awt.Stroke stroke31 = legendItem29.getOutlineStroke();
        polarPlot2.setAngleGridlineStroke(stroke31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = polarPlot2.getLegendItems();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(attributedString30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(legendItemCollection33);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.awt.Paint paint9 = categoryPlot5.getDomainCrosshairPaint();
        java.awt.Image image10 = categoryPlot5.getBackgroundImage();
        boolean boolean11 = categoryPlot5.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace13, false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedDomainXYPlot16.getRangeAxisLocation();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color19 = color18.darker();
        float[] floatArray24 = new float[] { (-2208927600000L), 4, 6, 5 };
        float[] floatArray25 = color19.getComponents(floatArray24);
        combinedDomainXYPlot16.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = combinedDomainXYPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double29 = barRenderer3D28.getUpperClip();
        boolean boolean31 = barRenderer3D28.isSeriesVisible(0);
        barRenderer3D28.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = barRenderer3D28.getToolTipGenerator(0, (int) (byte) 100, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = barRenderer3D28.getLegendItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.data.Range range40 = barRenderer3D28.findRangeBounds(categoryDataset39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = barRenderer3D28.getLegendItems();
        java.lang.Object obj42 = legendItemCollection41.clone();
        combinedDomainXYPlot16.setFixedLegendItems(legendItemCollection41);
        categoryPlot5.setFixedLegendItems(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNotNull(legendItemCollection41);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Comparable comparable2 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Comparable comparable5 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Paint paint6 = multiplePiePlot1.getAggregatedItemsPaint();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "Other" + "'", comparable2.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape5 = xYStepRenderer4.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean8 = xYStepRenderer6.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke9 = xYStepRenderer6.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape5, stroke9, paint16);
        java.awt.Font font18 = legendItem17.getLabelFont();
        boolean boolean19 = legendItem17.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Paint paint2 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Paint paint6 = null;
        xYStepRenderer0.setSeriesPaint((int) (short) 10, paint6, true);
        java.awt.Stroke stroke10 = xYStepRenderer0.lookupSeriesStroke((int) (short) 0);
        boolean boolean11 = xYStepRenderer0.getUseFillPaint();
        java.awt.Paint paint13 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint(2019, paint13, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis();
        logAxis5.configure();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        java.util.Date date17 = dateRange16.getLowerDate();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color20 = java.awt.Color.darkGray;
        boolean boolean21 = plotOrientation19.equals((java.lang.Object) color20);
        int int22 = year18.compareTo((java.lang.Object) plotOrientation19);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation14, plotOrientation19);
        axisCollection4.add((org.jfree.chart.axis.Axis) logAxis5, rectangleEdge23);
        java.awt.Paint paint25 = logAxis5.getTickLabelPaint();
        legendTitle1.setBackgroundPaint(paint25);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer38 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font39 = xYStepRenderer38.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = null;
        xYStepRenderer38.setSeriesURLGenerator((int) (short) 1, xYURLGenerator41);
        java.awt.Shape shape43 = xYStepRenderer38.getLegendLine();
        combinedRangeXYPlot21.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        combinedRangeXYPlot21.setFixedRangeAxisSpace(axisSpace45, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder49 = timeSeriesCollection48.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        double double53 = dateAxis52.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D54 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D54);
        java.awt.Paint paint56 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot55.setBackgroundPaint(paint56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot55.zoomRangeAxes((double) 10.0f, plotRenderingInfo59, point2D60, false);
        boolean boolean63 = timeSeriesCollection48.hasListener((java.util.EventListener) categoryPlot55);
        float float64 = categoryPlot55.getBackgroundImageAlpha();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot55.setBackgroundPaint((java.awt.Paint) color65);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot55);
        combinedRangeXYPlot21.plotChanged(plotChangeEvent67);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = null;
        try {
            combinedRangeXYPlot21.setDomainAxes(valueAxisArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(domainOrder49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.5f + "'", float64 == 0.5f);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        boolean boolean19 = jFreeChart18.isNotify();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = textTitle20.clone();
        textTitle20.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart18.setTitle(textTitle20);
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart18.createBufferedImage(15, (int) (short) 1, (double) 2, 3.0d, chartRenderingInfo30);
        org.jfree.chart.text.TextBlock textBlock33 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape41 = textBlock33.calculateBounds(graphics2D34, (float) 900000L, (float) 1900, textBlockAnchor37, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape49 = textBlock33.calculateBounds(graphics2D42, (float) 1, (float) 1560409200000L, textBlockAnchor45, (float) (short) -1, (float) (byte) 0, (double) 40);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj51 = textTitle50.clone();
        java.lang.String str52 = textTitle50.getText();
        textTitle50.setMaximumLinesToDisplay(1900);
        org.jfree.chart.entity.TitleEntity titleEntity55 = new org.jfree.chart.entity.TitleEntity(shape49, (org.jfree.chart.title.Title) textTitle50);
        try {
            jFreeChart18.addSubtitle((int) (short) 10, (org.jfree.chart.title.Title) textTitle50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(bufferedImage31);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 12, stroke2);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        timeSeriesCollection8.validateObject();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor14 = timeSeriesCollection8.getXPosition();
        java.util.List list15 = null;
        try {
            org.jfree.data.Range range17 = timeSeriesCollection8.getDomainBounds(list15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertNotNull(timePeriodAnchor14);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot21.getRangeAxisEdge(28);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection40 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder41 = timeSeriesCollection40.getDomainOrder();
        java.util.List list42 = timeSeriesCollection40.getSeries();
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection40);
        double double45 = timeSeriesCollection40.getDomainLowerBound(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = combinedRangeXYPlot21.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection40);
        java.util.List list47 = combinedRangeXYPlot21.getSubplots();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(domainOrder41);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("Combined Range XYPlot");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) 2);
        java.lang.Class class3 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange4);
        java.util.Date date6 = dateRange5.getLowerDate();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date6, timeZone8);
        java.util.Date date10 = dateTickUnit0.rollDate(date6);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis11.setTickUnit(dateTickUnit18);
        java.util.Date date20 = dateAxis11.getMaximumDate();
        java.lang.String str21 = dateTickUnit0.dateToString(date20);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "12/31/69 4:00 PM" + "'", str21.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = combinedDomainXYPlot0.getDomainMarkers(layer2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.add(xYPlot4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder43 = timeSeriesCollection42.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        double double47 = dateAxis46.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D48 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D48);
        java.awt.Paint paint50 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot49.setBackgroundPaint(paint50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot49.zoomRangeAxes((double) 10.0f, plotRenderingInfo53, point2D54, false);
        boolean boolean57 = timeSeriesCollection42.hasListener((java.util.EventListener) categoryPlot49);
        float float58 = categoryPlot49.getBackgroundImageAlpha();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot49.setBackgroundPaint((java.awt.Paint) color59);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent61 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot49);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot49.getDomainAxisLocation();
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation62);
        combinedDomainXYPlot0.setGap((double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(domainOrder43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        int int1 = xYStepRenderer0.getPassCount();
        java.lang.Object obj2 = xYStepRenderer0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline2.getStartTime();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder5 = timeSeriesCollection4.getDomainOrder();
        java.util.List list6 = timeSeriesCollection4.getSeries();
        segmentedTimeline2.addExceptions(list6);
        axisState0.setTicks(list6);
        axisState0.setCursor((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208927600000L) + "'", long3 == (-2208927600000L));
        org.junit.Assert.assertNotNull(domainOrder5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries3.addOrUpdate(10.0d, 2.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection10.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D16);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot17.setBackgroundPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot17.zoomRangeAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        boolean boolean25 = timeSeriesCollection10.hasListener((java.util.EventListener) categoryPlot17);
        float float26 = categoryPlot17.getBackgroundImageAlpha();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str31 = dateTickUnit29.valueToString((double) 2);
        java.lang.Class class32 = null;
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange33);
        java.util.Date date35 = dateRange34.getLowerDate();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date35, timeZone37);
        java.util.Date date39 = dateTickUnit29.rollDate(date35);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) dateTickUnit29);
        xYSeries3.setKey((java.lang.Comparable) dateTickUnit29);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection42.setIntervalWidth((double) 100);
        try {
            org.jfree.data.xy.XYSeries xYSeries46 = xYSeriesCollection42.getSeries(40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem9);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12/31/69 4:00 PM" + "'", str31.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        java.lang.Comparable comparable8 = categoryPlot5.getDomainCrosshairRowKey();
        boolean boolean9 = categoryPlot5.isDomainPannable();
        categoryPlot5.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean5 = legendTitle1.equals((java.lang.Object) paint4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle1.getWrapper();
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = legendTitle1.arrange(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(blockContainer6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        java.lang.Class class3 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange4);
        java.util.Date date6 = dateRange5.getLowerDate();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date6, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
        boolean boolean11 = segmentedTimeline0.containsDomainValue(date6);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace8);
        double double10 = combinedDomainXYPlot0.getRangeCrosshairValue();
        boolean boolean11 = combinedDomainXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getRangeAxisLocation(0);
        categoryPlot5.setRangeAxisLocation((int) ' ', axisLocation17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot5.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = standardChartTheme22.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = standardChartTheme22.getAxisOffset();
        java.awt.Paint paint25 = standardChartTheme22.getThermometerPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter26 = standardChartTheme22.getXYBarPainter();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = standardChartTheme22.getDrawingSupplier();
        categoryPlot5.setDrawingSupplier(drawingSupplier27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraintType.RANGE");
        categoryAxis3D30.setUpperMargin((double) 1.0f);
        categoryAxis3D30.setTickMarkInsideLength((float) (byte) 100);
        categoryAxis3D30.configure();
        java.util.List list36 = categoryPlot5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D30);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot5.setDomainCrosshairStroke(stroke37);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(xYBarPainter26);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        java.util.Date date3 = segmentedTimeline0.getDate((long) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long5 = segmentedTimeline4.getStartTime();
        long long8 = segmentedTimeline4.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean9 = segmentedTimeline4.getAdjustForDaylightSaving();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType18 = dateTickUnit17.getRollUnitType();
        dateAxis12.setTickUnit(dateTickUnit17, true, false);
        org.jfree.chart.axis.Timeline timeline22 = dateAxis12.getTimeline();
        dateAxis12.centerRange((double) 1L);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 7);
        java.awt.Stroke stroke28 = dateAxis25.getTickMarkStroke();
        dateAxis25.zoomRange(0.0d, 0.0d);
        double double32 = dateAxis25.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D37 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D37);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        dateAxis25.setPlot((org.jfree.chart.plot.Plot) categoryPlot38);
        dateAxis25.setLowerBound((double) 1.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str45 = dateTickUnit43.valueToString((double) 2);
        java.util.Date date46 = dateAxis25.calculateLowestVisibleTickValue(dateTickUnit43);
        java.util.Date date47 = dateAxis12.calculateLowestVisibleTickValue(dateTickUnit43);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment48 = segmentedTimeline4.getSegment(date47);
        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
        int int50 = segmentedTimeline4.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208927600000L) + "'", long5 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnitType18);
        org.junit.Assert.assertNotNull(timeline22);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "12/31/69 4:00 PM" + "'", str45.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(segment48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 96 + "'", int50 == 96);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        java.lang.Comparable comparable8 = categoryPlot5.getDomainCrosshairRowKey();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double10 = barRenderer3D9.getUpperClip();
        boolean boolean12 = barRenderer3D9.isSeriesVisible(0);
        barRenderer3D9.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke15 = barRenderer3D9.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double17 = barRenderer3D16.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = barRenderer3D18.getLegendItemLabelGenerator();
        barRenderer3D16.setLegendItemToolTipGenerator(categorySeriesLabelGenerator19);
        barRenderer3D16.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer3D16.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D9.setBasePositiveItemLabelPosition(itemLabelPosition24, false);
        java.awt.Font font29 = null;
        java.awt.Color color33 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font29, (java.awt.Paint) color33, (float) '4', textMeasurer35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor40 = null;
        java.awt.Shape shape44 = textBlock36.calculateBounds(graphics2D37, (float) 100L, (float) 1, textBlockAnchor40, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape44, "hi!");
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        chartEntity46.setArea(shape47);
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        org.jfree.chart.entity.TitleEntity titleEntity51 = new org.jfree.chart.entity.TitleEntity(shape47, (org.jfree.chart.title.Title) legendTitle50);
        barRenderer3D9.setLegendShape(100, shape47);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        dateAxis55.centerRange((double) 7);
        java.awt.Stroke stroke58 = dateAxis55.getTickMarkStroke();
        boolean boolean59 = dateAxis55.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange60 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange61 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange60);
        dateAxis55.setRange((org.jfree.data.Range) dateRange61, false, true);
        dateAxis55.setLowerMargin(0.0d);
        org.jfree.chart.plot.Marker marker67 = null;
        org.jfree.chart.LegendItemSource legendItemSource68 = null;
        org.jfree.chart.title.LegendTitle legendTitle69 = new org.jfree.chart.title.LegendTitle(legendItemSource68);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray70 = legendTitle69.getSources();
        java.awt.geom.Rectangle2D rectangle2D71 = legendTitle69.getBounds();
        barRenderer3D9.drawRangeMarker(graphics2D53, categoryPlot54, (org.jfree.chart.axis.ValueAxis) dateAxis55, marker67, rectangle2D71);
        int int73 = categoryPlot5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3D0.getURLGenerator();
        piePlot3D0.setLabelLinksVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape12 = xYStepRenderer11.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean15 = xYStepRenderer13.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke16 = xYStepRenderer13.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape12, stroke16, paint23);
        boolean boolean25 = legendItem24.isShapeFilled();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) -1);
        legendItem24.setLine(shape27);
        java.awt.Paint paint29 = legendItem24.getLinePaint();
        piePlot3D0.setLabelLinkPaint(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        org.jfree.data.xy.XYDataItem xYDataItem5 = null;
        try {
            xYSeries3.add(xYDataItem5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setLegendItemPaint(paint3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot7.removeDomainMarker(marker19, layer20);
        java.awt.Color color22 = java.awt.Color.BLUE;
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color22);
        double[] doubleArray28 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray31 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray34 = new double[] { (-2208927600000L), (short) 1 };
        double[] doubleArray37 = new double[] { (-2208927600000L), (short) 1 };
        double[][] doubleArray38 = new double[][] { doubleArray28, doubleArray31, doubleArray34, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("1969", "index.html", doubleArray38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot7.getRendererForDataset(categoryDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot7.getRangeAxis(4);
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNull(valueAxis42);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        multiplePiePlot1.setLimit((double) (short) 10);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedDomainXYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.centerRange((double) 7);
        java.awt.Stroke stroke11 = dateAxis8.getTickMarkStroke();
        combinedDomainXYPlot5.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedDomainXYPlot5.setFixedDomainAxisSpace(axisSpace13);
        double double15 = combinedDomainXYPlot5.getRangeCrosshairValue();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) combinedDomainXYPlot5);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot9 = categoryPlot6.getParent();
        java.awt.Paint paint10 = categoryPlot6.getDomainCrosshairPaint();
        piePlot3D0.setLabelShadowPaint(paint10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot3D0.setShadowPaint(paint12);
        piePlot3D0.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getYear();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.RED;
        try {
            org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("1969", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("#020000");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        periodAxis1.setRange((org.jfree.data.Range) dateRange2, false, false);
        periodAxis1.setMinorTickMarkOutsideLength(10.0f);
        float float8 = periodAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Combined Range XYPlot");
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("#020000");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("UnitType.ABSOLUTE", class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = combinedDomainXYPlot0.getDomainMarkers(layer2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot13 = categoryPlot10.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.panRangeAxes((double) 40, plotRenderingInfo15, point2D16);
        categoryPlot10.setCrosshairDatasetIndex(2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        java.util.Date date30 = dateRange29.getLowerDate();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color33 = java.awt.Color.darkGray;
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) color33);
        int int35 = year31.compareTo((java.lang.Object) plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation32);
        categoryPlot10.setDomainAxisLocation(axisLocation27, false);
        xYPlot4.setDomainAxisLocation(axisLocation27, false);
        combinedDomainXYPlot0.add(xYPlot4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder43 = timeSeriesCollection42.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        double double47 = dateAxis46.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D48 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D48);
        java.awt.Paint paint50 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot49.setBackgroundPaint(paint50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot49.zoomRangeAxes((double) 10.0f, plotRenderingInfo53, point2D54, false);
        boolean boolean57 = timeSeriesCollection42.hasListener((java.util.EventListener) categoryPlot49);
        float float58 = categoryPlot49.getBackgroundImageAlpha();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot49.setBackgroundPaint((java.awt.Paint) color59);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent61 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot49);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot49.getDomainAxisLocation();
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation62);
        boolean boolean64 = combinedDomainXYPlot0.isNotify();
        org.jfree.chart.plot.Marker marker65 = null;
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = combinedDomainXYPlot0.removeDomainMarker(marker65, layer66);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(domainOrder43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setDefaultEntityRadius((-16646144));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardXYSeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getYear();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//        java.awt.Shape shape10 = xYStepRenderer9.getLegendLine();
//        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//        boolean boolean13 = xYStepRenderer11.equals((java.lang.Object) 0.0f);
//        java.awt.Stroke stroke14 = xYStepRenderer11.getBaseOutlineStroke();
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
//        double double18 = dateAxis17.getLowerMargin();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
//        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D19);
//        java.awt.Paint paint21 = dateAxis17.getAxisLinePaint();
//        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape10, stroke14, paint21);
//        boolean boolean23 = legendItem22.isShapeFilled();
//        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) -1);
//        legendItem22.setLine(shape25);
//        int int27 = day0.compareTo((java.lang.Object) shape25);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(shape10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(shape25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape13 = xYStepRenderer12.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean16 = xYStepRenderer14.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke17 = xYStepRenderer14.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D22);
        java.awt.Paint paint24 = dateAxis20.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape13, stroke17, paint24);
        int int26 = legendItem25.getDatasetIndex();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color28 = color27.darker();
        legendItem25.setOutlinePaint((java.awt.Paint) color28);
        categoryPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color28);
        java.awt.Color color31 = color28.brighter();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color31);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
//        double double5 = dateAxis4.getLowerMargin();
//        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
//        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
//        categoryPlot7.setBackgroundPaint(paint8);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        java.awt.geom.Point2D point2D12 = null;
//        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
//        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
//        float float16 = categoryPlot7.getBackgroundImageAlpha();
//        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19, false);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getFirstMillisecond();
//        int int26 = day24.getYear();
//        java.lang.String str27 = day24.toString();
//        long long28 = day24.getLastMillisecond();
//        long long29 = day24.getFirstMillisecond();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getFirstMillisecond();
//        int int32 = day30.getYear();
//        java.lang.String str33 = day30.toString();
//        long long34 = day30.getLastMillisecond();
//        long long35 = day30.getFirstMillisecond();
//        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = October", (org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.Class class37 = periodAxis36.getMajorTickTimePeriodClass();
//        categoryPlot7.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) periodAxis36);
//        java.awt.Stroke stroke39 = periodAxis36.getMinorTickMarkStroke();
//        org.junit.Assert.assertNotNull(domainOrder1);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(stroke39);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getLegendItemGraphicPadding();
        double double6 = rectangleInsets5.getRight();
        double double8 = rectangleInsets5.extendHeight(Double.NaN);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter9 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double12 = barRenderer3D11.getUpperClip();
        boolean boolean14 = barRenderer3D11.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = barRenderer3D11.getLegendItems();
        boolean boolean16 = barRenderer3D11.getAutoPopulateSeriesPaint();
        barRenderer3D11.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj23 = textTitle22.clone();
        textTitle22.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str26 = textTitle22.getURLText();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        gradientBarPainter9.paintBar(graphics2D10, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D11, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D27, rectangleEdge28);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets5.createInsetRectangle(rectangle2D27);
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 10, 0.2d, rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator(0, (int) (byte) 100, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range12 = barRenderer3D0.findRangeBounds(categoryDataset11);
        barRenderer3D0.setSeriesItemLabelsVisible(40, (java.lang.Boolean) false);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj18 = textTitle17.clone();
        java.lang.String str19 = textTitle17.getText();
        java.awt.Font font20 = textTitle17.getFont();
        barRenderer3D0.setLegendTextFont(7, font20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator(0, (int) (byte) 100, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range12 = barRenderer3D0.findRangeBounds(categoryDataset11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = barRenderer3D0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double15 = barRenderer3D14.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D16 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = barRenderer3D16.getLegendItemLabelGenerator();
        barRenderer3D14.setLegendItemToolTipGenerator(categorySeriesLabelGenerator17);
        barRenderer3D0.setLegendItemLabelGenerator(categorySeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator17);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer2.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean6 = xYStepRenderer2.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange7);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) dateRange8);
        java.awt.Paint paint11 = xYStepRenderer2.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font1, paint11);
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        labelBlock12.setPaint(paint13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test410");
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Other");
//        java.lang.Object obj2 = standardPieSectionLabelGenerator1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getFirstMillisecond();
//        int int5 = day3.getYear();
//        java.lang.String str6 = day3.toString();
//        boolean boolean7 = standardPieSectionLabelGenerator1.equals((java.lang.Object) str6);
//        java.lang.Object obj8 = standardPieSectionLabelGenerator1.clone();
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//        boolean boolean10 = combinedDomainXYPlot9.isRangeGridlinesVisible();
//        java.awt.Stroke stroke11 = combinedDomainXYPlot9.getRangeZeroBaselineStroke();
//        boolean boolean12 = standardPieSectionLabelGenerator1.equals((java.lang.Object) combinedDomainXYPlot9);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(stroke11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getPadding();
        double double3 = legendTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getPadding();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean4 = xYStepRenderer0.getDrawSeriesLineAsPath();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder9 = timeSeriesCollection8.getDomainOrder();
        org.jfree.data.DomainOrder domainOrder10 = timeSeriesCollection8.getDomainOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepRenderer0.initialise(graphics2D5, rectangle2D6, xYPlot7, (org.jfree.data.xy.XYDataset) timeSeriesCollection8, plotRenderingInfo11);
        try {
            double double15 = timeSeriesCollection8.getYValue((int) (byte) 0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(domainOrder10);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.String str2 = standardXYToolTipGenerator1.getFormatString();
        java.lang.String str3 = standardXYToolTipGenerator1.getFormatString();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator4);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator6);
        boolean boolean8 = xYStepAreaRenderer7.getShapesVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}: ({1}, {2})" + "'", str3.equals("{0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        java.lang.Object obj5 = null;
        boolean boolean6 = polarPlot0.equals(obj5);
        java.lang.Object obj7 = polarPlot0.clone();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot8.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        combinedDomainXYPlot8.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedDomainXYPlot8.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D18.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint21 = barRenderer3D18.getBasePaint();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D26 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D26);
        java.awt.Paint paint28 = dateAxis24.getAxisLinePaint();
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint28);
        combinedDomainXYPlot8.setNoDataMessagePaint(paint28);
        polarPlot0.setRadiusGridlinePaint(paint28);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setBaseCreateEntities(true);
        boolean boolean10 = xYStepRenderer0.isSeriesVisibleInLegend((int) (short) -1);
        xYStepRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYStepRenderer0.getSeriesURLGenerator(7);
        java.awt.Paint paint15 = xYStepRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean2 = xYStepRenderer0.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke3 = xYStepRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        xYStepRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean12 = xYStepRenderer10.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke13 = xYStepRenderer10.getBaseOutlineStroke();
        xYStepRenderer0.setSeriesStroke(2, stroke13, false);
        java.io.ObjectOutputStream objectOutputStream16 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke13, objectOutputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        multiplePiePlot1.setLimit((double) (short) 10);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 2958465);
        double double7 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        dateAxis0.setRange((org.jfree.data.Range) dateRange6, false, true);
        int int10 = dateAxis0.getMinorTickCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(15, xYItemLabelGenerator5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 0, (double) 15, 900000.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) '4', textMeasurer7);
        org.jfree.chart.text.TextLine textLine9 = null;
        textBlock8.addLine(textLine9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlock textBlock14 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, (float) 900000L, (float) 1900, textBlockAnchor18, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape30 = textBlock14.calculateBounds(graphics2D23, (float) 1, (float) 1560409200000L, textBlockAnchor26, (float) (short) -1, (float) (byte) 0, (double) 40);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor34 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock14.draw(graphics2D31, (float) 128, (float) 100L, textBlockAnchor34, (float) (short) 10, (float) 1969, (double) 10);
        try {
            textBlock8.draw(graphics2D11, (float) ' ', (float) 3, textBlockAnchor34, (float) (-2208927600000L), 0.0f, (double) 644288400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(textBlockAnchor34);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        try {
            java.lang.Number number18 = timeSeriesCollection0.getStartY((int) (short) 10, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 900000L, (float) 1900, textBlockAnchor4, 0.5f, (-1.0f), (double) 2);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font11 = polarPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font13 = polarPlot12.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot12.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = polarPlot12.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D21);
        java.awt.Paint paint23 = dateAxis19.getAxisLinePaint();
        java.awt.Stroke stroke24 = dateAxis19.getAxisLineStroke();
        polarPlot12.setAngleGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font11, (org.jfree.chart.plot.Plot) polarPlot12, false);
        boolean boolean28 = jFreeChart27.isNotify();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj30 = textTitle29.clone();
        textTitle29.setMaximumLinesToDisplay((int) (byte) 0);
        jFreeChart27.setTitle(textTitle29);
        boolean boolean34 = jFreeChart27.isBorderVisible();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape8, jFreeChart27, "", "13-June-2019");
        java.lang.Object obj38 = jFreeChartEntity37.clone();
        java.lang.String str39 = jFreeChartEntity37.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "JFreeChartEntity: tooltip = " + "'", str39.equals("JFreeChartEntity: tooltip = "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (short) 100);
        java.awt.Font font6 = null;
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, (java.awt.Paint) color10, (float) '4', textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 100L, (float) 1, textBlockAnchor17, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle23.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer25 = legendTitle23.getItemContainer();
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean27 = legendTitle23.equals((java.lang.Object) paint26);
        org.jfree.chart.block.BlockContainer blockContainer28 = legendTitle23.getWrapper();
        org.jfree.chart.entity.TitleEntity titleEntity31 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) legendTitle23, "DatasetRenderingOrder.REVERSE", "");
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D32.setLabelPadding(rectangleInsets33);
        piePlot3D32.setDepthFactor((double) 1L);
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle23, (java.lang.Object) piePlot3D32);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(blockContainer25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(blockContainer28);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        jFreeChart18.setTextAntiAlias(true);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart18.getLegend();
        jFreeChart18.removeLegend();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(legendTitle21);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (byte) 1, plotRenderingInfo35, point2D36);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D38 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double39 = barRenderer3D38.getUpperClip();
        boolean boolean41 = barRenderer3D38.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = barRenderer3D38.getLegendItems();
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection42);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation44 = null;
        try {
            combinedDomainXYPlot0.addAnnotation(xYAnnotation44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(legendItemCollection42);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) (short) 100, (int) (short) 10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, false);
        java.awt.Paint paint11 = barRenderer3D0.getBasePaint();
        java.awt.Paint paint13 = barRenderer3D0.lookupSeriesFillPaint(1900);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D0.setLabelPadding(rectangleInsets1);
        boolean boolean3 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3D0.getURLGenerator();
        java.awt.Paint paint5 = piePlot3D0.getBaseSectionPaint();
        java.awt.Font font6 = piePlot3D0.getLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) (short) 100, (int) (short) 10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, false);
        boolean boolean11 = barRenderer3D0.getShadowsVisible();
        double double12 = barRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        java.lang.Comparable comparable8 = categoryPlot5.getDomainCrosshairRowKey();
        boolean boolean9 = categoryPlot5.isDomainPannable();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer3D0.getURLGenerator(0, (int) (short) 0, false);
        java.awt.Shape shape9 = barRenderer3D0.getBaseShape();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 900000L, (float) 1900, textBlockAnchor8, 0.5f, (-1.0f), (double) 2);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape20 = textBlock4.calculateBounds(graphics2D13, (float) 1, (float) 1560409200000L, textBlockAnchor16, (float) (short) -1, (float) (byte) 0, (double) 40);
        dateAxis0.setRightArrow(shape20);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle25.getSources();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle25.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean30 = rectangleEdge28.equals((java.lang.Object) lengthAdjustmentType29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets23.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType29, lengthAdjustmentType31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = dateAxis0.valueToJava2D(5.0d, rectangle2D32, rectangleEdge33);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset0.removeSeries((java.lang.Comparable) (byte) -1);
        try {
            int[] intArray6 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) defaultXYDataset0, 28, 90.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
        boolean boolean4 = xYSeries3.getAutoSort();
        xYSeries3.setNotify(true);
        double double7 = xYSeries3.getMinX();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        java.util.Date date2 = dateRange1.getLowerDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color5 = java.awt.Color.darkGray;
        boolean boolean6 = plotOrientation4.equals((java.lang.Object) color5);
        int int7 = year3.compareTo((java.lang.Object) plotOrientation4);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, number8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("Combined_Domain_XYPlot");
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "March" + "'", str1.equals("March"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("1969");
        projectInfo0.setName("1.2.0-pre");
        java.lang.String str5 = projectInfo0.getLicenceText();
        projectInfo0.setVersion("DatasetRenderingOrder.REVERSE");
        projectInfo0.addOptionalLibrary("JFreeChartEntity: tooltip = ");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = standardChartTheme1.getAxisOffset();
        java.awt.Paint paint4 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint5 = standardChartTheme1.getDomainGridlinePaint();
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = standardChartTheme7.getLabelLinkStyle();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        standardChartTheme7.setCrosshairPaint(paint9);
        java.awt.Paint paint11 = standardChartTheme7.getChartBackgroundPaint();
        standardChartTheme1.setGridBandAlternatePaint(paint11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        int int3 = xYStepRenderer2.getPassCount();
        combinedDomainXYPlot0.setRenderer(7, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer3D0.getSeriesURLGenerator(5);
        barRenderer3D0.setBaseSeriesVisible(false);
        double double5 = barRenderer3D0.getLowerClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer3D0.getItemLabelGenerator(15, 40, false);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle5.getSources();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle5.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean10 = rectangleEdge8.equals((java.lang.Object) lengthAdjustmentType9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets3.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType9, lengthAdjustmentType11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        java.awt.geom.Rectangle2D rectangle2D17 = legendTitle15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean20 = rectangleEdge18.equals((java.lang.Object) lengthAdjustmentType19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets13.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType19, lengthAdjustmentType21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer27.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean31 = xYStepRenderer27.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange32);
        boolean boolean34 = xYStepRenderer27.equals((java.lang.Object) dateRange33);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer35.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean39 = xYStepRenderer35.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange41 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange40);
        boolean boolean42 = xYStepRenderer35.equals((java.lang.Object) dateRange41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, (org.jfree.data.Range) dateRange41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer44.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean48 = xYStepRenderer44.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange49 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange49);
        boolean boolean51 = xYStepRenderer44.equals((java.lang.Object) dateRange50);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer52 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer52.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean56 = xYStepRenderer52.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange57 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange58 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange57);
        boolean boolean59 = xYStepRenderer52.equals((java.lang.Object) dateRange58);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange50, (org.jfree.data.Range) dateRange58);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer61 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer61.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean65 = xYStepRenderer61.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange66 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange67 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange66);
        boolean boolean68 = xYStepRenderer61.equals((java.lang.Object) dateRange67);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer69 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer69.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean73 = xYStepRenderer69.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange74 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange75 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange74);
        boolean boolean76 = xYStepRenderer69.equals((java.lang.Object) dateRange75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange67, (org.jfree.data.Range) dateRange75);
        org.jfree.data.Range range78 = rectangleConstraint77.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange50, range78);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange41, (org.jfree.data.Range) dateRange50);
        double double81 = dateRange50.getCentralValue();
        boolean boolean82 = plotRenderingInfo26.equals((java.lang.Object) double81);
        try {
            org.jfree.chart.axis.AxisState axisState83 = categoryAxis3D0.draw(graphics2D1, (double) 1L, rectangle2D12, rectangle2D22, rectangleEdge23, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.5d + "'", double81 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot5.setBackgroundPaint(paint6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomRangeAxes((double) 10.0f, plotRenderingInfo9, point2D10, false);
        int int13 = categoryPlot5.getRendererCount();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot5.removeDomainMarker(255, marker15, layer16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraintType.RANGE");
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getLegendItemGraphicPadding();
        double double8 = rectangleInsets7.getRight();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean11 = xYStepRenderer9.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke12 = xYStepRenderer9.getBaseOutlineStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYStepRenderer9.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        xYStepRenderer9.setBaseCreateEntities(true);
        boolean boolean19 = xYStepRenderer9.isSeriesVisibleInLegend((int) (short) -1);
        boolean boolean20 = xYStepRenderer9.getDrawSeriesLineAsPath();
        java.awt.Paint paint24 = xYStepRenderer9.getItemFillPaint(7, 500, true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter26 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double29 = barRenderer3D28.getUpperClip();
        boolean boolean31 = barRenderer3D28.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = barRenderer3D28.getLegendItems();
        boolean boolean33 = barRenderer3D28.getAutoPopulateSeriesPaint();
        barRenderer3D28.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj40 = textTitle39.clone();
        textTitle39.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str43 = textTitle39.getURLText();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        gradientBarPainter26.paintBar(graphics2D27, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D28, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D44, rectangleEdge45);
        org.jfree.chart.plot.XYPlot xYPlot47 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset48 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer9.initialise(graphics2D25, rectangle2D44, xYPlot47, (org.jfree.data.xy.XYDataset) defaultXYDataset48, plotRenderingInfo50);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets7.createOutsetRectangle(rectangle2D44);
        org.jfree.chart.axis.AxisCollection axisCollection53 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis();
        logAxis54.configure();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        double double59 = dateAxis58.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D60 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot61.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange64 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange65 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange64);
        java.util.Date date66 = dateRange65.getLowerDate();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color69 = java.awt.Color.darkGray;
        boolean boolean70 = plotOrientation68.equals((java.lang.Object) color69);
        int int71 = year67.compareTo((java.lang.Object) plotOrientation68);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation63, plotOrientation68);
        axisCollection53.add((org.jfree.chart.axis.Axis) logAxis54, rectangleEdge72);
        double double74 = categoryAxis3D1.getCategoryEnd(0, 10, rectangle2D44, rectangleEdge72);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("#020000");
        java.lang.Class class3 = periodAxis2.getAutoRangeTimePeriodClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("DateTickMarkPosition.END", class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(inputStream4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) (-1));
        java.awt.Shape shape3 = dateAxis0.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        boolean boolean10 = categoryPlot9.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot9, "October", "October");
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) (byte) 1, Double.NaN);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        org.jfree.chart.LegendItem legendItem5 = xYAreaRenderer1.getLegendItem(3, 1900);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection6.getDomainOrder();
        java.util.List list8 = timeSeriesCollection6.getSeries();
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range10 = xYAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean13 = combinedDomainXYPlot12.isRangeGridlinesVisible();
        java.lang.String str14 = combinedDomainXYPlot12.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = combinedDomainXYPlot12.getDomainAxisEdge((-1));
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedDomainXYPlot17.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.centerRange((double) 7);
        java.awt.Stroke stroke23 = dateAxis20.getTickMarkStroke();
        combinedDomainXYPlot17.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        dateAxis20.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray30 = legendTitle29.getSources();
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean34 = rectangleEdge32.equals((java.lang.Object) lengthAdjustmentType33);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets27.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType33, lengthAdjustmentType35);
        xYAreaRenderer1.fillRangeGridBand(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (org.jfree.chart.axis.ValueAxis) dateAxis20, rectangle2D36, (double) (byte) -1, 0.08d);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        combinedDomainXYPlot12.setOrientation(plotOrientation40);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(legendItemSourceArray30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(plotOrientation40);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 7);
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        boolean boolean4 = dateAxis0.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange5);
        dateAxis0.setRange((org.jfree.data.Range) dateRange6, false, true);
        boolean boolean10 = dateAxis0.isTickMarksVisible();
        boolean boolean11 = dateAxis0.isNegativeArrowVisible();
        dateAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        polarPlot19.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = polarPlot19.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D28);
        java.awt.Paint paint30 = dateAxis26.getAxisLinePaint();
        java.awt.Stroke stroke31 = dateAxis26.getAxisLineStroke();
        polarPlot19.setAngleGridlineStroke(stroke31);
        combinedDomainXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot0.panDomainAxes((double) (byte) 1, plotRenderingInfo35, point2D36);
        boolean boolean38 = combinedDomainXYPlot0.isDomainPannable();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = combinedDomainXYPlot0.getDomainAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) ' ', "index.html", "PlotEntity: tooltip = October", false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        standardChartTheme1.setCrosshairPaint(paint3);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        boolean boolean3 = barRenderer3D0.isSeriesVisible(0);
        barRenderer3D0.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke6 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double8 = barRenderer3D7.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer3D9.getLegendItemLabelGenerator();
        barRenderer3D7.setLegendItemToolTipGenerator(categorySeriesLabelGenerator10);
        barRenderer3D7.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer3D7.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        int int18 = barRenderer3D0.getPassCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        java.lang.Class class3 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange4);
        java.util.Date date6 = dateRange5.getLowerDate();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date6, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("DateTickUnit[DateTickUnitType.DAY, 1]", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) month10);
        long long12 = month10.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month10.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2649600000L) + "'", long12 == (-2649600000L));
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test459");
//        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
//        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "13-June-2019");
//        strokeMap0.clear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        int int6 = day4.getYear();
//        java.lang.String str7 = day4.toString();
//        long long8 = day4.getLastMillisecond();
//        long long9 = day4.getFirstMillisecond();
//        long long10 = day4.getFirstMillisecond();
//        java.awt.Stroke stroke11 = strokeMap0.getStroke((java.lang.Comparable) long10);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertNull(stroke11);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D6);
        java.awt.Paint paint8 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot7.setBackgroundPaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = timeSeriesCollection0.hasListener((java.util.EventListener) categoryPlot7);
        float float16 = categoryPlot7.getBackgroundImageAlpha();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot7.removeDomainMarker(marker19, layer20);
        java.awt.Color color22 = java.awt.Color.BLUE;
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color22);
        java.awt.Stroke stroke24 = categoryPlot7.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 28, true, true);
//        boolean boolean4 = xYSeries3.getAutoSort();
//        xYSeries3.add((double) 900000L, (java.lang.Number) (-1L), false);
//        double double9 = xYSeries3.getMaxX();
//        int int10 = xYSeries3.getMaximumItemCount();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getFirstMillisecond();
//        int int13 = day11.getYear();
//        java.lang.String str14 = day11.toString();
//        long long15 = day11.getLastMillisecond();
//        long long16 = day11.getFirstMillisecond();
//        xYSeries3.setKey((java.lang.Comparable) day11);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 900000.0d + "'", double9 == 900000.0d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle22.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getLegendItemGraphicPadding();
        java.awt.Color color25 = java.awt.Color.BLUE;
        legendTitle22.setItemPaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getLegendItemGraphicPadding();
        logAxis1.setTickLabelInsets(rectangleInsets27);
        logAxis1.setMinorTickMarkInsideLength((float) (-2208927599993L));
        logAxis1.centerRange((double) 255);
        logAxis1.setTickMarkInsideLength((float) (short) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        java.util.Date date3 = segmentedTimeline0.getDate((long) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long5 = segmentedTimeline4.getStartTime();
        long long8 = segmentedTimeline4.getExceptionSegmentCount((long) '4', (long) (byte) -1);
        boolean boolean9 = segmentedTimeline4.getAdjustForDaylightSaving();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D14);
        java.awt.Paint paint16 = dateAxis12.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType18 = dateTickUnit17.getRollUnitType();
        dateAxis12.setTickUnit(dateTickUnit17, true, false);
        org.jfree.chart.axis.Timeline timeline22 = dateAxis12.getTimeline();
        dateAxis12.centerRange((double) 1L);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 7);
        java.awt.Stroke stroke28 = dateAxis25.getTickMarkStroke();
        dateAxis25.zoomRange(0.0d, 0.0d);
        double double32 = dateAxis25.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D37 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D37);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        dateAxis25.setPlot((org.jfree.chart.plot.Plot) categoryPlot38);
        dateAxis25.setLowerBound((double) 1.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str45 = dateTickUnit43.valueToString((double) 2);
        java.util.Date date46 = dateAxis25.calculateLowestVisibleTickValue(dateTickUnit43);
        java.util.Date date47 = dateAxis12.calculateLowestVisibleTickValue(dateTickUnit43);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment48 = segmentedTimeline4.getSegment(date47);
        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
        segmentedTimeline4.addBaseTimelineExclusions(0L, (long) (byte) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208927600000L) + "'", long5 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(dateTickUnitType18);
        org.junit.Assert.assertNotNull(timeline22);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "12/31/69 4:00 PM" + "'", str45.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(segment48);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        org.jfree.chart.RenderingSource renderingSource3 = chartRenderingInfo1.getRenderingSource();
        org.junit.Assert.assertNull(renderingSource3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 0, "", false);
        int int4 = logFormat3.getMaximumIntegerDigits();
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        java.lang.StringBuffer stringBuffer8 = logFormat3.format((long) 1900, stringBuffer6, fieldPosition7);
        java.lang.String str10 = logFormat3.format(100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 40 + "'", int4 == 40);
        org.junit.Assert.assertNotNull(stringBuffer8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-0.0" + "'", str10.equals("-0.0"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font2 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        java.lang.String str7 = polarPlot3.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
        java.awt.Paint paint14 = dateAxis10.getAxisLinePaint();
        java.awt.Stroke stroke15 = dateAxis10.getAxisLineStroke();
        polarPlot3.setAngleGridlineStroke(stroke15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font2, (org.jfree.chart.plot.Plot) polarPlot3, false);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle20.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle20.getItemContainer();
        java.awt.Paint paint23 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean24 = legendTitle20.equals((java.lang.Object) paint23);
        org.jfree.chart.block.BlockContainer blockContainer25 = legendTitle20.getWrapper();
        jFreeChart18.addLegend(legendTitle20);
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart18.getLegend(5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(blockContainer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(blockContainer25);
        org.junit.Assert.assertNull(legendTitle28);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = dateTickUnit0.getRollUnitType();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) dateTickUnit0, "13-June-2019", "UnitType.RELATIVE");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries4.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        java.awt.Paint paint6 = dateAxis2.getAxisLinePaint();
        java.awt.Stroke stroke7 = dateAxis2.getAxisLineStroke();
        java.awt.Shape shape8 = dateAxis2.getLeftArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean11 = legendItemEntity9.equals((java.lang.Object) combinedDomainXYPlot10);
        org.jfree.data.general.Dataset dataset12 = legendItemEntity9.getDataset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dataset12);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) '4', textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = null;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, (float) 100L, (float) 1, textBlockAnchor12, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape16, "hi!");
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        chartEntity18.setArea(shape19);
        java.lang.String str21 = chartEntity18.getURLText();
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("#020000");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = standardChartTheme23.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = standardChartTheme23.getAxisOffset();
        boolean boolean26 = chartEntity18.equals((java.lang.Object) standardChartTheme23);
        java.awt.Font font28 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer29.setSeriesLinesVisible(100, (java.lang.Boolean) true);
        boolean boolean33 = xYStepRenderer29.getDrawSeriesLineAsPath();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange34);
        boolean boolean36 = xYStepRenderer29.equals((java.lang.Object) dateRange35);
        java.awt.Paint paint38 = xYStepRenderer29.lookupSeriesOutlinePaint(7);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("", font28, paint38);
        java.lang.String str40 = labelBlock39.getURLText();
        java.awt.Font font41 = labelBlock39.getFont();
        standardChartTheme23.setSmallFont(font41);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor(0.0f, (float) (short) 1, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) '4', textMeasurer7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = null;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, (float) 100L, (float) 1, textBlockAnchor12, (float) 0L, (float) (byte) 0, 2.0d);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle18.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle18.getItemContainer();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean22 = legendTitle18.equals((java.lang.Object) paint21);
        org.jfree.chart.block.BlockContainer blockContainer23 = legendTitle18.getWrapper();
        org.jfree.chart.entity.TitleEntity titleEntity26 = new org.jfree.chart.entity.TitleEntity(shape16, (org.jfree.chart.title.Title) legendTitle18, "DatasetRenderingOrder.REVERSE", "");
        java.awt.Graphics2D graphics2D27 = null;
        try {
            org.jfree.chart.util.Size2D size2D28 = legendTitle18.arrange(graphics2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(blockContainer20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(blockContainer23);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle2.getSources();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle2.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean7 = rectangleEdge5.equals((java.lang.Object) lengthAdjustmentType6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType6, lengthAdjustmentType8);
        double double11 = rectangleInsets0.trimWidth((double) 0.0f);
        double double12 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-8.0d) + "'", double11 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        boolean boolean1 = combinedDomainXYPlot0.isRangeGridlinesVisible();
        java.lang.String str2 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = combinedDomainXYPlot0.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D8);
        boolean boolean10 = categoryPlot9.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot9.getDatasetRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.centerRange((double) 7);
        dateAxis13.setVerticalTickLabels(false);
        categoryPlot9.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis13, true);
        int int20 = combinedDomainXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D25 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D25);
        java.awt.Paint paint27 = dateAxis23.getAxisLinePaint();
        dateAxis23.setMinorTickMarkInsideLength((float) 40);
        org.jfree.data.Range range30 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined_Domain_XYPlot" + "'", str2.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(range30);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        barRenderer3D0.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer3D0.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) ' ', 100.0d, plotRenderingInfo17, point2D18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        int int21 = categoryPlot14.indexOf(categoryDataset20);
        barRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint4 = xYStepRenderer2.lookupLegendTextPaint(192);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Object obj1 = defaultXYDataset0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double4 = barRenderer3D3.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D5.getLegendItemLabelGenerator();
        barRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        barRenderer3D3.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer3D3.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition11.getRotationAnchor();
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition11, false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter17 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double20 = barRenderer3D19.getUpperClip();
        boolean boolean22 = barRenderer3D19.isSeriesVisible(0);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = barRenderer3D19.getLegendItems();
        boolean boolean24 = barRenderer3D19.getAutoPopulateSeriesPaint();
        barRenderer3D19.setBaseSeriesVisible(true);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj31 = textTitle30.clone();
        textTitle30.setMaximumLinesToDisplay((int) (byte) 0);
        java.lang.String str34 = textTitle30.getURLText();
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        gradientBarPainter17.paintBar(graphics2D18, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D19, 100, 12, false, (java.awt.geom.RectangularShape) rectangle2D35, rectangleEdge36);
        try {
            barRenderer3D0.drawOutline(graphics2D15, categoryPlot16, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        java.util.Date date13 = dateRange12.getLowerDate();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color16 = java.awt.Color.darkGray;
        boolean boolean17 = plotOrientation15.equals((java.lang.Object) color16);
        int int18 = year14.compareTo((java.lang.Object) plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation15);
        axisCollection0.add((org.jfree.chart.axis.Axis) logAxis1, rectangleEdge19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedRangeXYPlot21.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.centerRange((double) 7);
        java.awt.Stroke stroke30 = dateAxis27.getTickMarkStroke();
        combinedDomainXYPlot24.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        combinedDomainXYPlot24.setFixedDomainAxisSpace(axisSpace32);
        combinedDomainXYPlot24.setDomainGridlinesVisible(false);
        combinedRangeXYPlot21.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot21.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer38 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font39 = xYStepRenderer38.getBaseItemLabelFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = null;
        xYStepRenderer38.setSeriesURLGenerator((int) (short) 1, xYURLGenerator41);
        java.awt.Shape shape43 = xYStepRenderer38.getLegendLine();
        combinedRangeXYPlot21.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer38);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = xYStepRenderer38.getLegendItems();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(legendItemCollection45);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) 900000L);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font7 = polarPlot6.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        polarPlot6.rendererChanged(rendererChangeEvent8);
        java.lang.String str10 = polarPlot6.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        java.awt.Paint paint17 = dateAxis13.getAxisLinePaint();
        java.awt.Stroke stroke18 = dateAxis13.getAxisLineStroke();
        polarPlot6.setAngleGridlineStroke(stroke18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("RectangleConstraintType.RANGE", font5, (org.jfree.chart.plot.Plot) polarPlot6, false);
        jFreeChart21.setTextAntiAlias(true);
        jFreeChart21.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity26 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        polarPlot0.setRadiusGridlinesVisible(false);
        java.awt.Paint paint6 = polarPlot0.getBackgroundPaint();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection7.getDomainOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D13);
        java.awt.Paint paint15 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot14.setBackgroundPaint(paint15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.zoomRangeAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        boolean boolean22 = timeSeriesCollection7.hasListener((java.util.EventListener) categoryPlot14);
        float float23 = categoryPlot14.getBackgroundImageAlpha();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26, false);
        polarPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26, true);
        java.awt.Shape shape31 = defaultDrawingSupplier26.getNextShape();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        java.util.Date date2 = dateRange1.getLowerDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, Double.NaN);
        int int8 = year3.getYear();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D13);
        java.awt.Paint paint15 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot14.setBackgroundPaint(paint15);
        categoryPlot14.setForegroundAlpha((float) (byte) 100);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color20 = java.awt.Color.darkGray;
        boolean boolean21 = plotOrientation19.equals((java.lang.Object) color20);
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font23 = polarPlot22.getNoDataMessageFont();
        java.awt.Paint paint24 = polarPlot22.getBackgroundPaint();
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color20, paint24);
        categoryPlot14.setRangeCrosshairPaint((java.awt.Paint) color20);
        int int27 = year3.compareTo((java.lang.Object) color20);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.centerRange((double) 7);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        dateAxis11.zoomRange(0.0d, 0.0d);
        combinedDomainXYPlot0.setRangeAxis(40, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis11.getTickMarkPosition();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Combined_Domain_XYPlot");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0, "Other", true);
        numberAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 0, "", false);
        boolean boolean4 = logFormat3.isParseIntegerOnly();
        try {
            java.math.RoundingMode roundingMode5 = logFormat3.getRoundingMode();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation(0);
        org.jfree.chart.plot.Plot plot8 = categoryPlot5.getParent();
        java.util.List list9 = categoryPlot5.getAnnotations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D4.getLegendItemURLGenerator();
        java.awt.Paint paint7 = barRenderer3D4.getBaseFillPaint();
        barRenderer3D4.setBaseCreateEntities(true, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = combinedDomainXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.centerRange((double) 7);
        java.awt.Stroke stroke6 = dateAxis3.getTickMarkStroke();
        combinedDomainXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot0.setFixedDomainAxisSpace(axisSpace8);
        combinedDomainXYPlot0.setDomainGridlinesVisible(false);
        int int12 = combinedDomainXYPlot0.getWeight();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset13 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset13);
        java.awt.Stroke stroke15 = piePlot3D14.getLabelOutlineStroke();
        boolean boolean16 = combinedDomainXYPlot0.equals((java.lang.Object) piePlot3D14);
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot3D14.setBaseSectionPaint(paint17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        piePlot3D14.setLegendLabelURLGenerator(pieURLGenerator19);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        barRenderer3D0.setMaximumBarWidth((double) (-1.0f));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer3D0.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        barRenderer3D0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        barRenderer3D0.setSeriesToolTipGenerator(0, categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getUpperClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer3D0.getURLGenerator(0, (int) (short) 0, false);
        double double9 = barRenderer3D0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) (short) 100, (int) (short) 10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer3D0.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape13 = xYStepRenderer12.getLegendLine();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean16 = xYStepRenderer14.equals((java.lang.Object) 0.0f);
        java.awt.Stroke stroke17 = xYStepRenderer14.getBaseOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLowerMargin();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D22);
        java.awt.Paint paint24 = dateAxis20.getAxisLinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "index.html", "Other", "Other", shape13, stroke17, paint24);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = legendItem25.getFillPaintTransformer();
        barRenderer3D0.setGradientPaintTransformer(gradientPaintTransformer26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        barRenderer3D0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition29, false);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
    }
}

