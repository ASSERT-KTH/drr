import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        long long5 = month0.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        try {
//            timeSeries3.setMaximumItemAge((-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        int int7 = month4.getMonth();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = month4.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        try {
            java.lang.Number number8 = timeSeries3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        try {
//            java.lang.Number number16 = timeSeries3.getValue((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        int int10 = year4.compareTo((java.lang.Object) month6);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem(regularTimePeriod7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date10, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        try {
            timeSeries3.delete((int) (short) 10, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560150000000L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "");
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
//        try {
//            timeSeries3.add(timeSeriesDataItem15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = null;
        try {
            timeSeries10.add(timeSeriesDataItem25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries3.add(regularTimePeriod9, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date10, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        int int10 = year4.compareTo((java.lang.Object) month6);
        java.lang.String str11 = year4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries3.removeChangeListener(seriesChangeListener22);
        try {
            timeSeries3.delete((int) (byte) 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries10.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = month4.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getLastMillisecond();
        long long3 = month1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.previous();
        org.jfree.data.time.Year year5 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        long long7 = year5.getSerialIndex();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) '4', year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.addOrUpdate(timeSeriesDataItem22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        org.jfree.data.time.Year year10 = month6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        boolean boolean10 = month6.equals((java.lang.Object) (byte) -1);
        long long11 = month6.getFirstMillisecond();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = day1.compareTo((java.lang.Object) month5);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month5, seriesChangeInfo7);
//        org.jfree.data.time.Year year9 = month5.getYear();
//        try {
//            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(9999, year9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = timeSeries3.equals(obj20);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries3.getTimePeriod((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries3.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = null;
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar4 = null;
        try {
            day3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        try {
//            timeSeries3.delete((int) (byte) 100, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        long long15 = month14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 23640L + "'", long15 == 23640L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 2019, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month12.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 15:59:59 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        java.util.Date date4 = month0.getStart();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        double double32 = timeSeries19.getMinY();
        java.util.Collection collection33 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.addChangeListener(seriesChangeListener40);
        java.util.Collection collection42 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.addAndOrUpdate(timeSeries39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = null;
        try {
            timeSeries3.add(regularTimePeriod44, (double) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(timeSeries43);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167363200000L) + "'", long3 == (-62167363200000L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        int int6 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        java.util.Calendar calendar8 = null;
        try {
            year4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        long long4 = month0.getMiddleMillisecond();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        try {
            timeSeriesDataItem63.setValue((java.lang.Number) (-62104204800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        long long22 = day15.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.util.Calendar calendar8 = null;
//        try {
//            month4.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            java.lang.Number number17 = timeSeries7.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        int int5 = year4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        long long5 = month0.getFirstMillisecond();
        java.lang.String str6 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
        try {
            timeSeries3.setMaximumItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day6.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        java.util.Date date4 = month0.getStart();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(0);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        try {
            timeSeries3.update(regularTimePeriod12, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62104204800001L) + "'", long11 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 8, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61820208000001L) + "'", long3 == (-61820208000001L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond7.peg(calendar15);
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getEnd();
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 9999, false);
//        java.util.Collection collection37 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        double double38 = timeSeries25.getMinY();
//        timeSeries25.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection41 = timeSeries25.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener42);
//        boolean boolean45 = timeSeries25.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "", "");
//        boolean boolean52 = timeSeries51.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries51.removeChangeListener(seriesChangeListener53);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month55, "", "");
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month59, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.addChangeListener(seriesChangeListener63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (double) 9999, false);
//        java.util.Collection collection70 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries62);
//        double double71 = timeSeries58.getMinY();
//        java.util.Collection collection72 = timeSeries51.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener73 = null;
//        timeSeries58.removeChangeListener(seriesChangeListener73);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date77 = fixedMillisecond76.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond76.previous();
//        java.lang.Number number79 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, number79);
//        timeSeries58.add(timeSeriesDataItem80, true);
//        timeSeries47.add(timeSeriesDataItem80, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries25.addOrUpdate(timeSeriesDataItem80);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries3.addOrUpdate(timeSeriesDataItem85);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(collection70);
//        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection72);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(timeSeriesDataItem85);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        java.lang.String str17 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        long long6 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        timeSeries3.removeAgedItems(true);
        java.lang.Comparable comparable26 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (-1) + "'", comparable26.equals((-1)));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getLastMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate(regularTimePeriod14, 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        boolean boolean21 = timeSeries20.getNotify();
        timeSeries20.setMaximumItemAge((long) 2019);
        int int24 = timeSeries20.getItemCount();
        int int25 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.lang.String str27 = timeSeries20.getDescription();
        boolean boolean28 = year4.equals((java.lang.Object) timeSeries20);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year4.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.removeAgedItems(true);
        timeSeries3.setMaximumItemAge((long) (short) 100);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Object obj0 = new java.lang.Object();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 15:59:59 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(regularTimePeriod9, (double) 0L);
        timeSeries3.setMaximumItemAge((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        try {
            timeSeries3.delete((int) (short) 1, (int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries3.removeChangeListener(seriesChangeListener22);
        int int24 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        long long8 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1558033199999L + "'", long8 == 1558033199999L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 2019, true);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        long long19 = month17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
        org.jfree.data.time.Year year21 = month17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        long long23 = year21.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        try {
            timeSeries3.update(0, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getLastMillisecond();
//        long long66 = month64.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
//        org.jfree.data.time.Year year68 = month64.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
//        long long70 = year68.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
//        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month74, "", "");
//        boolean boolean78 = timeSeries77.getNotify();
//        timeSeries77.setMaximumItemAge((long) 2019);
//        int int81 = timeSeries77.getItemCount();
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day82.next();
//        long long84 = day82.getFirstMillisecond();
//        boolean boolean86 = day82.equals((java.lang.Object) 10L);
//        long long87 = day82.getSerialIndex();
//        java.lang.Number number88 = timeSeries77.getValue((org.jfree.data.time.RegularTimePeriod) day82);
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day89.next();
//        long long91 = day89.getFirstMillisecond();
//        boolean boolean93 = day89.equals((java.lang.Object) 10L);
//        long long94 = day89.getLastMillisecond();
//        timeSeries77.delete((org.jfree.data.time.RegularTimePeriod) day89);
//        java.beans.PropertyChangeListener propertyChangeListener96 = null;
//        timeSeries77.removePropertyChangeListener(propertyChangeListener96);
//        boolean boolean98 = timeSeries77.getNotify();
//        int int99 = timeSeriesDataItem58.compareTo((java.lang.Object) timeSeries77);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 43626L + "'", long87 == 43626L);
//        org.junit.Assert.assertNull(number88);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560150000000L + "'", long91 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1560236399999L + "'", long94 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
//        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1 + "'", int99 == 1);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        int int4 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date7 = fixedMillisecond6.getTime();
        long long8 = fixedMillisecond6.getFirstMillisecond();
        int int9 = month0.compareTo((java.lang.Object) long8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy(0, 1);
        timeSeries18.removeAgedItems(true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setValue((java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 2019, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = null;
        try {
            timeSeries3.add(timeSeriesDataItem17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1969, (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = month4.equals(obj8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = month4.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
//        int int9 = day6.compareTo((java.lang.Object) 2019);
//        java.lang.String str10 = day6.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = timeSeries3.equals(obj20);
//        java.lang.Object obj22 = timeSeries3.clone();
//        timeSeries3.setDomainDescription("2019");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener25);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(obj22);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        org.jfree.data.time.Year year10 = month6.getYear();
        int int11 = year10.getYear();
        int int12 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        int int14 = month0.compareTo((java.lang.Object) regularTimePeriod13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month0.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 9999, false);
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        double double25 = timeSeries12.getMinY();
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries12.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
        timeSeries12.add(timeSeriesDataItem34, true);
        timeSeries1.add(timeSeriesDataItem34, false);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "");
        boolean boolean43 = timeSeries42.getNotify();
        timeSeries42.setMaximumItemAge((long) 2019);
        int int46 = timeSeries42.getItemCount();
        int int47 = timeSeries42.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener48);
        double double50 = timeSeries42.getMinY();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        long long52 = month51.getLastMillisecond();
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) month51, (double) 2019, true);
        int int56 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month57, "", "");
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month61.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries60.addOrUpdate(regularTimePeriod62, 1.0d);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "", "");
        boolean boolean69 = timeSeries68.getNotify();
        timeSeries68.setMaximumItemAge((long) 2019);
        int int72 = timeSeries68.getItemCount();
        int int73 = timeSeries68.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries60.addAndOrUpdate(timeSeries68);
        int int75 = month51.compareTo((java.lang.Object) timeSeries74);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1561964399999L + "'", long52 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2147483647 + "'", int73 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        java.lang.String str2 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        int int4 = year1.compareTo((java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("0");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries3.removeChangeListener(seriesChangeListener64);
        java.util.Collection collection66 = timeSeries3.getTimePeriods();
        boolean boolean68 = timeSeries3.equals((java.lang.Object) "June 2019");
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond7.peg(calendar15);
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getEnd();
        long long19 = fixedMillisecond7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timeSeries3.getNotify();
//        double double25 = timeSeries3.getMaxY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        double double32 = timeSeries19.getMinY();
        java.util.Collection collection33 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.addChangeListener(seriesChangeListener40);
        java.util.Collection collection42 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.addAndOrUpdate(timeSeries39);
        try {
            timeSeries3.delete(1969, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(timeSeries43);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day8.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        java.lang.String str17 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long20 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.addAndOrUpdate(timeSeries24);
        double double26 = timeSeries25.getMaxY();
        timeSeries25.setRangeDescription("Value");
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        try {
//            timeSeries3.update((int) '#', (java.lang.Number) 19L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        int int4 = year3.getYear();
        long long5 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        long long65 = month64.getLastMillisecond();
        long long66 = month64.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
        org.jfree.data.time.Year year68 = month64.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
        java.util.Date date74 = regularTimePeriod72.getStart();
        java.util.TimeZone timeZone75 = null;
        try {
            org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date74, timeZone75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        double double6 = timeSeries3.getMinY();
        java.lang.String str7 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.lang.String str19 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        long long22 = day20.getFirstMillisecond();
//        boolean boolean24 = day20.equals((java.lang.Object) 10L);
//        long long25 = day20.getLastMillisecond();
//        long long26 = day20.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        java.lang.String str30 = fixedMillisecond28.toString();
//        java.util.Date date31 = fixedMillisecond28.getTime();
//        boolean boolean32 = day20.equals((java.lang.Object) date31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) -1);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560150000000L + "'", long26 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str30.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        int int11 = month0.compareTo((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.String str12 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond7.peg(calendar15);
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = timeSeriesDataItem5.compareTo((java.lang.Object) month18);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
        try {
            timeSeries6.update(0, (java.lang.Number) (-62167363200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.lang.Object obj34 = timeSeries30.clone();
        java.util.Collection collection35 = timeSeries30.getTimePeriods();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        timeSeriesDataItem5.setSelected(false);
        java.lang.Number number8 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.String str18 = timeSeries11.getDescription();
        java.lang.Object obj19 = timeSeries11.clone();
        java.lang.String str20 = timeSeries11.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) (byte) -1);
        boolean boolean8 = timeSeriesDataItem5.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        try {
            timeSeriesDataItem63.setSelected(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.addChangeListener(seriesChangeListener25);
        java.util.Collection collection27 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        double double28 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.addAndOrUpdate(timeSeries29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        java.lang.Object obj14 = null;
        int int15 = fixedMillisecond7.compareTo(obj14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond7.peg(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.previous();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 9999, false);
        java.util.Collection collection34 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        double double35 = timeSeries22.getMinY();
        timeSeries22.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection38 = timeSeries22.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries22.removeChangeListener(seriesChangeListener39);
        boolean boolean42 = timeSeries22.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month45, "", "");
        boolean boolean49 = timeSeries48.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries48.removeChangeListener(seriesChangeListener50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month52, "", "");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries59.addChangeListener(seriesChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) 9999, false);
        java.util.Collection collection67 = timeSeries55.getTimePeriodsUniqueToOtherSeries(timeSeries59);
        double double68 = timeSeries55.getMinY();
        java.util.Collection collection69 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries55);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener70 = null;
        timeSeries55.removeChangeListener(seriesChangeListener70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date74 = fixedMillisecond73.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond73.previous();
        java.lang.Number number76 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, number76);
        timeSeries55.add(timeSeriesDataItem77, true);
        timeSeries44.add(timeSeriesDataItem77, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries22.addOrUpdate(timeSeriesDataItem77);
        boolean boolean83 = fixedMillisecond7.equals((java.lang.Object) timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNull(timeSeriesDataItem82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.util.List list18 = timeSeries11.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getLastMillisecond();
        long long21 = month19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.previous();
        org.jfree.data.time.Year year23 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        try {
            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1559372400000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            timeSeries3.update(regularTimePeriod27, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            java.lang.Number number26 = timeSeries3.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = null;
//        java.util.Locale locale14 = null;
//        try {
//            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11, timeZone13, locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.addOrUpdate(timeSeriesDataItem9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        long long4 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) serialDate5);
//        long long7 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183261321L + "'", long1 == 1560183261321L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183261321L + "'", long7 == 1560183261321L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        int int4 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        timeSeries3.setDescription("Overwritten values from: June 2019");
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy(0, 1);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, "", "");
//        boolean boolean23 = timeSeries22.getNotify();
//        timeSeries22.setMaximumItemAge((long) 2019);
//        int int26 = timeSeries22.getItemCount();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
//        long long29 = day27.getFirstMillisecond();
//        boolean boolean31 = day27.equals((java.lang.Object) 10L);
//        long long32 = day27.getSerialIndex();
//        java.lang.Number number33 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        long long36 = day34.getFirstMillisecond();
//        boolean boolean38 = day34.equals((java.lang.Object) 10L);
//        long long39 = day34.getLastMillisecond();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.String str41 = day34.toString();
//        java.lang.Number number42 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day34);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43626L + "'", long32 == 43626L);
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertNull(number42);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = month4.equals(obj8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month4.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        timeSeries6.clear();
//        java.lang.String str10 = timeSeries6.getDescription();
//        long long11 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        long long65 = year64.getSerialIndex();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.next();
//        long long68 = day66.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
//        int int71 = day66.compareTo((java.lang.Object) month70);
//        int int72 = day66.getYear();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year64, (org.jfree.data.time.RegularTimePeriod) day66);
//        timeSeries73.removeAgedItems(false);
//        boolean boolean76 = timeSeries73.isEmpty();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560150000000L + "'", long68 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        double double6 = timeSeries3.getMinY();
        try {
            timeSeries3.delete((int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = day1.compareTo((java.lang.Object) month5);
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) day1);
//        long long8 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond0.getFirstMillisecond(calendar11);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183263852L + "'", long8 == 1560183263852L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183263852L + "'", long10 == 1560183263852L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183263852L + "'", long12 == 1560183263852L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        long long7 = day5.getFirstMillisecond();
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        int int10 = fixedMillisecond1.compareTo((java.lang.Object) day5);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day5.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        int int7 = day0.getYear();
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        try {
            java.lang.Number number64 = timeSeriesDataItem63.getValue();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        boolean boolean64 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("0");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond5.getFirstMillisecond(calendar10);
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        int int15 = fixedMillisecond1.compareTo((java.lang.Object) "10-June-2019");
        java.util.Calendar calendar16 = null;
        fixedMillisecond1.peg(calendar16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(2019);
        timeSeries3.setKey((java.lang.Comparable) year18);
        long long20 = year18.getFirstMillisecond();
        java.util.Calendar calendar21 = null;
        try {
            year18.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond5.getFirstMillisecond(calendar10);
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        int int15 = fixedMillisecond1.compareTo((java.lang.Object) "10-June-2019");
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getLastMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.String str8 = seriesChangeEvent7.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent7.getSummary();
//        java.lang.String str10 = seriesChangeEvent7.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//        org.junit.Assert.assertNull(seriesChangeInfo9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str10.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getLastMillisecond();
//        boolean boolean24 = day15.equals((java.lang.Object) fixedMillisecond22);
//        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("10-June-2019");
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str29 = seriesException28.toString();
//        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
//        seriesException28.addSuppressed((java.lang.Throwable) seriesException31);
//        java.lang.Class<?> wildcardClass33 = seriesException28.getClass();
//        seriesException26.addSuppressed((java.lang.Throwable) seriesException28);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) seriesException26);
//        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str38 = seriesException37.toString();
//        org.jfree.data.general.SeriesException seriesException40 = new org.jfree.data.general.SeriesException("");
//        seriesException37.addSuppressed((java.lang.Throwable) seriesException40);
//        java.lang.Throwable[] throwableArray42 = seriesException37.getSuppressed();
//        seriesException26.addSuppressed((java.lang.Throwable) seriesException37);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183265756L + "'", long23 == 1560183265756L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str29.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str38.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertNotNull(throwableArray42);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        timeSeries10.setMaximumItemAge((long) 0);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        java.lang.Object obj34 = timeSeries30.clone();
//        timeSeries30.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
//        long long39 = day37.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate40 = day37.getSerialDate();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        int int42 = day37.compareTo((java.lang.Object) month41);
//        long long43 = month41.getSerialIndex();
//        long long44 = month41.getFirstMillisecond();
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) month41);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = month41.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560150000000L + "'", long39 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 24234L + "'", long43 == 24234L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1559372400000L + "'", long44 == 1559372400000L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        timeSeriesDataItem5.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj9 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        java.lang.Object obj14 = null;
        int int15 = fixedMillisecond7.compareTo(obj14);
        long long16 = fixedMillisecond7.getLastMillisecond();
        boolean boolean18 = fixedMillisecond7.equals((java.lang.Object) 1560183263852L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        boolean boolean20 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries24.addChangeListener(seriesChangeListener25);
//        java.util.Collection collection27 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        double double28 = timeSeries3.getMaxY();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
//        long long31 = day29.getFirstMillisecond();
//        boolean boolean33 = day29.equals((java.lang.Object) 10L);
//        long long34 = day29.getLastMillisecond();
//        long long35 = day29.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date38 = fixedMillisecond37.getTime();
//        java.lang.String str39 = fixedMillisecond37.toString();
//        java.util.Date date40 = fixedMillisecond37.getTime();
//        boolean boolean41 = day29.equals((java.lang.Object) date40);
//        java.util.Date date42 = day29.getStart();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str39.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date42);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
//        boolean boolean26 = timeSeries25.getNotify();
//        timeSeries25.setMaximumItemAge((long) 2019);
//        int int29 = timeSeries25.getItemCount();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        long long32 = day30.getFirstMillisecond();
//        boolean boolean34 = day30.equals((java.lang.Object) 10L);
//        long long35 = day30.getSerialIndex();
//        java.lang.Number number36 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
//        long long39 = day37.getFirstMillisecond();
//        boolean boolean41 = day37.equals((java.lang.Object) 10L);
//        long long42 = day37.getLastMillisecond();
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        long long45 = month44.getLastMillisecond();
//        long long46 = month44.getLastMillisecond();
//        boolean boolean48 = month44.equals((java.lang.Object) (byte) -1);
//        long long49 = month44.getFirstMillisecond();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month52, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date58 = fixedMillisecond57.getTime();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58);
//        java.lang.Object obj61 = null;
//        int int62 = year60.compareTo(obj61);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) year60);
//        java.lang.Number number64 = null;
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year60, number64);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560150000000L + "'", long39 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1561964399999L + "'", long45 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1561964399999L + "'", long46 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1559372400000L + "'", long49 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(timeSeries63);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        long long17 = day8.getFirstMillisecond();
//        java.lang.String str18 = day8.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod16, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass20 = timeSeries19.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date23 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date23, timeZone24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date23, timeZone26);
        java.util.TimeZone timeZone28 = null;
        java.util.Locale locale29 = null;
        try {
            org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date23, timeZone28, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        java.lang.Number number64 = timeSeriesDataItem58.getValue();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNull(number64);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=]");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        long long65 = month64.getLastMillisecond();
        long long66 = month64.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
        org.jfree.data.time.Year year68 = month64.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeriesDataItem58.getPeriod();
        java.lang.Number number75 = timeSeriesDataItem58.getValue();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNull(number75);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(24234L);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) 24234L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        int int6 = day0.compareTo(obj5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        double double22 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 9999, false);
        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        timeSeries26.setNotify(false);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        long long45 = month41.getMiddleMillisecond();
        long long46 = month41.getSerialIndex();
        int int47 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        int int48 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        java.util.Calendar calendar49 = null;
        try {
            long long50 = month41.getFirstMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560668399999L + "'", long45 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 24234L + "'", long46 == 24234L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
//        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        double double29 = timeSeries16.getMinY();
//        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        long long36 = day32.getFirstMillisecond();
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
//        int int38 = day32.getYear();
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        java.lang.String str5 = month0.toString();
        long long6 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = year15.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond10.getLastMillisecond(calendar21);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        int int17 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9999, false);
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double22 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        timeSeries9.clear();
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection25);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = day1.compareTo((java.lang.Object) month5);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month5, seriesChangeInfo7);
//        org.jfree.data.time.Year year9 = month5.getYear();
//        try {
//            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 100, year9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        long long65 = month64.getLastMillisecond();
        long long66 = month64.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
        org.jfree.data.time.Year year68 = month64.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
        timeSeriesDataItem58.setSelected(false);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        org.jfree.data.time.Year year8 = month4.getYear();
//        long long9 = month4.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day15);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        long long65 = month64.getLastMillisecond();
        long long66 = month64.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
        org.jfree.data.time.Year year68 = month64.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
        java.util.Date date74 = regularTimePeriod72.getStart();
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]");
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
//        java.util.List list11 = timeSeries10.getItems();
//        int int12 = day0.compareTo((java.lang.Object) list11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate(regularTimePeriod14, 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        boolean boolean21 = timeSeries20.getNotify();
        timeSeries20.setMaximumItemAge((long) 2019);
        int int24 = timeSeries20.getItemCount();
        int int25 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.lang.String str27 = timeSeries20.getDescription();
        boolean boolean28 = year4.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, (int) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
        int int14 = month13.getYearValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(2019);
        timeSeries3.setKey((java.lang.Comparable) year18);
        long long20 = year18.getSerialIndex();
        java.util.Date date21 = year18.getEnd();
        long long22 = year18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
//        java.lang.Object obj39 = null;
//        int int40 = year38.compareTo(obj39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) year38);
//        timeSeries3.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        timeSeries30.fireSeriesChanged();
        try {
            timeSeries30.delete((int) (byte) 0, 4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 9999, false);
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        double double25 = timeSeries12.getMinY();
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries12.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
        timeSeries12.add(timeSeriesDataItem34, true);
        timeSeries1.add(timeSeriesDataItem34, false);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        long long40 = month39.getLastMillisecond();
        long long41 = month39.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.previous();
        org.jfree.data.time.Year year43 = month39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 4);
        try {
            timeSeries1.add(timeSeriesDataItem46, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561964399999L + "'", long40 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        int int6 = year4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        java.lang.Object obj12 = null;
        int int13 = year11.compareTo(obj12);
        int int14 = year11.getYear();
        int int15 = year4.compareTo((java.lang.Object) int14);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (short) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo3);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        long long18 = day16.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        int int20 = day16.getYear();
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 1.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        try {
            java.lang.Number number23 = timeSeries3.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        long long15 = month14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        org.jfree.data.time.Year year17 = month14.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) 4);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries25.addOrUpdate(regularTimePeriod27, 1.0d);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        timeSeries33.setMaximumItemAge((long) 2019);
        int int37 = timeSeries33.getItemCount();
        int int38 = timeSeries33.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.addAndOrUpdate(timeSeries33);
        java.lang.String str40 = timeSeries33.getDescription();
        java.lang.Object obj41 = timeSeries33.clone();
        java.util.Collection collection42 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        double double43 = timeSeries33.getMaxY();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(0);
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        int int39 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("10-June-2019");
//        java.lang.Throwable[] throwableArray42 = seriesException41.getSuppressed();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo43 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException41, seriesChangeInfo43);
//        int int45 = year36.compareTo((java.lang.Object) seriesChangeInfo43);
//        java.util.Calendar calendar46 = null;
//        try {
//            year36.peg(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62104204800001L) + "'", long37 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        long long15 = month14.getLastMillisecond();
        long long16 = month14.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2649600000L) + "'", long16 == (-2649600000L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent2.getSummary();
        java.lang.String str8 = seriesChangeEvent2.toString();
        org.junit.Assert.assertNull(seriesChangeInfo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        java.util.List list5 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Overwritten values from: June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 10-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 10-June-2019"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int15 = timeSeries3.getMaximumItemCount();
//        long long16 = timeSeries3.getMaximumItemAge();
//        java.lang.String str17 = timeSeries3.getDescription();
//        try {
//            timeSeries3.delete(2, 10, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNull(str17);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate(regularTimePeriod11, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, "June 2019", "");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month2.next();
        long long70 = regularTimePeriod69.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-62116084800001L) + "'", long70 == (-62116084800001L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1560236399999L);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.String str2 = regularTimePeriod1.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11-June-2019" + "'", str2.equals("11-June-2019"));
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, number7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = year1.compareTo((java.lang.Object) month3);
        java.lang.String str5 = year1.toString();
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        java.lang.String str24 = timeSeries3.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.Date date13 = day0.getStart();
//        java.util.TimeZone timeZone14 = null;
//        java.util.Locale locale15 = null;
//        try {
//            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone14, locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.createCopy((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193199999L + "'", long4 == 1560193199999L);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        int int34 = timeSeries30.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries3.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(0);
        long long26 = year25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.next();
        java.lang.String str28 = year25.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year25);
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62104204800001L) + "'", long26 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        timeSeries6.clear();
//        java.lang.String str10 = timeSeries6.getDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.addChangeListener(seriesChangeListener19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 9999, false);
//        java.util.Collection collection26 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        double double27 = timeSeries14.getMinY();
//        timeSeries14.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection30 = timeSeries14.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener31);
//        boolean boolean34 = timeSeries14.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        boolean boolean41 = timeSeries40.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries40.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "", "");
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries51.addChangeListener(seriesChangeListener52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (double) 9999, false);
//        java.util.Collection collection59 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries51);
//        double double60 = timeSeries47.getMinY();
//        java.util.Collection collection61 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries47);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries47.removeChangeListener(seriesChangeListener62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date66 = fixedMillisecond65.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond65.previous();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, number68);
//        timeSeries47.add(timeSeriesDataItem69, true);
//        timeSeries36.add(timeSeriesDataItem69, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries14.addOrUpdate(timeSeriesDataItem69);
//        java.lang.Object obj75 = timeSeriesDataItem69.clone();
//        timeSeries6.setKey((java.lang.Comparable) timeSeriesDataItem69);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(collection59);
//        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(obj75);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond7.peg(calendar15);
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond7.previous();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond7.getLastMillisecond(calendar20);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = timeSeries3.equals(obj20);
//        java.lang.Comparable comparable22 = timeSeries3.getKey();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.createCopy((-9999), (-9999));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(comparable22);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Overwritten values from: June 2019");
//        int int8 = day0.compareTo((java.lang.Object) timePeriodFormatException7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener11);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
//        int int20 = day0.compareTo((java.lang.Object) fixedMillisecond13);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries24.addOrUpdate(regularTimePeriod26, 1.0d);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
//        boolean boolean33 = timeSeries32.getNotify();
//        timeSeries32.setMaximumItemAge((long) 2019);
//        int int36 = timeSeries32.getItemCount();
//        int int37 = timeSeries32.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries24.addAndOrUpdate(timeSeries32);
//        java.util.List list39 = timeSeries32.getItems();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        long long41 = month40.getLastMillisecond();
//        long long42 = month40.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month40.previous();
//        org.jfree.data.time.Year year44 = month40.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 4);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries32.addOrUpdate(timeSeriesDataItem47);
//        int int49 = fixedMillisecond13.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1561964399999L + "'", long42 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = null;
        try {
            timeSeries10.add(timeSeriesDataItem27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("0");
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        timeSeries10.setMaximumItemAge((long) 0);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        timeSeries30.fireSeriesChanged();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
//        long long37 = day35.getFirstMillisecond();
//        int int38 = day35.getYear();
//        java.lang.String str39 = day35.toString();
//        org.jfree.data.time.SerialDate serialDate40 = day35.getSerialDate();
//        long long41 = day35.getFirstMillisecond();
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) day35, (double) 52L, true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560150000000L + "'", long37 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.lang.Object obj11 = null;
        int int12 = fixedMillisecond7.compareTo(obj11);
        java.util.Date date13 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
//        try {
//            timeSeries3.add(regularTimePeriod15, (double) 1560183240083L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1969);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9999, false);
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double22 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        timeSeries3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        long long4 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) serialDate5);
//        long long7 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 9999, false);
//        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        double double24 = timeSeries11.getMinY();
//        timeSeries11.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection27 = timeSeries11.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        boolean boolean31 = timeSeries11.equals((java.lang.Object) 52L);
//        java.lang.String str32 = timeSeries11.getRangeDescription();
//        boolean boolean33 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183282372L + "'", long1 == 1560183282372L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183282372L + "'", long7 == 1560183282372L);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Overwritten values from: June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        java.lang.Object obj14 = null;
        int int15 = fixedMillisecond7.compareTo(obj14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond7.peg(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.previous();
        java.lang.String str19 = regularTimePeriod18.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str19.equals("Wed Dec 31 15:59:59 PST 1969"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.util.List list34 = timeSeries10.getItems();
        java.lang.Class class35 = timeSeries10.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNull(class35);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.lang.Object obj11 = null;
        int int12 = fixedMillisecond7.compareTo(obj11);
        java.util.Date date13 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
        java.lang.String str8 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        long long65 = month64.getLastMillisecond();
        long long66 = month64.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
        org.jfree.data.time.Year year68 = month64.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        boolean boolean73 = timeSeriesDataItem58.equals((java.lang.Object) regularTimePeriod72);
        java.util.Date date74 = regularTimePeriod72.getStart();
        java.util.TimeZone timeZone75 = null;
        java.util.Locale locale76 = null;
        try {
            org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date74, timeZone75, locale76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        boolean boolean14 = timeSeries13.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries13.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 9999, false);
        java.util.Collection collection32 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        double double33 = timeSeries20.getMinY();
        java.util.Collection collection34 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries20.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date39 = fixedMillisecond38.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
        java.lang.Number number41 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, number41);
        timeSeries20.add(timeSeriesDataItem42, true);
        timeSeries9.add(timeSeriesDataItem42, false);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.previous();
        long long49 = month47.getLastMillisecond();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 3);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 8, false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1561964399999L + "'", long49 == 1561964399999L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        int int8 = year4.getYear();
        java.lang.String str9 = year4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-62104204800001L));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        int int5 = year4.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        int int20 = day18.getMonth();
//        long long21 = day18.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day18, "", "");
//        timeSeries24.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date31 = fixedMillisecond30.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = timeSeriesDataItem34.equals(obj35);
//        timeSeries24.add(timeSeriesDataItem34);
//        timeSeries3.add(timeSeriesDataItem34);
//        java.lang.Number number39 = timeSeriesDataItem34.getValue();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNull(number39);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
        java.lang.Number number18 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond21.getLastMillisecond(calendar27);
        java.util.Calendar calendar29 = null;
        fixedMillisecond21.peg(calendar29);
        int int31 = timeSeriesDataItem19.compareTo((java.lang.Object) fixedMillisecond21);
        java.util.Date date32 = fixedMillisecond21.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date32, timeZone33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Comparable comparable18 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(comparable18);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(regularTimePeriod9, (double) 0L);
        try {
            timeSeries3.delete(2, 5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
//        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        double double29 = timeSeries16.getMinY();
//        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        long long36 = day32.getFirstMillisecond();
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
//        timeSeries3.removeAgedItems((long) 'a', false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        double double32 = timeSeries19.getMinY();
        timeSeries19.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection35 = timeSeries19.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries19.removeChangeListener(seriesChangeListener36);
        boolean boolean39 = timeSeries19.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month42, "", "");
        boolean boolean46 = timeSeries45.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries45.removeChangeListener(seriesChangeListener47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month49, "", "");
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries56.addChangeListener(seriesChangeListener57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries56.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) 9999, false);
        java.util.Collection collection64 = timeSeries52.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        double double65 = timeSeries52.getMinY();
        java.util.Collection collection66 = timeSeries45.getTimePeriodsUniqueToOtherSeries(timeSeries52);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries52.removeChangeListener(seriesChangeListener67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date71 = fixedMillisecond70.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = fixedMillisecond70.previous();
        java.lang.Number number73 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, number73);
        timeSeries52.add(timeSeriesDataItem74, true);
        timeSeries41.add(timeSeriesDataItem74, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries19.addOrUpdate(timeSeriesDataItem74);
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
        long long81 = month80.getLastMillisecond();
        long long82 = month80.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = month80.previous();
        org.jfree.data.time.Year year84 = month80.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year84.next();
        long long86 = year84.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = year84.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year84.previous();
        boolean boolean89 = timeSeriesDataItem74.equals((java.lang.Object) regularTimePeriod88);
        java.util.Date date90 = regularTimePeriod88.getStart();
        java.util.TimeZone timeZone91 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date90, timeZone91);
        java.util.TimeZone timeZone93 = null;
        try {
            org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date90, timeZone93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1561964399999L + "'", long81 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1561964399999L + "'", long82 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(year84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 2019L + "'", long86 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNull(regularTimePeriod92);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        int int6 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number13);
        timeSeriesDataItem14.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries8.addOrUpdate(timeSeriesDataItem14);
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "" + "'", obj6.equals(""));
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560183238280L);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries8.removeChangeListener(seriesChangeListener9);
//        boolean boolean12 = timeSeries8.equals((java.lang.Object) 43626L);
//        boolean boolean13 = timeSeries8.getNotify();
//        boolean boolean14 = day0.equals((java.lang.Object) boolean13);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day0.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNull(class21);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        int int6 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7);
        timeSeries8.setMaximumItemAge((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        java.lang.String str27 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(19L);
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1560183261107L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getLastMillisecond();
        java.lang.Object obj3 = null;
        boolean boolean4 = month0.equals(obj3);
        org.jfree.data.time.Year year6 = org.jfree.data.time.Year.parseYear("2019");
        int int7 = month0.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        timeSeries5.clear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
        boolean boolean39 = timeSeries38.getNotify();
        timeSeries38.setMaximumItemAge((long) 2019);
        int int42 = timeSeries38.getItemCount();
        int int43 = timeSeries38.getMaximumItemCount();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "", "");
        boolean boolean48 = timeSeries47.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries47.removeChangeListener(seriesChangeListener49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month51, "", "");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month55, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries58.addChangeListener(seriesChangeListener59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 9999, false);
        java.util.Collection collection66 = timeSeries54.getTimePeriodsUniqueToOtherSeries(timeSeries58);
        double double67 = timeSeries54.getMinY();
        java.util.Collection collection68 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries54);
        timeSeries54.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month71, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries74.addChangeListener(seriesChangeListener75);
        java.util.Collection collection77 = timeSeries54.getTimePeriodsUniqueToOtherSeries(timeSeries74);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries38.addAndOrUpdate(timeSeries74);
        int int79 = timeSeriesDataItem32.compareTo((java.lang.Object) timeSeries74);
        java.beans.PropertyChangeListener propertyChangeListener80 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener80);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2147483647 + "'", int43 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertNotNull(collection77);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = day1.compareTo((java.lang.Object) month5);
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) day1);
//        long long8 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        long long11 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183285347L + "'", long8 == 1560183285347L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183285347L + "'", long10 == 1560183285347L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183285347L + "'", long11 == 1560183285347L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 43626L);
        boolean boolean8 = timeSeries3.getNotify();
        timeSeries3.removeAgedItems(100L, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        long long44 = day42.getFirstMillisecond();
//        java.lang.String str45 = day42.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day42.previous();
//        long long47 = day42.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day42.next();
//        try {
//            timeSeries20.add(regularTimePeriod48, (java.lang.Number) 0L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560236399999L + "'", long47 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getFirstMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(0);
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        int int39 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("10-June-2019");
//        java.lang.Throwable[] throwableArray42 = seriesException41.getSuppressed();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo43 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException41, seriesChangeInfo43);
//        int int45 = year36.compareTo((java.lang.Object) seriesChangeInfo43);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month46, "", "");
//        boolean boolean50 = timeSeries49.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "");
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month57, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener61 = null;
//        timeSeries60.addChangeListener(seriesChangeListener61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) 9999, false);
//        java.util.Collection collection68 = timeSeries56.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        double double69 = timeSeries56.getMinY();
//        java.util.Collection collection70 = timeSeries49.getTimePeriodsUniqueToOtherSeries(timeSeries56);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener71 = null;
//        timeSeries56.removeChangeListener(seriesChangeListener71);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date75 = fixedMillisecond74.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond74.previous();
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, number77);
//        timeSeries56.add(timeSeriesDataItem78, true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
//        timeSeries56.removeChangeListener(seriesChangeListener81);
//        boolean boolean83 = year36.equals((java.lang.Object) seriesChangeListener81);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62104204800001L) + "'", long37 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(collection68);
//        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection70);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond5.getFirstMillisecond(calendar10);
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        int int15 = fixedMillisecond1.compareTo((java.lang.Object) "10-June-2019");
        long long16 = fixedMillisecond1.getMiddleMillisecond();
        long long17 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond5.getFirstMillisecond(calendar10);
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        int int15 = fixedMillisecond1.compareTo((java.lang.Object) "10-June-2019");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries19.createCopy(0, 1);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries34.getTimePeriods();
        int int37 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        long long27 = day25.getFirstMillisecond();
//        int int28 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.String str31 = timeSeries3.getDomainDescription();
//        try {
//            timeSeries3.delete(12, (int) (short) -1, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.String str8 = month4.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        double double18 = timeSeries5.getMinY();
        boolean boolean19 = timeSeries5.isEmpty();
        int int20 = month0.compareTo((java.lang.Object) boolean19);
        int int21 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        int int21 = timeSeries6.getMaximumItemCount();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate(regularTimePeriod14, 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        boolean boolean21 = timeSeries20.getNotify();
        timeSeries20.setMaximumItemAge((long) 2019);
        int int24 = timeSeries20.getItemCount();
        int int25 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.lang.String str27 = timeSeries20.getDescription();
        boolean boolean28 = year4.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, (int) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
        java.util.Collection collection33 = timeSeries20.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 43626L);
        boolean boolean8 = timeSeries3.getNotify();
        int int9 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries3.update(regularTimePeriod9, (java.lang.Number) 1560183261107L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        int int11 = month0.compareTo((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getLastMillisecond();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
//        long long46 = day44.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
//        boolean boolean48 = fixedMillisecond42.equals((java.lang.Object) serialDate47);
//        long long49 = fixedMillisecond42.getSerialIndex();
//        java.lang.Number number50 = null;
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, number50, false);
//        java.util.Calendar calendar53 = null;
//        fixedMillisecond42.peg(calendar53);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560183289119L + "'", long43 == 1560183289119L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560183289119L + "'", long49 == 1560183289119L);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = null;
//        java.util.Locale locale14 = null;
//        try {
//            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone13, locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        long long65 = year64.getSerialIndex();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.next();
//        long long68 = day66.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
//        int int71 = day66.compareTo((java.lang.Object) month70);
//        int int72 = day66.getYear();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year64, (org.jfree.data.time.RegularTimePeriod) day66);
//        timeSeries73.removeAgedItems(false);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day76.next();
//        int int78 = day76.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day76.previous();
//        try {
//            timeSeries73.add((org.jfree.data.time.RegularTimePeriod) day76, (java.lang.Number) 1560183280545L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560150000000L + "'", long68 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 6 + "'", int78 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        double double18 = timeSeries5.getMinY();
//        timeSeries5.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection21 = timeSeries5.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener22);
//        boolean boolean25 = timeSeries5.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "");
//        boolean boolean32 = timeSeries31.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries42.addChangeListener(seriesChangeListener43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 9999, false);
//        java.util.Collection collection50 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        double double51 = timeSeries38.getMinY();
//        java.util.Collection collection52 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date57 = fixedMillisecond56.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond56.previous();
//        java.lang.Number number59 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, number59);
//        timeSeries38.add(timeSeriesDataItem60, true);
//        timeSeries27.add(timeSeriesDataItem60, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries5.addOrUpdate(timeSeriesDataItem60);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        long long67 = year66.getSerialIndex();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.next();
//        long long70 = day68.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate71 = day68.getSerialDate();
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month();
//        int int73 = day68.compareTo((java.lang.Object) month72);
//        int int74 = day68.getYear();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year66, (org.jfree.data.time.RegularTimePeriod) day68);
//        boolean boolean76 = fixedMillisecond1.equals((java.lang.Object) day68);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560150000000L + "'", long70 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 2019, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
        try {
            java.lang.Number number19 = timeSeries3.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        long long4 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) serialDate5);
//        long long7 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        int int12 = month8.getYearValue();
//        long long13 = month8.getLastMillisecond();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        int int16 = day14.getMonth();
//        long long17 = day14.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, "", "");
//        timeSeries20.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        long long26 = month25.getLastMillisecond();
//        long long27 = month25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.previous();
//        org.jfree.data.time.Year year29 = month25.getYear();
//        int int30 = year29.getYear();
//        int int31 = year29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.previous();
//        long long33 = year29.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) year29);
//        int int35 = month8.compareTo((java.lang.Object) timeSeries34);
//        boolean boolean36 = fixedMillisecond0.equals((java.lang.Object) timeSeries34);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        boolean boolean41 = timeSeries40.getNotify();
//        timeSeries40.setMaximumItemAge((long) 2019);
//        int int44 = timeSeries40.getItemCount();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
//        long long47 = day45.getFirstMillisecond();
//        boolean boolean49 = day45.equals((java.lang.Object) 10L);
//        long long50 = day45.getSerialIndex();
//        java.lang.Number number51 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day45);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.next();
//        long long54 = day52.getFirstMillisecond();
//        boolean boolean56 = day52.equals((java.lang.Object) 10L);
//        long long57 = day52.getLastMillisecond();
//        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        long long60 = month59.getLastMillisecond();
//        long long61 = month59.getLastMillisecond();
//        boolean boolean63 = month59.equals((java.lang.Object) (byte) -1);
//        long long64 = month59.getFirstMillisecond();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month67, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date73);
//        java.lang.Object obj76 = null;
//        int int77 = year75.compareTo(obj76);
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) month67, (org.jfree.data.time.RegularTimePeriod) year75);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year75, 0.0d);
//        java.lang.Number number81 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) year75);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183290490L + "'", long1 == 1560183290490L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183290490L + "'", long7 == 1560183290490L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43626L + "'", long50 == 43626L);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1561964399999L + "'", long61 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1559372400000L + "'", long64 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertNull(number81);
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        int int27 = day22.compareTo((java.lang.Object) month26);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month26, seriesChangeInfo28);
//        org.jfree.data.time.Year year30 = month26.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        long long33 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = day31.compareTo((java.lang.Object) month35);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month35, seriesChangeInfo37);
//        java.lang.String str39 = seriesChangeEvent38.toString();
//        boolean boolean40 = year30.equals((java.lang.Object) str39);
//        timeSeries3.setKey((java.lang.Comparable) boolean40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        long long44 = day42.getFirstMillisecond();
//        boolean boolean46 = day42.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day42.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.addOrUpdate(regularTimePeriod47, (java.lang.Number) 1L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str39.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        double double21 = timeSeries3.getMaxY();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        long long24 = day22.getFirstMillisecond();
//        java.lang.String str25 = day22.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (-61851744000000L), true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month64, "", "");
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month68, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener72 = null;
        timeSeries71.addChangeListener(seriesChangeListener72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries71.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) 9999, false);
        java.util.Collection collection79 = timeSeries67.getTimePeriodsUniqueToOtherSeries(timeSeries71);
        double double80 = timeSeries67.getMinY();
        timeSeries67.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection83 = timeSeries67.getTimePeriods();
        boolean boolean84 = timeSeries67.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener85 = null;
        timeSeries67.removePropertyChangeListener(propertyChangeListener85);
        org.jfree.data.time.FixedMillisecond fixedMillisecond88 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date89 = fixedMillisecond88.getTime();
        java.lang.String str90 = fixedMillisecond88.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond88, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = fixedMillisecond88.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries3.addOrUpdate(regularTimePeriod93, (java.lang.Number) 2147483647);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(collection79);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str90.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem92);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNull(timeSeriesDataItem95);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getSerialIndex();
//        java.util.Date date6 = day0.getStart();
//        int int7 = day0.getYear();
//        int int8 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        long long26 = month25.getLastMillisecond();
//        long long27 = month25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.previous();
//        org.jfree.data.time.Year year29 = month25.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year29, (double) 28799999L);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        timeSeries36.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection52 = timeSeries36.getTimePeriods();
//        boolean boolean53 = timeSeries36.getNotify();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month54, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
//        timeSeries57.addChangeListener(seriesChangeListener58);
//        java.util.Collection collection60 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries57);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date64 = fixedMillisecond63.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (java.lang.Number) 1560183232403L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(collection60);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getLastMillisecond();
//        boolean boolean24 = day15.equals((java.lang.Object) fixedMillisecond22);
//        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("10-June-2019");
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str29 = seriesException28.toString();
//        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
//        seriesException28.addSuppressed((java.lang.Throwable) seriesException31);
//        java.lang.Class<?> wildcardClass33 = seriesException28.getClass();
//        seriesException26.addSuppressed((java.lang.Throwable) seriesException28);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) seriesException26);
//        java.lang.Throwable[] throwableArray36 = seriesException26.getSuppressed();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183293126L + "'", long23 == 1560183293126L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str29.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(throwableArray36);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries20.getNextTimePeriod();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
//        org.jfree.data.time.Year year4 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        long long8 = day6.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = day6.compareTo((java.lang.Object) month10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month10, seriesChangeInfo12);
//        boolean boolean14 = month0.equals((java.lang.Object) month10);
//        org.jfree.data.time.Year year15 = month0.getYear();
//        java.lang.String str16 = month0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
//        long long2 = month0.getLastMillisecond();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = month0.equals(obj3);
//        org.jfree.data.time.Year year6 = org.jfree.data.time.Year.parseYear("2019");
//        int int7 = month0.compareTo((java.lang.Object) year6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 9999, false);
//        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        double double24 = timeSeries11.getMinY();
//        java.lang.String str25 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long28 = fixedMillisecond27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod29, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries11.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        long long36 = day34.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate37 = day34.getSerialDate();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = day34.compareTo((java.lang.Object) month38);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month38, seriesChangeInfo40);
//        org.jfree.data.time.Year year42 = month38.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 0);
//        boolean boolean45 = month0.equals((java.lang.Object) month38);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, 9, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        int int4 = year1.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener26);
//        boolean boolean29 = timeSeries25.equals((java.lang.Object) 43626L);
//        boolean boolean30 = timeSeries25.getNotify();
//        java.util.Collection collection31 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        java.lang.Class<?> wildcardClass32 = collection31.getClass();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        long long15 = timeSeries3.getMaximumItemAge();
//        java.lang.Comparable comparable16 = timeSeries3.getKey();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(comparable16);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.lang.String str3 = fixedMillisecond1.toString();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries3.clear();
//        double double23 = timeSeries3.getMaxY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries10.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        timeSeries30.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
//        timeSeries10.add(timeSeriesDataItem32, true);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
//        boolean boolean39 = timeSeries38.getNotify();
//        timeSeries38.setMaximumItemAge((long) 2019);
//        int int42 = timeSeries38.getItemCount();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
//        long long45 = day43.getFirstMillisecond();
//        boolean boolean47 = day43.equals((java.lang.Object) 10L);
//        long long48 = day43.getSerialIndex();
//        java.lang.Number number49 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.next();
//        long long52 = day50.getFirstMillisecond();
//        boolean boolean54 = day50.equals((java.lang.Object) 10L);
//        long long55 = day50.getLastMillisecond();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        long long58 = month57.getLastMillisecond();
//        long long59 = month57.getLastMillisecond();
//        boolean boolean61 = month57.equals((java.lang.Object) (byte) -1);
//        long long62 = month57.getFirstMillisecond();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1L);
//        timeSeries38.removeAgedItems((long) 9999, true);
//        timeSeries38.removeAgedItems(true);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(0);
//        long long72 = year71.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year71.next();
//        int int74 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) year71);
//        boolean boolean75 = timeSeriesDataItem32.equals((java.lang.Object) year71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = timeSeriesDataItem32.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560236399999L + "'", long55 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1561964399999L + "'", long58 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1561964399999L + "'", long59 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1559372400000L + "'", long62 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-62104204800001L) + "'", long72 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 0);
//        boolean boolean7 = timeSeriesDataItem6.isSelected();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
//        int int4 = year1.getYear();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "", "");
//        boolean boolean9 = timeSeries8.getNotify();
//        timeSeries8.setMaximumItemAge((long) 2019);
//        int int12 = timeSeries8.getItemCount();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        long long15 = day13.getFirstMillisecond();
//        boolean boolean17 = day13.equals((java.lang.Object) 10L);
//        long long18 = day13.getSerialIndex();
//        java.lang.Number number19 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        long long22 = day20.getFirstMillisecond();
//        boolean boolean24 = day20.equals((java.lang.Object) 10L);
//        long long25 = day20.getLastMillisecond();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        long long28 = month27.getLastMillisecond();
//        long long29 = month27.getLastMillisecond();
//        boolean boolean31 = month27.equals((java.lang.Object) (byte) -1);
//        long long32 = month27.getFirstMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 1L);
//        timeSeries8.removeAgedItems((long) 9999, true);
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(0);
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.general.SeriesException seriesException46 = new org.jfree.data.general.SeriesException("10-June-2019");
//        java.lang.Throwable[] throwableArray47 = seriesException46.getSuppressed();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo48 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException46, seriesChangeInfo48);
//        int int50 = year41.compareTo((java.lang.Object) seriesChangeInfo48);
//        boolean boolean51 = year1.equals((java.lang.Object) seriesChangeInfo48);
//        java.util.Calendar calendar52 = null;
//        try {
//            long long53 = year1.getFirstMillisecond(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62104204800001L) + "'", long42 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(throwableArray47);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries3.removeChangeListener(seriesChangeListener64);
        timeSeries3.setDomainDescription("Wed Dec 31 15:59:59 PST 1969");
        try {
            org.jfree.data.time.TimeSeries timeSeries70 = timeSeries3.createCopy(1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        java.lang.String str2 = timeSeries1.getRangeDescription();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = day4.compareTo((java.lang.Object) month8);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month8, seriesChangeInfo10);
//        org.jfree.data.time.Year year12 = month8.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1560183282372L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        java.lang.String str15 = timeSeries3.getRangeDescription();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
//        boolean boolean20 = timeSeries19.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 9999, false);
//        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        double double39 = timeSeries26.getMinY();
//        java.util.Collection collection40 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date45 = fixedMillisecond44.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond44.previous();
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number47);
//        timeSeries26.add(timeSeriesDataItem48, true);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate(timeSeriesDataItem48);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        long long65 = year64.getSerialIndex();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.next();
//        long long68 = day66.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
//        int int71 = day66.compareTo((java.lang.Object) month70);
//        int int72 = day66.getYear();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year64, (org.jfree.data.time.RegularTimePeriod) day66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year64, (double) 19L);
//        java.lang.String str76 = year64.toString();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560150000000L + "'", long68 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2019" + "'", str76.equals("2019"));
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
//        java.lang.Object obj39 = null;
//        int int40 = year38.compareTo(obj39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(2019);
        timeSeries3.setKey((java.lang.Comparable) year18);
        long long20 = year18.getFirstMillisecond();
        long long21 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        timeSeries41.clear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getFirstMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond7.getMiddleMillisecond(calendar15);
        long long17 = fixedMillisecond7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) 4);
        timeSeries3.setMaximumItemAge(1969L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        long long27 = day25.getFirstMillisecond();
//        int int28 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.String str31 = timeSeries3.getDomainDescription();
//        java.util.Collection collection32 = timeSeries3.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertNotNull(collection32);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        long long27 = day25.getFirstMillisecond();
//        int int28 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.String str31 = timeSeries3.getDomainDescription();
//        try {
//            timeSeries3.update(1, (java.lang.Number) 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = month0.getYearValue();
        long long6 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        try {
            timeSeries3.delete((-9999), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        int int12 = day7.compareTo((java.lang.Object) month11);
//        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) day7);
//        long long14 = fixedMillisecond6.getSerialIndex();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1560183280545L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560183297640L + "'", long14 == 1560183297640L);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        timeSeries3.setNotify(true);
        try {
            timeSeries3.delete(1969, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 28799999L);
        timeSeriesDataItem70.setSelected(false);
        java.lang.Object obj73 = null;
        boolean boolean74 = timeSeriesDataItem70.equals(obj73);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.String str18 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        boolean boolean8 = timeSeries7.getNotify();
//        timeSeries7.setMaximumItemAge((long) 2019);
//        int int11 = timeSeries7.getItemCount();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        long long14 = day12.getFirstMillisecond();
//        boolean boolean16 = day12.equals((java.lang.Object) 10L);
//        long long17 = day12.getSerialIndex();
//        java.lang.Number number18 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        int int20 = day12.compareTo((java.lang.Object) (byte) 10);
//        long long21 = day12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12);
//        boolean boolean23 = day0.equals((java.lang.Object) day12);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.previous();
//        boolean boolean25 = month15.equals((java.lang.Object) regularTimePeriod24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month15.previous();
//        long long27 = month15.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        long long27 = day25.getFirstMillisecond();
//        java.lang.String str28 = day25.toString();
//        java.lang.Number number29 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNull(number29);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        java.lang.Object obj14 = null;
        int int15 = fixedMillisecond7.compareTo(obj14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long18 = fixedMillisecond17.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.previous();
        int int20 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond17);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setValue((java.lang.Number) 1560183232403L);
        boolean boolean37 = timeSeriesDataItem32.isSelected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 9999, false);
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        double double25 = timeSeries12.getMinY();
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries12.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
        timeSeries12.add(timeSeriesDataItem34, true);
        timeSeries1.add(timeSeriesDataItem34, false);
        timeSeriesDataItem34.setValue((java.lang.Number) (short) 1);
        timeSeriesDataItem34.setValue((java.lang.Number) 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod6, seriesChangeInfo7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries3.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "");
//        boolean boolean22 = timeSeries21.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "", "");
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 9999, false);
//        java.util.Collection collection40 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        double double41 = timeSeries28.getMinY();
//        java.util.Collection collection42 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
//        long long45 = day43.getFirstMillisecond();
//        int int46 = day43.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day43.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries3.addAndOrUpdate(timeSeries21);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries49.getDataItem(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183293126L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
//        java.lang.Object obj39 = null;
//        int int40 = year38.compareTo(obj39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, 0.0d);
//        int int44 = year38.getYear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1969 + "'", int44 == 1969);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date18 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date18, timeZone19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        java.lang.Object obj33 = timeSeries3.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(2019);
//        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("10-June-2019");
//        java.lang.Throwable[] throwableArray38 = seriesException37.getSuppressed();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException37, seriesChangeInfo39);
//        java.lang.Object obj41 = seriesChangeEvent40.getSource();
//        boolean boolean42 = year35.equals(obj41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener44);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(throwableArray38);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        timeSeriesDataItem5.setSelected(false);
        boolean boolean8 = timeSeriesDataItem5.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        double double18 = timeSeries5.getMinY();
        boolean boolean19 = timeSeries5.isEmpty();
        int int20 = month0.compareTo((java.lang.Object) boolean19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month0.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        java.util.Date date3 = month0.getEnd();
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        long long5 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(regularTimePeriod9, (double) 0L);
//        timeSeries3.setDescription("hi!");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        long long16 = day14.getFirstMillisecond();
//        int int17 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries23.addChangeListener(seriesChangeListener24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond27.peg(calendar31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond27.next();
//        int int34 = day14.compareTo((java.lang.Object) fixedMillisecond27);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.getDataItem(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setValue((java.lang.Number) 1560183232403L);
        java.lang.Object obj37 = null;
        int int38 = timeSeriesDataItem32.compareTo(obj37);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        timeSeries3.removeAgedItems(true);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.String str18 = timeSeries11.getDescription();
        java.lang.Object obj19 = timeSeries11.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.lang.Object obj25 = null;
        int int26 = year24.compareTo(obj25);
        int int27 = year24.getYear();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year24, (double) 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        java.lang.Object obj33 = timeSeries3.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        long long35 = fixedMillisecond34.getLastMillisecond();
//        long long36 = fixedMillisecond34.getFirstMillisecond();
//        int int38 = fixedMillisecond34.compareTo((java.lang.Object) (short) 0);
//        long long39 = fixedMillisecond34.getLastMillisecond();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) (-62116084800001L));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560183299642L + "'", long35 == 1560183299642L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183299642L + "'", long36 == 1560183299642L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183299642L + "'", long39 == 1560183299642L);
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        java.util.Date date6 = month4.getStart();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, "org.jfree.data.general.SeriesException: ", "");
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        long long8 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getSerialIndex();
//        int int6 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.String str8 = seriesChangeEvent7.toString();
//        java.lang.Object obj9 = seriesChangeEvent7.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//        org.junit.Assert.assertNotNull(obj9);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day8.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = year1.compareTo((java.lang.Object) month3);
        java.lang.String str5 = year1.toString();
        java.lang.Object obj6 = null;
        int int7 = year1.compareTo(obj6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = month0.compareTo((java.lang.Object) fixedMillisecond1);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int15 = timeSeries3.getMaximumItemCount();
//        long long16 = timeSeries3.getMaximumItemAge();
//        java.lang.Object obj17 = timeSeries3.clone();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(obj17);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
//        boolean boolean26 = timeSeries25.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 9999, false);
//        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        double double45 = timeSeries32.getMinY();
//        java.util.Collection collection46 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        timeSeries32.setMaximumItemAge((long) 0);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month49, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.util.Collection collection55 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        java.lang.Object obj56 = timeSeries52.clone();
//        timeSeries52.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
//        long long61 = day59.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate62 = day59.getSerialDate();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        int int64 = day59.compareTo((java.lang.Object) month63);
//        long long65 = month63.getSerialIndex();
//        long long66 = month63.getFirstMillisecond();
//        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) month63);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month63, (java.lang.Number) (-9999));
//        timeSeries3.removeAgedItems((-1L), false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNotNull(collection55);
//        org.junit.Assert.assertNotNull(obj56);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560150000000L + "'", long61 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1559372400000L + "'", long66 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setNotify(false);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "");
        long long22 = month18.getMiddleMillisecond();
        long long23 = month18.getSerialIndex();
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year25 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month18.previous();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        long long17 = day8.getFirstMillisecond();
//        long long18 = day8.getSerialIndex();
//        int int19 = day8.getDayOfMonth();
//        long long20 = day8.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//    }
//}

