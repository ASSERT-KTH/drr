import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        timeSeries12.setMaximumItemAge((long) 2019);
        int int16 = timeSeries12.getItemCount();
        int int17 = timeSeries12.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        java.lang.Class class19 = timeSeries12.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNull(class19);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        timeSeries12.setMaximumItemAge((long) 2019);
        int int16 = timeSeries12.getItemCount();
        int int17 = timeSeries12.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setDomainDescription("Value");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        int int2 = year1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1560236399999L);
        java.lang.Number number7 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.560236399999E12d + "'", number7.equals(1.560236399999E12d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = day1.compareTo((java.lang.Object) month5);
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) day1);
//        int int8 = day1.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            timeSeries10.update(regularTimePeriod35, (java.lang.Number) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy((int) (short) 0, 1);
        int int7 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getLastMillisecond();
//        int int9 = day0.getYear();
//        int int10 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month24, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries27.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 9999, false);
//        java.util.Calendar calendar35 = null;
//        fixedMillisecond31.peg(calendar35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond31.next();
//        java.lang.Object obj38 = null;
//        int int39 = fixedMillisecond31.compareTo(obj38);
//        java.util.Calendar calendar40 = null;
//        fixedMillisecond31.peg(calendar40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond31.previous();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond31.getFirstMillisecond(calendar43);
//        boolean boolean45 = timeSeries3.equals((java.lang.Object) fixedMillisecond31);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.previous();
//        java.lang.String str8 = month4.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException1, seriesChangeInfo3);
        java.lang.Object obj5 = seriesChangeEvent4.getSource();
        java.lang.Class<?> wildcardClass6 = obj5.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        java.lang.String str7 = month4.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "");
//        boolean boolean22 = timeSeries21.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "", "");
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 9999, false);
//        java.util.Collection collection40 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        double double41 = timeSeries28.getMinY();
//        java.util.Collection collection42 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
//        long long45 = day43.getFirstMillisecond();
//        int int46 = day43.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day43.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries3.addAndOrUpdate(timeSeries21);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.createCopy(1, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        java.lang.String str42 = timeSeries27.getDomainDescription();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy(0, 1);
        java.lang.String str19 = timeSeries18.getDescription();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.String str18 = timeSeries11.getDescription();
        java.lang.Object obj19 = timeSeries11.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries11.add(regularTimePeriod20, (java.lang.Number) 1560183289442L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
        boolean boolean39 = timeSeries38.getNotify();
        timeSeries38.setMaximumItemAge((long) 2019);
        int int42 = timeSeries38.getItemCount();
        int int43 = timeSeries38.getMaximumItemCount();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "", "");
        boolean boolean48 = timeSeries47.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries47.removeChangeListener(seriesChangeListener49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month51, "", "");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month55, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries58.addChangeListener(seriesChangeListener59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 9999, false);
        java.util.Collection collection66 = timeSeries54.getTimePeriodsUniqueToOtherSeries(timeSeries58);
        double double67 = timeSeries54.getMinY();
        java.util.Collection collection68 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries54);
        timeSeries54.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month71, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries74.addChangeListener(seriesChangeListener75);
        java.util.Collection collection77 = timeSeries54.getTimePeriodsUniqueToOtherSeries(timeSeries74);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries38.addAndOrUpdate(timeSeries74);
        int int79 = timeSeriesDataItem32.compareTo((java.lang.Object) timeSeries74);
        java.util.Collection collection80 = timeSeries74.getTimePeriods();
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month81, "", "");
        boolean boolean85 = timeSeries84.getNotify();
        timeSeries84.setMaximumItemAge((long) 2019);
        java.lang.Class<?> wildcardClass88 = timeSeries84.getClass();
        boolean boolean89 = timeSeries74.equals((java.lang.Object) wildcardClass88);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2147483647 + "'", int43 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertNotNull(collection77);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(collection80);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.addChangeListener(seriesChangeListener25);
        java.util.Collection collection27 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        double double28 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries36.addChangeListener(seriesChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 9999, false);
        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        double double45 = timeSeries32.getMinY();
        timeSeries32.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection48 = timeSeries32.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries32.removeChangeListener(seriesChangeListener49);
        double double51 = timeSeries32.getMaxY();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month52, "", "");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries59.addChangeListener(seriesChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) 9999, false);
        java.util.Collection collection67 = timeSeries55.getTimePeriodsUniqueToOtherSeries(timeSeries59);
        timeSeries55.setNotify(false);
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month70, "", "");
        long long74 = month70.getMiddleMillisecond();
        long long75 = month70.getSerialIndex();
        int int76 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) month70);
        int int77 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) month70);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.addAndOrUpdate(timeSeries32);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560668399999L + "'", long74 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 24234L + "'", long75 == 24234L);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(timeSeries78);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 1560183238280L);
//        timeSeries6.add(timeSeriesDataItem11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number17);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeriesDataItem18.equals(obj19);
//        int int21 = timeSeriesDataItem11.compareTo((java.lang.Object) boolean20);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        timeSeriesDataItem5.setValue((java.lang.Number) 1560183240083L);
        timeSeriesDataItem5.setSelected(false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        int int27 = day22.compareTo((java.lang.Object) month26);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month26, seriesChangeInfo28);
//        org.jfree.data.time.Year year30 = month26.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        long long33 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = day31.compareTo((java.lang.Object) month35);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month35, seriesChangeInfo37);
//        java.lang.String str39 = seriesChangeEvent38.toString();
//        boolean boolean40 = year30.equals((java.lang.Object) str39);
//        timeSeries3.setKey((java.lang.Comparable) boolean40);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries3.getTimePeriod((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str39.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = month4.equals(obj8);
//        long long10 = month4.getSerialIndex();
//        long long11 = month4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        long long13 = month9.getMiddleMillisecond();
        long long14 = month9.getSerialIndex();
        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getLastMillisecond();
        long long18 = month16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.previous();
        org.jfree.data.time.Year year20 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        long long22 = year20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.previous();
        java.lang.String str24 = year20.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 28799999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        timeSeries10.setMaximumItemAge((long) 0);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        java.util.Collection collection33 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        java.lang.Object obj34 = timeSeries30.clone();
//        timeSeries30.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
//        long long39 = day37.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate40 = day37.getSerialDate();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        int int42 = day37.compareTo((java.lang.Object) month41);
//        long long43 = month41.getSerialIndex();
//        long long44 = month41.getFirstMillisecond();
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        boolean boolean48 = month41.equals((java.lang.Object) "");
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560150000000L + "'", long39 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 24234L + "'", long43 == 24234L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1559372400000L + "'", long44 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
//        int int20 = day0.compareTo((java.lang.Object) fixedMillisecond13);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
//        timeSeries24.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        boolean boolean31 = timeSeries30.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries30.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, "", "");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month38, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries41.addChangeListener(seriesChangeListener42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (double) 9999, false);
//        java.util.Collection collection49 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        double double50 = timeSeries37.getMinY();
//        java.util.Collection collection51 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries24.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.next();
//        int int55 = day53.getMonth();
//        long long56 = day53.getLastMillisecond();
//        long long57 = day53.getFirstMillisecond();
//        int int58 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day53);
//        boolean boolean59 = day0.equals((java.lang.Object) timeSeries24);
//        timeSeries24.setMaximumItemAge(1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(collection49);
//        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560236399999L + "'", long56 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560150000000L + "'", long57 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        boolean boolean15 = fixedMillisecond11.equals((java.lang.Object) (-1.0f));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond11.getFirstMillisecond(calendar16);
        int int18 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        int int21 = fixedMillisecond7.compareTo((java.lang.Object) "10-June-2019");
        long long22 = fixedMillisecond7.getMiddleMillisecond();
        int int23 = month5.compareTo((java.lang.Object) long22);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month13, seriesChangeInfo14);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent15.setSummary(seriesChangeInfo16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.setMaximumItemCount(0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        double double21 = timeSeries3.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener22);
//        java.lang.Object obj24 = timeSeries3.clone();
//        java.util.List list25 = timeSeries3.getItems();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertNotNull(list25);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        java.lang.String str27 = timeSeries3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(str27);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        java.lang.Object obj33 = timeSeries3.clone();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.previous();
//        org.jfree.data.time.Year year38 = month34.getYear();
//        int int39 = year38.getYear();
//        int int40 = year38.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year38);
//        long long43 = year38.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = timeSeries3.equals(obj20);
//        java.lang.Comparable comparable22 = timeSeries3.getKey();
//        long long23 = timeSeries3.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(comparable22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        long long2 = year1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61851744000000L) + "'", long2 == (-61851744000000L));
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = null;
//        try {
//            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long17 = fixedMillisecond16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.next();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass22 = timeSeries21.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date30 = fixedMillisecond29.getTime();
        java.lang.String str31 = fixedMillisecond29.toString();
        java.util.Date date32 = fixedMillisecond29.getTime();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date32, timeZone33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date32, timeZone35);
        java.util.TimeZone timeZone37 = null;
        try {
            org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date32, timeZone37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str31.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 15:59:59 PST 1969");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(0);
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        int int39 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        timeSeries3.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62104204800001L) + "'", long37 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        int int8 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
//        long long13 = month9.getMiddleMillisecond();
//        long long14 = month9.getSerialIndex();
//        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
//        boolean boolean20 = timeSeries19.getNotify();
//        timeSeries19.setMaximumItemAge((long) 2019);
//        int int23 = timeSeries19.getItemCount();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.next();
//        long long26 = day24.getFirstMillisecond();
//        boolean boolean28 = day24.equals((java.lang.Object) 10L);
//        long long29 = day24.getSerialIndex();
//        java.lang.Number number30 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.previous();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) month31);
//        double double36 = timeSeries19.getMinY();
//        double double37 = timeSeries19.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener38);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560150000000L + "'", long26 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1561964399999L + "'", long33 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection40);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        int int7 = month4.getMonth();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        int int18 = day15.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 8);
//        timeSeries11.clear();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener24);
//        java.lang.Comparable comparable26 = timeSeries11.getKey();
//        int int27 = month4.compareTo((java.lang.Object) comparable26);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(comparable26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        java.lang.Object obj14 = null;
        int int15 = fixedMillisecond7.compareTo(obj14);
        java.util.Calendar calendar16 = null;
        fixedMillisecond7.peg(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.previous();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond7.getFirstMillisecond(calendar19);
        long long21 = fixedMillisecond7.getSerialIndex();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond7.getFirstMillisecond(calendar22);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "", "");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.addChangeListener(seriesChangeListener22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 9999, false);
        java.util.Collection collection29 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        double double30 = timeSeries17.getMinY();
        timeSeries17.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection33 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries17.removeChangeListener(seriesChangeListener34);
        boolean boolean37 = timeSeries17.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month40, "", "");
        boolean boolean44 = timeSeries43.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries43.removeChangeListener(seriesChangeListener45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month47, "", "");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month51, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries54.addChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 9999, false);
        java.util.Collection collection62 = timeSeries50.getTimePeriodsUniqueToOtherSeries(timeSeries54);
        double double63 = timeSeries50.getMinY();
        java.util.Collection collection64 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries50);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries50.removeChangeListener(seriesChangeListener65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date69 = fixedMillisecond68.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.previous();
        java.lang.Number number71 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, number71);
        timeSeries50.add(timeSeriesDataItem72, true);
        timeSeries39.add(timeSeriesDataItem72, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries17.addOrUpdate(timeSeriesDataItem72);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
        long long79 = month78.getLastMillisecond();
        long long80 = month78.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month78.previous();
        org.jfree.data.time.Year year82 = month78.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year82.next();
        long long84 = year82.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year82.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year82.previous();
        boolean boolean87 = timeSeriesDataItem72.equals((java.lang.Object) regularTimePeriod86);
        java.util.Date date88 = regularTimePeriod86.getStart();
        java.util.TimeZone timeZone89 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date88, timeZone89);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date88);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1561964399999L + "'", long79 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1561964399999L + "'", long80 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(year82);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 2019L + "'", long84 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNull(regularTimePeriod90);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = timeSeries6.equals((java.lang.Object) wildcardClass15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        timeSeries20.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "");
//        boolean boolean27 = timeSeries26.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 9999, false);
//        java.util.Collection collection45 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        double double46 = timeSeries33.getMinY();
//        java.util.Collection collection47 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries33);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries20.addAndOrUpdate(timeSeries33);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
//        int int51 = day49.getMonth();
//        long long52 = day49.getLastMillisecond();
//        long long53 = day49.getFirstMillisecond();
//        int int54 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
//        int int55 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560236399999L + "'", long52 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560150000000L + "'", long53 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.String str9 = year4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond7.peg(calendar15);
//        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
//        java.util.Date date18 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond7.previous();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        long long22 = day20.getFirstMillisecond();
//        int int23 = day20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
//        java.lang.String str25 = day20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day20.next();
//        boolean boolean27 = fixedMillisecond7.equals((java.lang.Object) regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getLastMillisecond(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.previous();
//        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 8, true);
//        java.lang.Number number51 = timeSeries27.getValue((int) (short) 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 52L + "'", long45 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 8 + "'", number51.equals(8));
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        long long9 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560193199999L + "'", long9 == 1560193199999L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year11 = month10.getYear();
        int int12 = year11.getYear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 10, year11);
        java.util.Date date14 = year11.getStart();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) date14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        long long27 = day25.getFirstMillisecond();
//        int int28 = day25.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day25.previous();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        double double13 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 9999.0d + "'", double13 == 9999.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.Date date5 = year4.getEnd();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        try {
            java.lang.Number number23 = timeSeries3.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        java.lang.String str27 = fixedMillisecond25.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        long long32 = day30.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        boolean boolean34 = fixedMillisecond28.equals((java.lang.Object) serialDate33);
//        boolean boolean35 = fixedMillisecond25.equals((java.lang.Object) serialDate33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        try {
//            java.lang.Class<?> wildcardClass37 = timeSeriesDataItem36.getClass();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str27.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560183306772L + "'", long29 == 1560183306772L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
//        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        double double29 = timeSeries16.getMinY();
//        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        long long36 = day32.getFirstMillisecond();
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.String str38 = timeSeries3.getDescription();
//        timeSeries3.setMaximumItemCount(2147483647);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str38.equals("org.jfree.data.general.SeriesException: "));
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number15);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = timeSeriesDataItem16.equals(obj17);
//        timeSeries6.add(timeSeriesDataItem16);
//        java.lang.Object obj20 = timeSeriesDataItem16.clone();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(obj20);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        double double22 = timeSeries3.getMaxY();
        java.lang.String str23 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        int int7 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
//        org.jfree.data.time.Year year4 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        long long8 = day6.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = day6.compareTo((java.lang.Object) month10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month10, seriesChangeInfo12);
//        boolean boolean14 = month0.equals((java.lang.Object) month10);
//        org.jfree.data.time.Year year15 = month0.getYear();
//        long long16 = year15.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond7.next();
        long long14 = fixedMillisecond7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        timeSeries3.clear();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener16);
//        java.lang.Comparable comparable18 = timeSeries3.getKey();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getTimePeriod(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(comparable18);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        long long26 = month25.getLastMillisecond();
//        long long27 = month25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.previous();
//        org.jfree.data.time.Year year29 = month25.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year29, (double) 28799999L);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        timeSeries36.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection52 = timeSeries36.getTimePeriods();
//        boolean boolean53 = timeSeries36.getNotify();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month54, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
//        timeSeries57.addChangeListener(seriesChangeListener58);
//        java.util.Collection collection60 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries57);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries3.addAndOrUpdate(timeSeries36);
//        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long66 = fixedMillisecond65.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond65.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond69.getLastMillisecond(calendar70);
//        boolean boolean73 = fixedMillisecond69.equals((java.lang.Object) (-1.0f));
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond69.getFirstMillisecond(calendar74);
//        int int76 = fixedMillisecond65.compareTo((java.lang.Object) fixedMillisecond69);
//        long long77 = fixedMillisecond65.getLastMillisecond();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(collection60);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1L) + "'", long66 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 52L + "'", long71 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        boolean boolean20 = timeSeries3.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        long long25 = day23.getFirstMillisecond();
//        boolean boolean27 = day23.equals((java.lang.Object) 10L);
//        long long28 = day23.getSerialIndex();
//        java.util.Date date29 = day23.getStart();
//        int int30 = day23.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.String str34 = day31.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day31.previous();
//        long long36 = day31.getLastMillisecond();
//        int int37 = day31.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day31.next();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        long long28 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        int int31 = day26.compareTo((java.lang.Object) month30);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month30, seriesChangeInfo32);
//        org.jfree.data.time.Year year34 = month30.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month30, seriesChangeInfo37);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        timeSeries6.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        long long13 = fixedMillisecond10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        try {
//            timeSeries6.delete((int) (short) 10, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
        java.util.List list6 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(list6);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond7.peg(calendar15);
//        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
//        java.util.Date date18 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        long long21 = day19.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        int int23 = fixedMillisecond7.compareTo((java.lang.Object) serialDate22);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int15 = timeSeries3.getMaximumItemCount();
//        long long16 = timeSeries3.getMaximumItemAge();
//        java.lang.String str17 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        long long20 = day18.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int23 = day18.compareTo((java.lang.Object) month22);
//        long long24 = month22.getSerialIndex();
//        long long25 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (-61820208000001L));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24234L + "'", long24 == 24234L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException3, seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        boolean boolean8 = year1.equals(obj7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(0);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = year10.compareTo((java.lang.Object) month12);
        boolean boolean14 = year1.equals((java.lang.Object) year10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62104204800001L) + "'", long11 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setNotify(false);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "");
        long long22 = month18.getMiddleMillisecond();
        long long23 = month18.getSerialIndex();
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.Object obj25 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        java.lang.Object obj6 = timeSeries3.clone();
        java.lang.Object obj7 = timeSeries3.clone();
        java.lang.Object obj8 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener64);
//        timeSeries3.setDomainDescription("Wed Dec 31 15:59:59 PST 1969");
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.next();
//        long long70 = day68.getFirstMillisecond();
//        boolean boolean72 = day68.equals((java.lang.Object) 10L);
//        long long73 = day68.getLastMillisecond();
//        int int74 = day68.getDayOfMonth();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day68, (java.lang.Number) (short) -1, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560150000000L + "'", long70 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560236399999L + "'", long73 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560183238280L);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        boolean boolean6 = timeSeriesDataItem4.isSelected();
//        java.lang.Number number7 = timeSeriesDataItem4.getValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.56018323828E12d + "'", number7.equals(1.56018323828E12d));
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getLastMillisecond();
//        int int9 = day0.getYear();
//        java.lang.String str10 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        long long7 = month4.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = month4.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        long long13 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getLastMillisecond();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
//        long long46 = day44.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
//        boolean boolean48 = fixedMillisecond42.equals((java.lang.Object) serialDate47);
//        long long49 = fixedMillisecond42.getSerialIndex();
//        java.lang.Number number50 = null;
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, number50, false);
//        long long53 = fixedMillisecond42.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560183308429L + "'", long43 == 1560183308429L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560183308429L + "'", long49 == 1560183308429L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560183308429L + "'", long53 == 1560183308429L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.String str4 = year3.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        timeSeries3.clear();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
//        boolean boolean13 = timeSeries12.getNotify();
//        timeSeries12.setMaximumItemAge((long) 2019);
//        int int16 = timeSeries12.getItemCount();
//        int int17 = timeSeries12.getMaximumItemCount();
//        java.util.Collection collection18 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        long long21 = day19.getFirstMillisecond();
//        boolean boolean23 = day19.equals((java.lang.Object) 10L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) 0);
//        java.lang.Object obj28 = timeSeries3.clone();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(obj28);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        long long20 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month15.next();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.removeAgedItems(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        long long8 = month6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        int int10 = year4.compareTo((java.lang.Object) month6);
        long long11 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        int int69 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 7 + "'", int69 == 7);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
//        org.jfree.data.time.Year year4 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        long long8 = day6.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = day6.compareTo((java.lang.Object) month10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month10, seriesChangeInfo12);
//        boolean boolean14 = month0.equals((java.lang.Object) month10);
//        org.jfree.data.time.Year year15 = month0.getYear();
//        java.util.Date date16 = month0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries3.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        boolean boolean4 = month0.equals((java.lang.Object) (byte) -1);
        long long5 = month0.getFirstMillisecond();
        long long6 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        timeSeries6.clear();
//        java.lang.String str10 = timeSeries6.getDescription();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertNull(str10);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        double double9 = timeSeries3.getMinY();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener4);
//        boolean boolean7 = timeSeries3.equals((java.lang.Object) 43626L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        long long12 = day10.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        boolean boolean14 = fixedMillisecond8.equals((java.lang.Object) serialDate13);
//        long long15 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond8.peg(calendar17);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183309185L + "'", long9 == 1560183309185L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183309185L + "'", long15 == 1560183309185L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getLastMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond7.peg(calendar15);
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getEnd();
        java.util.TimeZone timeZone19 = null;
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = timeSeries3.clone();
//        java.lang.Object obj7 = timeSeries3.clone();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        boolean boolean12 = timeSeries11.getNotify();
//        timeSeries11.setMaximumItemAge((long) 2019);
//        int int15 = timeSeries11.getItemCount();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        long long18 = day16.getFirstMillisecond();
//        boolean boolean20 = day16.equals((java.lang.Object) 10L);
//        long long21 = day16.getSerialIndex();
//        java.lang.Number number22 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        long long25 = day23.getFirstMillisecond();
//        boolean boolean27 = day23.equals((java.lang.Object) 10L);
//        long long28 = day23.getLastMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getLastMillisecond();
//        long long32 = month30.getLastMillisecond();
//        boolean boolean34 = month30.equals((java.lang.Object) (byte) -1);
//        long long35 = month30.getFirstMillisecond();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 1L);
//        timeSeries11.removeAgedItems((long) 9999, true);
//        timeSeries11.removeAgedItems(true);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(0);
//        long long45 = year44.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.next();
//        int int47 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
//        java.lang.String str48 = year44.toString();
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 2019L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62104204800001L) + "'", long45 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        double double49 = timeSeries36.getMinY();
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries36.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
        timeSeries36.add(timeSeriesDataItem58, true);
        timeSeries25.add(timeSeriesDataItem58, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries3.removeChangeListener(seriesChangeListener64);
        java.lang.Class class66 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(class66);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.util.List list18 = timeSeries11.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getLastMillisecond();
        long long21 = month19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.previous();
        org.jfree.data.time.Year year23 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem26);
        java.lang.String str28 = timeSeries11.getDomainDescription();
        java.util.List list29 = timeSeries11.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(list29);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        long long4 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) serialDate5);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond0.peg(calendar8);
//        long long10 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183309732L + "'", long1 == 1560183309732L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183309732L + "'", long7 == 1560183309732L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183309732L + "'", long10 == 1560183309732L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        long long17 = day8.getFirstMillisecond();
//        long long18 = day8.getSerialIndex();
//        int int19 = day8.getDayOfMonth();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day8.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getLastMillisecond(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.previous();
//        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 8, true);
//        int int50 = timeSeries27.getItemCount();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 52L + "'", long45 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        timeSeries3.removeAgedItems(1L, true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = timeSeries3.clone();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        boolean boolean11 = day7.equals((java.lang.Object) 10L);
//        long long12 = day7.getLastMillisecond();
//        java.lang.String str13 = day7.toString();
//        long long14 = day7.getLastMillisecond();
//        int int15 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        java.lang.String str8 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        timeSeries3.setRangeDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = null;
        try {
            timeSeries3.add(timeSeriesDataItem22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        double double23 = timeSeries10.getMinY();
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
//        timeSeries10.add(timeSeriesDataItem32, true);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
//        boolean boolean39 = timeSeries38.getNotify();
//        timeSeries38.setMaximumItemAge((long) 2019);
//        int int42 = timeSeries38.getItemCount();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
//        long long45 = day43.getFirstMillisecond();
//        boolean boolean47 = day43.equals((java.lang.Object) 10L);
//        long long48 = day43.getSerialIndex();
//        java.lang.Number number49 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.next();
//        long long52 = day50.getFirstMillisecond();
//        boolean boolean54 = day50.equals((java.lang.Object) 10L);
//        long long55 = day50.getLastMillisecond();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        long long58 = month57.getLastMillisecond();
//        long long59 = month57.getLastMillisecond();
//        boolean boolean61 = month57.equals((java.lang.Object) (byte) -1);
//        long long62 = month57.getFirstMillisecond();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1L);
//        timeSeries38.removeAgedItems((long) 9999, true);
//        timeSeries38.removeAgedItems(true);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(0);
//        long long72 = year71.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year71.next();
//        int int74 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) year71);
//        boolean boolean75 = timeSeriesDataItem32.equals((java.lang.Object) year71);
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month76, "", "");
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month80, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener84 = null;
//        timeSeries83.addChangeListener(seriesChangeListener84);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries83.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond87, (double) 9999, false);
//        java.util.Collection collection91 = timeSeries79.getTimePeriodsUniqueToOtherSeries(timeSeries83);
//        double double92 = timeSeries79.getMinY();
//        timeSeries79.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection95 = timeSeries79.getTimePeriods();
//        boolean boolean96 = timeSeries79.getNotify();
//        java.lang.String str97 = timeSeries79.getDescription();
//        boolean boolean98 = timeSeriesDataItem32.equals((java.lang.Object) str97);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560236399999L + "'", long55 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1561964399999L + "'", long58 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1561964399999L + "'", long59 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1559372400000L + "'", long62 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-62104204800001L) + "'", long72 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(collection91);
//        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection95);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
//        org.junit.Assert.assertNull(str97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
        long long7 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        timeSeries11.setDescription("org.jfree.data.general.SeriesException: ");
        java.lang.String str16 = timeSeries11.getDomainDescription();
        timeSeries11.setDomainDescription("Value");
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("");
        double double8 = timeSeries3.getMinY();
        try {
            timeSeries3.delete((-9999), 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        int int22 = timeSeries3.getItemCount();
//        java.lang.String str23 = timeSeries3.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) 4);
        timeSeries3.setMaximumItemCount((int) (byte) 0);
        boolean boolean24 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date27 = fixedMillisecond26.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond26.previous();
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond32.getLastMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        fixedMillisecond32.peg(calendar40);
        int int42 = timeSeriesDataItem30.compareTo((java.lang.Object) fixedMillisecond32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getLastMillisecond();
        long long10 = month8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.previous();
        org.jfree.data.time.Year year12 = month8.getYear();
        int int13 = year12.getYear();
        int int14 = year12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod15);
        int int17 = timeSeries3.getItemCount();
        java.lang.String str18 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=]" + "'", str18.equals("org.jfree.data.event.SeriesChangeEvent[source=]"));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getLastMillisecond();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
//        long long46 = day44.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
//        boolean boolean48 = fixedMillisecond42.equals((java.lang.Object) serialDate47);
//        long long49 = fixedMillisecond42.getSerialIndex();
//        java.lang.Number number50 = null;
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, number50, false);
//        boolean boolean53 = timeSeries41.isEmpty();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560183310765L + "'", long43 == 1560183310765L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560183310765L + "'", long49 == 1560183310765L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560183265756L);
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        long long4 = month0.getMiddleMillisecond();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "");
//        boolean boolean30 = timeSeries29.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 9999, false);
//        java.util.Collection collection48 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        double double49 = timeSeries36.getMinY();
//        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number57);
//        timeSeries36.add(timeSeriesDataItem58, true);
//        timeSeries25.add(timeSeriesDataItem58, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate(timeSeriesDataItem58);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        long long65 = year64.getSerialIndex();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.next();
//        long long68 = day66.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
//        int int71 = day66.compareTo((java.lang.Object) month70);
//        int int72 = day66.getYear();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year64, (org.jfree.data.time.RegularTimePeriod) day66);
//        timeSeries73.removeAgedItems(false);
//        try {
//            timeSeries73.update(4, (java.lang.Number) 1560183265756L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560150000000L + "'", long68 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.removeChangeListener(seriesChangeListener26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month32, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 9999, false);
//        java.util.Collection collection43 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        double double44 = timeSeries31.getMinY();
//        java.util.Collection collection45 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 0);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries51.addChangeListener(seriesChangeListener52);
//        java.util.Collection collection54 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries51);
//        java.util.List list55 = timeSeries51.getItems();
//        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries51);
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Number number61 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, number61);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertNotNull(collection54);
//        org.junit.Assert.assertNotNull(list55);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.addChangeListener(seriesChangeListener25);
        java.util.Collection collection27 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        long long28 = timeSeries24.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        int int6 = year4.getYear();
        long long7 = year4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 28799999L);
        long long71 = month2.getSerialIndex();
        int int72 = month2.getMonth();
        java.util.Calendar calendar73 = null;
        try {
            month2.peg(calendar73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 19L + "'", long71 == 19L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 7 + "'", int72 == 7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        double double32 = timeSeries19.getMinY();
        java.util.Collection collection33 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.addChangeListener(seriesChangeListener40);
        java.util.Collection collection42 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.addAndOrUpdate(timeSeries39);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeries43.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(timeSeries43);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 28799999L);
        long long71 = month2.getLastMillisecond();
        long long72 = month2.getFirstMillisecond();
        long long73 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-62117424000001L) + "'", long71 == (-62117424000001L));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-62120102400000L) + "'", long72 == (-62120102400000L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-62117424000001L) + "'", long73 == (-62117424000001L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setValue((java.lang.Number) 1560183232403L);
        java.lang.Object obj37 = timeSeriesDataItem32.clone();
        java.lang.Number number38 = timeSeriesDataItem32.getValue();
        java.lang.Object obj39 = timeSeriesDataItem32.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1560183232403L + "'", number38.equals(1560183232403L));
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Comparable comparable18 = timeSeries17.getKey();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getLastMillisecond();
        long long21 = month19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.previous();
        org.jfree.data.time.Year year23 = month19.getYear();
        int int24 = year23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        long long26 = year23.getFirstMillisecond();
        boolean boolean27 = timeSeries17.equals((java.lang.Object) long26);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "Overwritten values from: June 2019" + "'", comparable18.equals("Overwritten values from: June 2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        int int16 = day8.compareTo((java.lang.Object) (byte) 10);
//        long long17 = day8.getFirstMillisecond();
//        long long18 = day8.getSerialIndex();
//        int int19 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day8.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(serialDate20);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date10, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 9999, false);
        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        double double24 = timeSeries11.getMinY();
        timeSeries11.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection27 = timeSeries11.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries11.removeChangeListener(seriesChangeListener28);
        boolean boolean31 = timeSeries11.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, "", "");
        boolean boolean38 = timeSeries37.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries37.removeChangeListener(seriesChangeListener39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month45, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries48.addChangeListener(seriesChangeListener49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 9999, false);
        java.util.Collection collection56 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries48);
        double double57 = timeSeries44.getMinY();
        java.util.Collection collection58 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries44.removeChangeListener(seriesChangeListener59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date63 = fixedMillisecond62.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond62.previous();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, number65);
        timeSeries44.add(timeSeriesDataItem66, true);
        timeSeries33.add(timeSeriesDataItem66, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries11.addOrUpdate(timeSeriesDataItem66);
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month();
        long long73 = month72.getLastMillisecond();
        long long74 = month72.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month72.previous();
        org.jfree.data.time.Year year76 = month72.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year76.next();
        long long78 = year76.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year76.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year76.previous();
        boolean boolean81 = timeSeriesDataItem66.equals((java.lang.Object) regularTimePeriod80);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries6.addOrUpdate(regularTimePeriod80, (java.lang.Number) (-9999));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1561964399999L + "'", long73 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1561964399999L + "'", long74 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(year76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 2019L + "'", long78 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem83);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = month4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        int int4 = month2.compareTo((java.lang.Object) fixedMillisecond3);
        boolean boolean5 = year1.equals((java.lang.Object) int4);
        java.util.Calendar calendar6 = null;
        try {
            year1.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        double double22 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 9999, false);
        java.util.Collection collection38 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        timeSeries26.setNotify(false);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        long long45 = month41.getMiddleMillisecond();
        long long46 = month41.getSerialIndex();
        int int47 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        int int48 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries3.addChangeListener(seriesChangeListener49);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560668399999L + "'", long45 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 24234L + "'", long46 == 24234L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        boolean boolean20 = timeSeries3.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        long long25 = day23.getFirstMillisecond();
//        boolean boolean27 = day23.equals((java.lang.Object) 10L);
//        long long28 = day23.getSerialIndex();
//        java.util.Date date29 = day23.getStart();
//        int int30 = day23.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.String str34 = day31.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day31.previous();
//        long long36 = day31.getLastMillisecond();
//        int int37 = day31.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) (byte) 10);
//        long long41 = year40.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year40, 0.0d);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560183263852L);
//        java.lang.String str15 = day12.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        java.lang.String str35 = timeSeries3.getRangeDescription();
//        timeSeries3.setMaximumItemAge((long) 6);
//        boolean boolean38 = timeSeries3.getNotify();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        java.lang.String str35 = timeSeries3.getRangeDescription();
//        boolean boolean36 = timeSeries3.getNotify();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        java.lang.String str17 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long20 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.addAndOrUpdate(timeSeries24);
        double double26 = timeSeries25.getMaxY();
        try {
            timeSeries25.update(2019, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number31);
        timeSeries10.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setValue((java.lang.Number) 1560183232403L);
        java.lang.Number number37 = timeSeriesDataItem32.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1560183232403L + "'", number37.equals(1560183232403L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 3, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        int int22 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999, false);
        java.util.Collection collection19 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        double double20 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection23 = timeSeries7.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries7.removeChangeListener(seriesChangeListener24);
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 52L);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "", "");
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.addChangeListener(seriesChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 9999, false);
        java.util.Collection collection52 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        double double53 = timeSeries40.getMinY();
        java.util.Collection collection54 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries40.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date59 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond58.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, number61);
        timeSeries40.add(timeSeriesDataItem62, true);
        timeSeries29.add(timeSeriesDataItem62, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem62);
        int int68 = month2.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 28799999L);
        timeSeriesDataItem70.setSelected(false);
        java.lang.Object obj73 = timeSeriesDataItem70.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeriesDataItem70.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
//        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        double double29 = timeSeries16.getMinY();
//        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        long long36 = day32.getFirstMillisecond();
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
//        java.util.Date date38 = day32.getStart();
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
//        java.lang.Object obj39 = null;
//        int int40 = year38.compareTo(obj39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) year38);
//        timeSeries3.setMaximumItemCount(0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        timeSeries3.clear();
        java.util.List list10 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = month0.getYearValue();
        java.lang.Object obj6 = null;
        int int7 = month0.compareTo(obj6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.lang.String str4 = regularTimePeriod3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 2019" + "'", str4.equals("May 2019"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (short) 100);
        long long3 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58995878400000L) + "'", long3 == (-58995878400000L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, "org.jfree.data.time.TimePeriodFormatException: 10-June-2019", "0");
        timeSeries5.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.util.Date date6 = year4.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + "" + "'", obj5.equals(""));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        double double21 = timeSeries3.getMaxY();
//        java.lang.String str22 = timeSeries3.getRangeDescription();
//        timeSeries3.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9999, false);
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double22 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries3.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate(regularTimePeriod14, 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        boolean boolean21 = timeSeries20.getNotify();
        timeSeries20.setMaximumItemAge((long) 2019);
        int int24 = timeSeries20.getItemCount();
        int int25 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.lang.String str27 = timeSeries20.getDescription();
        boolean boolean28 = year4.equals((java.lang.Object) timeSeries20);
        timeSeries20.setMaximumItemCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year4 = month3.getYear();
        int int5 = year4.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, year4);
        java.util.Date date7 = year4.getStart();
        java.lang.String str8 = year4.toString();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        long long9 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        long long6 = month5.getFirstMillisecond();
        long long7 = month5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2649600000L) + "'", long6 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2649600000L) + "'", long7 == (-2649600000L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        java.lang.Object obj27 = timeSeries3.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(obj27);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        long long21 = day19.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        boolean boolean23 = fixedMillisecond17.equals((java.lang.Object) serialDate22);
//        long long24 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = month25.compareTo((java.lang.Object) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) month25);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 9999, false);
//        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        double double45 = timeSeries32.getMinY();
//        timeSeries32.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection48 = timeSeries32.getTimePeriods();
//        boolean boolean49 = timeSeries32.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.next();
//        long long54 = day52.getFirstMillisecond();
//        boolean boolean56 = day52.equals((java.lang.Object) 10L);
//        long long57 = day52.getSerialIndex();
//        java.util.Date date58 = day52.getStart();
//        int int59 = day52.getYear();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day60.next();
//        long long62 = day60.getFirstMillisecond();
//        java.lang.String str63 = day60.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day60.previous();
//        long long65 = day60.getLastMillisecond();
//        int int66 = day60.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day52, (org.jfree.data.time.RegularTimePeriod) day60);
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day52, (java.lang.Number) 1969L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries28.getDataItem((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183314761L + "'", long18 == 1560183314761L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183314761L + "'", long24 == 1560183314761L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 43626L + "'", long57 == 43626L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560150000000L + "'", long62 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10-June-2019" + "'", str63.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertNotNull(timeSeries67);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(2019);
        timeSeries3.setKey((java.lang.Comparable) year18);
        long long20 = year18.getFirstMillisecond();
        long long21 = year18.getFirstMillisecond();
        java.lang.Class<?> wildcardClass22 = year18.getClass();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9999, false);
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double22 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        boolean boolean26 = timeSeries9.isEmpty();
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        long long28 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        int int31 = day26.compareTo((java.lang.Object) month30);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month30, seriesChangeInfo32);
//        org.jfree.data.time.Year year34 = month30.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 0);
//        long long37 = month30.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) 4);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 9999, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries25.addChangeListener(seriesChangeListener33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.addChangeListener(seriesChangeListener39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) 9999, false);
        java.util.Calendar calendar46 = null;
        fixedMillisecond42.peg(calendar46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond42.next();
        java.lang.Object obj49 = null;
        int int50 = fixedMillisecond42.compareTo(obj49);
        long long51 = fixedMillisecond42.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        timeSeries3.add(timeSeriesDataItem52, false);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = month0.compareTo((java.lang.Object) fixedMillisecond1);
        int int3 = month0.getMonth();
        int int4 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        timeSeries3.removeAgedItems((long) 9999, true);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(0);
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        int int39 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
//        java.lang.String str40 = year36.toString();
//        java.util.Date date41 = year36.getStart();
//        java.util.TimeZone timeZone42 = null;
//        java.util.Locale locale43 = null;
//        try {
//            org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date41, timeZone42, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62104204800001L) + "'", long37 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
//        org.junit.Assert.assertNotNull(date41);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        boolean boolean10 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
//        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        double double29 = timeSeries16.getMinY();
//        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        long long36 = day32.getFirstMillisecond();
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(0);
//        long long40 = year39.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
//        long long46 = day44.getFirstMillisecond();
//        int int47 = day44.getYear();
//        java.lang.String str48 = day44.toString();
//        org.jfree.data.time.SerialDate serialDate49 = day44.getSerialDate();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(2019);
//        int int53 = day50.compareTo((java.lang.Object) 2019);
//        java.lang.Number number54 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day50);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (byte) 100 + "'", number54.equals((byte) 100));
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        boolean boolean12 = timeSeries11.getNotify();
//        timeSeries11.setMaximumItemAge((long) 2019);
//        int int15 = timeSeries11.getItemCount();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        long long18 = day16.getFirstMillisecond();
//        boolean boolean20 = day16.equals((java.lang.Object) 10L);
//        long long21 = day16.getSerialIndex();
//        java.lang.Number number22 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getLastMillisecond();
//        long long25 = month23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.previous();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
//        double double28 = timeSeries11.getMinY();
//        java.lang.String str29 = timeSeries11.getDescription();
//        timeSeries11.clear();
//        java.util.Collection collection31 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int34 = day32.getMonth();
//        long long35 = day32.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day32, "", "");
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day32, 0.0d, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge((long) 2019);
        int int7 = timeSeries3.getItemCount();
        int int8 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        boolean boolean13 = timeSeries12.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.addChangeListener(seriesChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999, false);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        double double32 = timeSeries19.getMinY();
        java.util.Collection collection33 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.setMaximumItemAge((long) 0);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.addChangeListener(seriesChangeListener40);
        java.util.Collection collection42 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.addAndOrUpdate(timeSeries39);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.addChangeListener(seriesChangeListener52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (double) 9999, false);
        java.util.Collection collection59 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries39.addAndOrUpdate(timeSeries51);
        java.lang.Object obj61 = timeSeries39.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(collection59);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(obj61);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        long long9 = day7.getFirstMillisecond();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        timeSeries3.clear();
//        java.lang.Comparable comparable16 = timeSeries3.getKey();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries3.addChangeListener(seriesChangeListener17);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(comparable16);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        double double16 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection19 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        java.lang.String str27 = fixedMillisecond25.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        long long32 = day30.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        boolean boolean34 = fixedMillisecond28.equals((java.lang.Object) serialDate33);
//        boolean boolean35 = fixedMillisecond25.equals((java.lang.Object) serialDate33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Object obj37 = null;
//        int int38 = fixedMillisecond25.compareTo(obj37);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str27.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560183316842L + "'", long29 == 1560183316842L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.lang.String str4 = year1.toString();
        java.util.Date date5 = year1.getStart();
        long long6 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167363200000L) + "'", long6 == (-62167363200000L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long17 = fixedMillisecond16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.next();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass22 = timeSeries21.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date30 = fixedMillisecond29.getTime();
        java.lang.String str31 = fixedMillisecond29.toString();
        java.util.Date date32 = fixedMillisecond29.getTime();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date32, timeZone33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date32, timeZone35);
        java.util.TimeZone timeZone37 = null;
        try {
            org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date32, timeZone37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str31.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 9999, false);
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        double double25 = timeSeries12.getMinY();
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries12.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
        timeSeries12.add(timeSeriesDataItem34, true);
        timeSeries1.add(timeSeriesDataItem34, false);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.previous();
        long long41 = month39.getLastMillisecond();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 3);
        long long44 = month39.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 24234L + "'", long44 == 24234L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries9.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        double double29 = timeSeries16.getMinY();
        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
        boolean boolean32 = timeSeries16.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date35 = fixedMillisecond34.getTime();
        java.lang.String str36 = fixedMillisecond34.toString();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 1560183290490L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str36.equals("Wed Dec 31 15:59:59 PST 1969"));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
//        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "", "");
//        long long29 = month25.getMiddleMillisecond();
//        long long30 = month25.getSerialIndex();
//        int int31 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
//        int int32 = day0.compareTo((java.lang.Object) int31);
//        java.lang.String str33 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.lang.String str26 = fixedMillisecond24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond24.previous();
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("");
        java.lang.String str32 = seriesException31.toString();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("");
        seriesException31.addSuppressed((java.lang.Throwable) seriesException34);
        java.lang.Class<?> wildcardClass36 = seriesException31.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        java.util.Date date40 = fixedMillisecond38.getTime();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date40);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date40);
        int int45 = fixedMillisecond24.compareTo((java.lang.Object) month44);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str26.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str32.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Comparable comparable18 = timeSeries17.getKey();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        timeSeries17.setMaximumItemCount(10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "Overwritten values from: June 2019" + "'", comparable18.equals("Overwritten values from: June 2019"));
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getLastMillisecond();
//        long long24 = month22.getLastMillisecond();
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) -1);
//        long long27 = month22.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1L);
//        java.lang.String str30 = timeSeries3.getDomainDescription();
//        double double31 = timeSeries3.getMaxY();
//        long long32 = timeSeries3.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getLastMillisecond();
        java.lang.Object obj3 = null;
        boolean boolean4 = month0.equals(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
//        java.lang.String str3 = seriesChangeEvent2.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent2.setSummary(seriesChangeInfo4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent2.getSummary();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]"));
//        org.junit.Assert.assertNull(seriesChangeInfo6);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.TimeZone timeZone13 = null;
//        try {
//            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException1, seriesChangeInfo3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        java.lang.String str8 = seriesException7.toString();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        seriesException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.Class<?> wildcardClass12 = seriesException7.getClass();
        java.lang.Throwable[] throwableArray13 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException7.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.String str16 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str16.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy((int) (short) 0, 1);
        java.lang.Object obj7 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        boolean boolean20 = timeSeries3.getNotify();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.addChangeListener(seriesChangeListener25);
        java.util.Collection collection27 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        double double28 = timeSeries3.getMaxY();
        int int29 = timeSeries3.getMaximumItemCount();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries9.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9999, false);
        java.util.Collection collection28 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        double double29 = timeSeries16.getMinY();
        java.util.Collection collection30 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.addAndOrUpdate(timeSeries16);
        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries16.addChangeListener(seriesChangeListener34);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getLastMillisecond();
        long long5 = month3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month3.previous();
        org.jfree.data.time.Year year7 = month3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560236399999L);
        long long10 = year7.getLastMillisecond();
        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) long10);
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) "org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
//        int int20 = day0.compareTo((java.lang.Object) fixedMillisecond13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond13.next();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond13.getFirstMillisecond(calendar22);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        long long5 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(regularTimePeriod9, (double) 0L);
        java.lang.String str12 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.general.SeriesException: ", "Value");
        long long7 = fixedMillisecond1.getFirstMillisecond();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) 1560183260090L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries10.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month2);
        int int5 = month2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        long long21 = day19.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        boolean boolean23 = fixedMillisecond17.equals((java.lang.Object) serialDate22);
//        long long24 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = month25.compareTo((java.lang.Object) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) month25);
//        java.util.Calendar calendar29 = null;
//        try {
//            month25.peg(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183318553L + "'", long18 == 1560183318553L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183318553L + "'", long24 == 1560183318553L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
//        int int4 = year1.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        int int7 = day5.getMonth();
//        long long8 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, "", "");
//        timeSeries11.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        long long17 = month16.getLastMillisecond();
//        long long18 = month16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.previous();
//        org.jfree.data.time.Year year20 = month16.getYear();
//        int int21 = year20.getYear();
//        int int22 = year20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.previous();
//        long long24 = year20.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        int int28 = day26.getMonth();
//        long long29 = day26.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day26, "", "");
//        timeSeries32.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
//        java.lang.Number number41 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, number41);
//        java.lang.Object obj43 = null;
//        boolean boolean44 = timeSeriesDataItem42.equals(obj43);
//        timeSeries32.add(timeSeriesDataItem42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries25.addAndOrUpdate(timeSeries32);
//        int int47 = year1.compareTo((java.lang.Object) timeSeries46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond49.getLastMillisecond(calendar50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond49.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        long long54 = fixedMillisecond49.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800001L) + "'", long2 == (-62104204800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 52L + "'", long54 == 52L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9999, false);
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double22 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        timeSeries3.removeAgedItems(1560183261321L, false);
        java.lang.Comparable comparable29 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(comparable29);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "org.jfree.data.event.SeriesChangeEvent[source=June 2019]", "org.jfree.data.event.SeriesChangeEvent[source=June 2019]");
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date10 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date15 = fixedMillisecond14.getTime();
        java.lang.String str16 = fixedMillisecond14.toString();
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date17, timeZone18);
        java.util.TimeZone timeZone20 = null;
        java.util.Locale locale21 = null;
        try {
            org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate(regularTimePeriod9, 1.0d);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "");
//        boolean boolean16 = timeSeries15.getNotify();
//        timeSeries15.setMaximumItemAge((long) 2019);
//        int int19 = timeSeries15.getItemCount();
//        int int20 = timeSeries15.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.addAndOrUpdate(timeSeries15);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries7.addChangeListener(seriesChangeListener22);
//        int int24 = day0.compareTo((java.lang.Object) seriesChangeListener22);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=]");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        int int28 = day27.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day27.previous();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        long long31 = month30.getLastMillisecond();
        long long32 = month30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.previous();
        org.jfree.data.time.Year year34 = month30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) year34);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems(true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        double double16 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (-1));
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.removeChangeListener(seriesChangeListener20);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) 52L);
        java.lang.String str24 = timeSeries3.getRangeDescription();
        try {
            java.lang.Number number26 = timeSeries3.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9999, false);
        java.lang.Object obj11 = null;
        int int12 = fixedMillisecond7.compareTo(obj11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getFirstMillisecond(calendar13);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
//        java.lang.String str3 = seriesChangeEvent2.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent2.setSummary(seriesChangeInfo4);
//        java.lang.Object obj6 = seriesChangeEvent2.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=11-June-2019]"));
//        org.junit.Assert.assertNotNull(obj6);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getLastMillisecond();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        double double20 = timeSeries3.getMinY();
//        java.lang.String str21 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        int int27 = day22.compareTo((java.lang.Object) month26);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month26, seriesChangeInfo28);
//        org.jfree.data.time.Year year30 = month26.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        long long33 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = day31.compareTo((java.lang.Object) month35);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month35, seriesChangeInfo37);
//        java.lang.String str39 = seriesChangeEvent38.toString();
//        boolean boolean40 = year30.equals((java.lang.Object) str39);
//        timeSeries3.setKey((java.lang.Comparable) boolean40);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date45 = fixedMillisecond44.getTime();
//        java.lang.String str46 = fixedMillisecond44.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getLastMillisecond();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
//        long long51 = day49.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate52 = day49.getSerialDate();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) serialDate52);
//        boolean boolean54 = fixedMillisecond44.equals((java.lang.Object) serialDate52);
//        java.lang.Number number55 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number55, false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str39.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str46.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560183319322L + "'", long48 == 1560183319322L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560150000000L + "'", long51 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        long long4 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        long long15 = month14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        long long17 = month14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 23640L + "'", long17 == 23640L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("May 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "");
//        java.lang.String str10 = seriesChangeEvent9.toString();
//        java.lang.Object obj11 = seriesChangeEvent9.getSource();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = seriesChangeEvent9.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = seriesChangeEvent9.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = seriesChangeEvent9.getSummary();
//        java.lang.Object obj15 = seriesChangeEvent9.getSource();
//        int int16 = day0.compareTo((java.lang.Object) seriesChangeEvent9);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day0.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=]" + "'", str10.equals("org.jfree.data.event.SeriesChangeEvent[source=]"));
//        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "" + "'", obj11.equals(""));
//        org.junit.Assert.assertNull(seriesChangeInfo12);
//        org.junit.Assert.assertNull(seriesChangeInfo13);
//        org.junit.Assert.assertNull(seriesChangeInfo14);
//        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + "" + "'", obj15.equals(""));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        int int20 = day18.getMonth();
//        long long21 = day18.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day18, "", "");
//        timeSeries24.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date31 = fixedMillisecond30.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = timeSeriesDataItem34.equals(obj35);
//        timeSeries24.add(timeSeriesDataItem34);
//        timeSeries3.add(timeSeriesDataItem34);
//        timeSeriesDataItem34.setValue((java.lang.Number) 1560183282495L);
//        boolean boolean41 = timeSeriesDataItem34.isSelected();
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.util.List list18 = timeSeries11.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getLastMillisecond();
        long long21 = month19.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.previous();
        org.jfree.data.time.Year year23 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem26);
        java.lang.String str28 = timeSeries11.getDomainDescription();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries11, seriesChangeInfo29);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560183238280L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries3.clear();
//        int int23 = timeSeries3.getItemCount();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month4, seriesChangeInfo6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.String str18 = timeSeries11.getDescription();
        java.lang.Comparable comparable19 = timeSeries11.getKey();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries11, seriesChangeInfo20);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        java.lang.Class<?> wildcardClass4 = month0.getClass();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getLastMillisecond();
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999, false);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        double double23 = timeSeries10.getMinY();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries10.removeChangeListener(seriesChangeListener25);
        java.lang.Comparable comparable27 = timeSeries10.getKey();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(comparable27);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        long long10 = day8.getFirstMillisecond();
//        boolean boolean12 = day8.equals((java.lang.Object) 10L);
//        long long13 = day8.getSerialIndex();
//        java.lang.Number number14 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        boolean boolean19 = day15.equals((java.lang.Object) 10L);
//        long long20 = day15.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries3.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 7, true);
//        java.util.Date date30 = fixedMillisecond24.getTime();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getLastMillisecond();
        long long9 = month7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.previous();
        org.jfree.data.time.Year year11 = month7.getYear();
        int int12 = year11.getYear();
        int int13 = year11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod14);
        boolean boolean16 = month0.equals((java.lang.Object) timeSeries15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        timeSeries15.setKey((java.lang.Comparable) int18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries15.update(regularTimePeriod20, (java.lang.Number) 1560183263852L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "");
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 9999, false);
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        double double25 = timeSeries12.getMinY();
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries12.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.lang.Number number33 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number33);
        timeSeries12.add(timeSeriesDataItem34, true);
        timeSeries1.add(timeSeriesDataItem34, false);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "");
        boolean boolean43 = timeSeries42.getNotify();
        timeSeries42.setMaximumItemAge((long) 2019);
        int int46 = timeSeries42.getItemCount();
        int int47 = timeSeries42.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener48);
        double double50 = timeSeries42.getMinY();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        long long52 = month51.getLastMillisecond();
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) month51, (double) 2019, true);
        int int56 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month51);
        java.util.Calendar calendar57 = null;
        try {
            long long58 = month51.getLastMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1561964399999L + "'", long52 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.util.Date date2 = year1.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        java.lang.String str10 = fixedMillisecond8.toString();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        boolean boolean12 = day0.equals((java.lang.Object) date11);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, 1.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.setMaximumItemAge((long) 2019);
        int int15 = timeSeries11.getItemCount();
        int int16 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(7, 1);
        int int21 = month20.getYearValue();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1559372400000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "org.jfree.data.event.SeriesChangeEvent[source=]", "hi!");
        java.util.List list4 = timeSeries3.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1560183289119L, false);
        org.junit.Assert.assertNotNull(list4);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day21.getMonth();
//        long long24 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "");
//        timeSeries27.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
//        timeSeries27.add(timeSeriesDataItem37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries20.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        int int44 = day42.getMonth();
//        java.lang.Class<?> wildcardClass45 = day42.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        boolean boolean47 = timeSeries41.equals((java.lang.Object) class46);
//        java.util.Collection collection48 = timeSeries41.getTimePeriods();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(collection48);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999, false);
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        java.util.Collection collection16 = timeSeries7.getTimePeriods();
        java.util.Collection collection17 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(collection17);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 9999, false);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
//        int int20 = day0.compareTo((java.lang.Object) fixedMillisecond13);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "");
//        timeSeries24.setDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "", "");
//        boolean boolean31 = timeSeries30.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries30.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, "", "");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month38, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries41.addChangeListener(seriesChangeListener42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (double) 9999, false);
//        java.util.Collection collection49 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        double double50 = timeSeries37.getMinY();
//        java.util.Collection collection51 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries24.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.next();
//        int int55 = day53.getMonth();
//        long long56 = day53.getLastMillisecond();
//        long long57 = day53.getFirstMillisecond();
//        int int58 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day53);
//        boolean boolean59 = day0.equals((java.lang.Object) timeSeries24);
//        int int60 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(collection49);
//        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560236399999L + "'", long56 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560150000000L + "'", long57 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass6 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "");
//        timeSeries6.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getLastMillisecond();
//        long long13 = month11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.Year year15 = month11.getYear();
//        int int16 = year15.getYear();
//        int int17 = year15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        long long19 = year15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year15);
//        java.lang.String str21 = year15.toString();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = year15.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.setMaximumItemAge((long) 2019);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 9999, false);
//        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        double double24 = timeSeries11.getMinY();
//        timeSeries11.setKey((java.lang.Comparable) (-1));
//        java.util.Collection collection27 = timeSeries11.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        boolean boolean31 = timeSeries11.equals((java.lang.Object) 52L);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, "", "");
//        boolean boolean38 = timeSeries37.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "", "");
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month45, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 9999, false);
//        java.util.Collection collection56 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        double double57 = timeSeries44.getMinY();
//        java.util.Collection collection58 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.util.Date date63 = fixedMillisecond62.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond62.previous();
//        java.lang.Number number65 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, number65);
//        timeSeries44.add(timeSeriesDataItem66, true);
//        timeSeries33.add(timeSeriesDataItem66, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries11.addOrUpdate(timeSeriesDataItem66);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
//        long long73 = year72.getSerialIndex();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.next();
//        long long76 = day74.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate77 = day74.getSerialDate();
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
//        int int79 = day74.compareTo((java.lang.Object) month78);
//        int int80 = day74.getYear();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year72, (org.jfree.data.time.RegularTimePeriod) day74);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (double) 19L);
//        timeSeriesDataItem83.setSelected(true);
//        timeSeriesDataItem83.setSelected(true);
//        timeSeries3.add(timeSeriesDataItem83, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = timeSeries3.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2019L + "'", long73 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560150000000L + "'", long76 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2019 + "'", int80 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//    }
//}

