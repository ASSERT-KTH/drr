import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 8, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 10, year3);
//        int int6 = week4.compareTo((java.lang.Object) 2);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year3.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 2);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        java.util.Date date6 = regularTimePeriod4.getStart();
//        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
//        java.util.Date date8 = regularTimePeriod4.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        int int12 = week9.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date13 = week9.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass3 = week1.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        java.util.Date date7 = regularTimePeriod5.getStart();
//        java.lang.Class<?> wildcardClass8 = regularTimePeriod5.getClass();
//        java.util.Date date9 = regularTimePeriod5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone15);
//        try {
//            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date0, timeZone15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560970799999L + "'", long6 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.util.Date date8 = regularTimePeriod6.getStart();
//        java.lang.Class<?> wildcardClass9 = regularTimePeriod6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getMiddleMillisecond();
//        long long12 = week10.getLastMillisecond();
//        java.lang.String str13 = week10.toString();
//        java.util.Date date14 = week10.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        int int18 = week15.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date19 = week15.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone20);
//        java.util.Locale locale23 = null;
//        try {
//            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date4, timeZone20, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560970799999L + "'", long7 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Year year4 = week2.getYear();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
        java.util.Date date8 = year4.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, 8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar4 = null;
        try {
            week0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Date date3 = week0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            week0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, year4);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        boolean boolean3 = week0.equals((java.lang.Object) 0);
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        org.jfree.data.time.Year year22 = week20.getYear();
//        java.util.Date date23 = year22.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass26 = week24.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        int int34 = week31.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date35 = week31.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date23, timeZone36);
//        java.util.Locale locale40 = null;
//        try {
//            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date9, timeZone36, locale40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560365999999L + "'", long25 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getStart();
//        java.lang.Class<?> wildcardClass22 = regularTimePeriod19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        long long25 = week23.getLastMillisecond();
//        java.lang.String str26 = week23.toString();
//        java.util.Date date27 = week23.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass38 = week36.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        java.util.Date date44 = regularTimePeriod40.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        int int48 = week45.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date49 = week45.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date27, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        int int57 = week54.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date58 = week54.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = date58.getClass();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        long long65 = regularTimePeriod64.getMiddleMillisecond();
//        java.util.Date date66 = regularTimePeriod64.getStart();
//        java.lang.Class<?> wildcardClass67 = regularTimePeriod64.getClass();
//        java.util.Date date68 = regularTimePeriod64.getStart();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.util.Date date74 = year73.getStart();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        long long76 = week75.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass77 = week75.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.next();
//        org.jfree.data.time.Year year80 = week78.getYear();
//        java.util.Date date81 = year80.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.next();
//        int int85 = week82.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date86 = week82.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone87);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date74, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date68, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date27, timeZone87);
//        java.lang.Class<?> wildcardClass93 = date27.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560970799999L + "'", long20 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560970799999L + "'", long65 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560365999999L + "'", long76 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(wildcardClass93);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
//        java.lang.String str5 = week4.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 10, 2019" + "'", str5.equals("Week 10, 2019"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        java.util.Date date3 = week0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        int int8 = week4.compareTo((java.lang.Object) throwableArray7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 8);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        java.util.Date date7 = regularTimePeriod5.getStart();
//        java.lang.Class<?> wildcardClass8 = regularTimePeriod5.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getMiddleMillisecond();
//        long long11 = week9.getLastMillisecond();
//        java.lang.String str12 = week9.toString();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        int int17 = week14.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date18 = week14.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone19);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date13, timeZone22);
//        java.util.Locale locale24 = null;
//        try {
//            org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560970799999L + "'", long6 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeZone22);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(4, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            week4.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getWeek();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62131420800001L) + "'", long8 == (-62131420800001L));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        int int20 = week19.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        int int5 = week0.getYearValue();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        int int18 = week15.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date19 = week15.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date14, timeZone20, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        java.util.Date date14 = regularTimePeriod10.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        long long22 = week21.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week21.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date20, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone33);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(class38);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        long long3 = regularTimePeriod2.getMiddleMillisecond();
//        java.util.Date date4 = regularTimePeriod2.getStart();
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod2.getClass();
//        java.util.Date date6 = regularTimePeriod2.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale10 = null;
//        try {
//            org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560970799999L + "'", long3 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(timeZone9);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        int int5 = week2.getYearValue();
//        long long6 = week2.getFirstMillisecond();
//        java.util.Date date7 = week2.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        int int11 = week8.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date12 = week8.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        java.lang.Class<?> wildcardClass15 = date12.getClass();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        long long19 = regularTimePeriod18.getMiddleMillisecond();
//        java.util.Date date20 = regularTimePeriod18.getStart();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod18.getClass();
//        java.util.Date date22 = regularTimePeriod18.getStart();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
//        org.jfree.data.time.Year year27 = week25.getYear();
//        java.util.Date date28 = year27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        long long30 = week29.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass31 = week29.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        java.util.Date date35 = year34.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
//        int int39 = week36.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date40 = week36.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone41);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date28, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone41);
//        java.util.Locale locale46 = null;
//        try {
//            org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date7, timeZone41, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560970799999L + "'", long19 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560365999999L + "'", long30 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone35);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        long long45 = week44.getMiddleMillisecond();
//        long long46 = week44.getLastMillisecond();
//        java.lang.String str47 = week44.toString();
//        java.util.Date date48 = week44.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        int int52 = week49.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date53 = week49.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone54);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date48, timeZone57);
//        java.util.Locale locale59 = null;
//        try {
//            org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date22, timeZone57, locale59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560365999999L + "'", long45 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560668399999L + "'", long46 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 24, 2019" + "'", str47.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone57);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        long long15 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1606334399999L + "'", long15 == 1606334399999L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.lang.Class<?> wildcardClass6 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
        org.jfree.data.time.Year year8 = week0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        int int9 = week6.compareTo((java.lang.Object) (byte) 100);
//        long long10 = week6.getLastMillisecond();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        long long12 = week0.getFirstMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 10, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.util.Date date8 = regularTimePeriod6.getStart();
//        java.lang.Class<?> wildcardClass9 = regularTimePeriod6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getMiddleMillisecond();
//        long long12 = week10.getLastMillisecond();
//        java.lang.String str13 = week10.toString();
//        java.util.Date date14 = week10.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        int int18 = week15.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date19 = week15.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        int int26 = week23.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date27 = week23.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass30 = week28.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.util.Date date34 = year33.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        int int38 = week35.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date39 = week35.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date27, timeZone40);
//        java.util.Locale locale44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date4, timeZone40, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560970799999L + "'", long7 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 0);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107228800001L) + "'", long3 == (-62107228800001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        boolean boolean6 = week2.equals((java.lang.Object) (short) 1);
        long long7 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62131420800001L) + "'", long7 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass22 = week20.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        long long25 = regularTimePeriod24.getMiddleMillisecond();
//        java.util.Date date26 = regularTimePeriod24.getStart();
//        java.lang.Class<?> wildcardClass27 = regularTimePeriod24.getClass();
//        java.util.Date date28 = regularTimePeriod24.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        int int32 = week29.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date33 = week29.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone34);
//        java.util.Locale locale37 = null;
//        try {
//            org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date9, timeZone34, locale37);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560365999999L + "'", long21 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560970799999L + "'", long25 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        int int23 = week20.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date24 = week20.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
//        java.lang.Class<?> wildcardClass27 = date24.getClass();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        long long31 = regularTimePeriod30.getMiddleMillisecond();
//        java.util.Date date32 = regularTimePeriod30.getStart();
//        java.lang.Class<?> wildcardClass33 = regularTimePeriod30.getClass();
//        java.util.Date date34 = regularTimePeriod30.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        org.jfree.data.time.Year year39 = week37.getYear();
//        java.util.Date date40 = year39.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        long long42 = week41.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass43 = week41.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        java.util.Date date47 = year46.getStart();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
//        int int51 = week48.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date52 = week48.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date40, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date34, timeZone53);
//        java.util.Locale locale58 = null;
//        try {
//            org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date9, timeZone53, locale58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560970799999L + "'", long31 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560365999999L + "'", long42 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 2);
        int int3 = week2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getMiddleMillisecond();
//        long long16 = week14.getLastMillisecond();
//        java.lang.String str17 = week14.toString();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        int int22 = week19.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date23 = week19.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        int int30 = week27.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date31 = week27.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass34 = week32.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        int int42 = week39.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date43 = week39.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date31, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date4, timeZone44);
//        java.lang.Class<?> wildcardClass49 = date4.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException17.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        java.util.Date date3 = week0.getEnd();
        org.jfree.data.time.Year year4 = week0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        long long7 = week6.getFirstMillisecond();
//        int int8 = week6.getYearValue();
//        java.util.Date date9 = week6.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        long long5 = week4.getFirstMillisecond();
//        int int6 = week4.getYearValue();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1606032000000L + "'", long5 == 1606032000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getLastMillisecond();
//        int int9 = week6.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) '#');
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getLastMillisecond();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.util.Date date17 = year16.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone23);
//        boolean boolean26 = week7.equals((java.lang.Object) wildcardClass13);
//        boolean boolean27 = week4.equals((java.lang.Object) week7);
//        long long28 = week4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 8, 1" + "'", str8.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62131420800001L) + "'", long9 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1606334399999L + "'", long28 == 1606334399999L);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        int int6 = week3.compareTo((java.lang.Object) (byte) 100);
//        long long7 = week3.getLastMillisecond();
//        long long8 = week3.getSerialIndex();
//        boolean boolean10 = week3.equals((java.lang.Object) 4);
//        int int11 = week3.getWeek();
//        boolean boolean12 = week0.equals((java.lang.Object) week3);
//        java.lang.Class<?> wildcardClass13 = week3.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        int int8 = week0.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
        int int3 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str12 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException1.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getMiddleMillisecond();
//        long long16 = week14.getLastMillisecond();
//        java.lang.String str17 = week14.toString();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        int int22 = week19.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date23 = week19.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        int int30 = week27.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date31 = week27.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass34 = week32.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        int int42 = week39.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date43 = week39.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date31, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date4, timeZone44);
//        long long49 = week48.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560365999999L + "'", long49 == 1560365999999L);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        int int9 = week6.compareTo((java.lang.Object) (byte) 100);
//        long long10 = week6.getLastMillisecond();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week0.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        boolean boolean23 = week2.equals((java.lang.Object) 1L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Date date9 = regularTimePeriod8.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date4, timeZone15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year3);
        long long6 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1551599999999L + "'", long6 == 1551599999999L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        java.lang.String str9 = timePeriodFormatException6.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62131723200001L) + "'", long6 == (-62131723200001L));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.String str7 = week0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.Year year9 = week6.getYear();
        java.util.Date date10 = week6.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        long long15 = week13.getLastMillisecond();
        java.util.Date date16 = week13.getStart();
        int int17 = week6.compareTo((java.lang.Object) date16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62107228800001L) + "'", long15 == (-62107228800001L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 0);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        int int7 = week6.getWeek();
//        long long8 = week6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1606032000000L + "'", long8 == 1606032000000L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.Year year9 = week6.getYear();
        org.jfree.data.time.Year year10 = week6.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        boolean boolean6 = week2.equals((java.lang.Object) (short) 1);
        long long7 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62131420800001L) + "'", long7 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        long long22 = week2.getLastMillisecond();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        long long25 = regularTimePeriod24.getMiddleMillisecond();
//        java.util.Date date26 = regularTimePeriod24.getStart();
//        java.lang.Class<?> wildcardClass27 = regularTimePeriod24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getMiddleMillisecond();
//        long long30 = week28.getLastMillisecond();
//        java.lang.String str31 = week28.toString();
//        java.util.Date date32 = week28.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        int int36 = week33.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date37 = week33.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        int int44 = week41.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date45 = week41.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        long long47 = week46.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass48 = week46.getClass();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        org.jfree.data.time.Year year51 = week49.getYear();
//        java.util.Date date52 = year51.getStart();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
//        int int56 = week53.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date57 = week53.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date57, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date45, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.next();
//        long long64 = regularTimePeriod63.getMiddleMillisecond();
//        java.util.Date date65 = regularTimePeriod63.getStart();
//        java.lang.Class<?> wildcardClass66 = regularTimePeriod63.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        long long68 = week67.getMiddleMillisecond();
//        long long69 = week67.getLastMillisecond();
//        java.lang.String str70 = week67.toString();
//        java.util.Date date71 = week67.getStart();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
//        int int75 = week72.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date76 = week72.getEnd();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date76, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date71, timeZone77);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date71, timeZone80);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        long long83 = week82.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass84 = week82.getClass();
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = week85.next();
//        org.jfree.data.time.Year year87 = week85.getYear();
//        java.util.Date date88 = year87.getStart();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = week89.next();
//        int int92 = week89.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date93 = week89.getEnd();
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date93, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date88, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date71, timeZone94);
//        boolean boolean98 = week2.equals((java.lang.Object) wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62131420800001L) + "'", long22 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560970799999L + "'", long25 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560668399999L + "'", long30 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560365999999L + "'", long47 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560970799999L + "'", long64 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560365999999L + "'", long68 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560668399999L + "'", long69 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 24, 2019" + "'", str70.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560365999999L + "'", long83 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(year87);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Year year4 = week2.getYear();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year4.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 6);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        long long8 = week4.getSerialIndex();
//        boolean boolean9 = week2.equals((java.lang.Object) week4);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        java.util.Date date8 = year4.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getMiddleMillisecond();
//        long long11 = week9.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.next();
//        java.util.Date date13 = regularTimePeriod12.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        int int17 = week14.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date18 = week14.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date13, timeZone19);
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone19, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.lang.Class<?> wildcardClass4 = year3.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 10, year3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            week4.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int5 = week2.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date6 = week2.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(4, year9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 1, year9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year9);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getLastMillisecond();
//        java.lang.String str9 = week6.toString();
//        int int10 = week6.getYearValue();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        java.util.Calendar calendar15 = null;
//        try {
//            week7.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        long long22 = week2.getLastMillisecond();
//        java.util.Date date23 = week2.getEnd();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62131420800001L) + "'", long22 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date23);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getWeek();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getStart();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        int int6 = week4.compareTo((java.lang.Object) 1.0d);
//        long long7 = week4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107107L + "'", long7 == 107107L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int10 = week7.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date11 = week7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week7.previous();
        java.lang.Class<?> wildcardClass13 = week7.getClass();
        boolean boolean14 = week2.equals((java.lang.Object) week7);
        java.util.Calendar calendar15 = null;
        try {
            week2.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        java.lang.Class<?> wildcardClass24 = regularTimePeriod21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getMiddleMillisecond();
//        long long27 = week25.getLastMillisecond();
//        java.lang.String str28 = week25.toString();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        int int43 = week40.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date44 = week40.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date29, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date9, timeZone45);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        long long51 = week50.getMiddleMillisecond();
//        org.jfree.data.time.Year year52 = week50.getYear();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) (short) 100, year52);
//        org.jfree.data.time.Year year54 = week53.getYear();
//        boolean boolean55 = week48.equals((java.lang.Object) year54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.next();
//        org.jfree.data.time.Year year58 = week56.getYear();
//        java.util.Date date59 = year58.getStart();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        long long61 = week60.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass62 = week60.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        org.jfree.data.time.Year year65 = week63.getYear();
//        java.util.Date date66 = year65.getStart();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
//        int int70 = week67.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date71 = week67.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date71, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date66, timeZone72);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date59, timeZone72);
//        int int76 = week48.compareTo((java.lang.Object) week75);
//        java.util.Calendar calendar77 = null;
//        try {
//            long long78 = week48.getLastMillisecond(calendar77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560970799999L + "'", long22 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560365999999L + "'", long26 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560365999999L + "'", long51 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560365999999L + "'", long61 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 23 + "'", int76 == 23);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        int int6 = week0.getYearValue();
        java.lang.Object obj7 = null;
        int int8 = week0.compareTo(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        int int5 = week4.getWeek();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week4.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        java.util.Date date13 = year12.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        int int17 = week14.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date18 = week14.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone19, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        java.lang.String str6 = week4.toString();
//        int int7 = week4.getWeek();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 10, 2019" + "'", str6.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        java.lang.Object obj22 = null;
//        int int23 = week2.compareTo(obj22);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        long long21 = regularTimePeriod20.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559761199999L + "'", long21 == 1559761199999L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
//        long long5 = week4.getSerialIndex();
//        long long6 = week4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107013L + "'", long5 == 107013L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1549180800000L + "'", long6 == 1549180800000L);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        int int23 = week20.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date24 = week20.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date9, timeZone25);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        java.util.Date date33 = year32.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(9, year32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (byte) 100, year32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
//        long long38 = regularTimePeriod37.getMiddleMillisecond();
//        java.util.Date date39 = regularTimePeriod37.getStart();
//        java.lang.Class<?> wildcardClass40 = regularTimePeriod37.getClass();
//        boolean boolean41 = week35.equals((java.lang.Object) wildcardClass40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
//        int int45 = week42.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date46 = week42.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date46, timeZone47);
//        org.jfree.data.time.Year year49 = week48.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week48.next();
//        org.jfree.data.time.Year year51 = week48.getYear();
//        java.util.Date date52 = week48.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
//        long long55 = regularTimePeriod54.getMiddleMillisecond();
//        java.util.Date date56 = regularTimePeriod54.getStart();
//        java.lang.Class<?> wildcardClass57 = regularTimePeriod54.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        long long59 = week58.getMiddleMillisecond();
//        long long60 = week58.getLastMillisecond();
//        java.lang.String str61 = week58.toString();
//        java.util.Date date62 = week58.getStart();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        int int66 = week63.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date67 = week63.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date62, timeZone68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        int int74 = week71.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date75 = week71.getEnd();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        long long77 = week76.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass78 = week76.getClass();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week79.next();
//        org.jfree.data.time.Year year81 = week79.getYear();
//        java.util.Date date82 = year81.getStart();
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = week83.next();
//        int int86 = week83.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date87 = week83.getEnd();
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date87, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date82, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date75, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date52, timeZone88);
//        java.util.Locale locale93 = null;
//        try {
//            org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date9, timeZone88, locale93);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560970799999L + "'", long38 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560970799999L + "'", long55 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560365999999L + "'", long59 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560668399999L + "'", long60 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Week 24, 2019" + "'", str61.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560365999999L + "'", long77 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 100);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        int int8 = week0.getWeek();
//        long long9 = week0.getFirstMillisecond();
//        java.util.Date date10 = week0.getEnd();
//        java.util.Date date11 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        java.util.Date date14 = regularTimePeriod10.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        long long22 = week21.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week21.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        java.util.Date date27 = year26.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date20, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone33);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date5 = week1.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(4, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (byte) 0, year18);
//        java.lang.Class<?> wildcardClass20 = year18.getClass();
//        boolean boolean21 = week9.equals((java.lang.Object) wildcardClass20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        int int25 = week22.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date26 = week22.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = date26.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        long long33 = regularTimePeriod32.getMiddleMillisecond();
//        java.util.Date date34 = regularTimePeriod32.getStart();
//        java.lang.Class<?> wildcardClass35 = regularTimePeriod32.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        long long38 = week36.getLastMillisecond();
//        java.lang.String str39 = week36.toString();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        int int44 = week41.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date45 = week41.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        int int52 = week49.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date53 = week49.getEnd();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        long long55 = week54.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass56 = week54.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.next();
//        org.jfree.data.time.Year year59 = week57.getYear();
//        java.util.Date date60 = year59.getStart();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
//        int int64 = week61.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date65 = week61.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date53, timeZone66);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date26, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        long long73 = regularTimePeriod72.getMiddleMillisecond();
//        java.util.Date date74 = regularTimePeriod72.getStart();
//        java.lang.Class<?> wildcardClass75 = regularTimePeriod72.getClass();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        long long77 = week76.getMiddleMillisecond();
//        long long78 = week76.getLastMillisecond();
//        java.lang.String str79 = week76.toString();
//        java.util.Date date80 = week76.getStart();
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = week81.next();
//        int int84 = week81.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date85 = week81.getEnd();
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date85, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date80, timeZone86);
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date80, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560970799999L + "'", long33 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 24, 2019" + "'", str39.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560365999999L + "'", long55 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560970799999L + "'", long73 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560365999999L + "'", long77 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560668399999L + "'", long78 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Week 24, 2019" + "'", str79.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        java.util.Date date9 = regularTimePeriod7.getStart();
//        java.lang.Class<?> wildcardClass10 = regularTimePeriod7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getMiddleMillisecond();
//        long long13 = week11.getLastMillisecond();
//        java.lang.String str14 = week11.toString();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        int int19 = week16.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date20 = week16.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone21);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560970799999L + "'", long8 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        java.util.Date date5 = year3.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str11 = timePeriodFormatException7.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        boolean boolean8 = week0.equals((java.lang.Object) 1.0d);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        long long9 = week6.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week6.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((-1), year8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        int int11 = week9.getWeek();
        java.lang.String str12 = week9.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        long long13 = week9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week9.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546156799999L + "'", long13 == 1546156799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getFirstMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62131420800001L) + "'", long9 == (-62131420800001L));
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        java.lang.Class<?> wildcardClass20 = timeZone18.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
//        boolean boolean7 = week0.equals((java.lang.Object) week4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        int int9 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        long long9 = week6.getMiddleMillisecond();
//        java.lang.String str10 = week6.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        int int11 = week2.compareTo((java.lang.Object) timePeriodFormatException9);
        java.lang.String str12 = timePeriodFormatException9.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 10, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        java.util.Date date4 = week2.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        int int8 = week5.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date9 = week5.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.lang.Class<?> wildcardClass12 = date9.getClass();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        long long16 = regularTimePeriod15.getMiddleMillisecond();
//        java.util.Date date17 = regularTimePeriod15.getStart();
//        java.lang.Class<?> wildcardClass18 = regularTimePeriod15.getClass();
//        java.util.Date date19 = regularTimePeriod15.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        java.util.Date date25 = year24.getStart();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass28 = week26.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        org.jfree.data.time.Year year31 = week29.getYear();
//        java.util.Date date32 = year31.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        int int36 = week33.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date37 = week33.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date37, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date25, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date19, timeZone38);
//        java.util.Locale locale43 = null;
//        try {
//            org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date4, timeZone38, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560970799999L + "'", long16 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        int int22 = week2.getYearValue();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        long long9 = week6.getMiddleMillisecond();
//        int int11 = week6.compareTo((java.lang.Object) 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        java.lang.String str6 = week4.toString();
//        long long7 = week4.getMiddleMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            week4.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 10, 2019" + "'", str6.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1551902399999L + "'", long7 == 1551902399999L);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.Date date18 = regularTimePeriod17.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        org.jfree.data.time.Year year23 = week21.getYear();
//        java.util.Date date24 = year23.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(9, year23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (byte) 100, year23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        long long29 = regularTimePeriod28.getMiddleMillisecond();
//        java.util.Date date30 = regularTimePeriod28.getStart();
//        java.lang.Class<?> wildcardClass31 = regularTimePeriod28.getClass();
//        boolean boolean32 = week26.equals((java.lang.Object) wildcardClass31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.util.Date date39 = year38.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(9, year38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (byte) 100, year38);
//        java.util.Date date42 = year38.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
//        long long45 = regularTimePeriod44.getMiddleMillisecond();
//        java.util.Date date46 = regularTimePeriod44.getStart();
//        java.lang.Class<?> wildcardClass47 = regularTimePeriod44.getClass();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        long long49 = week48.getMiddleMillisecond();
//        long long50 = week48.getLastMillisecond();
//        java.lang.String str51 = week48.toString();
//        java.util.Date date52 = week48.getStart();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
//        int int56 = week53.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date57 = week53.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date57, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date52, timeZone58);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date52);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date52);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        int int66 = week63.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date67 = week63.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67, timeZone68);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date52, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date42, timeZone68);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date18, timeZone68);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560970799999L + "'", long29 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560970799999L + "'", long45 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560365999999L + "'", long49 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560668399999L + "'", long50 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 24, 2019" + "'", str51.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        long long10 = week9.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546156799999L + "'", long10 == 1546156799999L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        org.jfree.data.time.Year year4 = week0.getYear();
        int int5 = week0.getYearValue();
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        java.lang.Class<?> wildcardClass24 = regularTimePeriod21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getMiddleMillisecond();
//        long long27 = week25.getLastMillisecond();
//        java.lang.String str28 = week25.toString();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        int int43 = week40.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date44 = week40.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date29, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date9, timeZone45);
//        java.util.TimeZone timeZone49 = null;
//        try {
//            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date9, timeZone49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560970799999L + "'", long22 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560365999999L + "'", long26 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        java.util.Date date6 = regularTimePeriod4.getStart();
//        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getMiddleMillisecond();
//        long long10 = week8.getLastMillisecond();
//        java.lang.String str11 = week8.toString();
//        java.util.Date date12 = week8.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        long long22 = week21.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week21.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        long long26 = regularTimePeriod25.getMiddleMillisecond();
//        java.util.Date date27 = regularTimePeriod25.getStart();
//        java.lang.Class<?> wildcardClass28 = regularTimePeriod25.getClass();
//        java.util.Date date29 = regularTimePeriod25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date12, timeZone35);
//        java.lang.Class<?> wildcardClass39 = week38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        boolean boolean43 = week0.equals((java.lang.Object) class42);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560970799999L + "'", long26 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        int int23 = week20.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date24 = week20.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date9, timeZone25);
//        int int28 = week27.getYearValue();
//        java.lang.Object obj29 = null;
//        boolean boolean30 = week27.equals(obj29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        int int34 = week31.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date35 = week31.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        java.lang.Class<?> wildcardClass38 = date35.getClass();
//        int int39 = week27.compareTo((java.lang.Object) date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getMiddleMillisecond();
//        boolean boolean6 = week0.equals((java.lang.Object) 1606334399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week4.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        java.lang.String str9 = week7.toString();
//        java.lang.String str10 = week7.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 10, 2019" + "'", str10.equals("Week 10, 2019"));
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        java.lang.Class<?> wildcardClass8 = week7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(9, year14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 100, year14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getStart();
//        java.lang.Class<?> wildcardClass22 = regularTimePeriod19.getClass();
//        boolean boolean23 = week17.equals((java.lang.Object) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        org.jfree.data.time.Year year29 = week27.getYear();
//        java.util.Date date30 = year29.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(9, year29);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (byte) 100, year29);
//        java.util.Date date33 = year29.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
//        long long36 = regularTimePeriod35.getMiddleMillisecond();
//        java.util.Date date37 = regularTimePeriod35.getStart();
//        java.lang.Class<?> wildcardClass38 = regularTimePeriod35.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getMiddleMillisecond();
//        long long41 = week39.getLastMillisecond();
//        java.lang.String str42 = week39.toString();
//        java.util.Date date43 = week39.getStart();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
//        int int47 = week44.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date48 = week44.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date48, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        int int57 = week54.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date58 = week54.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date43, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date33, timeZone59);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        long long64 = week63.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass65 = week63.getClass();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.next();
//        long long68 = regularTimePeriod67.getMiddleMillisecond();
//        java.util.Date date69 = regularTimePeriod67.getStart();
//        java.lang.Class<?> wildcardClass70 = regularTimePeriod67.getClass();
//        java.util.Date date71 = regularTimePeriod67.getStart();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
//        int int75 = week72.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date76 = week72.getEnd();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date76, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date71, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date33, timeZone77);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560970799999L + "'", long20 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560970799999L + "'", long36 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560365999999L + "'", long40 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560668399999L + "'", long41 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560365999999L + "'", long64 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560970799999L + "'", long68 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week6.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 3);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) 'a', year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(11, year6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.util.Date date6 = week5.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        int int9 = week6.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date10 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.previous();
        java.lang.Class<?> wildcardClass12 = week6.getClass();
        int int13 = week2.compareTo((java.lang.Object) week6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62131420800001L) + "'", long5 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2018) + "'", int13 == (-2018));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        int int5 = week2.getYearValue();
//        long long6 = week2.getFirstMillisecond();
//        java.util.Date date7 = week2.getEnd();
//        java.util.Date date8 = week2.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        java.util.Date date13 = year12.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass16 = week14.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        int int24 = week21.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date25 = week21.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date13, timeZone26);
//        java.util.Locale locale30 = null;
//        try {
//            org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date8, timeZone26, locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        java.util.Date date12 = week6.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        int int5 = week0.getYearValue();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        int int11 = week9.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.String str16 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str20 = timePeriodFormatException13.toString();
        int int21 = week9.compareTo((java.lang.Object) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        int int15 = week7.getYearValue();
//        long long16 = week7.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1606032000000L + "'", long16 == 1606032000000L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        java.lang.Class<?> wildcardClass5 = week4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getStart();
//        java.lang.Class<?> wildcardClass22 = regularTimePeriod19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        long long25 = week23.getLastMillisecond();
//        java.lang.String str26 = week23.toString();
//        java.util.Date date27 = week23.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass38 = week36.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        java.util.Date date44 = regularTimePeriod40.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        int int48 = week45.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date49 = week45.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date27, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        int int57 = week54.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date58 = week54.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = date58.getClass();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        long long65 = regularTimePeriod64.getMiddleMillisecond();
//        java.util.Date date66 = regularTimePeriod64.getStart();
//        java.lang.Class<?> wildcardClass67 = regularTimePeriod64.getClass();
//        java.util.Date date68 = regularTimePeriod64.getStart();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.util.Date date74 = year73.getStart();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        long long76 = week75.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass77 = week75.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.next();
//        org.jfree.data.time.Year year80 = week78.getYear();
//        java.util.Date date81 = year80.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.next();
//        int int85 = week82.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date86 = week82.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone87);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date74, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date68, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date27, timeZone87);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560970799999L + "'", long20 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560970799999L + "'", long65 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560365999999L + "'", long76 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        java.lang.Class<?> wildcardClass5 = week4.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        int int9 = week6.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date10 = week6.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = date10.getClass();
//        boolean boolean14 = week4.equals((java.lang.Object) date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week4.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        long long20 = week19.getSerialIndex();
//        java.lang.String str21 = week19.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107008L + "'", long20 == 107008L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 1, 2019" + "'", str21.equals("Week 1, 2019"));
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        java.util.Calendar calendar20 = null;
//        try {
//            week19.peg(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        int int15 = week7.getYearValue();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = week7.equals(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week7.previous();
//        int int19 = week7.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.previous();
//        int int14 = week6.getWeek();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.util.Date date18 = regularTimePeriod16.getStart();
//        java.lang.Class<?> wildcardClass19 = regularTimePeriod16.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getMiddleMillisecond();
//        long long22 = week20.getLastMillisecond();
//        java.lang.String str23 = week20.toString();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
//        int int28 = week25.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date29 = week25.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date24);
//        boolean boolean34 = week6.equals((java.lang.Object) week33);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560970799999L + "'", long17 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560365999999L + "'", long21 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str14 = timePeriodFormatException9.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        long long8 = week7.getLastMillisecond();
//        java.util.Date date9 = week7.getStart();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1552204799999L + "'", long8 == 1552204799999L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        long long20 = week19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107008L + "'", long20 == 107008L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        java.lang.String str24 = timePeriodFormatException22.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = week19.equals(obj20);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        java.util.Date date8 = year4.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass11 = week9.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        long long14 = regularTimePeriod13.getMiddleMillisecond();
//        java.util.Date date15 = regularTimePeriod13.getStart();
//        java.lang.Class<?> wildcardClass16 = regularTimePeriod13.getClass();
//        java.util.Date date17 = regularTimePeriod13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone23);
//        java.util.Locale locale26 = null;
//        try {
//            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date8, timeZone23, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560970799999L + "'", long14 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        org.jfree.data.time.Year year15 = week7.getYear();
//        long long16 = week7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1606636799999L + "'", long16 == 1606636799999L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        int int6 = week3.compareTo((java.lang.Object) (byte) 100);
//        long long7 = week3.getLastMillisecond();
//        long long8 = week3.getSerialIndex();
//        boolean boolean10 = week3.equals((java.lang.Object) 4);
//        int int11 = week3.getWeek();
//        boolean boolean12 = week0.equals((java.lang.Object) week3);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
//        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException14.getClass();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException14.getClass();
//        int int35 = week0.compareTo((java.lang.Object) timePeriodFormatException14);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(throwableArray22);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getMiddleMillisecond();
//        long long23 = week19.getFirstMillisecond();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str28 = week27.toString();
//        long long29 = week27.getLastMillisecond();
//        java.util.Date date30 = week27.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        long long33 = regularTimePeriod32.getMiddleMillisecond();
//        java.util.Date date34 = regularTimePeriod32.getStart();
//        java.lang.Class<?> wildcardClass35 = regularTimePeriod32.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        long long38 = week36.getLastMillisecond();
//        java.lang.String str39 = week36.toString();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        int int44 = week41.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date45 = week41.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        int int52 = week49.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date53 = week49.getEnd();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        long long55 = week54.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass56 = week54.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.next();
//        org.jfree.data.time.Year year59 = week57.getYear();
//        java.util.Date date60 = year59.getStart();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
//        int int64 = week61.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date65 = week61.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date53, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date30, timeZone66);
//        int int71 = week19.compareTo((java.lang.Object) timeZone66);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560063600000L + "'", long23 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 8, 1" + "'", str28.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62131420800001L) + "'", long29 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560970799999L + "'", long33 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 24, 2019" + "'", str39.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560365999999L + "'", long55 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Date date3 = regularTimePeriod2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        java.util.Date date9 = year8.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(9, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 100, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        long long14 = regularTimePeriod13.getMiddleMillisecond();
//        java.util.Date date15 = regularTimePeriod13.getStart();
//        java.lang.Class<?> wildcardClass16 = regularTimePeriod13.getClass();
//        boolean boolean17 = week11.equals((java.lang.Object) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        org.jfree.data.time.Year year23 = week21.getYear();
//        java.util.Date date24 = year23.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(9, year23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (byte) 100, year23);
//        java.util.Date date27 = year23.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        long long30 = regularTimePeriod29.getMiddleMillisecond();
//        java.util.Date date31 = regularTimePeriod29.getStart();
//        java.lang.Class<?> wildcardClass32 = regularTimePeriod29.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        long long34 = week33.getMiddleMillisecond();
//        long long35 = week33.getLastMillisecond();
//        java.lang.String str36 = week33.toString();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.next();
//        int int41 = week38.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date42 = week38.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
//        int int51 = week48.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date52 = week48.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date37, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date27, timeZone53);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date3, timeZone53);
//        org.jfree.data.time.Year year58 = week57.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560970799999L + "'", long14 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560970799999L + "'", long30 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560365999999L + "'", long34 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560668399999L + "'", long35 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(year58);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        long long7 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str8 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.String str13 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str19 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        java.lang.Class<?> wildcardClass5 = week4.getClass();
//        long long6 = week4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1606334399999L + "'", long6 == 1606334399999L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        long long13 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        int int5 = week2.getYearValue();
//        long long6 = week2.getFirstMillisecond();
//        java.util.Date date7 = week2.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getMiddleMillisecond();
//        long long15 = week13.getLastMillisecond();
//        java.lang.String str16 = week13.toString();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass28 = week26.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        long long31 = regularTimePeriod30.getMiddleMillisecond();
//        java.util.Date date32 = regularTimePeriod30.getStart();
//        java.lang.Class<?> wildcardClass33 = regularTimePeriod30.getClass();
//        java.util.Date date34 = regularTimePeriod30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        int int38 = week35.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date39 = week35.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone40);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date17, timeZone40);
//        java.util.Locale locale44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date7, timeZone40, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560970799999L + "'", long31 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Date date3 = week0.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        int int5 = week4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        boolean boolean7 = week0.equals((java.lang.Object) week4);
        boolean boolean9 = week0.equals((java.lang.Object) 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        int int13 = week9.getWeek();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week9.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(53, year6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getMiddleMillisecond();
//        long long15 = week13.getLastMillisecond();
//        java.lang.String str16 = week13.toString();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone23);
//        java.lang.Class<?> wildcardClass26 = timeZone23.getClass();
//        int int27 = week7.compareTo((java.lang.Object) wildcardClass26);
//        long long28 = week7.getLastMillisecond();
//        int int29 = week7.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week4.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        long long14 = week7.getLastMillisecond();
//        java.util.Date date15 = week7.getEnd();
//        long long16 = week7.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1606636799999L + "'", long14 == 1606636799999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107107L + "'", long16 == 107107L);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.lang.Class<?> wildcardClass6 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        int int10 = week0.compareTo((java.lang.Object) throwableArray9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week0.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Year year4 = week2.getYear();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
        java.lang.Class<?> wildcardClass8 = week7.getClass();
        java.util.Calendar calendar9 = null;
        try {
            week7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getMiddleMillisecond();
//        long long16 = week14.getLastMillisecond();
//        java.lang.String str17 = week14.toString();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        int int22 = week19.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date23 = week19.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        int int30 = week27.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date31 = week27.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass34 = week32.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        int int42 = week39.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date43 = week39.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date31, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date4, timeZone44);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week6.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException4.getSuppressed();
        java.lang.String str9 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int5 = week2.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date6 = week2.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 0, year9);
        java.lang.Class<?> wildcardClass11 = year9.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 10, year9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Year year4 = week2.getYear();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2019");
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year4.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        java.util.Date date4 = week0.getStart();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str12 = timePeriodFormatException1.toString();
        java.lang.String str13 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        java.lang.String str15 = week7.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 100, 2019" + "'", str15.equals("Week 100, 2019"));
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        long long8 = week7.getLastMillisecond();
//        long long9 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1552204799999L + "'", long8 == 1552204799999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1551600000000L + "'", long9 == 1551600000000L);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        int int13 = week9.getWeek();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week9.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 10, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-2018), year5);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int5 = week2.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date6 = week2.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(4, year9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(10, year9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.String str17 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        long long20 = week19.getSerialIndex();
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = week19.getMiddleMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107008L + "'", long20 == 107008L);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        int int8 = week0.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str11 = week10.toString();
        long long12 = week10.getLastMillisecond();
        java.util.Date date13 = week10.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week10.previous();
        java.util.Date date15 = week10.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
        int int19 = week10.compareTo((java.lang.Object) timePeriodFormatException17);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str21 = timePeriodFormatException17.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 8, 1" + "'", str11.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62131420800001L) + "'", long12 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        java.lang.Class<?> wildcardClass18 = date15.getClass();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        java.lang.Class<?> wildcardClass24 = regularTimePeriod21.getClass();
//        java.util.Date date25 = regularTimePeriod21.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.util.Date date31 = year30.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass34 = week32.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.util.Date date38 = year37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        int int42 = week39.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date43 = week39.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date31, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone44);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560970799999L + "'", long22 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 10, year3);
//        long long5 = week4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551600000000L + "'", long5 == 1551600000000L);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        long long8 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1551902399999L + "'", long8 == 1551902399999L);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getStart();
//        java.lang.Class<?> wildcardClass22 = regularTimePeriod19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        long long25 = week23.getLastMillisecond();
//        java.lang.String str26 = week23.toString();
//        java.util.Date date27 = week23.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass38 = week36.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        java.util.Date date44 = regularTimePeriod40.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        int int48 = week45.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date49 = week45.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date27, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        int int57 = week54.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date58 = week54.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = date58.getClass();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        long long65 = regularTimePeriod64.getMiddleMillisecond();
//        java.util.Date date66 = regularTimePeriod64.getStart();
//        java.lang.Class<?> wildcardClass67 = regularTimePeriod64.getClass();
//        java.util.Date date68 = regularTimePeriod64.getStart();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.util.Date date74 = year73.getStart();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        long long76 = week75.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass77 = week75.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.next();
//        org.jfree.data.time.Year year80 = week78.getYear();
//        java.util.Date date81 = year80.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.next();
//        int int85 = week82.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date86 = week82.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone87);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date74, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date68, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date27, timeZone87);
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date27, timeZone93);
//        java.util.Calendar calendar95 = null;
//        try {
//            long long96 = week94.getMiddleMillisecond(calendar95);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560970799999L + "'", long20 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560970799999L + "'", long65 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560365999999L + "'", long76 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(timeZone93);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        boolean boolean3 = week0.equals((java.lang.Object) 0);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        boolean boolean6 = week2.equals((java.lang.Object) (short) 1);
        long long7 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62131420800001L) + "'", long7 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62199460800001L) + "'", long3 == (-62199460800001L));
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 7);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 100, year5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod10.getClass();
//        boolean boolean14 = week8.equals((java.lang.Object) wildcardClass13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week8.next();
//        org.jfree.data.time.Year year16 = week8.getYear();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560970799999L + "'", long11 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        java.lang.String str9 = week7.toString();
//        long long10 = week7.getSerialIndex();
//        long long11 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107017L + "'", long10 == 107017L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1551600000000L + "'", long11 == 1551600000000L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        int int13 = week9.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException24.getSuppressed();
        java.lang.String str27 = timePeriodFormatException24.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException29.getSuppressed();
        java.lang.String str34 = timePeriodFormatException29.toString();
        boolean boolean35 = week9.equals((java.lang.Object) str34);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(6, year9);
//        long long11 = week10.getSerialIndex();
//        int int12 = week4.compareTo((java.lang.Object) week10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107013L + "'", long11 == 107013L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 94 + "'", int12 == 94);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.previous();
//        int int14 = week6.getYearValue();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week6.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        int int15 = week7.getYearValue();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = week7.equals(obj16);
//        long long18 = week7.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107107L + "'", long18 == 107107L);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        java.lang.Class<?> wildcardClass19 = week18.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        int int17 = week14.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date18 = week14.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.Year year21 = week20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week20.next();
//        org.jfree.data.time.Year year23 = week20.getYear();
//        java.util.Date date24 = week20.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
//        long long27 = regularTimePeriod26.getMiddleMillisecond();
//        java.util.Date date28 = regularTimePeriod26.getStart();
//        java.lang.Class<?> wildcardClass29 = regularTimePeriod26.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        long long31 = week30.getMiddleMillisecond();
//        long long32 = week30.getLastMillisecond();
//        java.lang.String str33 = week30.toString();
//        java.util.Date date34 = week30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        int int38 = week35.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date39 = week35.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone40);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
//        int int46 = week43.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date47 = week43.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        long long49 = week48.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass50 = week48.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.next();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.util.Date date54 = year53.getStart();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
//        int int58 = week55.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date59 = week55.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date47, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date24, timeZone60);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560970799999L + "'", long27 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560365999999L + "'", long31 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560668399999L + "'", long32 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 24, 2019" + "'", str33.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560365999999L + "'", long49 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str8 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.String str13 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException15.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = year10.getStart();
//        boolean boolean12 = week7.equals((java.lang.Object) year10);
//        long long13 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1551902399999L + "'", long13 == 1551902399999L);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        long long15 = week7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1606636799999L + "'", long15 == 1606636799999L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException19.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.String str34 = timePeriodFormatException28.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException1.getClass();
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException1.getClass();
        java.lang.String str22 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        long long14 = week7.getLastMillisecond();
//        long long15 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1606636799999L + "'", long14 == 1606636799999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1606334399999L + "'", long15 == 1606334399999L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year3);
        java.lang.Class<?> wildcardClass6 = year3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        int int8 = week5.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date9 = week5.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date4, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        boolean boolean7 = week0.equals((java.lang.Object) 4);
//        long long8 = week0.getLastMillisecond();
//        java.lang.String str9 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        java.util.Date date15 = regularTimePeriod14.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        int int11 = week2.compareTo((java.lang.Object) timePeriodFormatException9);
        int int12 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        int int13 = week9.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str23 = timePeriodFormatException17.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        long long21 = week19.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getLastMillisecond();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.util.Date date17 = year16.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone23);
//        boolean boolean26 = week7.equals((java.lang.Object) wildcardClass13);
//        boolean boolean27 = week4.equals((java.lang.Object) week7);
//        java.lang.String str28 = week7.toString();
//        long long29 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 8, 1" + "'", str8.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62131420800001L) + "'", long9 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 8, 1" + "'", str28.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62132025600000L) + "'", long29 == (-62132025600000L));
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        int int5 = week0.getYearValue();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        long long8 = week0.getMiddleMillisecond();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = week0.equals(obj9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) 'a', year5);
//        java.util.Date date9 = week8.getEnd();
//        java.lang.Object obj10 = null;
//        int int11 = week8.compareTo(obj10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        long long9 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        boolean boolean11 = week6.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.previous();
//        int int14 = week6.getWeek();
//        int int15 = week6.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        long long7 = week6.getMiddleMillisecond();
//        long long8 = week6.getLastMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week6.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1606334399999L + "'", long7 == 1606334399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1606636799999L + "'", long8 == 1606636799999L);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.util.Date date14 = week7.getStart();
//        int int15 = week7.getYearValue();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = week7.equals(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week7.previous();
//        java.util.Date date19 = week7.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        java.lang.Class<?> wildcardClass24 = regularTimePeriod21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getMiddleMillisecond();
//        long long27 = week25.getLastMillisecond();
//        java.lang.String str28 = week25.toString();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        int int43 = week40.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date44 = week40.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date29, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date9, timeZone45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Year year50 = week49.getYear();
//        java.util.Calendar calendar51 = null;
//        try {
//            long long52 = year50.getMiddleMillisecond(calendar51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560970799999L + "'", long22 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560365999999L + "'", long26 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(year50);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        int int8 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        int int7 = week4.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date8 = week4.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8, timeZone9);
//        java.lang.String str11 = week10.toString();
//        long long12 = week10.getLastMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
//        int int22 = week19.getYearValue();
//        long long23 = week19.getFirstMillisecond();
//        int int24 = week10.compareTo((java.lang.Object) week19);
//        int int25 = week0.compareTo((java.lang.Object) week19);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560063600000L + "'", long23 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        long long8 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        java.util.Date date13 = year12.getStart();
//        boolean boolean14 = week9.equals((java.lang.Object) year12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(23, year12);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) ' ', year12);
//        long long17 = week16.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1565204399999L + "'", long17 == 1565204399999L);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 10, year3);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, year8);
//        java.lang.Class<?> wildcardClass10 = week9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        boolean boolean12 = week4.equals((java.lang.Object) class11);
//        int int13 = week4.getWeek();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 10, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year5.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        int int8 = week5.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date9 = week5.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        long long15 = regularTimePeriod14.getMiddleMillisecond();
//        java.util.Date date16 = regularTimePeriod14.getStart();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        long long19 = week18.getMiddleMillisecond();
//        long long20 = week18.getLastMillisecond();
//        java.lang.String str21 = week18.toString();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        int int26 = week23.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date27 = week23.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone28);
//        java.lang.Class<?> wildcardClass31 = timeZone28.getClass();
//        int int32 = week12.compareTo((java.lang.Object) wildcardClass31);
//        boolean boolean33 = week0.equals((java.lang.Object) wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560970799999L + "'", long15 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone35);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(class41);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        long long3 = regularTimePeriod2.getMiddleMillisecond();
//        java.util.Date date4 = regularTimePeriod2.getStart();
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        long long8 = week6.getLastMillisecond();
//        java.lang.String str9 = week6.toString();
//        java.util.Date date10 = week6.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        int int24 = week21.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date25 = week21.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date10, timeZone26);
//        java.util.Locale locale29 = null;
//        try {
//            org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date0, timeZone26, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560970799999L + "'", long3 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        long long7 = week6.getMiddleMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        int int11 = week9.getWeek();
//        long long12 = week9.getFirstMillisecond();
//        int int13 = week6.compareTo((java.lang.Object) long12);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1606334399999L + "'", long7 == 1606334399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1606032000000L + "'", long8 == 1606032000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException5.getClass();
//        boolean boolean11 = week0.equals((java.lang.Object) wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) 'a');
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str10 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
        java.lang.String str15 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getMiddleMillisecond();
//        long long23 = week19.getFirstMillisecond();
//        long long24 = week19.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560063600000L + "'", long23 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        int int7 = week6.getWeek();
//        java.lang.Object obj8 = null;
//        int int9 = week6.compareTo(obj8);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((-2018), year3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Year year5 = week3.getYear();
        java.util.Date date6 = year5.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(9, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 100, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(1, year5);
        long long10 = week9.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546761599999L + "'", long10 == 1546761599999L);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        java.lang.String str9 = week7.toString();
//        long long10 = week7.getSerialIndex();
//        int int11 = week7.getYearValue();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107017L + "'", long10 == 107017L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(9, year6);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 100, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(1, year6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(53, year6);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException33.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        java.lang.String str36 = timePeriodFormatException30.toString();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.String str38 = timePeriodFormatException21.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 11);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date5 = week1.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        java.lang.String str12 = week9.toString();
        long long13 = week9.getLastMillisecond();
        java.lang.String str14 = week9.toString();
        long long15 = week9.getMiddleMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week9.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546156799999L + "'", long13 == 1546156799999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 0, 2019" + "'", str14.equals("Week 0, 2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1545854399999L + "'", long15 == 1545854399999L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 8, 1");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 100, year4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Date date11 = regularTimePeriod9.getStart();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod9.getClass();
//        boolean boolean13 = week7.equals((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.next();
//        org.jfree.data.time.Year year15 = week7.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
//        java.lang.String str28 = timePeriodFormatException26.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
//        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException30.getSuppressed();
//        java.lang.String str33 = timePeriodFormatException30.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
//        boolean boolean39 = week7.equals((java.lang.Object) timePeriodFormatException20);
//        int int40 = week7.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray31);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Year year4 = week2.getYear();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, year3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean14 = week6.equals((java.lang.Object) week12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62131420800001L) + "'", long5 == (-62131420800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date4 = week0.getEnd();
//        int int5 = week0.getYearValue();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        long long8 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        long long13 = week12.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 100, year14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (byte) 100, year14);
//        long long17 = year14.getMiddleMillisecond();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(9, year14);
//        int int19 = week0.compareTo((java.lang.Object) 9);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        int int23 = week20.compareTo((java.lang.Object) (byte) 100);
//        long long24 = week20.getLastMillisecond();
//        long long25 = week20.getSerialIndex();
//        boolean boolean27 = week20.equals((java.lang.Object) 4);
//        boolean boolean28 = week0.equals((java.lang.Object) boolean27);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int10 = week7.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date11 = week7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week7.previous();
        java.lang.Class<?> wildcardClass13 = week7.getClass();
        boolean boolean14 = week2.equals((java.lang.Object) week7);
        long long15 = week2.getFirstMillisecond();
        int int16 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62132025600000L) + "'", long15 == (-62132025600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        int int4 = week1.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date5 = week1.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year8);
//        java.util.Date date10 = week9.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getMiddleMillisecond();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 100, year15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 100, year15);
//        java.util.Date date18 = year15.getStart();
//        int int19 = week9.compareTo((java.lang.Object) year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 8, 1");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str27 = timePeriodFormatException21.toString();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        int int29 = week2.compareTo((java.lang.Object) timePeriodFormatException21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62132025600000L) + "'", long6 == (-62132025600000L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 8, 1" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: Week 8, 1"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
//        long long4 = week0.getLastMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        java.util.Date date6 = regularTimePeriod4.getStart();
//        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
//        java.util.Date date8 = regularTimePeriod4.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        int int12 = week9.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date13 = week9.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone14);
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560970799999L + "'", long17 == 1560970799999L);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.util.Date date10 = year9.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        int int14 = week11.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date15 = week11.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone16);
//        long long20 = week19.getLastMillisecond();
//        java.lang.String str21 = week19.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546761599999L + "'", long20 == 1546761599999L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 1, 2019" + "'", str21.equals("Week 1, 2019"));
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date5, timeZone18);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = week21.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int3 = week0.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.lang.Class<?> wildcardClass6 = week0.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int10 = week7.compareTo((java.lang.Object) (byte) 100);
        java.util.Date date11 = week7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week7.previous();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date13, timeZone14);
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 4);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        int int8 = week0.compareTo((java.lang.Object) wildcardClass7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        int int21 = week18.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date22 = week18.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.util.Date date29 = year28.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        int int33 = week30.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date34 = week30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone35);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        long long45 = week44.getMiddleMillisecond();
//        long long46 = week44.getLastMillisecond();
//        java.lang.String str47 = week44.toString();
//        java.util.Date date48 = week44.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        int int52 = week49.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date53 = week49.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone54);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date48, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        long long60 = week59.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass61 = week59.getClass();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.next();
//        org.jfree.data.time.Year year64 = week62.getYear();
//        java.util.Date date65 = year64.getStart();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.next();
//        int int69 = week66.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date70 = week66.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date70, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date48, timeZone71);
//        java.lang.Class<?> wildcardClass75 = timeZone71.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560365999999L + "'", long45 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560668399999L + "'", long46 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 24, 2019" + "'", str47.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560365999999L + "'", long60 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int16 = week13.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date17 = week13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone18);
//        boolean boolean21 = week2.equals((java.lang.Object) wildcardClass8);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 8, 1" + "'", str3.equals("Week 8, 1"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62131420800001L) + "'", long4 == (-62131420800001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(class22);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = regularTimePeriod1.getMiddleMillisecond();
//        java.util.Date date3 = regularTimePeriod1.getStart();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        long long7 = week5.getLastMillisecond();
//        java.lang.String str8 = week5.toString();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int13 = week10.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date14 = week10.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getStart();
//        java.lang.Class<?> wildcardClass22 = regularTimePeriod19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getMiddleMillisecond();
//        long long25 = week23.getLastMillisecond();
//        java.lang.String str26 = week23.toString();
//        java.util.Date date27 = week23.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        int int31 = week28.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date32 = week28.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass38 = week36.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getStart();
//        java.lang.Class<?> wildcardClass43 = regularTimePeriod40.getClass();
//        java.util.Date date44 = regularTimePeriod40.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        int int48 = week45.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date49 = week45.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date27, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        int int57 = week54.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date58 = week54.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.lang.Class<?> wildcardClass61 = date58.getClass();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        long long65 = regularTimePeriod64.getMiddleMillisecond();
//        java.util.Date date66 = regularTimePeriod64.getStart();
//        java.lang.Class<?> wildcardClass67 = regularTimePeriod64.getClass();
//        java.util.Date date68 = regularTimePeriod64.getStart();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.util.Date date74 = year73.getStart();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        long long76 = week75.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass77 = week75.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.next();
//        org.jfree.data.time.Year year80 = week78.getYear();
//        java.util.Date date81 = year80.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.next();
//        int int85 = week82.compareTo((java.lang.Object) (byte) 100);
//        java.util.Date date86 = week82.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone87);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date74, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date68, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date27, timeZone87);
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date27, timeZone93);
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560970799999L + "'", long2 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560970799999L + "'", long20 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560365999999L + "'", long24 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560970799999L + "'", long41 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560970799999L + "'", long65 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560365999999L + "'", long76 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(timeZone93);
//    }
//}

