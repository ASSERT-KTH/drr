import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries1.add(timeSeriesDataItem4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (short) -1);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Number number13 = null;
        try {
            timeSeries1.update((int) (byte) 10, number13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (byte) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(regularTimePeriod3, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.Object obj8 = null;
        try {
            int int9 = spreadsheetDate6.compareTo(obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) "hi!");
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries1.update(regularTimePeriod5, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (short) -1);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1560441774909L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        java.lang.Comparable comparable6 = null;
        try {
            timeSeries1.setKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate7.getNearestDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.text.DateFormatSymbols dateFormatSymbols8 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass9 = dateFormatSymbols8.getClass();
        try {
            int int10 = spreadsheetDate6.compareTo((java.lang.Object) dateFormatSymbols8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.text.DateFormatSymbols cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateFormatSymbols8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441778707L + "'", long2 == 1560441778707L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441778707L + "'", long4 == 1560441778707L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441778707L + "'", long5 == 1560441778707L);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.delete(7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("2019");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.String str7 = timeSeries4.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        int int14 = month0.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isInRange(serialDate9, serialDate18, (int) ' ');
        java.lang.String str21 = spreadsheetDate3.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem(regularTimePeriod7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass2 = dateFormatSymbols1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass2);
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) inputStream3, (java.lang.Object) "2018");
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass6 = dateFormatSymbols5.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass6);
        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass10);
        java.text.DateFormatSymbols dateFormatSymbols13 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass14 = dateFormatSymbols13.getClass();
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass14);
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("9-April-1900", (java.lang.Class) wildcardClass14);
        org.junit.Assert.assertNotNull(dateFormatSymbols5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(dateFormatSymbols9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(dateFormatSymbols13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = timeSeries5.getDomainDescription();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setDomainDescription("Time");
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        int int18 = fixedMillisecond15.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        int int24 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeriesDataItem28.getPeriod();
        boolean boolean30 = timeSeriesDataItem20.equals((java.lang.Object) regularTimePeriod29);
        try {
            timeSeries1.add(regularTimePeriod29, (double) 1560441781865L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Object obj12 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        int int24 = fixedMillisecond21.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (short) -1);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        int int30 = timeSeriesDataItem26.compareTo((java.lang.Object) year28);
        try {
            timeSeries1.add(timeSeriesDataItem26, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        int int15 = year12.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDomainDescription("Time");
        timeSeries1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int9 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            boolean boolean11 = spreadsheetDate4.isOnOrAfter(serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1.0f);
        java.lang.String str13 = timeSeries2.getDescription();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10L, (java.lang.Object) timeSeries2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) (short) -1);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        int int14 = timeSeriesDataItem10.compareTo((java.lang.Object) year12);
        try {
            timeSeries1.add(timeSeriesDataItem10, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        try {
            java.lang.Number number13 = timeSeries7.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day10.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate15 = null;
        try {
            org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate6.getEndOfCurrentMonth(serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str0.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        int int12 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int14 = fixedMillisecond11.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (short) -1);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        int int18 = timeSeriesDataItem7.compareTo(obj17);
//        java.lang.Object obj19 = timeSeriesDataItem7.clone();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(obj19);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate15 = null;
        try {
            boolean boolean16 = spreadsheetDate6.isOn(serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Object obj12 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str7 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.addChangeListener(seriesChangeListener10);
//        java.lang.String str12 = timeSeries9.getDomainDescription();
//        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        int int14 = month0.compareTo((java.lang.Object) timeSeries9);
//        long long15 = timeSeries9.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        long long19 = fixedMillisecond16.getMiddleMillisecond();
//        try {
//            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 1900);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560441790111L + "'", long18 == 1560441790111L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560441790111L + "'", long19 == 1560441790111L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass15);
        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass19);
        java.text.DateFormatSymbols dateFormatSymbols22 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass23 = dateFormatSymbols22.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass23);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem7, "Thu Jun 13 09:02:58 PDT 2019", "Time", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        java.lang.Number number28 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.addOrUpdate(regularTimePeriod27, number28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(dateFormatSymbols18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(dateFormatSymbols22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(inputStream25);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        java.util.Calendar calendar10 = null;
        try {
            day9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(4, (int) (byte) 10);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class10);
        int int12 = day0.compareTo((java.lang.Object) "June 2019");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getFollowingDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        int int13 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        int int15 = fixedMillisecond12.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1.0f);
        java.lang.Object obj18 = timeSeries7.clone();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries20.getDomainDescription();
        java.util.Collection collection24 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        int int28 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.lang.String str29 = timeSeries26.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.addChangeListener(seriesChangeListener32);
        java.lang.String str34 = timeSeries31.getDomainDescription();
        java.util.Collection collection35 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean39 = timeSeries37.equals((java.lang.Object) "hi!");
        boolean boolean40 = timeSeries37.getNotify();
        timeSeries37.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries31.addAndOrUpdate(timeSeries37);
        java.util.Collection collection44 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries1.addAndOrUpdate(timeSeries31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeries45);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        boolean boolean11 = timeSeries6.getNotify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = year0.compareTo((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isInRange(serialDate9, serialDate18, (int) ' ');
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getNearestDayOfWeek(2);
        int int23 = spreadsheetDate3.getYYYY();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.String str3 = regularTimePeriod2.toString();
        long long4 = regularTimePeriod2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2018" + "'", str3.equals("2018"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1530561599999L + "'", long4 == 1530561599999L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        long long13 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond6.getMiddleMillisecond(calendar14);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441793137L + "'", long12 == 1560441793137L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441793137L + "'", long13 == 1560441793137L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560441793137L + "'", long15 == 1560441793137L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.String str7 = regularTimePeriod6.toString();
        int int8 = fixedMillisecond3.compareTo((java.lang.Object) str7);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2018" + "'", str7.equals("2018"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int9 = spreadsheetDate4.toSerial();
        java.util.Date date10 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond6.getFirstMillisecond(calendar13);
//        long long15 = fixedMillisecond6.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441794068L + "'", long12 == 1560441794068L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441794068L + "'", long14 == 1560441794068L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560441794068L + "'", long15 == 1560441794068L);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems(true);
        int int8 = timeSeries1.getItemCount();
        try {
            timeSeries1.update((-1), (java.lang.Number) 1560441774909L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Object obj12 = timeSeries1.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
        try {
            timeSeries1.add(timeSeriesDataItem13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        java.lang.String str4 = month0.toString();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.Year year6 = month0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate4.isInRange(serialDate10, serialDate19, (int) ' ');
        int int22 = spreadsheetDate4.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        java.lang.Object obj8 = timeSeries1.clone();
        boolean boolean9 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.Date date0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        int int7 = spreadsheetDate2.getMonth();
        java.util.Date date8 = spreadsheetDate2.toDate();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone12);
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date0, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day10.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = year0.compareTo((java.lang.Object) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate10.getNearestDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2200406400001L));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441798111L + "'", long2 == 1560441798111L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441798111L + "'", long3 == 1560441798111L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        java.lang.Number number9 = timeSeriesDataItem7.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem7.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        long long10 = day9.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2200406400001L) + "'", long10 == (-2200406400001L));
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.lang.String str9 = year8.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1900" + "'", str9.equals("1900"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day10.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(10, year2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, year2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        long long7 = month5.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        int int19 = month5.compareTo((java.lang.Object) timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries20.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.text.DateFormatSymbols dateFormatSymbols4 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass5 = dateFormatSymbols4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass5);
        java.text.DateFormatSymbols dateFormatSymbols8 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass9 = dateFormatSymbols8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass9);
        java.text.DateFormatSymbols dateFormatSymbols12 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass13 = dateFormatSymbols12.getClass();
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass13);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass13);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass13);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader16);
        org.junit.Assert.assertNotNull(dateFormatSymbols4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNotNull(dateFormatSymbols8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(dateFormatSymbols12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(classLoader16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.text.DateFormatSymbols dateFormatSymbols3 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass4 = dateFormatSymbols3.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass4);
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass8);
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass12 = dateFormatSymbols11.getClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass12);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(dateFormatSymbols3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(classLoader14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        java.lang.Object obj8 = timeSeries1.clone();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year11.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208960000000L) + "'", long12 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day10.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 09:02:58 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Object obj0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) day1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        int int10 = timeSeriesDataItem7.compareTo((java.lang.Object) "Value");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        java.lang.String str4 = month0.toString();
        java.lang.String str5 = month0.toString();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        java.lang.String str4 = month0.toString();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.Year year6 = month0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.util.List list12 = timeSeries1.getItems();
        try {
            java.util.Collection collection13 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list12);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int9 = spreadsheetDate4.toSerial();
        java.util.Date date10 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        java.lang.String str12 = month11.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month11.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "April 1900" + "'", str12.equals("April 1900"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.String str7 = timeSeries4.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        int int14 = month0.compareTo((java.lang.Object) timeSeries9);
        long long15 = month0.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month0.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getYearValue();
        org.jfree.data.time.Year year12 = month8.getYear();
        int int13 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        long long14 = timeSeries1.getMaximumItemAge();
        boolean boolean15 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        long long4 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries1.clone();
        timeSeries1.setRangeDescription("1900");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1560441793137L, (java.lang.Object) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass1 = dateFormatSymbols0.getClass();
        java.lang.ClassLoader classLoader2 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader2);
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(classLoader2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 09:03:22 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year5);
        java.lang.String str9 = month8.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "August 2019" + "'", str9.equals("August 2019"));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond6.getFirstMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond6.peg(calendar15);
//        long long17 = fixedMillisecond6.getFirstMillisecond();
//        long long18 = fixedMillisecond6.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441802945L + "'", long12 == 1560441802945L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441802945L + "'", long14 == 1560441802945L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441802945L + "'", long17 == 1560441802945L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560441802945L + "'", long18 == 1560441802945L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass15);
        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass19);
        java.text.DateFormatSymbols dateFormatSymbols22 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass23 = dateFormatSymbols22.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass23);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem7, "Thu Jun 13 09:02:58 PDT 2019", "Time", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate31.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int36 = spreadsheetDate31.toSerial();
        java.util.Date date37 = spreadsheetDate31.toDate();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate40.getDayOfWeek();
        int int45 = spreadsheetDate40.getMonth();
        java.util.Date date46 = spreadsheetDate40.toDate();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date46, timeZone48);
        java.lang.String str50 = day49.toString();
        long long51 = day49.getFirstMillisecond();
        int int52 = day49.getMonth();
        java.util.Date date53 = day49.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int59 = spreadsheetDate55.getDayOfWeek();
        int int60 = spreadsheetDate55.getMonth();
        java.util.Date date61 = spreadsheetDate55.toDate();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date61, timeZone63);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date61, timeZone65);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date53, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date37, timeZone65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(dateFormatSymbols18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(dateFormatSymbols22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2200492800000L) + "'", long51 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod68);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-451) + "'", int1 == (-451));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        long long21 = month19.getLastMillisecond();
        int int22 = month19.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (double) 8);
        java.lang.String str25 = month19.toString();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond6.getFirstMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond6.peg(calendar15);
//        long long17 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Date date18 = fixedMillisecond6.getTime();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441805605L + "'", long12 == 1560441805605L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441805605L + "'", long14 == 1560441805605L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441805605L + "'", long17 == 1560441805605L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate16.isInRange(serialDate22, serialDate31, (int) ' ');
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate16.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        int int51 = spreadsheetDate47.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate39.isInRange(serialDate45, serialDate54, (int) ' ');
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate39.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate60.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate62.getFollowingDayOfWeek(4);
        boolean boolean67 = spreadsheetDate16.isInRange(serialDate58, serialDate65, (int) '4');
        boolean boolean68 = spreadsheetDate2.isOnOrAfter(serialDate65);
        try {
            org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, serialDate65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate3.equals((java.lang.Object) spreadsheetDate18);
        int int21 = spreadsheetDate3.toSerial();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        long long10 = day9.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            day9.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2200406400001L) + "'", long10 == (-2200406400001L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        int int7 = spreadsheetDate2.getMonth();
        java.util.Date date8 = spreadsheetDate2.toDate();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year12);
        java.lang.String str14 = seriesChangeEvent13.toString();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1560441793137L, (java.lang.Object) str14);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1900]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=1900]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass7 = dateFormatSymbols6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass7);
        boolean boolean9 = year0.equals((java.lang.Object) inputStream8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = year0.equals((java.lang.Object) spreadsheetDate20);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (double) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate14.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean23 = timeSeriesDataItem10.equals((java.lang.Object) boolean22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        java.util.List list7 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass3 = dateFormatSymbols2.getClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass3);
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Last", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(inputStream4);
        org.junit.Assert.assertNull(inputStream5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("August 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate4.isInRange(serialDate10, serialDate19, (int) ' ');
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, serialDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean26 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), (org.jfree.data.time.SerialDate) spreadsheetDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        java.lang.Object obj9 = timeSeriesDataItem7.clone();
        java.lang.Number number10 = null;
        timeSeriesDataItem7.setValue(number10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean15 = timeSeries13.equals((java.lang.Object) "hi!");
        boolean boolean16 = timeSeries13.getNotify();
        int int17 = timeSeriesDataItem7.compareTo((java.lang.Object) boolean16);
        java.lang.Number number18 = timeSeriesDataItem7.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        long long4 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries1.clone();
        timeSeries1.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Date date14 = day10.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getDayOfWeek();
        int int21 = spreadsheetDate16.getMonth();
        java.util.Date date22 = spreadsheetDate16.toDate();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date14, timeZone26);
        java.lang.String str29 = day28.toString();
        java.util.Calendar calendar30 = null;
        try {
            day28.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
//        java.lang.String str4 = regularTimePeriod3.toString();
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) str4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2018" + "'", str4.equals("2018"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560441808112L + "'", long10 == 1560441808112L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Thu Jun 13 09:03:28 PDT 2019");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        java.lang.String str12 = timeSeries7.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2958465, 2019, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean25 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        java.util.Calendar calendar5 = null;
        try {
            year1.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass7 = dateFormatSymbols6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass7);
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass11 = dateFormatSymbols10.getClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass11);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=-1.0]", (java.lang.Class) wildcardClass11);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertNull(inputStream18);
        org.junit.Assert.assertNull(uRL19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = spreadsheetDate10.getMonth();
        java.util.Date date16 = spreadsheetDate10.toDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date7, timeZone18);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int13 = fixedMillisecond10.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        boolean boolean17 = timeSeriesDataItem7.equals((java.lang.Object) regularTimePeriod16);
        java.lang.Number number18 = timeSeriesDataItem7.getValue();
        java.lang.Number number19 = null;
        timeSeriesDataItem7.setValue(number19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) -1 + "'", number18.equals((short) -1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.previous();
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int13 = fixedMillisecond10.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        boolean boolean17 = timeSeriesDataItem7.equals((java.lang.Object) regularTimePeriod16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean25 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = timeSeriesDataItem7.equals((java.lang.Object) spreadsheetDate21);
        java.lang.Object obj27 = timeSeriesDataItem7.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) "hi!");
        boolean boolean4 = timeSeries1.getNotify();
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setDescription("Time");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        long long12 = year10.getFirstMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1560441808280L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 2147483647, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) "hi!");
        boolean boolean4 = timeSeries1.getNotify();
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        try {
            timeSeries1.delete((-460), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        long long7 = month5.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        int int19 = month5.compareTo((java.lang.Object) timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries14);
        timeSeries1.removeAgedItems((long) 31, true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        long long8 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isInRange(serialDate9, serialDate18, (int) ' ');
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getNearestDayOfWeek(2);
        java.lang.String str23 = serialDate22.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        boolean boolean18 = timeSeries16.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        int int24 = fixedMillisecond21.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod27, (double) 'a');
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries16, (java.lang.Object) regularTimePeriod27);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        long long2 = month0.getLastMillisecond();
//        java.lang.String str3 = month0.toString();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        int int13 = fixedMillisecond10.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
//        long long16 = fixedMillisecond10.getLastMillisecond();
//        java.lang.String str17 = fixedMillisecond10.toString();
//        int int18 = month0.compareTo((java.lang.Object) fixedMillisecond10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560441811738L + "'", long16 == 1560441811738L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Thu Jun 13 09:03:31 PDT 2019" + "'", str17.equals("Thu Jun 13 09:03:31 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond6.getFirstMillisecond(calendar13);
//        long long15 = fixedMillisecond6.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441811828L + "'", long12 == 1560441811828L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441811828L + "'", long14 == 1560441811828L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560441811828L + "'", long15 == 1560441811828L);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.clear();
        try {
            timeSeries1.update((-1), (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        int int6 = timeSeries1.getItemCount();
        timeSeries1.setMaximumItemAge((long) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Date date14 = day10.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getDayOfWeek();
        int int21 = spreadsheetDate16.getMonth();
        java.util.Date date22 = spreadsheetDate16.toDate();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date14, timeZone26);
        java.lang.String str29 = day28.toString();
        java.lang.String str30 = day28.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day9.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 0.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.getDayOfWeek();
        int int14 = spreadsheetDate9.getMonth();
        java.util.Date date15 = spreadsheetDate9.toDate();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
        java.lang.String str19 = day18.toString();
        long long20 = day18.getFirstMillisecond();
        int int21 = day18.getMonth();
        java.util.Date date22 = day18.getStart();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560441786739L, true);
        java.lang.String str26 = day18.toString();
        long long27 = day18.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2200492800000L) + "'", long20 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2200406400001L) + "'", long27 == (-2200406400001L));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.lang.String str13 = fixedMillisecond6.toString();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond6.peg(calendar14);
//        java.util.Date date16 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = year18.getFirstMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441812313L + "'", long12 == 1560441812313L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 09:03:32 PDT 2019" + "'", str13.equals("Thu Jun 13 09:03:32 PDT 2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        long long11 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDescription("1900");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries6.removeChangeListener(seriesChangeListener14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries6.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) "hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-460), (int) ' ', 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.addChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timeSeries11.getDomainDescription();
//        java.util.Collection collection15 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        long long18 = month16.getLastMillisecond();
//        int int19 = month16.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month16.previous();
//        boolean boolean23 = fixedMillisecond0.equals((java.lang.Object) month16);
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = month16.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441812915L + "'", long2 == 1560441812915L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441812915L + "'", long3 == 1560441812915L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441812915L + "'", long4 == 1560441812915L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean14 = timeSeries12.equals((java.lang.Object) "hi!");
        boolean boolean15 = timeSeries12.getNotify();
        timeSeries12.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441813511L + "'", long3 == 1560441813511L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441813511L + "'", long5 == 1560441813511L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        long long4 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries1.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries1.update(regularTimePeriod6, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        int int16 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        int int18 = fixedMillisecond15.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
        boolean boolean22 = timeSeriesDataItem12.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean30 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = timeSeriesDataItem12.equals((java.lang.Object) spreadsheetDate26);
        int int32 = spreadsheetDate26.getYYYY();
        boolean boolean33 = month0.equals((java.lang.Object) int32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year8.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 9223372036854775807L);
        java.lang.String str12 = year8.toString();
        java.util.Date date13 = year8.getEnd();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1900" + "'", str12.equals("1900"));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries4.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(4, (int) (byte) 10);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class11);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", class11);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(uRL14);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441814303L + "'", long3 == 1560441814303L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441814303L + "'", long8 == 1560441814303L);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        java.lang.String str4 = month0.toString();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        int int8 = month0.compareTo((java.lang.Object) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.setDescription("hi!");
        java.lang.String str8 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-451), 8, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timeSeries2.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries2.createCopy(4, (int) (byte) 10);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 09:03:25 PDT 2019", class9);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        java.lang.Number number9 = timeSeriesDataItem7.getValue();
        int int11 = timeSeriesDataItem7.compareTo((java.lang.Object) "Thu Jun 13 09:03:28 PDT 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem7.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int10 = spreadsheetDate5.toSerial();
        java.util.Date date11 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate5.getFollowingDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setMaximumItemAge((long) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        timeSeries1.setNotify(false);
        timeSeries1.setDomainDescription("");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate15.isInRange(serialDate21, serialDate30, (int) ' ');
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate15.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate36.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate46.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate38.isInRange(serialDate44, serialDate53, (int) ' ');
        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate38.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate59.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SerialDate serialDate64 = spreadsheetDate61.getFollowingDayOfWeek(4);
        boolean boolean66 = spreadsheetDate15.isInRange(serialDate57, serialDate64, (int) '4');
        boolean boolean67 = spreadsheetDate1.isOnOrAfter(serialDate64);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean67);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.text.DateFormatSymbols dateFormatSymbols3 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass4 = dateFormatSymbols3.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass4);
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass8);
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass12 = dateFormatSymbols11.getClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass12);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader14);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader14);
        org.junit.Assert.assertNotNull(dateFormatSymbols3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(classLoader14);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.addChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timeSeries11.getDomainDescription();
//        java.util.Collection collection15 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        long long18 = month16.getLastMillisecond();
//        int int19 = month16.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month16.previous();
//        boolean boolean23 = fixedMillisecond0.equals((java.lang.Object) month16);
//        boolean boolean25 = fixedMillisecond0.equals((java.lang.Object) 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441817251L + "'", long2 == 1560441817251L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441817251L + "'", long3 == 1560441817251L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441817251L + "'", long4 == 1560441817251L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.util.List list12 = timeSeries1.getItems();
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getFirstMillisecond();
        int int4 = year1.getYear();
        int int5 = year1.getYear();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        boolean boolean10 = year1.equals((java.lang.Object) inputStream9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = year1.equals((java.lang.Object) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-451), (org.jfree.data.time.SerialDate) spreadsheetDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        int int20 = fixedMillisecond17.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1.0f);
        boolean boolean23 = timeSeries6.equals((java.lang.Object) timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        int int12 = month11.getMonth();
//        long long13 = month11.getLastMillisecond();
//        int int14 = month11.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        long long24 = fixedMillisecond22.getLastMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 0);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441817930L + "'", long24 == 1560441817930L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Date date14 = day10.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean22 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate21.toSerial();
        java.lang.String str24 = spreadsheetDate21.getDescription();
        int int25 = day10.compareTo((java.lang.Object) str24);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.toSerial();
        int int9 = spreadsheetDate6.getYYYY();
        int int10 = spreadsheetDate6.getYYYY();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean14 = timeSeries12.equals((java.lang.Object) "hi!");
        boolean boolean15 = timeSeries12.getNotify();
        timeSeries12.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
        timeSeries6.removeAgedItems(true);
        try {
            timeSeries6.update(9, (java.lang.Number) 1560668399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean10 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getFollowingDayOfWeek(4);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean19 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getDayOfWeek();
        int int26 = spreadsheetDate21.getMonth();
        java.util.Date date27 = spreadsheetDate21.toDate();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone29);
        java.lang.Class<?> wildcardClass31 = timeZone29.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean19, (java.lang.Class) wildcardClass31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        java.lang.String str12 = day10.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int10 = spreadsheetDate5.toSerial();
        java.util.Date date11 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        spreadsheetDate5.setDescription("");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate5.compare(serialDate19);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-21) + "'", int20 == (-21));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        timeSeries6.setDescription("9-April-1900");
        timeSeries6.setDomainDescription("Thu Jun 13 09:02:58 PDT 2019");
        timeSeries6.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        int int20 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int22 = fixedMillisecond19.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (short) -1);
        java.lang.Object obj25 = timeSeriesDataItem24.clone();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        int int28 = timeSeriesDataItem24.compareTo((java.lang.Object) year26);
        try {
            timeSeries6.add(timeSeriesDataItem24);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = year0.compareTo((java.lang.Object) spreadsheetDate10);
        int int16 = spreadsheetDate10.getYYYY();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        timeSeries6.setDescription("9-April-1900");
        timeSeries6.setMaximumItemAge((long) '#');
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timeSeries6.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2018");
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        java.util.Collection collection17 = timeSeries6.getTimePeriods();
        java.lang.String str18 = timeSeries6.getRangeDescription();
        java.lang.String str19 = timeSeries6.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getYearValue();
        org.jfree.data.time.Year year12 = month8.getYear();
        int int13 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month8.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 09:02:58 PDT 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 09:02:58 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 09:02:58 PDT 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 09:02:58 PDT 2019"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Date date14 = day10.getStart();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        long long16 = month15.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2199888000001L) + "'", long16 == (-2199888000001L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, (int) (byte) 100, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = spreadsheetDate10.getMonth();
        java.util.Date date16 = spreadsheetDate10.toDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date7, timeZone18);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.util.Date date18 = month11.getStart();
        long long19 = month11.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        java.lang.String str4 = year1.toString();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(8, year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass12 = dateFormatSymbols11.getClass();
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass12);
        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass16 = dateFormatSymbols15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass16);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "October", "", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int29 = spreadsheetDate24.toSerial();
        java.util.Date date30 = spreadsheetDate24.toDate();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        try {
            timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1560441793137L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of java.text.DateFormatSymbols.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(dateFormatSymbols15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
//        long long6 = fixedMillisecond2.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond2.getTime();
//        boolean boolean11 = fixedMillisecond2.equals((java.lang.Object) 3);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441822005L + "'", long6 == 1560441822005L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441822005L + "'", long8 == 1560441822005L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year8.getYear();
        long long10 = year8.getFirstMillisecond();
        long long11 = year8.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2177424000001L) + "'", long11 == (-2177424000001L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean8 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            int int11 = spreadsheetDate7.compareTo((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        java.lang.String str17 = month11.toString();
        org.jfree.data.time.Year year18 = month11.getYear();
        java.lang.String str19 = month11.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int18 = spreadsheetDate13.toSerial();
        boolean boolean19 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getDayOfWeek();
        int int26 = spreadsheetDate21.getMonth();
        java.util.Date date27 = spreadsheetDate21.toDate();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date27, timeZone31);
        long long33 = day32.getFirstMillisecond();
        try {
            int int34 = spreadsheetDate6.compareTo((java.lang.Object) long33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2200492800000L) + "'", long33 == (-2200492800000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.String str11 = day10.toString();
        long long12 = day10.getFirstMillisecond();
        int int13 = day10.getMonth();
        java.util.Date date14 = day10.getStart();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2200492800000L) + "'", long12 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.String str7 = timeSeries4.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        int int14 = month0.compareTo((java.lang.Object) timeSeries9);
        long long15 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.createCopy(0, (int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int24 = spreadsheetDate20.getDayOfWeek();
        int int25 = spreadsheetDate20.getMonth();
        java.util.Date date26 = spreadsheetDate20.toDate();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year30);
        java.lang.Number number32 = null;
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year30, number32);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate15.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        boolean boolean29 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate31.getDayOfWeek();
        int int36 = spreadsheetDate31.getMonth();
        boolean boolean37 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str38 = spreadsheetDate24.getDescription();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        boolean boolean18 = timeSeries16.isEmpty();
        timeSeries16.setNotify(false);
        timeSeries16.setDescription("9-April-1900");
        try {
            timeSeries16.update(2, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Thu Jun 13 09:03:21 PDT 2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean9 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-21), (org.jfree.data.time.SerialDate) spreadsheetDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        boolean boolean18 = timeSeries16.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        int int29 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem33.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod34, (double) 'a');
        boolean boolean37 = spreadsheetDate21.equals((java.lang.Object) regularTimePeriod34);
        try {
            timeSeries16.add(regularTimePeriod34, (double) (-2200406400001L), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int24 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate29.getDayOfWeek();
        boolean boolean34 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate36.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int40 = spreadsheetDate36.getDayOfWeek();
        int int41 = spreadsheetDate36.getMonth();
        boolean boolean42 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.lang.String str43 = spreadsheetDate29.getDescription();
        int int44 = year1.compareTo((java.lang.Object) spreadsheetDate29);
        int int45 = spreadsheetDate29.getYYYY();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        long long11 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDescription("1900");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) "hi!");
        boolean boolean4 = timeSeries1.getNotify();
        timeSeries1.setDescription("2019");
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        timeSeries1.setDescription("Thu Jun 13 09:03:28 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100L + "'", comparable7.equals(100L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        try {
            timeSeries16.delete(12, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(comparable17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass6 = dateFormatSymbols5.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass6);
        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass10);
        java.text.DateFormatSymbols dateFormatSymbols13 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass14 = dateFormatSymbols13.getClass();
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass14);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 09:03:31 PDT 2019", (java.lang.Class) wildcardClass10);
        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(dateFormatSymbols5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(dateFormatSymbols9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(dateFormatSymbols13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(dateFormatSymbols18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.util.Date date0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        long long3 = month1.getLastMillisecond();
        int int4 = month1.getYearValue();
        java.lang.String str5 = month1.toString();
        java.lang.String str6 = month1.toString();
        org.jfree.data.time.Year year7 = month1.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        long long21 = month19.getLastMillisecond();
        int int22 = month19.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month19.previous();
        java.util.Date date26 = month19.getStart();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month1, (java.lang.Object) timeZone28);
        try {
            org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date0, timeZone28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year1);
        java.lang.String str5 = month4.toString();
        long long6 = month4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "August 2019" + "'", str5.equals("August 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24236L + "'", long6 == 24236L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560441806361L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener15);
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setRangeDescription("ThreadContext");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean11 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate15.getFollowingDayOfWeek(4);
        boolean boolean19 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean20 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate1.setDescription("Last");
        int int14 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass12 = dateFormatSymbols11.getClass();
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass12);
        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass16 = dateFormatSymbols15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass16);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "October", "", (java.lang.Class) wildcardClass16);
        try {
            timeSeries19.delete((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(dateFormatSymbols15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(uRL18);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        long long11 = day10.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2200492800000L) + "'", long11 == (-2200492800000L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        long long11 = timeSeries6.getMaximumItemAge();
        boolean boolean12 = timeSeries6.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((-460), serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems((long) (short) 10, false);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone(collection7);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        int int7 = spreadsheetDate2.getMonth();
        java.util.Date date8 = spreadsheetDate2.toDate();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        java.lang.Class<?> wildcardClass12 = timeZone10.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=1900]", class13);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(inputStream14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        int int15 = year12.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = year18.compareTo((java.lang.Object) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate28.getDayOfWeek();
        int int33 = year18.compareTo((java.lang.Object) spreadsheetDate28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1560441776618L);
        timeSeries7.setDomainDescription("2018");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass15);
        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.lang.String str26 = regularTimePeriod25.toString();
        int int27 = fixedMillisecond22.compareTo((java.lang.Object) str26);
        java.util.Date date28 = fixedMillisecond22.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.getDayOfWeek();
        int int38 = spreadsheetDate33.getMonth();
        java.util.Date date39 = spreadsheetDate33.toDate();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone41);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date7, timeZone41);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(dateFormatSymbols18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2018" + "'", str26.equals("2018"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = year0.compareTo((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year0.next();
        long long17 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(1900, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str11 = spreadsheetDate5.toString();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        timeSeries1.clear();
        timeSeries1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 09:02:58 PDT 2019");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str13 = spreadsheetDate4.toString();
        int int14 = spreadsheetDate4.getYYYY();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setDomainDescription("Value");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getSerialIndex();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        int int4 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1.0f);
        java.lang.Object obj13 = timeSeries2.clone();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.addChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries15.getDomainDescription();
        java.util.Collection collection19 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Class<?> wildcardClass20 = timeSeries2.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", (java.lang.Class) wildcardClass20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("August 2019", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getYearValue();
        org.jfree.data.time.Year year12 = month8.getYear();
        int int13 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        long long14 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable15 = timeSeries1.getKey();
        boolean boolean16 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 100L + "'", comparable15.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass15);
        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        int int26 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (short) -1);
        java.lang.Object obj31 = timeSeriesDataItem30.clone();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        int int34 = timeSeriesDataItem30.compareTo((java.lang.Object) year32);
        try {
            int int35 = spreadsheetDate1.compareTo((java.lang.Object) timeSeriesDataItem30);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeriesDataItem cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(dateFormatSymbols18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getFirstMillisecond();
        int int15 = year12.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = year18.compareTo((java.lang.Object) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate28.getDayOfWeek();
        int int33 = year18.compareTo((java.lang.Object) spreadsheetDate28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 1560441776618L);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        int int39 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) (short) -1);
        java.lang.Object obj44 = timeSeriesDataItem43.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        int int48 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        int int52 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        int int54 = fixedMillisecond51.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 1.0f);
        java.lang.Object obj57 = timeSeries46.clone();
        int int58 = timeSeriesDataItem43.compareTo(obj57);
        boolean boolean59 = year18.equals((java.lang.Object) timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.getDayOfWeek();
        int int14 = spreadsheetDate9.getMonth();
        java.util.Date date15 = spreadsheetDate9.toDate();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
        java.lang.String str19 = day18.toString();
        long long20 = day18.getFirstMillisecond();
        int int21 = day18.getMonth();
        java.util.Date date22 = day18.getStart();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560441786739L, true);
        int int26 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.addChangeListener(seriesChangeListener29);
        java.lang.String str31 = timeSeries28.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries28.createCopy(4, (int) (byte) 10);
        timeSeries28.clear();
        java.util.Collection collection36 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        int int40 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        timeSeries38.setMaximumItemAge(0L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate46.getDayOfWeek();
        int int51 = spreadsheetDate46.getMonth();
        java.util.Date date52 = spreadsheetDate46.toDate();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52, timeZone54);
        java.lang.String str56 = day55.toString();
        long long57 = day55.getFirstMillisecond();
        int int58 = day55.getMonth();
        java.util.Date date59 = day55.getStart();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 1560441786739L, true);
        org.jfree.data.time.SerialDate serialDate63 = day55.getSerialDate();
        java.lang.Number number64 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day55, number64);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 9-April-1900 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2200492800000L) + "'", long20 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-April-1900" + "'", str56.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-2200492800000L) + "'", long57 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(serialDate63);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate1.setDescription("Last");
        org.jfree.data.time.SerialDate serialDate14 = null;
        try {
            boolean boolean15 = spreadsheetDate1.isOnOrAfter(serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = timeSeries5.getDomainDescription();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setDomainDescription("Time");
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.addOrUpdate(regularTimePeriod13, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.util.List list12 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        java.util.Date date15 = year13.getEnd();
        java.lang.Number number16 = null;
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, number16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean20 = timeSeries19.isEmpty();
        java.lang.String str21 = timeSeries19.getRangeDescription();
        long long22 = timeSeries19.getMaximumItemAge();
        java.lang.Object obj23 = timeSeries19.clone();
        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.text.DateFormatSymbols dateFormatSymbols5 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass6 = dateFormatSymbols5.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass6);
        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass10);
        java.text.DateFormatSymbols dateFormatSymbols13 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass14 = dateFormatSymbols13.getClass();
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass14);
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=-1.0]", (java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader18);
        org.junit.Assert.assertNotNull(dateFormatSymbols5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(dateFormatSymbols9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(dateFormatSymbols13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(inputStream16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertNotNull(classLoader18);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        int int7 = spreadsheetDate3.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass15);
//        java.text.DateFormatSymbols dateFormatSymbols18 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        java.lang.Class<?> wildcardClass19 = dateFormatSymbols18.getClass();
//        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass19);
//        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass15);
//        java.lang.String str23 = timeSeries22.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        long long27 = fixedMillisecond24.getSerialIndex();
//        try {
//            timeSeries22.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 100.0f, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of java.text.DateFormatSymbols.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateFormatSymbols14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(inputStream16);
//        org.junit.Assert.assertNotNull(dateFormatSymbols18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(inputStream20);
//        org.junit.Assert.assertNull(obj21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441827474L + "'", long27 == 1560441827474L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 09:03:31 PDT 2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        java.lang.Object obj12 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries14.addChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timeSeries14.getDomainDescription();
//        java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.String str23 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries25.addChangeListener(seriesChangeListener26);
//        java.lang.String str28 = timeSeries25.getDomainDescription();
//        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        boolean boolean33 = timeSeries31.equals((java.lang.Object) "hi!");
//        boolean boolean34 = timeSeries31.getNotify();
//        timeSeries31.setDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries25.addAndOrUpdate(timeSeries31);
//        java.util.Collection collection38 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        int int50 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.Number number51 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, number51);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560441827644L + "'", long41 == 1560441827644L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560441827644L + "'", long43 == 1560441827644L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560441827644L + "'", long44 == 1560441827644L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = spreadsheetDate10.getMonth();
        java.util.Date date16 = spreadsheetDate10.toDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date7, timeZone18);
        long long21 = day20.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Object obj12 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.String str23 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.addChangeListener(seriesChangeListener26);
        java.lang.String str28 = timeSeries25.getDomainDescription();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean33 = timeSeries31.equals((java.lang.Object) "hi!");
        boolean boolean34 = timeSeries31.getNotify();
        timeSeries31.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries25.addAndOrUpdate(timeSeries31);
        java.util.Collection collection38 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries1.addChangeListener(seriesChangeListener39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
        try {
            timeSeries1.delete(regularTimePeriod41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(collection38);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date7, timeZone11);
        long long13 = day12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.previous();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2200492800000L) + "'", long13 == (-2200492800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 09:02:58 PDT 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 09:02:58 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Thu Jun 13 09:03:21 PDT 2019");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(4);
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.previous();
        java.lang.Object obj16 = null;
        int int17 = fixedMillisecond8.compareTo(obj16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean14 = timeSeries12.equals((java.lang.Object) "hi!");
        boolean boolean15 = timeSeries12.getNotify();
        timeSeries12.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        long long22 = year20.getFirstMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        java.lang.Number number25 = timeSeries6.getValue(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean14 = timeSeries12.equals((java.lang.Object) "hi!");
        boolean boolean15 = timeSeries12.getNotify();
        timeSeries12.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
        timeSeries6.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(4, (int) (byte) 10);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = timeSeries5.getDomainDescription();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setDomainDescription("Time");
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.util.Collection collection13 = org.jfree.chart.util.ObjectUtilities.deepClone(collection12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(collection13);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        timeSeries6.setDescription("9-April-1900");
//        timeSeries6.setMaximumItemAge((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int24 = fixedMillisecond21.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1.0f);
//        long long27 = fixedMillisecond21.getLastMillisecond();
//        java.lang.String str28 = fixedMillisecond21.toString();
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond21.peg(calendar29);
//        java.util.Date date31 = fixedMillisecond21.getTime();
//        int int32 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        timeSeries6.setMaximumItemCount(9);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441828455L + "'", long27 == 1560441828455L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 09:03:48 PDT 2019" + "'", str28.equals("Thu Jun 13 09:03:48 PDT 2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 09:03:22 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean10 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getFollowingDayOfWeek(4);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean19 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int47 = spreadsheetDate43.getDayOfWeek();
        boolean boolean48 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate50.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int54 = spreadsheetDate50.getDayOfWeek();
        int int55 = spreadsheetDate50.getMonth();
        boolean boolean56 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean57 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int58 = spreadsheetDate9.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = year0.compareTo((java.lang.Object) spreadsheetDate10);
        java.lang.String str16 = spreadsheetDate10.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        int int11 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int13 = fixedMillisecond10.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        boolean boolean17 = timeSeriesDataItem7.equals((java.lang.Object) regularTimePeriod16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean25 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = timeSeriesDataItem7.equals((java.lang.Object) spreadsheetDate21);
        int int27 = spreadsheetDate21.getYYYY();
        spreadsheetDate21.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.util.List list4 = timeSeries1.getItems();
        long long5 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.lang.String str13 = fixedMillisecond6.toString();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond6.peg(calendar14);
//        java.util.Date date16 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441831335L + "'", long12 == 1560441831335L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 09:03:51 PDT 2019" + "'", str13.equals("Thu Jun 13 09:03:51 PDT 2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        int int7 = spreadsheetDate2.getMonth();
        java.util.Date date8 = spreadsheetDate2.toDate();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        java.lang.Class<?> wildcardClass12 = timeZone10.getClass();
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("August 2019", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(inputStream13);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) 12);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate15.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        boolean boolean29 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate31.getDayOfWeek();
        int int36 = spreadsheetDate31.getMonth();
        boolean boolean37 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.Object obj38 = null;
        boolean boolean39 = spreadsheetDate24.equals(obj38);
        int int40 = spreadsheetDate24.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) day0, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date7, timeZone11);
        long long13 = day12.getFirstMillisecond();
        long long14 = day12.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2200492800000L) + "'", long13 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2200406400001L) + "'", long14 == (-2200406400001L));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 10, 9999);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate10.getDayOfWeek();
        int int15 = spreadsheetDate10.getMonth();
        java.util.Date date16 = spreadsheetDate10.toDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date7, timeZone18);
        java.lang.Object obj21 = null;
        boolean boolean22 = day20.equals(obj21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        int int6 = timeSeries1.getItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.lang.Class<?> wildcardClass11 = timeZone9.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class12);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(classLoader13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("Last");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getDayOfWeek();
        int int21 = spreadsheetDate16.getMonth();
        java.util.Date date22 = spreadsheetDate16.toDate();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
        java.lang.String str26 = day25.toString();
        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
        int int28 = day25.getYear();
        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
        boolean boolean30 = spreadsheetDate2.isAfter(serialDate29);
        try {
            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, serialDate29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 'a');
        int int4 = day0.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year11);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        int int6 = spreadsheetDate1.getMonth();
//        java.util.Date date7 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date7, timeZone11);
//        long long13 = day12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (short) 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        int int23 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        int int25 = fixedMillisecond22.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1.0f);
//        java.lang.String str28 = timeSeries17.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond29.peg(calendar30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) (-1.0f));
//        int int34 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeriesDataItem33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem15.getPeriod();
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2200492800000L) + "'", long13 == (-2200492800000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', (int) ' ', (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate19.isInRange(serialDate25, serialDate34, (int) ' ');
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate19.getNearestDayOfWeek(2);
        int int39 = spreadsheetDate11.compareTo((java.lang.Object) spreadsheetDate19);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date41 = spreadsheetDate19.toDate();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(date41);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = timeSeries5.getDomainDescription();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setDomainDescription("Time");
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries1.setMaximumItemAge(1560441808112L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getDayOfWeek();
        int int21 = spreadsheetDate16.getMonth();
        java.util.Date date22 = spreadsheetDate16.toDate();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        long long24 = year23.getMiddleMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year23);
        long long26 = year23.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2193192000001L) + "'", long24 == (-2193192000001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2193192000001L) + "'", long26 == (-2193192000001L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = year2.compareTo((java.lang.Object) day5);
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day5);
        java.util.Calendar calendar8 = null;
        try {
            day5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("April 1900");
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        long long12 = year11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208960000000L) + "'", long12 == (-2208960000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate16.isInRange(serialDate22, serialDate31, (int) ' ');
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate16.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        int int51 = spreadsheetDate47.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate39.isInRange(serialDate45, serialDate54, (int) ' ');
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate39.getNearestDayOfWeek(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate60.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate62.getFollowingDayOfWeek(4);
        boolean boolean67 = spreadsheetDate16.isInRange(serialDate58, serialDate65, (int) '4');
        boolean boolean68 = spreadsheetDate2.isOnOrAfter(serialDate65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addDays((-1), (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date70 = spreadsheetDate2.toDate();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(date70);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.util.List list12 = timeSeries1.getItems();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        long long15 = month13.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.String str20 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        java.lang.String str25 = timeSeries22.getDomainDescription();
        java.util.Collection collection26 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        int int27 = month13.compareTo((java.lang.Object) timeSeries22);
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, number28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
        java.lang.Object obj12 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries14.getDomainDescription();
        java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.String str23 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.addChangeListener(seriesChangeListener26);
        java.lang.String str28 = timeSeries25.getDomainDescription();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean33 = timeSeries31.equals((java.lang.Object) "hi!");
        boolean boolean34 = timeSeries31.getNotify();
        timeSeries31.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries25.addAndOrUpdate(timeSeries31);
        java.util.Collection collection38 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries25.addChangeListener(seriesChangeListener39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate42.getDayOfWeek();
        int int47 = spreadsheetDate42.getMonth();
        java.util.Date date48 = spreadsheetDate42.toDate();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate51.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate53);
        int int55 = spreadsheetDate51.getDayOfWeek();
        int int56 = spreadsheetDate51.getMonth();
        java.util.Date date57 = spreadsheetDate51.toDate();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57, timeZone59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date48, timeZone59);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) 1560441813529L);
        long long64 = day61.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-457), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        boolean boolean6 = year4.equals((java.lang.Object) 1560441780097L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1560668399999L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = year2.compareTo((java.lang.Object) day5);
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day5);
        java.lang.String str8 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        timeSeries6.setDescription("9-April-1900");
//        timeSeries6.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        long long18 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond15.getFirstMillisecond(calendar22);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441837441L + "'", long17 == 1560441837441L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560441837441L + "'", long18 == 1560441837441L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560441837441L + "'", long23 == 1560441837441L);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        spreadsheetDate19.setDescription("Last");
        boolean boolean32 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean33 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1560441811738L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year11);
        int int13 = year11.getYear();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass7 = dateFormatSymbols6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass7);
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass11 = dateFormatSymbols10.getClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass11);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.text.DateFormatSymbols dateFormatSymbols20 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass21 = dateFormatSymbols20.getClass();
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass21);
        java.text.DateFormatSymbols dateFormatSymbols24 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass25 = dateFormatSymbols24.getClass();
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass21, (java.lang.Class) wildcardClass25);
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass21);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("August 2019", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertNotNull(dateFormatSymbols20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(dateFormatSymbols24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNull(inputStream30);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.util.Date date18 = month11.getStart();
        int int19 = month11.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        long long3 = month1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = timeSeries5.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries10.getDomainDescription();
        java.util.Collection collection14 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        int int15 = month1.compareTo((java.lang.Object) timeSeries10);
        java.text.DateFormatSymbols dateFormatSymbols20 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass21 = dateFormatSymbols20.getClass();
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass21);
        java.text.DateFormatSymbols dateFormatSymbols24 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass25 = dateFormatSymbols24.getClass();
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass21, (java.lang.Class) wildcardClass25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.previous();
        java.lang.String str32 = regularTimePeriod31.toString();
        int int33 = fixedMillisecond28.compareTo((java.lang.Object) str32);
        java.util.Date date34 = fixedMillisecond28.getTime();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate39.getDayOfWeek();
        int int44 = spreadsheetDate39.getMonth();
        java.util.Date date45 = spreadsheetDate39.toDate();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date45, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int15, "Last", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", (java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        int int54 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        int int58 = timeSeries56.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        int int60 = fixedMillisecond57.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (java.lang.Number) 1.0f);
        java.lang.Object obj63 = timeSeries52.clone();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
        timeSeries65.addChangeListener(seriesChangeListener66);
        java.lang.String str68 = timeSeries65.getDomainDescription();
        java.util.Collection collection69 = timeSeries52.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        java.lang.Class<?> wildcardClass70 = timeSeries52.getClass();
        java.lang.Object obj71 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass21, (java.lang.Class) wildcardClass70);
        java.lang.ClassLoader classLoader72 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateFormatSymbols20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(dateFormatSymbols24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2018" + "'", str32.equals("2018"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(obj71);
        org.junit.Assert.assertNotNull(classLoader72);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getMiddleMillisecond();
        long long10 = year8.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2193192000001L) + "'", long9 == (-2193192000001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2177424000001L) + "'", long10 == (-2177424000001L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        java.lang.String str17 = month11.toString();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month11.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass7 = dateFormatSymbols6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass7);
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass11 = dateFormatSymbols10.getClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass11);
        java.text.DateFormatSymbols dateFormatSymbols14 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass15 = dateFormatSymbols14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass15);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass15);
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass15);
        java.lang.Class class19 = null;
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 09:03:31 PDT 2019", (java.lang.Class) wildcardClass15, class19);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass15);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(dateFormatSymbols14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(inputStream21);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        long long6 = month4.getLastMillisecond();
        int int7 = month4.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) 1560441778014L);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy((-21), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        java.lang.String str12 = timeSeries7.getRangeDescription();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate19.isInRange(serialDate25, serialDate34, (int) ' ');
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate19.getNearestDayOfWeek(2);
        int int39 = spreadsheetDate11.compareTo((java.lang.Object) spreadsheetDate19);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (double) (byte) -1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Preceding");
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        int int4 = year0.compareTo((java.lang.Object) day3);
        int int5 = day3.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.util.Date date15 = fixedMillisecond8.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.getDayOfWeek();
        int int22 = spreadsheetDate17.getMonth();
        java.util.Date date23 = spreadsheetDate17.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date15, timeZone25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        long long4 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond14.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560441778707L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        java.lang.String str13 = fixedMillisecond6.toString();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond6.peg(calendar14);
//        java.util.Date date16 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        long long22 = year20.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        int int28 = year20.compareTo((java.lang.Object) spreadsheetDate24);
//        int int29 = spreadsheetDate24.getDayOfWeek();
//        boolean boolean30 = fixedMillisecond19.equals((java.lang.Object) spreadsheetDate24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441840248L + "'", long12 == 1560441840248L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 09:04:00 PDT 2019" + "'", str13.equals("Thu Jun 13 09:04:00 PDT 2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.util.Date date0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        int int7 = spreadsheetDate2.getMonth();
        java.util.Date date8 = spreadsheetDate2.toDate();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass16 = dateFormatSymbols15.getClass();
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass16);
        java.text.DateFormatSymbols dateFormatSymbols19 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass20 = dateFormatSymbols19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass20);
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass16, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        java.lang.String str27 = regularTimePeriod26.toString();
        int int28 = fixedMillisecond23.compareTo((java.lang.Object) str27);
        java.util.Date date29 = fixedMillisecond23.getTime();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getDayOfWeek();
        int int39 = spreadsheetDate34.getMonth();
        java.util.Date date40 = spreadsheetDate34.toDate();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date40, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date29, timeZone42);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date8, timeZone42);
        try {
            org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date0, timeZone42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateFormatSymbols15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(inputStream17);
        org.junit.Assert.assertNotNull(dateFormatSymbols19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2018" + "'", str27.equals("2018"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(4, (int) (byte) 10);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getFirstMillisecond();
        timeSeries7.setKey((java.lang.Comparable) long10);
        java.lang.Object obj12 = timeSeries7.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries7.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate15.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        boolean boolean29 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate31.getDayOfWeek();
        int int36 = spreadsheetDate31.getMonth();
        boolean boolean37 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.Object obj38 = null;
        boolean boolean39 = spreadsheetDate24.equals(obj38);
        int int40 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate45.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int50 = spreadsheetDate45.toSerial();
        int int51 = spreadsheetDate45.getMonth();
        boolean boolean52 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        try {
            org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        timeSeries6.setDescription("9-April-1900");
//        timeSeries6.setMaximumItemAge((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int24 = fixedMillisecond21.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1.0f);
//        long long27 = fixedMillisecond21.getLastMillisecond();
//        java.lang.String str28 = fixedMillisecond21.toString();
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond21.peg(calendar29);
//        java.util.Date date31 = fixedMillisecond21.getTime();
//        int int32 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560441811738L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441840650L + "'", long27 == 1560441840650L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 09:04:00 PDT 2019" + "'", str28.equals("Thu Jun 13 09:04:00 PDT 2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        timeSeries1.setKey((java.lang.Comparable) month6);
        java.lang.String str9 = month6.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int15 = spreadsheetDate6.getYYYY();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass12 = dateFormatSymbols11.getClass();
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass12);
        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass16 = dateFormatSymbols15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass16);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 09:02:58 PDT 2019", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560441774909L, "Time", "August 2019", (java.lang.Class) wildcardClass16);
        try {
            java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "August 2019");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(dateFormatSymbols15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(uRL18);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        boolean boolean14 = timeSeries12.equals((java.lang.Object) "hi!");
        boolean boolean15 = timeSeries12.getNotify();
        timeSeries12.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.addAndOrUpdate(timeSeries12);
        timeSeries6.removeAgedItems(true);
        timeSeries6.removeAgedItems((long) 2, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441843006L + "'", long6 == 1560441843006L);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener15);
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setNotify(false);
        try {
            java.lang.Number number24 = timeSeries1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date7, timeZone11);
        long long13 = day12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (short) 100);
        long long16 = day12.getLastMillisecond();
        java.lang.Number number17 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, number17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2200492800000L) + "'", long13 == (-2200492800000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2200406400001L) + "'", long16 == (-2200406400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        int int5 = fixedMillisecond2.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (double) 'a');
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        int int20 = fixedMillisecond17.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1.0f);
//        long long23 = fixedMillisecond17.getLastMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond17.getFirstMillisecond(calendar24);
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond17.peg(calendar26);
//        long long28 = fixedMillisecond17.getFirstMillisecond();
//        int int29 = timeSeriesDataItem10.compareTo((java.lang.Object) fixedMillisecond17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond17.previous();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560441843157L + "'", long23 == 1560441843157L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560441843157L + "'", long25 == 1560441843157L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560441843157L + "'", long28 == 1560441843157L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getFollowingDayOfWeek(4);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate6);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getFollowingDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        long long28 = day27.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 2019L);
        java.util.Date date31 = day27.getStart();
        java.lang.String str32 = day27.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2200406400001L) + "'", long28 == (-2200406400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        timeSeries6.setDescription("9-April-1900");
//        timeSeries6.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        long long18 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        timeSeries23.setMaximumItemAge(0L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int35 = spreadsheetDate31.getDayOfWeek();
//        int int36 = spreadsheetDate31.getMonth();
//        java.util.Date date37 = spreadsheetDate31.toDate();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        java.lang.String str41 = day40.toString();
//        long long42 = day40.getFirstMillisecond();
//        int int43 = day40.getMonth();
//        java.util.Date date44 = day40.getStart();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 1560441786739L, true);
//        org.jfree.data.time.SerialDate serialDate48 = day40.getSerialDate();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day40, (double) (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441844175L + "'", long17 == 1560441844175L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560441844175L + "'", long18 == 1560441844175L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-April-1900" + "'", str41.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2200492800000L) + "'", long42 == (-2200492800000L));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(serialDate48);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.lang.String str4 = regularTimePeriod3.toString();
        int int5 = fixedMillisecond0.compareTo((java.lang.Object) str4);
        java.util.Date date6 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2018" + "'", str4.equals("2018"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getMiddleMillisecond();
        int int10 = year8.getYear();
        long long11 = year8.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2193192000001L) + "'", long9 == (-2193192000001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2177424000001L) + "'", long11 == (-2177424000001L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1.0d) + "'", obj2.equals((-1.0d)));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Friday" + "'", str1.equals("Friday"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getMiddleMillisecond();
        int int7 = month4.compareTo((java.lang.Object) month5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1.0f);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        long long13 = fixedMillisecond6.getFirstMillisecond();
//        long long14 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond6.previous();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond6.getMiddleMillisecond(calendar16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441845247L + "'", long12 == 1560441845247L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441845247L + "'", long13 == 1560441845247L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441845247L + "'", long14 == 1560441845247L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560441845247L + "'", long17 == 1560441845247L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        java.lang.String str17 = month11.toString();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month11.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem27.getPeriod();
        boolean boolean29 = timeSeriesDataItem19.equals((java.lang.Object) regularTimePeriod28);
        java.lang.Number number30 = timeSeriesDataItem19.getValue();
        int int31 = year11.compareTo((java.lang.Object) number30);
        long long32 = year11.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long32);
        java.lang.String str34 = seriesChangeEvent33.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) -1 + "'", number30.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2177424000001L) + "'", long32 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-2177424000001]" + "'", str34.equals("org.jfree.data.general.SeriesChangeEvent[source=-2177424000001]"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries6.getDomainDescription();
        java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        long long13 = month11.getLastMillisecond();
        int int14 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 8);
        java.lang.String str17 = month11.toString();
        org.jfree.data.time.Year year18 = month11.getYear();
        java.util.Calendar calendar19 = null;
        try {
            month11.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1900");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getMonth();
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        int int15 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem27.getPeriod();
        boolean boolean29 = timeSeriesDataItem19.equals((java.lang.Object) regularTimePeriod28);
        java.lang.Number number30 = timeSeriesDataItem19.getValue();
        int int31 = year11.compareTo((java.lang.Object) number30);
        long long32 = year11.getLastMillisecond();
        java.util.Calendar calendar33 = null;
        try {
            year11.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) -1 + "'", number30.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2177424000001L) + "'", long32 == (-2177424000001L));
    }
}

