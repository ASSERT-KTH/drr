import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { (byte) -1, 0.0f, '#', 0, 100 };
        try {
            float[] floatArray8 = color0.getComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        boolean boolean4 = strokeMap0.containsKey((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) (-1.0f), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { (-1), (-1) };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean2 = strokeMap0.equals((java.lang.Object) color1);
        java.awt.Stroke stroke4 = null;
        strokeMap0.put((java.lang.Comparable) "hi!", stroke4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        java.lang.String str6 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str6.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Paint paint0 = null;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) '#', (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str6 = rectangleEdge5.toString();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleEdge5);
        org.jfree.chart.util.ObjectList objectList9 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color11 = java.awt.Color.orange;
        objectList9.set((int) 'a', (java.lang.Object) color11);
        boolean boolean13 = standardPieSectionLabelGenerator0.equals((java.lang.Object) color11);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        try {
            java.text.AttributedString attributedString16 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset14, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets7.createInsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 10L, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-246) + "'", int3 == (-246));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke4 = null;
        strokeMap0.put((java.lang.Comparable) 0.0f, stroke4);
        try {
            java.awt.Stroke stroke7 = strokeMap0.getStroke((java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to java.lang.Double");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (short) 100, 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator5 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator6 = null;
        try {
            java.lang.String str7 = chartEntity4.getImageMapAreaTag(toolTipTagFragmentGenerator5, uRLTagFragmentGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str6 = rectangleEdge5.toString();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleEdge5);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        try {
            java.text.AttributedString attributedString10 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset8, (java.lang.Comparable) "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.String str4 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setForegroundAlpha((float) ' ');
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        boolean boolean11 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        try {
            legendTitle10.setLegendItemGraphicEdge(rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = flowArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) 10L, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = java.awt.Color.GRAY;
        float[] floatArray4 = new float[] { 'a', 1L, 100 };
        try {
            float[] floatArray5 = color0.getRGBComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        piePlot1.setPieIndex(100);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        boolean boolean4 = strokeMap0.containsKey((java.lang.Comparable) 175);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        double double6 = rotation5.getFactor();
        double double7 = rotation5.getFactor();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        boolean boolean15 = rectangleAnchor13.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = java.awt.Color.GRAY;
        boolean boolean9 = textTitle7.equals((java.lang.Object) color8);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        try {
            jFreeChart6.plotChanged(plotChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.getAntiAlias();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            rectangleInsets7.trim(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        try {
            piePlot1.setInteriorGap((double) (-246));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-246.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setBackgroundImageAlpha((float) 2);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = null;
        try {
            jFreeChart6.titleChanged(titleChangeEvent11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.removeChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        java.lang.Comparable comparable14 = null;
        java.awt.Stroke stroke15 = null;
        try {
            piePlot1.setSectionOutlineStroke(comparable14, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart2, chartChangeEventType3);
        boolean boolean5 = chartChangeEventType0.equals((java.lang.Object) chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.GENERAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get(192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        try {
            java.lang.Object obj19 = legendTitle10.draw(graphics2D14, rectangle2D15, (java.lang.Object) rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("PieLabelLinkStyle.QUAD_CURVE", "org.jfree.chart.event.ChartChangeEvent[source=100]", "", "{0}");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.lang.String str3 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ChartChangeEventType.GENERAL", "", "java.awt.Color[r=64,g=255,b=255]", "RectangleAnchor.BOTTOM", "ChartChangeEventType.GENERAL");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.TOP", "VerticalAlignment.CENTER", "", "", "PieLabelLinkStyle.QUAD_CURVE");
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.lang.String str4 = pieLabelLinkStyle2.toString();
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean6 = pieLabelLinkStyle2.equals((java.lang.Object) shapeArray5);
        java.lang.String str7 = pieLabelLinkStyle2.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str4.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str7.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "org.jfree.chart.event.ChartChangeEvent[source=100]", "VerticalAlignment.CENTER");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.Color color1 = color0.darker();
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        chartChangeEvent3.setType(chartChangeEventType4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean4 = strokeMap0.equals((java.lang.Object) projectInfo3);
        java.lang.Object obj5 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        boolean boolean6 = piePlot1.isSubplot();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            piePlot2.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart6.createBufferedImage(0, 10, chartRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.block.Arrangement arrangement16 = null;
        try {
            blockContainer13.setArrangement(arrangement16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = blockContainer13.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart6.createBufferedImage(1, 15, (int) (short) -1, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) "java.awt.Color[r=64,g=255,b=255]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: java.awt.Color[r=64,g=255,b=255]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getBottom();
        double double4 = rectangleInsets2.getBottom();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: RectangleAnchor.BOTTOM incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setTextAntiAlias(true);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart6.getSubtitle((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = piePlot1.getSectionPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getTransparency();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.lightGray;
        int int4 = color3.getTransparency();
        float[] floatArray10 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray11 = color3.getRGBColorComponents(floatArray10);
        try {
            float[] floatArray12 = color0.getColorComponents(colorSpace2, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        projectInfo0.setLicenceName("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            legendTitle15.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3.getLegendLabelURLGenerator();
        java.lang.Object obj5 = piePlot3.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3.getLegendLabelURLGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart8.createBufferedImage(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (8) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "RectangleEdge.TOP", "");
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", stroke7);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.String str3 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Stroke stroke5 = piePlot4.getBaseSectionOutlineStroke();
        piePlot0.setLabelOutlineStroke(stroke5);
        java.lang.String str7 = piePlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        double double11 = piePlot9.getMaximumExplodePercent();
        java.awt.Paint paint12 = piePlot9.getLabelBackgroundPaint();
        java.awt.Stroke stroke13 = piePlot9.getLabelOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot1.getLabelBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            piePlot1.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        chartEntity4.setToolTipText("{0}");
        java.lang.String str7 = chartEntity4.getShapeCoords();
        java.lang.Object obj8 = chartEntity4.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str7.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle17 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot16.setLabelLinkStyle(pieLabelLinkStyle17);
        java.awt.Paint paint20 = piePlot16.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement21.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement23.clear();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) flowArrangement21, (org.jfree.chart.block.Arrangement) columnArrangement23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle25.arrange(graphics2D26);
        org.jfree.chart.block.BlockContainer blockContainer28 = legendTitle25.getItemContainer();
        java.awt.Color color29 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean31 = color29.equals((java.lang.Object) rectangleAnchor30);
        legendTitle25.setLegendItemGraphicLocation(rectangleAnchor30);
        java.awt.Font font33 = legendTitle25.getItemFont();
        try {
            java.lang.Object obj34 = legendTitle10.draw(graphics2D13, rectangle2D14, (java.lang.Object) font33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle17);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(blockContainer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets2.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        legendTitle15.setNotify(false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.lang.Object obj21 = legendTitle15.draw(graphics2D18, rectangle2D19, (java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        int int8 = piePlot1.getBackgroundImageAlignment();
        java.awt.Paint paint9 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        java.awt.Image image9 = jFreeChart6.getBackgroundImage();
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart6.createBufferedImage((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (97) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "poly", "poly", "RectangleEdge.TOP");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle11.arrange(graphics2D12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle11.getItemContainer();
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean17 = color15.equals((java.lang.Object) rectangleAnchor16);
        legendTitle11.setLegendItemGraphicLocation(rectangleAnchor16);
        try {
            java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0}", "");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.data.general.PieDataset pieDataset4 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(pieDataset4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        double double6 = rotation5.getFactor();
        java.lang.String str7 = rotation5.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Rotation.CLOCKWISE" + "'", str7.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        java.lang.Comparable comparable6 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot9.setLabelLinkStyle(pieLabelLinkStyle10);
        java.awt.Paint paint12 = piePlot9.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot9);
        jFreeChart13.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart13.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart13.setBorderStroke(stroke22);
        try {
            piePlot1.setSectionOutlineStroke(comparable6, stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "TableOrder.BY_COLUMN", "Pie Plot", "poly");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        try {
            defaultCategoryDataset0.incrementValue(0.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.chart.ui.Contributor contributor12 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        boolean boolean13 = pieSectionEntity9.equals((java.lang.Object) "");
        int int14 = pieSectionEntity9.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray0, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.jfree.data.general.Dataset dataset4 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNull(dataset4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, 0.5f, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-589829) + "'", int3 == (-589829));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color4 = java.awt.Color.blue;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get((int) '4');
        int int7 = objectList1.size();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint14 = piePlot11.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart15.getTitle();
        java.lang.String str17 = textTitle16.getURLText();
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle16.setFont(font18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle16.setPaint((java.awt.Paint) color20);
        try {
            objectList1.set((int) (short) -1, (java.lang.Object) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 98 + "'", int7 == 98);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke4 = null;
        strokeMap0.put((java.lang.Comparable) 0.0f, stroke4);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Stroke stroke7 = strokeMap0.getStroke(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -2.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        try {
            org.jfree.chart.title.Title title18 = jFreeChart10.getSubtitle(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.calculateTopInset((double) (-1));
        textTitle7.setPadding(rectangleInsets10);
        org.jfree.chart.block.BlockFrame blockFrame14 = null;
        try {
            textTitle7.setFrame(blockFrame14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        textTitle7.setToolTipText("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        double double12 = rectangleInsets10.calculateTopInset((double) (-1));
        textTitle7.setPadding(rectangleInsets10);
        double double15 = rectangleInsets10.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Stroke stroke9 = piePlot8.getBaseSectionOutlineStroke();
        piePlot2.setBaseSectionOutlineStroke(stroke9);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Paint paint8 = jFreeChart6.getBorderPaint();
        org.jfree.chart.title.Title title9 = null;
        jFreeChart6.removeSubtitle(title9);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = null;
        try {
            jFreeChart6.titleChanged(titleChangeEvent11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        try {
            defaultCategoryDataset0.removeRow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle7.setTextAlignment(horizontalAlignment15);
        textTitle7.setURLText("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "poly", "poly", "RectangleEdge.TOP");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setCopyright("{0}");
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            lineBorder14.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.lang.Object obj11 = textTitle7.clone();
        textTitle7.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            jFreeChart6.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultCategoryDataset0.removeChangeListener(datasetChangeListener5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = null;
        try {
            jFreeChart1.titleChanged(titleChangeEvent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.awt.Stroke stroke12 = piePlot1.getLabelOutlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            piePlot1.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) (-246), 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "PieLabelLinkStyle.QUAD_CURVE", dataset1);
        java.lang.String str3 = datasetChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]" + "'", str3.equals("org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str14 = color13.toString();
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str14.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            piePlot1.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        java.awt.Paint paint9 = textTitle7.getPaint();
        java.lang.String str10 = textTitle7.getID();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.lang.Object obj9 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.Title title11 = null;
        try {
            jFreeChart6.addSubtitle((int) '#', title11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get(100);
        java.lang.Object obj7 = objectList1.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        int int9 = pieSectionEntity8.getSectionIndex();
        java.lang.Comparable comparable10 = pieSectionEntity8.getSectionKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 35.0d + "'", comparable10.equals(35.0d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]", (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint10 = piePlot6.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle15.setVerticalAlignment(verticalAlignment16);
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("", font19);
        legendTitle15.setItemFont(font19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle15.setVerticalAlignment(verticalAlignment22);
        org.jfree.chart.block.FlowArrangement flowArrangement26 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment22, (double) (-246), 0.0d);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot28.setLabelLinkStyle(pieLabelLinkStyle29);
        java.awt.Paint paint32 = piePlot28.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement33.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement35.clear();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot28, (org.jfree.chart.block.Arrangement) flowArrangement33, (org.jfree.chart.block.Arrangement) columnArrangement35);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = legendTitle37.arrange(graphics2D38);
        org.jfree.chart.block.BlockContainer blockContainer40 = legendTitle37.getItemContainer();
        boolean boolean41 = blockContainer40.isEmpty();
        java.lang.Object obj42 = blockContainer40.clone();
        blockContainer40.clear();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = null;
        try {
            org.jfree.chart.util.Size2D size2D46 = flowArrangement26.arrange(blockContainer40, graphics2D44, rectangleConstraint45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(blockContainer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = textTitle7.getBackgroundPaint();
        textTitle7.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray0, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean4 = strokeMap0.equals((java.lang.Object) projectInfo3);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getOptionalLibraries();
        java.awt.Image image6 = null;
        projectInfo3.setLogo(image6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        jFreeChart6.clearSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        double double28 = piePlot1.getExplodePercent((java.lang.Comparable) (short) 0);
        java.awt.Image image29 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(image29);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot7 = jFreeChart6.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setBackgroundImageAlpha((float) 2);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        piePlot12.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot17 = piePlot12.getParent();
        boolean boolean18 = jFreeChart6.equals((java.lang.Object) piePlot12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(175, (int) (byte) 100, (int) (short) 10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        double double17 = rectangleInsets15.trimWidth((double) 0L);
        double double18 = rectangleInsets15.getRight();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            rectangleInsets15.trim(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-2.0d) + "'", double17 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        jFreeChart6.clearSubtitles();
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 4.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        org.jfree.chart.StrokeMap strokeMap14 = new org.jfree.chart.StrokeMap();
        boolean boolean16 = strokeMap14.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke18 = null;
        strokeMap14.put((java.lang.Comparable) 0.0f, stroke18);
        boolean boolean20 = legendTitle10.equals((java.lang.Object) 0.0f);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle10.getSources();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.lang.Object obj25 = legendTitle10.draw(graphics2D22, rectangle2D23, (java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot2.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        piePlot2.setNoDataMessageFont(font8);
        java.awt.Paint paint10 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint16 = piePlot13.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        boolean boolean19 = textTitle18.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.TOP;
        textTitle18.setPosition(rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        double double28 = rectangleInsets27.getBottom();
        try {
            org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font8, paint10, rectangleEdge22, horizontalAlignment23, verticalAlignment24, rectangleInsets27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'paint' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(192, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 192, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        try {
            java.lang.Number number8 = defaultKeyedValues2D1.getValue((int) (byte) 0, 98);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 98, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke0);
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.addValue((java.lang.Number) 8, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        int int8 = piePlot1.getBackgroundImageAlignment();
        boolean boolean9 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getLegendItemGraphicPadding();
        double double14 = rectangleInsets12.calculateTopOutset((double) 8);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            rectangleInsets12.trim(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("", font12);
        java.lang.Object obj14 = null;
        flowArrangement6.add((org.jfree.chart.block.Block) textTitle13, obj14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint21 = piePlot17.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement22.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement24.clear();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement24);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = legendTitle26.arrange(graphics2D27);
        org.jfree.chart.block.BlockContainer blockContainer29 = legendTitle26.getItemContainer();
        boolean boolean30 = blockContainer29.isEmpty();
        boolean boolean31 = blockContainer29.isEmpty();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = null;
        try {
            org.jfree.chart.util.Size2D size2D34 = flowArrangement6.arrange(blockContainer29, graphics2D32, rectangleConstraint33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(blockContainer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        boolean boolean16 = legendTitle15.getNotify();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor9 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor9.sort();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor9);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord13 = pieLabelDistributor9.getPieLabelRecord(175);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 175, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        columnArrangement8.clear();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle19 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle19);
        java.awt.Paint paint22 = piePlot18.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement23.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement25.clear();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18, (org.jfree.chart.block.Arrangement) flowArrangement23, (org.jfree.chart.block.Arrangement) columnArrangement25);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = legendTitle27.arrange(graphics2D28);
        org.jfree.chart.block.BlockContainer blockContainer30 = legendTitle27.getItemContainer();
        boolean boolean31 = blockContainer30.isEmpty();
        java.lang.Object obj32 = blockContainer30.clone();
        org.jfree.chart.block.Arrangement arrangement33 = blockContainer30.getArrangement();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = null;
        try {
            org.jfree.chart.util.Size2D size2D36 = columnArrangement8.arrange(blockContainer30, graphics2D34, rectangleConstraint35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(blockContainer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(arrangement33);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot1.datasetChanged(datasetChangeEvent2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        pieSectionEntity9.setSectionIndex(0);
        java.lang.String str12 = pieSectionEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PieSection: -1, 0(100)" + "'", str12.equals("PieSection: -1, 0(100)"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator6.generateSectionLabel(pieDataset7, (java.lang.Comparable) '#');
        java.lang.Object obj10 = standardPieSectionLabelGenerator6.clone();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.lang.String str12 = standardPieSectionLabelGenerator6.getLabelFormat();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{0}" + "'", str12.equals("{0}"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle19 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle19);
        java.awt.Paint paint22 = piePlot18.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement23.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement25.clear();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18, (org.jfree.chart.block.Arrangement) flowArrangement23, (org.jfree.chart.block.Arrangement) columnArrangement25);
        legendTitle27.setHeight((double) '#');
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str31 = color30.toString();
        legendTitle27.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle27.getPadding();
        try {
            java.lang.Object obj34 = blockContainer13.draw(graphics2D15, rectangle2D16, (java.lang.Object) legendTitle27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str31.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.String str16 = chartEntity15.getShapeType();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "RectangleEdge.TOP", "");
        chartEntity15.setArea(shape17);
        java.lang.String str22 = chartEntity15.getToolTipText();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "poly" + "'", str16.equals("poly"));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("", font12);
        java.lang.Object obj14 = null;
        flowArrangement6.add((org.jfree.chart.block.Block) textTitle13, obj14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint21 = piePlot17.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement22.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement24.clear();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement24);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = legendTitle26.arrange(graphics2D27);
        org.jfree.chart.block.BlockContainer blockContainer29 = legendTitle26.getItemContainer();
        boolean boolean30 = blockContainer29.isEmpty();
        boolean boolean31 = blockContainer29.isEmpty();
        java.util.List list32 = blockContainer29.getBlocks();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = null;
        try {
            org.jfree.chart.util.Size2D size2D35 = flowArrangement6.arrange(blockContainer29, graphics2D33, rectangleConstraint34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(blockContainer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setBackgroundImageAlignment((int) (byte) -1);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        java.lang.String str10 = pieSectionEntity9.getShapeType();
        java.lang.String str11 = pieSectionEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: -1, 0(100)" + "'", str11.equals("PieSection: -1, 0(100)"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.addOptionalLibrary("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        try {
            defaultKeyedValues2D1.removeValue((java.lang.Comparable) "PieSection: -1, 0(100)", (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to java.lang.Integer");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        basicProjectInfo5.setCopyright("java.awt.Color[r=64,g=255,b=255]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        basicProjectInfo13.setInfo("ChartChangeEventType.GENERAL");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color1 = java.awt.Color.lightGray;
        int int2 = color1.getTransparency();
        float[] floatArray8 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray9 = color1.getRGBColorComponents(floatArray8);
        boolean boolean10 = pieLabelLinkStyle0.equals((java.lang.Object) color1);
        java.lang.String str11 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str11.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        try {
            defaultCategoryDataset0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getParent();
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray5, dataset6);
        org.jfree.data.general.Dataset dataset8 = datasetChangeEvent7.getDataset();
        try {
            plot4.datasetChanged(datasetChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNull(dataset8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor9 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor9.sort();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor9);
        java.lang.String str12 = pieLabelDistributor9.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Paint paint7 = null;
        try {
            piePlot1.setLabelLinkPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        jFreeChart10.setBorderVisible(true);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo0.setName("{0}");
        projectInfo0.setVersion("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        try {
            defaultCategoryDataset0.incrementValue(90.0d, (java.lang.Comparable) 0L, (java.lang.Comparable) "org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart6.handleClick(0, (int) (short) 10, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        projectInfo0.setContributors(list2);
        projectInfo0.setVersion("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle11.arrange(graphics2D12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle11.getItemContainer();
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean17 = color15.equals((java.lang.Object) rectangleAnchor16);
        legendTitle11.setLegendItemGraphicLocation(rectangleAnchor16);
        java.awt.Font font19 = legendTitle11.getItemFont();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        java.lang.String str23 = standardPieSectionLabelGenerator20.generateSectionLabel(pieDataset21, (java.lang.Comparable) '#');
        java.lang.Object obj24 = standardPieSectionLabelGenerator20.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str26 = rectangleEdge25.toString();
        boolean boolean27 = standardPieSectionLabelGenerator20.equals((java.lang.Object) rectangleEdge25);
        org.jfree.chart.util.ObjectList objectList29 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color31 = java.awt.Color.orange;
        objectList29.set((int) 'a', (java.lang.Object) color31);
        boolean boolean33 = standardPieSectionLabelGenerator20.equals((java.lang.Object) color31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment36, verticalAlignment37, (double) (byte) 10, (double) (-1));
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle43 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot42.setLabelLinkStyle(pieLabelLinkStyle43);
        java.awt.Paint paint46 = piePlot42.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement47 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement47.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement49.clear();
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot42, (org.jfree.chart.block.Arrangement) flowArrangement47, (org.jfree.chart.block.Arrangement) columnArrangement49);
        org.jfree.chart.plot.Plot plot52 = piePlot42.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator53 = null;
        piePlot42.setLegendLabelURLGenerator(pieURLGenerator53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        piePlot57.addChangeListener(plotChangeListener58);
        piePlot57.setSimpleLabels(true);
        java.awt.Stroke stroke62 = piePlot57.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset63 = null;
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot(pieDataset63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder66 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = blockBorder66.getInsets();
        piePlot64.setLabelPadding(rectangleInsets67);
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke62, rectangleInsets67);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = lineBorder69.getInsets();
        double double72 = rectangleInsets70.trimWidth((double) 0L);
        double double73 = rectangleInsets70.getRight();
        piePlot42.setInsets(rectangleInsets70, true);
        org.jfree.data.general.PieDataset pieDataset76 = null;
        org.jfree.chart.plot.PiePlot piePlot77 = new org.jfree.chart.plot.PiePlot(pieDataset76);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle78 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot77.setLabelLinkStyle(pieLabelLinkStyle78);
        java.awt.Paint paint80 = piePlot77.getLabelLinkPaint();
        java.awt.Stroke stroke81 = piePlot77.getLabelLinkStroke();
        boolean boolean82 = rectangleInsets70.equals((java.lang.Object) piePlot77);
        double double84 = rectangleInsets70.calculateLeftInset((double) 10L);
        try {
            org.jfree.chart.title.TextTitle textTitle85 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=192]", font19, (java.awt.Paint) color31, rectangleEdge34, horizontalAlignment35, verticalAlignment37, rectangleInsets70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleEdge.TOP" + "'", str26.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(plot52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-2.0d) + "'", double72 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0d + "'", double84 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot16.setLabelLinkStyle(pieLabelLinkStyle21);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement23.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) columnArrangement23, (org.jfree.chart.block.Arrangement) flowArrangement29);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement23);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = null;
        try {
            org.jfree.chart.util.Size2D size2D34 = blockContainer13.arrange(graphics2D32, rectangleConstraint33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        double double3 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        textTitle7.setPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle11.setVerticalAlignment(verticalAlignment12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle11.getLegendItemGraphicEdge();
        try {
            double double15 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        java.util.List list13 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart6.getLegend();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        try {
            java.lang.Object obj18 = legendTitle14.draw(graphics2D15, rectangle2D16, (java.lang.Object) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(legendTitle14);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=0,b=192]", "Rotation.CLOCKWISE", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "VerticalAlignment.CENTER", "JFreeChart version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:hi!  ().hi!  ().hi!  ().hi!  ().JFreeChart 1.2.0-pre (http://www.jfree.org/jfreechart/index.html).hi!  ().JFreeChart 1.2.0-pre (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().\nJFreeChart LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) multiplePiePlot2);
        java.lang.String str4 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        piePlot1.setMinimumArcAngleToDraw((double) 255);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot7.getLegendLabelURLGenerator();
        double double9 = piePlot7.getMaximumExplodePercent();
        java.awt.Paint paint10 = piePlot7.getLabelBackgroundPaint();
        piePlot1.setLabelPaint(paint10);
        try {
            piePlot1.setInteriorGap((double) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (192.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle10.arrange(graphics2D13, rectangleConstraint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) 1.0f, (double) 64, rectangleAnchor18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNull(rectangle2D19);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        java.util.List list13 = defaultCategoryDataset0.getRowKeys();
        try {
            java.lang.Number number16 = defaultCategoryDataset0.getValue((int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100]", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        double double28 = piePlot1.getExplodePercent((java.lang.Comparable) (short) 0);
        double double29 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.14d + "'", double29 == 0.14d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = projectInfo3.equals((java.lang.Object) 2);
//        java.lang.String str6 = projectInfo3.toString();
//        boolean boolean7 = defaultKeyedValues2D1.equals((java.lang.Object) str6);
//        try {
//            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "VerticalAlignment.CENTER");
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: VerticalAlignment.CENTER");
//        } catch (org.jfree.data.UnknownKeyException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n" + "'", str6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.clear();
        int int4 = defaultCategoryDataset1.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        try {
            defaultCategoryDataset1.removeColumn((java.lang.Comparable) "PieSection: -1, 0(100)");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: PieSection: -1, 0(100)");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double5 = rectangleInsets2.getBottom();
        double double7 = rectangleInsets2.calculateBottomOutset((double) 3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean2 = columnArrangement0.equals((java.lang.Object) 64);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str14 = color13.toString();
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            legendTitle10.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str14.equals("java.awt.Color[r=64,g=255,b=255]"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean14 = projectInfo12.equals((java.lang.Object) 2);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0);
        org.jfree.chart.JFreeChart jFreeChart17 = chartChangeEvent16.getChart();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jFreeChart17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        piePlot1.setNoDataMessageFont(font7);
        java.lang.Object obj9 = piePlot1.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart6.getPadding();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createInsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        int int9 = piePlot1.getPieIndex();
        double double10 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        java.awt.Image image9 = jFreeChart6.getBackgroundImage();
        java.awt.Stroke stroke10 = jFreeChart6.getBorderStroke();
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Paint paint11 = null;
        try {
            textTitle7.setPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        java.lang.String str9 = textTitle7.getText();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str9.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.lang.Object obj9 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart6.createBufferedImage((int) (byte) 10, (-1), (double) 100L, (double) 192, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot7 = plotChangeEvent6.getPlot();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setLabelLinksVisible(false);
        piePlot9.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot9.setForegroundAlpha((float) '#');
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = piePlot17.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot17.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        piePlot21.setLabelPadding(rectangleInsets24);
        piePlot17.setInsets(rectangleInsets24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = piePlot17.getDrawingSupplier();
        piePlot9.setDrawingSupplier(drawingSupplier27);
        plot7.setDrawingSupplier(drawingSupplier27);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNull(pieURLGenerator18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(drawingSupplier27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        double double9 = textTitle7.getWidth();
        textTitle7.setHeight((double) 175);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color9 = java.awt.Color.lightGray;
        int int10 = color9.getTransparency();
        float[] floatArray16 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray17 = color9.getRGBColorComponents(floatArray16);
        boolean boolean18 = pieLabelLinkStyle8.equals((java.lang.Object) color9);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle8);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo25 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.TOP", "RectangleEdge.TOP", "", "java.awt.Color[r=64,g=255,b=255]", "java.awt.Color[r=64,g=64,b=64]");
        boolean boolean26 = pieLabelLinkStyle8.equals((java.lang.Object) "java.awt.Color[r=64,g=64,b=64]");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 10.0d);
        java.awt.Paint paint9 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        objectList1.clear();
        int int3 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 100);
        java.lang.Object obj3 = strokeMap0.clone();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint10 = piePlot7.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Stroke stroke14 = piePlot13.getBaseSectionOutlineStroke();
        piePlot7.setBaseSectionOutlineStroke(stroke14);
        strokeMap0.put((java.lang.Comparable) 0.14d, stroke14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        double double9 = textTitle7.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle7.getTextAlignment();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = projectInfo3.equals((java.lang.Object) 2);
//        java.lang.String str6 = projectInfo3.toString();
//        boolean boolean7 = defaultKeyedValues2D1.equals((java.lang.Object) str6);
//        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) (-589829));
//        try {
//            java.lang.Number number13 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "TableOrder.BY_COLUMN", (java.lang.Comparable) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
//        } catch (org.jfree.data.UnknownKeyException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n" + "'", str6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("", font14);
        legendTitle10.setItemFont(font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle10.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray19 = legendTitle10.getSources();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(legendItemSourceArray19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getBottom();
        double double5 = rectangleInsets2.calculateBottomInset(1.0E-5d);
        double double6 = rectangleInsets2.getRight();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        java.lang.Object obj6 = null;
        boolean boolean7 = defaultCategoryDataset0.equals(obj6);
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        double double15 = piePlot10.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle19 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle19);
        java.awt.Paint paint21 = piePlot18.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot18);
        jFreeChart22.setBorderVisible(false);
        piePlot10.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        piePlot10.setNoDataMessagePaint((java.awt.Paint) color26);
        piePlot2.setBackgroundPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.14d + "'", double15 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("JFreeChart version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:hi!  ().hi!  ().hi!  ().hi!  ().JFreeChart 1.2.0-pre (http://www.jfree.org/jfreechart/index.html).hi!  ().JFreeChart 1.2.0-pre (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().\nJFreeChart LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean14 = projectInfo12.equals((java.lang.Object) 2);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D17 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list18 = defaultKeyedValues2D17.getRowKeys();
        projectInfo12.setContributors(list18);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        int int5 = piePlot2.getBackgroundImageAlignment();
        piePlot2.setMinimumArcAngleToDraw(0.0d);
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        java.lang.Object obj3 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot8.getLegendItems();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        double double16 = rectangleInsets14.calculateTopInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        piePlot8.setLabelPadding(rectangleInsets14);
        boolean boolean19 = piePlot1.equals((java.lang.Object) rectangleInsets14);
        double double21 = rectangleInsets14.trimWidth(100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 98.0d + "'", double21 == 98.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        double double8 = textTitle7.getContentYOffset();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.String str12 = color11.toString();
        java.lang.Object obj13 = textTitle7.draw(graphics2D9, rectangle2D10, (java.lang.Object) color11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=0,g=0,b=192]" + "'", str12.equals("java.awt.Color[r=0,g=0,b=192]"));
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.clear();
        int int4 = defaultCategoryDataset1.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.lang.Comparable comparable6 = null;
        try {
            defaultCategoryDataset1.removeValue(comparable6, (java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart6.removeChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        multiplePiePlot0.setLimit((double) ' ');
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean6 = projectInfo4.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library12 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str13 = library12.getInfo();
        boolean boolean14 = standardPieSectionLabelGenerator7.equals((java.lang.Object) library12);
        projectInfo4.addLibrary(library12);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle19 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle19);
        java.awt.Paint paint21 = piePlot18.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot18);
        jFreeChart22.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        java.awt.image.BufferedImage bufferedImage30 = jFreeChart22.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo29);
        projectInfo4.setLogo((java.awt.Image) bufferedImage30);
        multiplePiePlot0.setBackgroundImage((java.awt.Image) bufferedImage30);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(bufferedImage30);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        try {
            piePlot1.setBackgroundImageAlpha((float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Rotation.CLOCKWISE", "", "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n", "java.awt.Color[r=0,g=0,b=192]", "org.jfree.chart.event.ChartChangeEvent[source=100]");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Color color0 = java.awt.Color.green;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16711936) + "'", int1 == (-16711936));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getLegendItemGraphicPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets12.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType14, lengthAdjustmentType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=64,g=255,b=255]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.clear();
        int int4 = defaultCategoryDataset1.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        int int6 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-12517377) + "'", int6 == (-12517377));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        basicProjectInfo5.setLicenceName("1.2.0-pre");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getInsets();
        double double6 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder3 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder3);
        java.lang.String str5 = tableOrder3.toString();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TableOrder.BY_ROW" + "'", str5.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        try {
            java.lang.Comparable comparable7 = defaultKeyedValues2D1.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot29.setLabelLinkStyle(pieLabelLinkStyle30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        piePlot29.addChangeListener(plotChangeListener32);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator36 = piePlot35.getLegendLabelURLGenerator();
        double double37 = piePlot35.getMaximumExplodePercent();
        java.awt.Paint paint38 = piePlot35.getLabelBackgroundPaint();
        piePlot29.setLabelPaint(paint38);
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) piePlot29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.PiePlot@1cd3fc99 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNull(pieURLGenerator36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color0 = java.awt.Color.blue;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent3.setType(chartChangeEventType4);
        java.lang.Object obj6 = chartChangeEvent3.getSource();
        java.lang.Object obj7 = chartChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (byte) 10, (double) (byte) 10);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement20);
        flowArrangement20.clear();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-246), 0.025d, (double) 100, (double) 0L);
        org.jfree.chart.util.TableOrder tableOrder6 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str7 = tableOrder6.toString();
        boolean boolean8 = unitType0.equals((java.lang.Object) tableOrder6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TableOrder.BY_COLUMN" + "'", str7.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Pie Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap7 = new org.jfree.chart.StrokeMap();
        boolean boolean9 = strokeMap7.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean11 = strokeMap7.equals((java.lang.Object) projectInfo10);
        projectInfo6.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo10);
        java.awt.Image image13 = projectInfo10.getLogo();
        piePlot1.setBackgroundImage(image13);
        float float15 = piePlot1.getForegroundAlpha();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(image13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.clear();
        int int4 = defaultCategoryDataset1.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        try {
            java.lang.Number number8 = defaultCategoryDataset1.getValue(8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot5.setLabelOutlineStroke(stroke8);
        piePlot1.setBaseSectionOutlineStroke(stroke8);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        textTitle7.setPadding((double) (byte) 10, (double) 10L, (double) 100, (double) (-1));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=64,g=64,b=64]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint8 = piePlot4.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement9.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement11.clear();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle13.arrange(graphics2D14);
        org.jfree.chart.block.BlockContainer blockContainer16 = legendTitle13.getItemContainer();
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean19 = color17.equals((java.lang.Object) rectangleAnchor18);
        legendTitle13.setLegendItemGraphicLocation(rectangleAnchor18);
        try {
            jFreeChart1.addSubtitle((int) '4', (org.jfree.chart.title.Title) legendTitle13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(blockContainer16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNull(categoryDataset3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        java.lang.String str20 = textTitle4.getURLText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.lang.Comparable comparable9 = null;
        try {
            double double10 = piePlot1.getExplodePercent(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        java.lang.Object obj26 = jFreeChart6.clone();
        jFreeChart6.setAntiAlias(true);
        boolean boolean29 = jFreeChart6.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle32 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot31.setLabelLinkStyle(pieLabelLinkStyle32);
        java.awt.Paint paint35 = piePlot31.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap37 = new org.jfree.chart.StrokeMap();
        boolean boolean39 = strokeMap37.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo40 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean41 = strokeMap37.equals((java.lang.Object) projectInfo40);
        projectInfo36.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo40);
        java.awt.Image image43 = projectInfo40.getLogo();
        piePlot31.setBackgroundImage(image43);
        float float45 = piePlot31.getForegroundAlpha();
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) float45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 1.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle32);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(projectInfo36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(projectInfo40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(image43);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Stroke stroke12 = jFreeChart6.getBorderStroke();
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) 8);
        defaultCategoryDataset0.clear();
        java.lang.Comparable comparable18 = null;
        try {
            defaultCategoryDataset0.incrementValue((double) (byte) 0, (java.lang.Comparable) "hi!", comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot8.getLegendItems();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        double double16 = rectangleInsets14.calculateTopInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        piePlot8.setLabelPadding(rectangleInsets14);
        boolean boolean19 = piePlot1.equals((java.lang.Object) rectangleInsets14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(pieURLGenerator20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        objectList1.clear();
        java.lang.Object obj3 = objectList1.clone();
        java.lang.Object obj5 = objectList1.get(98);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.calculateTopInset((double) (-1));
        double double10 = rectangleInsets7.getBottom();
        piePlot1.setLabelPadding(rectangleInsets7);
        double double13 = rectangleInsets7.calculateBottomOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        org.jfree.chart.plot.Plot plot3 = piePlot0.getParent();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertNull(chartChangeEventType5);
        org.junit.Assert.assertNull(chartChangeEventType6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.block.BlockFrame blockFrame15 = legendTitle10.getFrame();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendTitle10.arrange(graphics2D16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNotNull(size2D17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray10 = color3.getColorComponents(floatArray9);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        double double15 = piePlot13.getMaximumExplodePercent();
        java.awt.Paint paint16 = piePlot13.getLabelBackgroundPaint();
        java.awt.Stroke stroke17 = piePlot13.getLabelOutlineStroke();
        boolean boolean18 = blockBorder1.equals((java.lang.Object) piePlot13);
        piePlot13.setOutlineVisible(false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset22.clear();
        int int25 = defaultCategoryDataset22.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color21, (org.jfree.data.general.Dataset) defaultCategoryDataset22);
        piePlot13.datasetChanged(datasetChangeEvent26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=64,g=255,b=255]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultKeyedValues2D1.equals(obj8);
        java.lang.Object obj10 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeColumn((-12517377));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -12517377");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation8 = piePlot4.getDirection();
        piePlot1.setDirection(rotation8);
        double double10 = rotation8.getFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (-1));
        java.lang.Comparable comparable11 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 102.0d, comparable11, (java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double23 = rectangleInsets18.extendHeight((double) 64);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 68.0d + "'", double23 == 68.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        boolean boolean5 = piePlot1.isOutlineVisible();
        double double6 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "PieSection: -1, 0(100)", "java.awt.Color[r=64,g=64,b=64]");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(175, attributedString2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(102.0d, 90.0d, (double) (short) 10, 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = defaultDrawingSupplier0.equals((java.lang.Object) rectangleAnchor1);
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        piePlot26.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot26.getLabelGenerator();
        piePlot26.setIgnoreNullValues(true);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot26);
        boolean boolean35 = piePlot26.isSubplot();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color1 = java.awt.Color.lightGray;
        int int2 = color1.getTransparency();
        float[] floatArray8 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray9 = color1.getRGBColorComponents(floatArray8);
        boolean boolean10 = pieLabelLinkStyle0.equals((java.lang.Object) color1);
        int int11 = color1.getTransparency();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean2 = color0.equals((java.lang.Object) rectangleAnchor1);
        float[] floatArray11 = new float[] { 1.0f, '#', (byte) 100, 10L, (-1) };
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 0, (int) (byte) 0, floatArray11);
        float[] floatArray13 = color0.getRGBComponents(floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Font font10 = null;
        try {
            piePlot1.setNoDataMessageFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Comparable comparable1 = null;
        try {
            java.awt.Paint paint2 = paintMap0.getPaint(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart6.getLegend(0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart6.getTitle();
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.removeProgressListener(chartProgressListener9);
        java.lang.Object obj11 = jFreeChart6.clone();
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart6.createBufferedImage(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.lang.Object obj5 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3.getLegendLabelURLGenerator();
        java.lang.Object obj5 = piePlot3.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3.getLegendLabelURLGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart8.removeChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 2);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 2 + "'", obj2.equals(2));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color4 = java.awt.Color.orange;
        objectList2.set((int) 'a', (java.lang.Object) color4);
        java.lang.Object obj7 = objectList2.get((int) '4');
        int int8 = objectList2.size();
        boolean boolean9 = rotation0.equals((java.lang.Object) objectList2);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 98 + "'", int8 == 98);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint16 = piePlot13.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (-1));
        textTitle18.setPadding(rectangleInsets21);
        double double26 = rectangleInsets21.calculateRightInset((double) 192);
        boolean boolean27 = pieSectionEntity8.equals((java.lang.Object) rectangleInsets21);
        double double29 = rectangleInsets21.calculateLeftInset((-1.0d));
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint10 = piePlot6.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("", font17);
        java.lang.Object obj19 = null;
        flowArrangement11.add((org.jfree.chart.block.Block) textTitle18, obj19);
        java.lang.Object obj21 = null;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle18, obj21);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = unitType0.equals((java.lang.Object) 98);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.14d, 0.0d, 4.0d, (double) 10.0f);
        java.lang.String str8 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 10, 35.0d, (double) 3, 90.0d);
        double double15 = rectangleInsets13.calculateLeftOutset((double) 'a');
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 35.0d + "'", double15 == 35.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str1 = verticalAlignment0.toString();
        java.lang.String str2 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        org.jfree.chart.block.BlockFrame blockFrame3 = null;
        try {
            textTitle2.setFrame(blockFrame3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color2 = java.awt.Color.getColor("VerticalAlignment.CENTER", 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        int int2 = pieLabelDistributor1.getItemCount();
        int int3 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean4 = piePlot2.getIgnoreZeroValues();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        java.awt.Shape shape7 = chartEntity6.getArea();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot2.setLegendItemShape(shape7);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape7);
        java.lang.String str17 = chartEntity16.getShapeType();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "RectangleEdge.TOP", "");
        chartEntity16.setArea(shape18);
        boolean boolean23 = standardPieSectionLabelGenerator0.equals((java.lang.Object) shape18);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "poly" + "'", str17.equals("poly"));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("TableOrder.BY_COLUMN", "RectangleAnchor.BOTTOM");
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color6 = java.awt.Color.orange;
        objectList4.set((int) 'a', (java.lang.Object) color6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot9.setLabelLinkStyle(pieLabelLinkStyle10);
        java.awt.Paint paint13 = piePlot9.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot9.setOutlinePaint((java.awt.Paint) color14);
        float[] floatArray24 = new float[] { 1.0f, '#', (byte) 100, 10L, (-1) };
        float[] floatArray25 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 0, (int) (byte) 0, floatArray24);
        float[] floatArray26 = color14.getRGBComponents(floatArray24);
        float[] floatArray27 = color6.getColorComponents(floatArray24);
        float[] floatArray28 = java.awt.Color.RGBtoHSB(0, 10, (-1), floatArray27);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart18.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        projectInfo0.setLicenceName("TableOrder.BY_COLUMN");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        java.lang.String str5 = chartEntity4.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "poly" + "'", str5.equals("poly"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        java.awt.Image image9 = jFreeChart6.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot11.setLabelOutlineStroke(stroke14);
        jFreeChart6.setBorderStroke(stroke14);
        try {
            org.jfree.chart.plot.XYPlot xYPlot17 = jFreeChart6.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot8.getLegendItems();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        double double16 = rectangleInsets14.calculateTopInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        piePlot8.setLabelPadding(rectangleInsets14);
        boolean boolean19 = piePlot1.equals((java.lang.Object) rectangleInsets14);
        double double20 = rectangleInsets14.getBottom();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot1.getLabelLinkStyle();
        java.lang.String str8 = pieLabelLinkStyle7.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str8.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.QUAD_CURVE");
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        int int4 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        try {
            defaultCategoryDataset0.removeRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = projectInfo3.equals((java.lang.Object) 2);
//        java.lang.String str6 = projectInfo3.toString();
//        boolean boolean7 = defaultKeyedValues2D1.equals((java.lang.Object) str6);
//        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
//        try {
//            java.lang.Comparable comparable10 = defaultKeyedValues2D1.getColumnKey((-589829));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -589829");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(list8);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.plot.Plot plot21 = plotChangeEvent20.getPlot();
        jFreeChart6.plotChanged(plotChangeEvent20);
        java.lang.String str23 = plotChangeEvent20.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 'a');
        java.awt.Color color4 = java.awt.Color.RED;
        paintMap0.put((java.lang.Comparable) 0.5f, (java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean4 = piePlot2.getIgnoreZeroValues();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        java.awt.Shape shape7 = chartEntity6.getArea();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot2.setLegendItemShape(shape7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator17);
        java.awt.Stroke stroke19 = piePlot2.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot21.getLegendLabelURLGenerator();
        double double23 = piePlot21.getMaximumExplodePercent();
        java.awt.Paint paint24 = piePlot21.getLabelBackgroundPaint();
        java.awt.Stroke stroke25 = piePlot21.getLabelOutlineStroke();
        piePlot2.setLabelOutlineStroke(stroke25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot28.setLabelLinkStyle(pieLabelLinkStyle29);
        java.awt.Paint paint32 = piePlot28.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement33.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement35.clear();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot28, (org.jfree.chart.block.Arrangement) flowArrangement33, (org.jfree.chart.block.Arrangement) columnArrangement35);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = legendTitle37.arrange(graphics2D38);
        org.jfree.chart.block.BlockContainer blockContainer40 = legendTitle37.getItemContainer();
        boolean boolean41 = blockContainer40.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = blockContainer40.getMargin();
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke25, rectangleInsets42);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(blockContainer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = projectInfo3.equals((java.lang.Object) 2);
//        java.lang.String str6 = projectInfo3.toString();
//        boolean boolean7 = defaultKeyedValues2D1.equals((java.lang.Object) str6);
//        java.util.List list8 = defaultKeyedValues2D1.getColumnKeys();
//        try {
//            java.lang.Comparable comparable10 = defaultKeyedValues2D1.getRowKey((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(list8);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint16 = piePlot13.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (-1));
        textTitle18.setPadding(rectangleInsets21);
        double double26 = rectangleInsets21.calculateRightInset((double) 192);
        boolean boolean27 = pieSectionEntity8.equals((java.lang.Object) rectangleInsets21);
        org.jfree.data.general.PieDataset pieDataset28 = pieSectionEntity8.getDataset();
        pieSectionEntity8.setSectionKey((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(pieDataset28);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.util.List list8 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.lang.Object obj2 = null;
        boolean boolean3 = blockBorder1.equals(obj2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.RenderingHints renderingHints15 = jFreeChart10.getRenderingHints();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            jFreeChart10.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(renderingHints15);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.chart.util.Rotation rotation10 = piePlot1.getDirection();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(rotation10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean8 = color6.equals((java.lang.Object) rectangleAnchor7);
        objectList1.set(192, (java.lang.Object) rectangleAnchor7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        multiplePiePlot0.setLimit((double) ' ');
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint10 = piePlot6.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendTitle15.arrange(graphics2D16);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle15.getItemContainer();
        boolean boolean19 = blockContainer18.isEmpty();
        boolean boolean20 = blockContainer18.isEmpty();
        boolean boolean21 = flowArrangement4.equals((java.lang.Object) boolean20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        piePlot23.setLabelPadding(rectangleInsets26);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle28 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot23.setLabelLinkStyle(pieLabelLinkStyle28);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement30.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement36 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment32, verticalAlignment33, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23, (org.jfree.chart.block.Arrangement) columnArrangement30, (org.jfree.chart.block.Arrangement) flowArrangement36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement4, (org.jfree.chart.block.Arrangement) columnArrangement30);
        org.jfree.chart.block.FlowArrangement flowArrangement39 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement39.clear();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle43 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot42.setLabelLinkStyle(pieLabelLinkStyle43);
        java.awt.Paint paint46 = piePlot42.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement47 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement47.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement49.clear();
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot42, (org.jfree.chart.block.Arrangement) flowArrangement47, (org.jfree.chart.block.Arrangement) columnArrangement49);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.util.Size2D size2D53 = legendTitle51.arrange(graphics2D52);
        org.jfree.chart.block.BlockContainer blockContainer54 = legendTitle51.getItemContainer();
        blockContainer54.clear();
        java.lang.Object obj56 = null;
        flowArrangement39.add((org.jfree.chart.block.Block) blockContainer54, obj56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = null;
        try {
            org.jfree.chart.util.Size2D size2D60 = flowArrangement4.arrange(blockContainer54, graphics2D58, rectangleConstraint59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle28);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(size2D53);
        org.junit.Assert.assertNotNull(blockContainer54);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        paintMap0.put((java.lang.Comparable) (-16777216), (java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray12 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray13 = color6.getColorComponents(floatArray12);
        float[] floatArray14 = color2.getColorComponents(colorSpace5, floatArray13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Paint paint8 = jFreeChart6.getBorderPaint();
        org.jfree.chart.title.Title title9 = null;
        jFreeChart6.removeSubtitle(title9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        piePlot12.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot12.getLabelGenerator();
        piePlot12.setIgnoreNullValues(true);
        java.awt.Color color20 = java.awt.Color.DARK_GRAY;
        piePlot12.setLabelPaint((java.awt.Paint) color20);
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        java.awt.Color color8 = java.awt.Color.gray;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color8);
        piePlot1.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        piePlot3.setSimpleLabels(true);
        int int8 = piePlot3.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot3.getToolTipGenerator();
        java.awt.Stroke stroke10 = piePlot3.getLabelOutlineStroke();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets13);
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean3 = projectInfo1.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library9 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str10 = library9.getInfo();
        boolean boolean11 = standardPieSectionLabelGenerator4.equals((java.lang.Object) library9);
        projectInfo1.addLibrary(library9);
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean15 = projectInfo13.equals((java.lang.Object) 2);
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo1);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.Library[] libraryArray19 = projectInfo1.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(libraryArray19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint2 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getBlue();
        java.lang.Class<?> wildcardClass2 = color0.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator11);
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean15 = projectInfo13.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library21 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str22 = library21.getInfo();
        boolean boolean23 = standardPieSectionLabelGenerator16.equals((java.lang.Object) library21);
        projectInfo13.addLibrary(library21);
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean26 = library21.equals((java.lang.Object) paint25);
        piePlot1.setLabelShadowPaint(paint25);
        double double28 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.08d + "'", double28 == 0.08d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getLegendItemGraphicPadding();
        double double15 = rectangleInsets13.calculateTopOutset((double) 8);
        double double16 = rectangleInsets13.getBottom();
        boolean boolean17 = multiplePiePlot0.equals((java.lang.Object) rectangleInsets13);
        java.lang.Comparable comparable18 = null;
        try {
            multiplePiePlot0.setAggregatedItemsKey(comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor(175);
        boolean boolean7 = piePlot1.equals((java.lang.Object) 175);
        piePlot1.zoom(0.14d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint15 = piePlot11.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement16.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement18.clear();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) columnArrangement18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle20.setVerticalAlignment(verticalAlignment21);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("", font24);
        legendTitle20.setItemFont(font24);
        piePlot1.setLabelFont(font24);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = piePlot1.getLabelPadding();
        double double29 = rectangleInsets28.getLeft();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.clearSubtitles();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle4);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int22 = color21.getTransparency();
        textTitle4.setBackgroundPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getLegendItemGraphicPadding();
        double double15 = rectangleInsets13.calculateTopOutset((double) 8);
        double double16 = rectangleInsets13.getBottom();
        boolean boolean17 = multiplePiePlot0.equals((java.lang.Object) rectangleInsets13);
        org.jfree.chart.util.TableOrder tableOrder18 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str19 = tableOrder18.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder18);
        boolean boolean21 = multiplePiePlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tableOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TableOrder.BY_ROW" + "'", str19.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str6 = rectangleEdge5.toString();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleEdge5);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.lang.Object obj9 = null;
        boolean boolean10 = standardPieSectionLabelGenerator0.equals(obj9);
        java.lang.String str11 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.Comparable comparable13 = null;
        try {
            java.text.AttributedString attributedString14 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset12, comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        jFreeChart10.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        piePlot26.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot26.getLabelGenerator();
        piePlot26.setIgnoreNullValues(true);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot26);
        piePlot1.setLabelLinkMargin(0.4d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get(100);
        objectList1.clear();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean18 = objectList1.equals((java.lang.Object) pieSectionEntity17);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle22 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot21.setLabelLinkStyle(pieLabelLinkStyle22);
        java.awt.Paint paint24 = piePlot21.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot21);
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart25.getTitle();
        textTitle26.setWidth((double) 1L);
        int int29 = objectList1.indexOf((java.lang.Object) textTitle26);
        int int30 = objectList1.size();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getColumnKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        java.lang.String str3 = chartEntity1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartEntity: tooltip = null" + "'", str3.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        boolean boolean3 = color0.equals((java.lang.Object) list2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("UnitType.RELATIVE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name UnitType.RELATIVE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get(100);
        objectList1.clear();
        java.lang.Object obj8 = objectList1.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            java.lang.Number number5 = defaultCategoryDataset0.getValue(98, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 98, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "poly", "1.2.0-pre", "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        double double5 = rectangleInsets4.getRight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getInsets();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("", font7);
        java.lang.String str9 = textTitle8.getText();
        java.awt.Paint paint10 = textTitle8.getPaint();
        piePlot1.setLabelOutlinePaint(paint10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = defaultDrawingSupplier0.equals((java.lang.Object) rectangleAnchor1);
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint5 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        int int8 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot1.axisChanged(axisChangeEvent9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        double double5 = piePlot2.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot2.getToolTipGenerator();
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot2.setOutlinePaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color10 = java.awt.Color.lightGray;
        int int11 = color10.getTransparency();
        float[] floatArray17 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getTransparency();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int22 = color21.getTransparency();
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint7, color9, color10, color19, color21 };
        java.awt.Paint[] paintArray24 = null;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray23, paintArray24, strokeArray25, strokeArray26, shapeArray27);
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextFillPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean32 = defaultDrawingSupplier30.equals((java.lang.Object) rectangleAnchor31);
        java.awt.Paint paint33 = defaultDrawingSupplier30.getNextFillPaint();
        boolean boolean34 = defaultDrawingSupplier28.equals((java.lang.Object) paint33);
        java.awt.Shape shape35 = defaultDrawingSupplier28.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double6 = rectangleInsets2.calculateRightOutset(1.0E-5d);
        double double8 = rectangleInsets2.calculateRightInset(2.0d);
        double double9 = rectangleInsets2.getBottom();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart6.getLegend();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        legendTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.awt.Color color13 = java.awt.Color.pink;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot15.setLabelOutlineStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke18, rectangleInsets20);
        double double23 = rectangleInsets20.calculateBottomInset((double) 0.5f);
        legendTitle9.setItemLabelPadding(rectangleInsets20);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(legendTitle9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        boolean boolean15 = blockContainer13.isEmpty();
        blockContainer13.clear();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        piePlot5.setLabelPadding(rectangleInsets8);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = piePlot1.getDrawingSupplier();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint18 = piePlot14.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement19.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement21.clear();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) columnArrangement21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle23.setVerticalAlignment(verticalAlignment24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = null;
        org.jfree.chart.util.Size2D size2D28 = legendTitle23.arrange(graphics2D26, rectangleConstraint27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) (-589829), 0.0d, rectangleAnchor31);
        try {
            piePlot1.drawOutline(graphics2D12, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        pieSectionEntity8.setSectionKey((java.lang.Comparable) (byte) 0);
        java.awt.Shape shape13 = pieSectionEntity8.getArea();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.lang.String str2 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) -1, (java.lang.Comparable) 0, (java.lang.Comparable) (-1.0d));
        try {
            java.lang.Number number14 = defaultKeyedValues2D1.getValue((int) (byte) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        java.awt.Paint paint9 = textTitle7.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle7.setVerticalAlignment(verticalAlignment10);
        textTitle7.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        defaultCategoryDataset0.setValue((double) 0.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 0.0d);
        try {
            java.lang.Number number19 = defaultCategoryDataset0.getValue((java.lang.Comparable) "hi!", (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: hi!");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getBottom();
        double double5 = rectangleInsets2.calculateRightInset((double) (-16777216));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint11 = piePlot8.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot8);
        java.awt.Paint paint13 = jFreeChart12.getBackgroundPaint();
        int int14 = jFreeChart12.getSubtitleCount();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart12.createBufferedImage((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot2.getLegendLabelURLGenerator();
        java.lang.Object obj4 = piePlot2.clone();
        java.awt.Paint paint5 = piePlot2.getLabelOutlinePaint();
        boolean boolean6 = horizontalAlignment0.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        float float18 = piePlot15.getBackgroundAlpha();
        java.awt.Paint paint19 = piePlot15.getLabelShadowPaint();
        boolean boolean20 = blockBorder13.equals((java.lang.Object) paint19);
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        java.lang.Object obj6 = null;
        boolean boolean7 = defaultCategoryDataset0.equals(obj6);
        defaultCategoryDataset0.clear();
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = projectInfo3.equals((java.lang.Object) 2);
//        java.lang.String str6 = projectInfo3.toString();
//        boolean boolean7 = defaultKeyedValues2D1.equals((java.lang.Object) str6);
//        try {
//            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\n" + "'", str6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().\n{0} LICENCE TERMS:\n"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Paint paint8 = jFreeChart6.getBorderPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray10 = color3.getColorComponents(floatArray9);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        double double15 = piePlot13.getMaximumExplodePercent();
        java.awt.Paint paint16 = piePlot13.getLabelBackgroundPaint();
        java.awt.Stroke stroke17 = piePlot13.getLabelOutlineStroke();
        boolean boolean18 = blockBorder1.equals((java.lang.Object) piePlot13);
        double double19 = piePlot13.getLabelLinkMargin();
        java.awt.Paint paint21 = piePlot13.getSectionPaint((java.lang.Comparable) "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.025d + "'", double19 == 0.025d);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart18.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        projectInfo0.setLicenceText("org.jfree.chart.event.ChartChangeEvent[source=100]");
        java.util.List list30 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateRightOutset(0.0d);
        double double6 = rectangleInsets2.calculateLeftInset((-2.0d));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint16 = piePlot13.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (-1));
        textTitle18.setPadding(rectangleInsets21);
        double double26 = rectangleInsets21.calculateRightInset((double) 192);
        boolean boolean27 = pieSectionEntity8.equals((java.lang.Object) rectangleInsets21);
        double double29 = rectangleInsets21.extendWidth((double) '#');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 37.0d + "'", double29 == 37.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        java.awt.Color color8 = java.awt.Color.gray;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot1.setDataset(pieDataset10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        pieSectionEntity8.setSectionKey((java.lang.Comparable) (byte) 0);
        pieSectionEntity8.setToolTipText("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = unitType0.equals((java.lang.Object) 98);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.14d, 0.0d, 4.0d, (double) 10.0f);
        double double8 = rectangleInsets7.getTop();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = null;
        try {
            textTitle4.setHorizontalAlignment(horizontalAlignment20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation25 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot1.setDirection(rotation25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertNotNull(drawingSupplier27);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        java.awt.Shape shape11 = pieSectionEntity8.getArea();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.chart.ui.Contributor contributor12 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        boolean boolean13 = pieSectionEntity9.equals((java.lang.Object) "");
        java.lang.String str14 = pieSectionEntity9.getURLText();
        java.lang.Comparable comparable15 = pieSectionEntity9.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (byte) 100 + "'", comparable15.equals((byte) 100));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        try {
            defaultCategoryDataset0.removeRow(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-12517377), (double) 100L, (double) ' ', 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        plot11.markerChanged(markerChangeEvent12);
        float float14 = plot11.getForegroundAlpha();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setIgnoreNullValues(false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color9 = java.awt.Color.lightGray;
        int int10 = color9.getTransparency();
        float[] floatArray16 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray17 = color9.getRGBColorComponents(floatArray16);
        boolean boolean18 = pieLabelLinkStyle8.equals((java.lang.Object) color9);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle8);
        java.lang.Object obj20 = null;
        boolean boolean21 = pieLabelLinkStyle8.equals(obj20);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]", stroke8);
        java.lang.Object obj10 = piePlot1.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        double double10 = textTitle9.getContentYOffset();
        java.lang.String str11 = textTitle9.getText();
        java.lang.Object obj12 = null;
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle9, obj12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str11.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset0.getGroup();
        java.lang.Object obj4 = datasetGroup3.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        int int2 = pieLabelDistributor1.getItemCount();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((double) '#', (double) '4');
        java.lang.String str8 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        abstractPieLabelDistributor8.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord10 = null;
        try {
            abstractPieLabelDistributor8.addPieLabelRecord(pieLabelRecord10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        piePlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        piePlot1.setBackgroundAlpha(1.0f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        java.awt.Shape shape6 = null;
        try {
            piePlot1.setLegendItemShape(shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setSimpleLabels(true);
        java.awt.Stroke stroke21 = piePlot16.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        piePlot23.setLabelPadding(rectangleInsets26);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke21, rectangleInsets26);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = lineBorder28.getInsets();
        double double31 = rectangleInsets29.trimWidth((double) 0L);
        double double32 = rectangleInsets29.getRight();
        piePlot1.setInsets(rectangleInsets29, true);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle37 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot36.setLabelLinkStyle(pieLabelLinkStyle37);
        java.awt.Paint paint39 = piePlot36.getLabelLinkPaint();
        java.awt.Stroke stroke40 = piePlot36.getLabelLinkStroke();
        boolean boolean41 = rectangleInsets29.equals((java.lang.Object) piePlot36);
        double double43 = rectangleInsets29.calculateLeftInset((double) 10L);
        double double45 = rectangleInsets29.calculateTopOutset(100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-2.0d) + "'", double31 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        java.lang.String str9 = textTitle7.getToolTipText();
        java.lang.Object obj10 = null;
        boolean boolean11 = textTitle7.equals(obj10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setLabelLinksVisible(false);
        piePlot9.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot15.setLabelLinkStyle(pieLabelLinkStyle16);
        java.awt.Paint paint19 = piePlot15.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement20.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement22.clear();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15, (org.jfree.chart.block.Arrangement) flowArrangement20, (org.jfree.chart.block.Arrangement) columnArrangement22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendTitle24.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getLegendItemGraphicPadding();
        double double28 = rectangleInsets26.calculateTopOutset((double) 8);
        piePlot9.setSimpleLabelOffset(rectangleInsets26);
        double double30 = rectangleInsets26.getLeft();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset31.clear();
        int int34 = defaultCategoryDataset31.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        piePlot36.addChangeListener(plotChangeListener37);
        piePlot36.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator41 = piePlot36.getLabelGenerator();
        boolean boolean42 = defaultCategoryDataset31.equals((java.lang.Object) pieSectionLabelGenerator41);
        java.util.List list43 = defaultCategoryDataset31.getRowKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double30, (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        piePlot1.datasetChanged(datasetChangeEvent44);
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape46);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape46, "poly");
        piePlot1.setLegendItemShape(shape46);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        double double5 = piePlot2.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot2.getToolTipGenerator();
        double double7 = piePlot2.getMaximumExplodePercent();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        defaultCategoryDataset0.setValue(0.08d, (java.lang.Comparable) 90.0d, (java.lang.Comparable) (-246));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str6 = rectangleEdge5.toString();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleEdge5);
        org.jfree.chart.util.ObjectList objectList9 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color11 = java.awt.Color.orange;
        objectList9.set((int) 'a', (java.lang.Object) color11);
        boolean boolean13 = standardPieSectionLabelGenerator0.equals((java.lang.Object) color11);
        java.text.AttributedString attributedString15 = standardPieSectionLabelGenerator0.getAttributedLabel((int) 'a');
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(attributedString15);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.awt.Paint paint12 = piePlot1.getNoDataMessagePaint();
        try {
            piePlot1.setBackgroundImageAlpha((float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj4 = defaultCategoryDataset3.clone();
        java.lang.Object obj5 = defaultCategoryDataset3.clone();
        multiplePiePlot2.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint6 = piePlot3.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart7.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        java.awt.image.BufferedImage bufferedImage15 = jFreeChart7.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke16);
        multiplePiePlot0.setPieChart(jFreeChart7);
        org.jfree.chart.util.TableOrder tableOrder19 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(bufferedImage15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        java.lang.String str10 = pieSectionEntity9.getShapeType();
        java.lang.Comparable comparable11 = pieSectionEntity9.getSectionKey();
        int int12 = pieSectionEntity9.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 100 + "'", comparable11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        java.lang.String str5 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset3, (java.lang.Comparable) '#');
        java.lang.Object obj6 = standardPieSectionLabelGenerator2.clone();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        double double11 = piePlot9.getMaximumExplodePercent();
        java.awt.Paint paint12 = piePlot9.getLabelBackgroundPaint();
        java.awt.Stroke stroke13 = piePlot9.getLabelOutlineStroke();
        boolean boolean14 = standardPieSectionLabelGenerator2.equals((java.lang.Object) stroke13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset17 = multiplePiePlot15.getDataset();
        boolean boolean18 = standardPieSectionLabelGenerator2.equals((java.lang.Object) categoryDataset17);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setSimpleLabels(true);
        int int20 = piePlot15.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = piePlot15.getToolTipGenerator();
        double double22 = piePlot15.getInteriorGap();
        boolean boolean23 = legendTitle10.equals((java.lang.Object) double22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = lineBorder25.getInsets();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot29.setLabelLinkStyle(pieLabelLinkStyle30);
        java.awt.Paint paint33 = piePlot29.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement34.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement36.clear();
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot29, (org.jfree.chart.block.Arrangement) flowArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle38.setVerticalAlignment(verticalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = null;
        org.jfree.chart.util.Size2D size2D43 = legendTitle38.arrange(graphics2D41, rectangleConstraint42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, (double) (-589829), 0.0d, rectangleAnchor46);
        lineBorder25.draw(graphics2D27, rectangle2D47);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean51 = defaultDrawingSupplier49.equals((java.lang.Object) rectangleAnchor50);
        java.awt.Paint paint52 = defaultDrawingSupplier49.getNextFillPaint();
        try {
            java.lang.Object obj53 = legendTitle10.draw(graphics2D24, rectangle2D47, (java.lang.Object) paint52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.08d + "'", double22 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        java.lang.Object obj5 = chartEntity4.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double6 = rectangleInsets2.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("", font14);
        legendTitle10.setItemFont(font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle10.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        java.lang.String str20 = titleChangeEvent19.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }
}

