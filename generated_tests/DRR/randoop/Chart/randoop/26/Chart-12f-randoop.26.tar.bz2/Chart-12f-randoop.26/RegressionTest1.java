import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.chart.ui.Contributor contributor12 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        boolean boolean13 = pieSectionEntity9.equals((java.lang.Object) "");
        java.lang.String str14 = pieSectionEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VerticalAlignment.CENTER" + "'", str14.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo19 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        org.jfree.chart.ui.Library[] libraryArray20 = basicProjectInfo19.getLibraries();
        boolean boolean21 = color12.equals((java.lang.Object) basicProjectInfo19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(libraryArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Rotation.CLOCKWISE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("", font14);
        legendTitle10.setItemFont(font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle10.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        java.awt.Font font20 = null;
        try {
            legendTitle10.setItemFont(font20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        float float6 = piePlot3.getBackgroundAlpha();
        java.awt.Paint paint7 = piePlot3.getLabelShadowPaint();
        boolean boolean8 = blockBorder1.equals((java.lang.Object) paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        double double5 = piePlot2.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot2.getToolTipGenerator();
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot2.setOutlinePaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color10 = java.awt.Color.lightGray;
        int int11 = color10.getTransparency();
        float[] floatArray17 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getTransparency();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int22 = color21.getTransparency();
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint7, color9, color10, color19, color21 };
        java.awt.Paint[] paintArray24 = null;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray23, paintArray24, strokeArray25, strokeArray26, shapeArray27);
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextFillPaint();
        try {
            java.awt.Stroke stroke30 = defaultDrawingSupplier28.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        piePlot1.zoom(100.0d);
        piePlot1.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        java.awt.Font font4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint10 = piePlot6.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement13);
        org.jfree.chart.plot.Plot plot16 = piePlot6.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot6.setLegendLabelURLGenerator(pieURLGenerator17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        piePlot21.addChangeListener(plotChangeListener22);
        piePlot21.setSimpleLabels(true);
        java.awt.Stroke stroke26 = piePlot21.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        piePlot28.setLabelPadding(rectangleInsets31);
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color19, stroke26, rectangleInsets31);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = lineBorder33.getInsets();
        double double36 = rectangleInsets34.trimWidth((double) 0L);
        double double37 = rectangleInsets34.getRight();
        piePlot6.setInsets(rectangleInsets34, true);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("java.awt.Color[r=64,g=64,b=64]", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        boolean boolean42 = tableOrder2.equals((java.lang.Object) "java.awt.Color[r=64,g=64,b=64]");
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-2.0d) + "'", double36 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        jFreeChart6.clearSubtitles();
        org.jfree.chart.plot.Plot plot9 = jFreeChart6.getPlot();
        plot9.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        java.lang.Object obj26 = jFreeChart6.clone();
        jFreeChart6.setAntiAlias(true);
        boolean boolean29 = jFreeChart6.getAntiAlias();
        jFreeChart6.clearSubtitles();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        jFreeChart1.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        java.awt.Paint paint15 = piePlot1.getBackgroundPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset18.clear();
        int int21 = defaultCategoryDataset18.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color17, (org.jfree.data.general.Dataset) defaultCategoryDataset18);
        piePlot1.datasetChanged(datasetChangeEvent22);
        java.lang.Object obj24 = piePlot1.clone();
        java.lang.String str25 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = titleChangeEvent14.getType();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot13.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = blockBorder19.getInsets();
        piePlot17.setLabelPadding(rectangleInsets20);
        piePlot13.setInsets(rectangleInsets20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = piePlot13.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = piePlot13.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = piePlot13.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = lineBorder26.getInsets();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle31 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot30.setLabelLinkStyle(pieLabelLinkStyle31);
        java.awt.Paint paint34 = piePlot30.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement35 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement35.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement37 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement37.clear();
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot30, (org.jfree.chart.block.Arrangement) flowArrangement35, (org.jfree.chart.block.Arrangement) columnArrangement37);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle39.setVerticalAlignment(verticalAlignment40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = null;
        org.jfree.chart.util.Size2D size2D44 = legendTitle39.arrange(graphics2D42, rectangleConstraint43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) (-589829), 0.0d, rectangleAnchor47);
        lineBorder26.draw(graphics2D28, rectangle2D48);
        rectangleInsets25.trim(rectangle2D48);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D48, "");
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets11.createInsetRectangle(rectangle2D48);
        try {
            piePlot1.drawOutline(graphics2D6, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle31);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        basicProjectInfo5.setCopyright("java.awt.Color[r=64,g=255,b=255]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        basicProjectInfo13.addOptionalLibrary("org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("UnitType.ABSOLUTE", "VerticalAlignment.CENTER", "UnitType.ABSOLUTE", "java.awt.Color[r=64,g=255,b=255]");
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        int int4 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        textTitle7.setWidth((double) 1L);
        java.awt.Color color10 = java.awt.Color.white;
        textTitle7.setBackgroundPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot5.setLabelLinkStyle(pieLabelLinkStyle6);
        java.awt.Paint paint8 = piePlot5.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation9 = piePlot5.getDirection();
        piePlot2.setDirection(rotation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.QUAD_CURVE", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart11.setBorderVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 10.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot1.setDataset(pieDataset9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 10.0d);
        piePlot1.setCircular(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        java.awt.Paint paint9 = textTitle7.getPaint();
        java.lang.String str10 = textTitle7.getText();
        boolean boolean11 = textTitle7.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str10.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-16711936));
        pieLabelDistributor1.distributeLabels(4.0d, (double) (byte) 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getParent();
        double double7 = piePlot1.getLabelLinkMargin();
        piePlot1.setIgnoreNullValues(true);
        java.awt.Color color10 = java.awt.Color.orange;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color10);
        java.lang.String str12 = color10.toString();
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str12.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke4);
        double double6 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            piePlot1.setInsets(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint10 = piePlot6.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement13.clear();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6, (org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle15.setVerticalAlignment(verticalAlignment16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = null;
        org.jfree.chart.util.Size2D size2D20 = legendTitle15.arrange(graphics2D18, rectangleConstraint19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) (-589829), 0.0d, rectangleAnchor23);
        try {
            piePlot1.drawBackground(graphics2D4, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke4 = null;
        strokeMap0.put((java.lang.Comparable) 0.0f, stroke4);
        try {
            boolean boolean7 = strokeMap0.containsKey((java.lang.Comparable) "ChartChangeEventType.GENERAL");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double22 = rectangleInsets18.getLeft();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset23.clear();
        int int26 = defaultCategoryDataset23.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        piePlot28.addChangeListener(plotChangeListener29);
        piePlot28.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator33 = piePlot28.getLabelGenerator();
        boolean boolean34 = defaultCategoryDataset23.equals((java.lang.Object) pieSectionLabelGenerator33);
        java.util.List list35 = defaultCategoryDataset23.getRowKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double22, (org.jfree.data.general.Dataset) defaultCategoryDataset23);
        defaultCategoryDataset23.setValue((java.lang.Number) (-246), (java.lang.Comparable) (-1), (java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray10 = color3.getColorComponents(floatArray9);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        double double15 = piePlot13.getMaximumExplodePercent();
        java.awt.Paint paint16 = piePlot13.getLabelBackgroundPaint();
        java.awt.Stroke stroke17 = piePlot13.getLabelOutlineStroke();
        boolean boolean18 = blockBorder1.equals((java.lang.Object) piePlot13);
        double double19 = piePlot13.getLabelLinkMargin();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        piePlot13.setDataset(pieDataset20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.025d + "'", double19 == 0.025d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultKeyedValues2D1.equals(obj8);
        java.util.List list10 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.addValue((java.lang.Number) 10.0f, (java.lang.Comparable) 100L, (java.lang.Comparable) "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        java.lang.String str8 = piePlot1.getPlotType();
        java.awt.Paint paint10 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 255);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        piePlot13.setLabelPadding(rectangleInsets16);
        piePlot9.setInsets(rectangleInsets16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot9.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier19);
        piePlot1.setShadowYOffset((double) (short) 1);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendTitle10.setLegendItemGraphicPadding(rectangleInsets15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = piePlot24.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot24.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        piePlot28.setLabelPadding(rectangleInsets31);
        piePlot24.setInsets(rectangleInsets31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = piePlot24.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle35 = piePlot24.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = piePlot24.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = lineBorder37.getInsets();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle42 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot41.setLabelLinkStyle(pieLabelLinkStyle42);
        java.awt.Paint paint45 = piePlot41.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement46.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement48 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement48.clear();
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot41, (org.jfree.chart.block.Arrangement) flowArrangement46, (org.jfree.chart.block.Arrangement) columnArrangement48);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle50.setVerticalAlignment(verticalAlignment51);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = null;
        org.jfree.chart.util.Size2D size2D55 = legendTitle50.arrange(graphics2D53, rectangleConstraint54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, (double) (-589829), 0.0d, rectangleAnchor58);
        lineBorder37.draw(graphics2D39, rectangle2D59);
        rectangleInsets36.trim(rectangle2D59);
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D59, "");
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets22.createInsetRectangle(rectangle2D59);
        org.jfree.data.general.PieDataset pieDataset65 = null;
        org.jfree.chart.plot.PiePlot piePlot66 = new org.jfree.chart.plot.PiePlot(pieDataset65);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle67 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot66.setLabelLinkStyle(pieLabelLinkStyle67);
        java.awt.Paint paint70 = piePlot66.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement71 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement71.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement73 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement73.clear();
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot66, (org.jfree.chart.block.Arrangement) flowArrangement71, (org.jfree.chart.block.Arrangement) columnArrangement73);
        legendTitle75.setHeight((double) '#');
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = null;
        org.jfree.chart.util.Size2D size2D80 = legendTitle75.arrange(graphics2D78, rectangleConstraint79);
        try {
            java.lang.Object obj81 = legendTitle10.draw(graphics2D17, rectangle2D64, (java.lang.Object) rectangleConstraint79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(pieURLGenerator25);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle42);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle67);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertNotNull(size2D80);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        piePlot13.setLabelPadding(rectangleInsets16);
        piePlot9.setInsets(rectangleInsets16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot9.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier19);
        piePlot1.setSimpleLabels(false);
        java.awt.Paint paint23 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double5 = rectangleInsets2.getBottom();
        double double7 = rectangleInsets2.calculateLeftInset((double) 64);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: a");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot1.getLabelBackgroundPaint();
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double7 = legendTitle6.getContentXOffset();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = piePlot16.getLegendItems();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (-1));
        double double25 = rectangleInsets22.getBottom();
        piePlot16.setLabelPadding(rectangleInsets22);
        blockContainer13.setPadding(rectangleInsets22);
        double double29 = rectangleInsets22.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 90.0d, stroke26);
        boolean boolean28 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str13 = basicProjectInfo12.getVersion();
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) basicProjectInfo12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str6 = chartChangeEventType5.toString();
        chartChangeEvent3.setType(chartChangeEventType5);
        java.lang.String str8 = chartChangeEventType5.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str6.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str8.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultKeyedValues2D1.equals(obj8);
        java.lang.Object obj10 = defaultKeyedValues2D1.clone();
        int int11 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor(175);
        boolean boolean7 = piePlot1.equals((java.lang.Object) 175);
        piePlot1.setMinimumArcAngleToDraw((double) 10.0f);
        piePlot1.zoom((double) 0L);
        piePlot1.setBackgroundImageAlignment(64);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) -1);
        double double3 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double6 = rectangleInsets2.calculateRightOutset(1.0E-5d);
        double double8 = rectangleInsets2.calculateRightInset(2.0d);
        double double10 = rectangleInsets2.calculateRightOutset(2.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        java.awt.Stroke stroke8 = jFreeChart6.getBorderStroke();
        boolean boolean9 = jFreeChart6.isNotify();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double23 = rectangleInsets18.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(98, (int) (byte) 1, chartRenderingInfo16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot20.setLabelLinkStyle(pieLabelLinkStyle21);
        java.awt.Paint paint24 = piePlot20.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement25.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement27.clear();
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20, (org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle29.setVerticalAlignment(verticalAlignment30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = null;
        org.jfree.chart.util.Size2D size2D34 = legendTitle29.arrange(graphics2D32, rectangleConstraint33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (-589829), 0.0d, rectangleAnchor37);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            jFreeChart10.draw(graphics2D18, rectangle2D38, point2D39, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        int int15 = color13.getRed();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 128 + "'", int15 == 128);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart18.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        projectInfo0.setLicenceText("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.jfree.chart.ui.Library[] libraryArray30 = projectInfo0.getLibraries();
        projectInfo0.setVersion("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNotNull(libraryArray30);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleInsets7);
        java.lang.Object obj9 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = piePlot16.getLegendItems();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (-1));
        double double25 = rectangleInsets22.getBottom();
        piePlot16.setLabelPadding(rectangleInsets22);
        blockContainer13.setPadding(rectangleInsets22);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator36 = piePlot35.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = piePlot35.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = blockBorder41.getInsets();
        piePlot39.setLabelPadding(rectangleInsets42);
        piePlot35.setInsets(rectangleInsets42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = piePlot35.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle46 = piePlot35.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = piePlot35.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = lineBorder48.getInsets();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle53 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot52.setLabelLinkStyle(pieLabelLinkStyle53);
        java.awt.Paint paint56 = piePlot52.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement57 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement57.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement59 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement59.clear();
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot52, (org.jfree.chart.block.Arrangement) flowArrangement57, (org.jfree.chart.block.Arrangement) columnArrangement59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle61.setVerticalAlignment(verticalAlignment62);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = null;
        org.jfree.chart.util.Size2D size2D66 = legendTitle61.arrange(graphics2D64, rectangleConstraint65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D70 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D66, (double) (-589829), 0.0d, rectangleAnchor69);
        lineBorder48.draw(graphics2D50, rectangle2D70);
        rectangleInsets47.trim(rectangle2D70);
        org.jfree.chart.entity.ChartEntity chartEntity74 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "");
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets33.createInsetRectangle(rectangle2D70);
        try {
            blockContainer13.draw(graphics2D28, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNull(pieURLGenerator36);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle53);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(size2D66);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            piePlot1.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        java.awt.Image image7 = projectInfo4.getLogo();
        projectInfo4.setInfo("");
        projectInfo4.setLicenceText("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(image7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart18.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        projectInfo0.addOptionalLibrary("{0}");
        org.jfree.chart.ui.Library[] libraryArray30 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNotNull(libraryArray30);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot7 = piePlot2.getParent();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot9.getURLGenerator();
        piePlot9.setCircular(true);
        java.awt.Font font22 = piePlot9.getNoDataMessageFont();
        piePlot2.setLabelFont(font22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset26 = multiplePiePlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font22, (org.jfree.chart.plot.Plot) multiplePiePlot24, true);
        org.jfree.data.category.CategoryDataset categoryDataset29 = multiplePiePlot24.getDataset();
        float float30 = multiplePiePlot24.getBackgroundAlpha();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot7 = piePlot2.getParent();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot9.getURLGenerator();
        piePlot9.setCircular(true);
        java.awt.Font font22 = piePlot9.getNoDataMessageFont();
        piePlot2.setLabelFont(font22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset26 = multiplePiePlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font22, (org.jfree.chart.plot.Plot) multiplePiePlot24, true);
        multiplePiePlot24.setOutlineVisible(false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNull(categoryDataset26);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot16.setLabelLinkStyle(pieLabelLinkStyle21);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement23.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) columnArrangement23, (org.jfree.chart.block.Arrangement) flowArrangement29);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement23);
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        java.awt.Shape shape34 = chartEntity33.getArea();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity41 = new org.jfree.chart.entity.PieSectionEntity(shape34, pieDataset35, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.chart.ui.Contributor contributor44 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        boolean boolean45 = pieSectionEntity41.equals((java.lang.Object) "");
        boolean boolean46 = columnArrangement23.equals((java.lang.Object) pieSectionEntity41);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart6.getLegend();
        java.awt.Paint paint15 = null;
        jFreeChart6.setBorderPaint(paint15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(legendTitle14);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo4.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        java.awt.Paint paint9 = textTitle7.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle7.setVerticalAlignment(verticalAlignment10);
        textTitle7.setNotify(false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.Object obj8 = textTitle7.clone();
        java.awt.Paint paint9 = textTitle7.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle7.setVerticalAlignment(verticalAlignment10);
        java.awt.Paint paint12 = null;
        try {
            textTitle7.setPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double22 = rectangleInsets18.getRight();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = java.awt.Color.pink;
        int int9 = color8.getBlue();
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color8.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart6.getTitle();
        java.lang.String str18 = textTitle17.getToolTipText();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 175 + "'", int9 == 175);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        double double18 = piePlot1.getExplodePercent((java.lang.Comparable) (-1L));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        boolean boolean3 = piePlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) 8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getParent();
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot10.getLegendLabelURLGenerator();
        java.lang.Object obj12 = piePlot10.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot10.getLegendLabelURLGenerator();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        piePlot10.setSectionOutlinesVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot10.setLabelLinkStroke(stroke18);
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap21 = new org.jfree.chart.StrokeMap();
        boolean boolean23 = strokeMap21.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo24 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean25 = strokeMap21.equals((java.lang.Object) projectInfo24);
        projectInfo20.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo24);
        projectInfo24.setLicenceName("{0}");
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle32 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot31.setLabelLinkStyle(pieLabelLinkStyle32);
        java.awt.Paint paint34 = piePlot31.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot31);
        jFreeChart35.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart35.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo42);
        projectInfo24.setLogo((java.awt.Image) bufferedImage43);
        piePlot10.setBackgroundImage((java.awt.Image) bufferedImage43);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage43);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(projectInfo24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(bufferedImage43);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity8.setDataset(pieDataset11);
        org.jfree.data.general.PieDataset pieDataset13 = pieSectionEntity8.getDataset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(pieDataset13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        java.awt.Paint paint12 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.lang.String str12 = piePlot1.getPlotType();
        piePlot1.setLabelGap(98.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = java.awt.Color.pink;
        int int9 = color8.getBlue();
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color8.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        jFreeChart6.setTitle("UnitType.RELATIVE");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 175 + "'", int9 == 175);
        org.junit.Assert.assertNotNull(paintContext15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint11 = piePlot8.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot8);
        java.awt.Paint paint13 = jFreeChart12.getBackgroundPaint();
        int int14 = jFreeChart12.getSubtitleCount();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = piePlot23.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot23.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockBorder29.getInsets();
        piePlot27.setLabelPadding(rectangleInsets30);
        piePlot23.setInsets(rectangleInsets30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = piePlot23.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = piePlot23.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = piePlot23.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = lineBorder36.getInsets();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle41 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot40.setLabelLinkStyle(pieLabelLinkStyle41);
        java.awt.Paint paint44 = piePlot40.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement45.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement47 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement47.clear();
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot40, (org.jfree.chart.block.Arrangement) flowArrangement45, (org.jfree.chart.block.Arrangement) columnArrangement47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle49.setVerticalAlignment(verticalAlignment50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = null;
        org.jfree.chart.util.Size2D size2D54 = legendTitle49.arrange(graphics2D52, rectangleConstraint53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D54, (double) (-589829), 0.0d, rectangleAnchor57);
        lineBorder36.draw(graphics2D38, rectangle2D58);
        rectangleInsets35.trim(rectangle2D58);
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D58, "");
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets21.createInsetRectangle(rectangle2D58);
        try {
            jFreeChart12.draw(graphics2D16, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(pieURLGenerator24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle41);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(verticalAlignment50);
        org.junit.Assert.assertNotNull(size2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) 4.0d);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot7.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        piePlot11.setLabelPadding(rectangleInsets14);
        piePlot7.setInsets(rectangleInsets14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = piePlot7.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = piePlot7.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot7.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder20.getInsets();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle25 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot24.setLabelLinkStyle(pieLabelLinkStyle25);
        java.awt.Paint paint28 = piePlot24.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement29.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement31 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement31.clear();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot24, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) columnArrangement31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle33.setVerticalAlignment(verticalAlignment34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = null;
        org.jfree.chart.util.Size2D size2D38 = legendTitle33.arrange(graphics2D36, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) (-589829), 0.0d, rectangleAnchor41);
        lineBorder20.draw(graphics2D22, rectangle2D42);
        rectangleInsets19.trim(rectangle2D42);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        piePlot46.setLabelLinksVisible(false);
        piePlot46.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle54 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot53.setLabelLinkStyle(pieLabelLinkStyle54);
        java.awt.Paint paint56 = piePlot53.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot53);
        java.awt.Paint paint58 = jFreeChart57.getBackgroundPaint();
        int int59 = jFreeChart57.getSubtitleCount();
        piePlot46.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart57);
        jFreeChart57.setTitle("Pie Plot");
        jFreeChart57.clearSubtitles();
        try {
            java.lang.Object obj64 = blockContainer4.draw(graphics2D5, rectangle2D42, (java.lang.Object) jFreeChart57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle25);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        piePlot1.markerChanged(markerChangeEvent6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getBlue();
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray17 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray18 = color11.getColorComponents(floatArray17);
        float[] floatArray19 = color3.getRGBColorComponents(floatArray18);
        float[] floatArray20 = java.awt.Color.RGBtoHSB(128, (-589829), 0, floatArray18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        piePlot1.zoom(10.0d);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot1.setBackgroundPaint((java.awt.Paint) chartColor13);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = piePlot16.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot16.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        piePlot20.setLabelPadding(rectangleInsets23);
        piePlot16.setInsets(rectangleInsets23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = piePlot16.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = piePlot16.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = piePlot16.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = lineBorder29.getInsets();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot33.setLabelLinkStyle(pieLabelLinkStyle34);
        java.awt.Paint paint37 = piePlot33.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement38.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement40.clear();
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot33, (org.jfree.chart.block.Arrangement) flowArrangement38, (org.jfree.chart.block.Arrangement) columnArrangement40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle42.setVerticalAlignment(verticalAlignment43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = null;
        org.jfree.chart.util.Size2D size2D47 = legendTitle42.arrange(graphics2D45, rectangleConstraint46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D51 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, (double) (-589829), 0.0d, rectangleAnchor50);
        lineBorder29.draw(graphics2D31, rectangle2D51);
        rectangleInsets28.trim(rectangle2D51);
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D51, "");
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets14.createInsetRectangle(rectangle2D51);
        try {
            jFreeChart6.draw(graphics2D9, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str9 = library8.getInfo();
        boolean boolean10 = standardPieSectionLabelGenerator3.equals((java.lang.Object) library8);
        projectInfo0.addLibrary(library8);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart18.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        projectInfo0.setInfo("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot11.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        piePlot15.setLabelPadding(rectangleInsets18);
        piePlot11.setInsets(rectangleInsets18);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = piePlot11.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle22 = piePlot11.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot11.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = lineBorder24.getInsets();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot28.setLabelLinkStyle(pieLabelLinkStyle29);
        java.awt.Paint paint32 = piePlot28.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement33.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement35.clear();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot28, (org.jfree.chart.block.Arrangement) flowArrangement33, (org.jfree.chart.block.Arrangement) columnArrangement35);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle37.setVerticalAlignment(verticalAlignment38);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        org.jfree.chart.util.Size2D size2D42 = legendTitle37.arrange(graphics2D40, rectangleConstraint41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) (-589829), 0.0d, rectangleAnchor45);
        lineBorder24.draw(graphics2D26, rectangle2D46);
        rectangleInsets23.trim(rectangle2D46);
        try {
            piePlot1.drawOutline(graphics2D9, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get((int) '4');
        int int7 = objectList1.size();
        java.lang.Object obj8 = null;
        boolean boolean9 = objectList1.equals(obj8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 98 + "'", int7 == 98);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Font font5 = piePlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        plot11.markerChanged(markerChangeEvent12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        plot11.markerChanged(markerChangeEvent14);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke4 = null;
        strokeMap0.put((java.lang.Comparable) 0.0f, stroke4);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor(175);
        int int8 = pieLabelDistributor7.getItemCount();
        int int9 = pieLabelDistributor7.getItemCount();
        pieLabelDistributor7.sort();
        boolean boolean11 = strokeMap0.equals((java.lang.Object) pieLabelDistributor7);
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        double double28 = piePlot1.getExplodePercent((java.lang.Comparable) (short) 0);
        piePlot1.setIgnoreZeroValues(true);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle31 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle31);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        blockContainer13.clear();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer13.getArrangement();
        java.util.List list18 = blockContainer13.getBlocks();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = blockContainer13.arrange(graphics2D19, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(arrangement17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 98, 64, (java.lang.Comparable) 1L, "org.jfree.chart.event.ChartChangeEvent[source=100]", "java.awt.Color[r=64,g=64,b=64]");
        int int12 = pieSectionEntity11.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 98 + "'", int12 == 98);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("", font14);
        legendTitle10.setItemFont(font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle10.setVerticalAlignment(verticalAlignment17);
        legendTitle10.setPadding(98.0d, (double) (byte) 10, (double) (byte) -1, (double) 175);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = legendTitle16.arrange(graphics2D17);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle16.getItemContainer();
        boolean boolean20 = blockContainer19.isEmpty();
        java.lang.Object obj21 = blockContainer19.clone();
        blockContainer19.clear();
        org.jfree.chart.block.Arrangement arrangement23 = blockContainer19.getArrangement();
        java.util.List list24 = blockContainer19.getBlocks();
        boolean boolean25 = defaultCategoryDataset0.equals((java.lang.Object) blockContainer19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(blockContainer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(arrangement23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        multiplePiePlot0.setLimit((double) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(tableOrder5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot16.setLabelLinkStyle(pieLabelLinkStyle21);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement23.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16, (org.jfree.chart.block.Arrangement) columnArrangement23, (org.jfree.chart.block.Arrangement) flowArrangement29);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement23);
        org.jfree.chart.block.Arrangement arrangement32 = null;
        try {
            blockContainer13.setArrangement(arrangement32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = piePlot16.getLegendItems();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (-1));
        double double25 = rectangleInsets22.getBottom();
        piePlot16.setLabelPadding(rectangleInsets22);
        blockContainer13.setPadding(rectangleInsets22);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = null;
        try {
            org.jfree.chart.util.Size2D size2D30 = blockContainer13.arrange(graphics2D28, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        java.awt.Stroke stroke16 = lineBorder14.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        piePlot1.setStartAngle(0.025d);
        org.jfree.chart.util.Rotation rotation27 = piePlot1.getDirection();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(rotation27);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ChartEntity: tooltip = null", "PieSection: -1, 0(100)", "PieSection: -1, 0(100)", "Multiple Pie Plot");
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
//        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 100);
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean4 = strokeMap0.equals((java.lang.Object) projectInfo3);
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getOptionalLibraries();
//        java.lang.String str6 = projectInfo3.getVersion();
//        java.lang.String str7 = projectInfo3.getName();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(libraryArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str6.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (byte) 10, (double) (byte) 10);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.chart.ui.ProjectInfo projectInfo22 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean23 = flowArrangement20.equals((java.lang.Object) projectInfo22);
        projectInfo22.setLicenceName("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(projectInfo22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setSimpleLabels(true);
        int int20 = piePlot15.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = piePlot15.getToolTipGenerator();
        double double22 = piePlot15.getInteriorGap();
        boolean boolean23 = legendTitle10.equals((java.lang.Object) double22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.block.BlockContainer blockContainer25 = legendTitle10.getItemContainer();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.08d + "'", double22 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(blockContainer25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        piePlot1.setStartAngle(0.025d);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("", font32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font32);
        org.jfree.chart.ui.ProjectInfo projectInfo35 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean37 = projectInfo35.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library43 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str44 = library43.getInfo();
        boolean boolean45 = standardPieSectionLabelGenerator38.equals((java.lang.Object) library43);
        projectInfo35.addLibrary(library43);
        java.awt.Paint paint47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean48 = library43.equals((java.lang.Object) paint47);
        textTitle34.setPaint(paint47);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 4.0d, paint47);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(projectInfo35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color4 = java.awt.Color.blue;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.lang.Object obj6 = piePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        java.lang.Object obj6 = null;
        boolean boolean7 = defaultCategoryDataset0.equals(obj6);
        int int9 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "hi!");
        java.lang.Comparable comparable11 = defaultCategoryDataset0.getRowKey((int) (short) 0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 64 + "'", comparable11.equals(64));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.setBorderVisible(true);
        try {
            org.jfree.chart.title.Title title16 = jFreeChart6.getSubtitle(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getInsets();
        double double6 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = textTitle7.getExpandToFitSpace();
        textTitle7.setToolTipText("{0}");
        java.awt.Font font11 = textTitle7.getFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str13 = rectangleEdge12.toString();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        java.awt.Paint paint16 = defaultDrawingSupplier14.getNextPaint();
        boolean boolean17 = rectangleEdge12.equals((java.lang.Object) paint16);
        textTitle7.setPosition(rectangleEdge12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.TOP" + "'", str13.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.plot.Plot plot21 = plotChangeEvent20.getPlot();
        jFreeChart6.plotChanged(plotChangeEvent20);
        try {
            org.jfree.chart.plot.XYPlot xYPlot23 = jFreeChart6.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.block.Arrangement arrangement16 = blockContainer13.getArrangement();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder18.getInsets();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot22.setLabelLinkStyle(pieLabelLinkStyle23);
        java.awt.Paint paint26 = piePlot22.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement27.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement29.clear();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot22, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle31.setVerticalAlignment(verticalAlignment32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = null;
        org.jfree.chart.util.Size2D size2D36 = legendTitle31.arrange(graphics2D34, rectangleConstraint35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D36, (double) (-589829), 0.0d, rectangleAnchor39);
        lineBorder18.draw(graphics2D20, rectangle2D40);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle46 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot45.setLabelLinkStyle(pieLabelLinkStyle46);
        java.awt.Paint paint49 = piePlot45.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement50.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement52.clear();
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot45, (org.jfree.chart.block.Arrangement) flowArrangement50, (org.jfree.chart.block.Arrangement) columnArrangement52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment55 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle54.setVerticalAlignment(verticalAlignment55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle54.getLegendItemGraphicEdge();
        textTitle43.setPosition(rectangleEdge57);
        textTitle43.setHeight(102.0d);
        try {
            java.lang.Object obj61 = blockContainer13.draw(graphics2D17, rectangle2D40, (java.lang.Object) textTitle43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(arrangement16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle46);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(verticalAlignment55);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        try {
            piePlot1.setInteriorGap(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.awt.Shape[] shapeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) shapeArray2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) "rect");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shapeArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot1.getLabelDistributor();
        boolean boolean7 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setSimpleLabels(true);
        java.awt.Stroke stroke21 = piePlot16.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        piePlot23.setLabelPadding(rectangleInsets26);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke21, rectangleInsets26);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = lineBorder28.getInsets();
        double double31 = rectangleInsets29.trimWidth((double) 0L);
        double double32 = rectangleInsets29.getRight();
        piePlot1.setInsets(rectangleInsets29, true);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle37 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot36.setLabelLinkStyle(pieLabelLinkStyle37);
        java.awt.Paint paint39 = piePlot36.getLabelLinkPaint();
        java.awt.Stroke stroke40 = piePlot36.getLabelLinkStroke();
        boolean boolean41 = rectangleInsets29.equals((java.lang.Object) piePlot36);
        java.lang.Object obj42 = piePlot36.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-2.0d) + "'", double31 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        java.lang.Object obj20 = textTitle4.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color3 = java.awt.Color.orange;
        objectList1.set((int) 'a', (java.lang.Object) color3);
        java.lang.Object obj6 = objectList1.get((int) '4');
        java.lang.Object obj7 = objectList1.clone();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint14 = piePlot11.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart15.getTitle();
        java.lang.String str17 = textTitle16.getToolTipText();
        java.lang.String str18 = textTitle16.getToolTipText();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle16.setPaint((java.awt.Paint) color19);
        java.lang.String str21 = textTitle16.getToolTipText();
        textTitle16.setID("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
        objectList1.set(0, (java.lang.Object) textTitle16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint7 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement10.clear();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = legendTitle12.arrange(graphics2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = legendTitle12.getItemContainer();
        boolean boolean16 = blockContainer15.isEmpty();
        boolean boolean17 = blockContainer15.isEmpty();
        boolean boolean18 = flowArrangement1.equals((java.lang.Object) boolean17);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(blockContainer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup17 = piePlot1.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint[] paintArray19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray19, dataset20);
        piePlot1.datasetChanged(datasetChangeEvent21);
        int int23 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        java.awt.Paint paint15 = piePlot1.getBackgroundPaint();
        java.awt.Paint paint16 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = textTitle7.getExpandToFitSpace();
        java.lang.String str9 = textTitle7.getID();
        java.awt.Paint paint10 = textTitle7.getPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        boolean boolean3 = tableOrder0.equals((java.lang.Object) (-2.0d));
        java.lang.String str4 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getLegendItemGraphicPadding();
        double double15 = rectangleInsets13.calculateTopOutset((double) 8);
        double double16 = rectangleInsets13.getBottom();
        boolean boolean17 = multiplePiePlot0.equals((java.lang.Object) rectangleInsets13);
        org.jfree.chart.util.TableOrder tableOrder18 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str19 = tableOrder18.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder18);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Paint paint23 = defaultDrawingSupplier21.getNextPaint();
        java.awt.Paint paint24 = defaultDrawingSupplier21.getNextOutlinePaint();
        java.awt.Paint paint25 = defaultDrawingSupplier21.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Paint paint27 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tableOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TableOrder.BY_ROW" + "'", str19.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 192, (float) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = java.awt.Color.pink;
        int int9 = color8.getBlue();
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color8.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart6.getTitle();
        java.awt.Image image18 = jFreeChart6.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 175 + "'", int9 == 175);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.lang.Object obj4 = piePlot1.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        java.awt.Stroke stroke8 = piePlot1.getLabelOutlineStroke();
        java.awt.Image image9 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        jFreeChart6.clearSubtitles();
        jFreeChart6.removeLegend();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultKeyedValues2D1.equals(obj8);
        try {
            defaultKeyedValues2D1.removeRow((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777216");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder3 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str4 = tableOrder3.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder3);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke7 = jFreeChart6.getBorderStroke();
        jFreeChart6.setAntiAlias(false);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) 1L, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16646144) + "'", int3 == (-16646144));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Paint paint19 = jFreeChart18.getBackgroundPaint();
        java.awt.Paint paint20 = jFreeChart18.getBorderPaint();
        boolean boolean21 = defaultCategoryDataset0.hasListener((java.util.EventListener) jFreeChart18);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        java.awt.Shape shape24 = chartEntity23.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "java.awt.Color[r=64,g=255,b=255]");
        chartEntity26.setToolTipText("{0}");
        java.lang.String str29 = chartEntity26.getURLText();
        boolean boolean30 = defaultCategoryDataset0.equals((java.lang.Object) str29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        boolean boolean14 = piePlot13.getSectionOutlinesVisible();
        boolean boolean15 = piePlot13.getSectionOutlinesVisible();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot13);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        piePlot19.setSimpleLabels(true);
        java.awt.Stroke stroke24 = piePlot19.getLabelLinkStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 1, stroke24);
        java.awt.Font font26 = null;
        try {
            piePlot13.setNoDataMessageFont(font26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        defaultKeyedValues2D1.addValue((java.lang.Number) 100, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (-246));
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: ");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Color color3 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        float[] floatArray5 = null;
        float[] floatArray6 = color3.getComponents(floatArray5);
        float[] floatArray7 = java.awt.Color.RGBtoHSB((int) (short) -1, (int) (byte) -1, (int) (short) 0, floatArray6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
//        java.lang.String str3 = projectInfo0.toString();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "poly", "poly", "RectangleEdge.TOP");
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo8);
//        java.awt.Image image10 = projectInfo0.getLogo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0} version RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0].\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:PieLabelLinkStyle.STANDARD\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str3.equals("{0} version RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0].\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:PieLabelLinkStyle.STANDARD\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]"));
//        org.junit.Assert.assertNotNull(image10);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = textTitle7.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot17.addChangeListener(plotChangeListener18);
        piePlot17.setSimpleLabels(true);
        int int22 = piePlot17.getBackgroundImageAlignment();
        piePlot17.setCircular(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = piePlot17.getInsets();
        textTitle7.setPadding(rectangleInsets25);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        paintMap0.put((java.lang.Comparable) (-16777216), (java.awt.Paint) color2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot5.setLabelLinkStyle(pieLabelLinkStyle6);
        java.awt.Paint paint9 = piePlot5.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement10.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement12.clear();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot5, (org.jfree.chart.block.Arrangement) flowArrangement10, (org.jfree.chart.block.Arrangement) columnArrangement12);
        org.jfree.chart.plot.Plot plot15 = piePlot5.getRootPlot();
        java.awt.Stroke stroke16 = piePlot5.getLabelOutlineStroke();
        double double17 = piePlot5.getStartAngle();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = piePlot5.getLegendItems();
        boolean boolean19 = paintMap0.equals((java.lang.Object) legendItemCollection18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        int int2 = pieLabelDistributor1.getItemCount();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        pieLabelDistributor1.distributeLabels((double) '#', (double) '4');
        pieLabelDistributor1.sort();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle7.setTextAlignment(horizontalAlignment15);
        java.lang.String str17 = textTitle7.getText();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str17.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color9 = java.awt.Color.lightGray;
        int int10 = color9.getTransparency();
        float[] floatArray16 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray17 = color9.getRGBColorComponents(floatArray16);
        boolean boolean18 = pieLabelLinkStyle8.equals((java.lang.Object) color9);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle8);
        java.lang.String str20 = pieLabelLinkStyle8.toString();
        java.lang.Object obj21 = null;
        boolean boolean22 = pieLabelLinkStyle8.equals(obj21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str20.equals("PieLabelLinkStyle.CUBIC_CURVE"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        java.lang.Object obj10 = pieSectionEntity9.clone();
        java.lang.Comparable comparable11 = pieSectionEntity9.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 100 + "'", comparable11.equals((byte) 100));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray13 = legendTitle10.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        java.awt.Stroke stroke22 = piePlot21.getBaseSectionOutlineStroke();
        boolean boolean23 = piePlot21.getIgnoreZeroValues();
        java.awt.Color color24 = java.awt.Color.blue;
        piePlot21.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (short) 0, (double) (short) 10, (double) 15, (java.awt.Paint) color24);
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(legendItemSourceArray13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        java.awt.Image image9 = jFreeChart6.getBackgroundImage();
        java.awt.Image image10 = jFreeChart6.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        java.lang.Object obj14 = piePlot12.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = piePlot12.getLegendLabelURLGenerator();
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) pieURLGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(pieURLGenerator15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "java.awt.Color[r=255,g=200,b=0]", "TableOrder.BY_COLUMN", "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.lang.String str12 = piePlot1.getPlotType();
        piePlot1.setLabelLinkMargin((double) (byte) 10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle10.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D19 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D19.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D19.removeRow((int) (short) 0);
        java.lang.Object obj26 = null;
        boolean boolean27 = defaultKeyedValues2D19.equals(obj26);
        java.util.List list28 = defaultKeyedValues2D19.getColumnKeys();
        try {
            jFreeChart10.setSubtitles(list28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap2 = new org.jfree.chart.StrokeMap();
        boolean boolean4 = strokeMap2.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean6 = strokeMap2.equals((java.lang.Object) projectInfo5);
        projectInfo1.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        boolean boolean8 = color0.equals((java.lang.Object) projectInfo5);
        float[] floatArray9 = null;
        float[] floatArray10 = color0.getComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Paint paint0 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint6 = piePlot3.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Stroke stroke10 = piePlot9.getBaseSectionOutlineStroke();
        piePlot3.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean14 = unitType12.equals((java.lang.Object) 98);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType12, 0.14d, 0.0d, 4.0d, (double) 10.0f);
        try {
            org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint0, stroke10, rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Font font7 = piePlot1.getNoDataMessageFont();
        java.awt.Font font8 = piePlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 8, (double) 'a', (double) '#', (double) (short) 100);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot12.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = piePlot12.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot12.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = lineBorder25.getInsets();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot29.setLabelLinkStyle(pieLabelLinkStyle30);
        java.awt.Paint paint33 = piePlot29.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement34.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement36.clear();
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot29, (org.jfree.chart.block.Arrangement) flowArrangement34, (org.jfree.chart.block.Arrangement) columnArrangement36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle38.setVerticalAlignment(verticalAlignment39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = null;
        org.jfree.chart.util.Size2D size2D43 = legendTitle38.arrange(graphics2D41, rectangleConstraint42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, (double) (-589829), 0.0d, rectangleAnchor46);
        lineBorder25.draw(graphics2D27, rectangle2D47);
        rectangleInsets24.trim(rectangle2D47);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D47, "");
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets10.createInsetRectangle(rectangle2D47);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        int int4 = piePlot1.getPieIndex();
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        piePlot1.zoom(4.0d);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
//        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
//        java.lang.String str7 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str7.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        textTitle7.setPaint(paint13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (-1));
        org.jfree.chart.PaintMap paintMap5 = new org.jfree.chart.PaintMap();
        boolean boolean7 = paintMap5.containsKey((java.lang.Comparable) "");
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.lang.String str16 = textTitle15.getToolTipText();
        java.lang.String str17 = textTitle15.getToolTipText();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle15.setPaint((java.awt.Paint) color18);
        java.lang.String str20 = textTitle15.getToolTipText();
        boolean boolean21 = paintMap5.equals((java.lang.Object) str20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.util.UnitType unitType23 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType23, (double) (-246), 0.025d, (double) 100, (double) 0L);
        boolean boolean29 = datasetGroup22.equals((java.lang.Object) 0.025d);
        java.lang.String str30 = datasetGroup22.getID();
        boolean boolean31 = paintMap5.equals((java.lang.Object) datasetGroup22);
        boolean boolean32 = flowArrangement4.equals((java.lang.Object) datasetGroup22);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "NOID" + "'", str30.equals("NOID"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        legendTitle15.setNotify(false);
        double double18 = legendTitle15.getHeight();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("NOID", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint8 = piePlot4.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement9.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement11.clear();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle13.setVerticalAlignment(verticalAlignment14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        org.jfree.chart.util.Size2D size2D18 = legendTitle13.arrange(graphics2D16, rectangleConstraint17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) (-589829), 0.0d, rectangleAnchor21);
        lineBorder0.draw(graphics2D2, rectangle2D22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(point2D25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.plot.Plot plot15 = jFreeChart6.getPlot();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        int int6 = defaultKeyedValues2D1.getColumnCount();
        try {
            defaultKeyedValues2D1.removeColumn((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        boolean boolean18 = lineBorder14.equals((java.lang.Object) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder14.getInsets();
        java.awt.Paint paint20 = lineBorder14.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray13 = legendTitle10.getSources();
        java.awt.Font font14 = legendTitle10.getItemFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(legendItemSourceArray13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color4 = java.awt.Color.blue;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor9 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor9.sort();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot1.getInsets();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        double double28 = piePlot1.getExplodePercent((java.lang.Comparable) (short) 0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: PieLabelLinkStyle.STANDARD");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.lang.String str12 = piePlot1.getPlotType();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieToolTipGenerator13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
//        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
//        projectInfo4.setLicenceName("{0}");
//        java.awt.Image image9 = projectInfo4.getLogo();
//        projectInfo4.setCopyright("PieLabelLinkStyle.QUAD_CURVE");
//        java.lang.String str12 = projectInfo4.getLicenceText();
//        projectInfo4.setVersion("RectangleEdge.TOP");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(image9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str12.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.extendWidth(98.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        java.awt.Paint paint2 = piePlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation8 = piePlot4.getDirection();
        piePlot1.setDirection(rotation8);
        piePlot1.setBackgroundAlpha((float) (-16646144));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(98);
        objectList1.clear();
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Paint paint8 = jFreeChart6.getBorderPaint();
        org.jfree.chart.title.Title title9 = null;
        jFreeChart6.removeSubtitle(title9);
        java.util.List list11 = jFreeChart6.getSubtitles();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle4);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot23.setLabelLinkStyle(pieLabelLinkStyle24);
        java.awt.Paint paint26 = piePlot23.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.chart.title.TextTitle textTitle28 = jFreeChart27.getTitle();
        boolean boolean29 = textTitle28.getExpandToFitSpace();
        textTitle28.setToolTipText("{0}");
        java.awt.Font font32 = textTitle28.getFont();
        textTitle4.setFont(font32);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textTitle28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        boolean boolean18 = lineBorder14.equals((java.lang.Object) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = lineBorder14.getInsets();
        java.awt.Stroke stroke20 = lineBorder14.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot5.setLabelLinkStyle(pieLabelLinkStyle6);
        java.awt.Paint paint8 = piePlot5.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation9 = piePlot5.getDirection();
        piePlot2.setDirection(rotation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.QUAD_CURVE", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint12 = piePlot2.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.LEFT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot4.getLegendLabelURLGenerator();
        java.lang.Object obj6 = piePlot4.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot4.getLegendLabelURLGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        org.jfree.chart.StrokeMap strokeMap10 = new org.jfree.chart.StrokeMap();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean12 = strokeMap10.equals((java.lang.Object) color11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str14 = rectangleEdge13.toString();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint20 = piePlot17.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.title.TextTitle textTitle22 = jFreeChart21.getTitle();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateTopInset((double) (-1));
        textTitle22.setPadding(rectangleInsets25);
        textTitle22.setMargin(0.0d, (double) '4', (double) (short) 100, (double) 100L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle22.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = null;
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle38 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot37.setLabelLinkStyle(pieLabelLinkStyle38);
        java.awt.Paint paint41 = piePlot37.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement42.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement44.clear();
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot37, (org.jfree.chart.block.Arrangement) flowArrangement42, (org.jfree.chart.block.Arrangement) columnArrangement44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendTitle46.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = legendTitle46.getLegendItemGraphicPadding();
        double double50 = rectangleInsets48.calculateRightOutset(0.4d);
        org.jfree.chart.util.UnitType unitType51 = rectangleInsets48.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets(unitType51, 35.0d, 10.0d, (double) (byte) 10, (double) 3);
        try {
            org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n", font2, (java.awt.Paint) color11, rectangleEdge13, horizontalAlignment34, verticalAlignment35, rectangleInsets56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleEdge.LEFT" + "'", str14.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textTitle22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle38);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(unitType51);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        textTitle7.setWidth((double) 1L);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        textTitle7.draw(graphics2D10, rectangle2D11);
        double double13 = textTitle7.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle7.getMargin();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        piePlot1.setBackgroundImageAlignment((-589829));
        java.awt.Color color7 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        piePlot1.setLabelShadowPaint((java.awt.Paint) color7);
        int int10 = color7.getRGB();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16711936) + "'", int10 == (-16711936));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        java.awt.Stroke stroke18 = piePlot1.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot20.getLegendLabelURLGenerator();
        double double22 = piePlot20.getMaximumExplodePercent();
        java.awt.Paint paint23 = piePlot20.getLabelBackgroundPaint();
        java.awt.Stroke stroke24 = piePlot20.getLabelOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke24);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot28.setLabelLinkStyle(pieLabelLinkStyle29);
        java.awt.Paint paint31 = piePlot28.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot28);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart32.getTitle();
        java.lang.String str34 = textTitle33.getToolTipText();
        java.lang.String str35 = textTitle33.getToolTipText();
        java.awt.Paint paint36 = textTitle33.getBackgroundPaint();
        java.awt.Font font37 = textTitle33.getFont();
        piePlot1.setNoDataMessageFont(font37);
        org.jfree.data.general.DatasetGroup datasetGroup39 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textTitle33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(datasetGroup39);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) 128);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3.getLegendLabelURLGenerator();
        java.lang.Object obj5 = piePlot3.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3.getLegendLabelURLGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        piePlot3.setSectionOutlinesVisible(false);
        java.lang.Object obj11 = piePlot3.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color1 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "PieLabelLinkStyle.QUAD_CURVE", dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        java.lang.Object obj4 = datasetChangeEvent2.getSource();
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", obj4.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot1.getLabelBackgroundPaint();
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        int int7 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Color color0 = java.awt.Color.blue;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint10 = piePlot7.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot7);
        jFreeChart11.fireChartChanged();
        jFreeChart11.clearSubtitles();
        java.awt.Paint paint14 = jFreeChart11.getBorderPaint();
        chartChangeEvent3.setChart(jFreeChart11);
        jFreeChart11.setBackgroundImageAlignment((int) (byte) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]"));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        java.lang.String str8 = piePlot1.getPlotType();
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint15 = piePlot11.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement16.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement18.clear();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) columnArrangement18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle20.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getLegendItemGraphicPadding();
        java.lang.String str23 = rectangleInsets22.toString();
        piePlot1.setSimpleLabelOffset(rectangleInsets22);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str23.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.lang.String str13 = verticalAlignment11.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.TOP" + "'", str13.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        piePlot5.setLabelPadding(rectangleInsets8);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = piePlot1.getLabelLinkStyle();
        boolean boolean13 = piePlot1.getLabelLinksVisible();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder16.getInsets();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot20.setLabelLinkStyle(pieLabelLinkStyle21);
        java.awt.Paint paint24 = piePlot20.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement25.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement27.clear();
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20, (org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle29.setVerticalAlignment(verticalAlignment30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = null;
        org.jfree.chart.util.Size2D size2D34 = legendTitle29.arrange(graphics2D32, rectangleConstraint33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (-589829), 0.0d, rectangleAnchor37);
        lineBorder16.draw(graphics2D18, rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets15.createOutsetRectangle(rectangle2D38, false, true);
        try {
            piePlot1.drawOutline(graphics2D14, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.plot.Plot plot21 = plotChangeEvent20.getPlot();
        jFreeChart6.plotChanged(plotChangeEvent20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        try {
            java.awt.image.BufferedImage bufferedImage27 = jFreeChart6.createBufferedImage((int) (byte) 1, (-589829), 100, chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        java.lang.String str9 = textTitle7.getToolTipText();
        java.lang.String str10 = textTitle7.getText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle7.getVerticalAlignment();
        textTitle7.setURLText("TableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str10.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) -1, (java.lang.Comparable) 0, (java.lang.Comparable) (-1.0d));
        try {
            defaultKeyedValues2D1.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) 8);
        defaultCategoryDataset0.clear();
        java.lang.Comparable comparable18 = null;
        try {
            defaultCategoryDataset0.addValue(0.08d, (java.lang.Comparable) "rect", comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 98, 64, (java.lang.Comparable) 1L, "org.jfree.chart.event.ChartChangeEvent[source=100]", "java.awt.Color[r=64,g=64,b=64]");
        pieSectionEntity11.setPieIndex(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity(shape15, pieDataset16, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity11.setArea(shape15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (-1));
        java.lang.Object obj10 = null;
        boolean boolean11 = defaultKeyedValues2D1.equals(obj10);
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getLegendItemGraphicPadding();
        java.awt.Paint paint13 = legendTitle10.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        legendTitle10.setItemLabelPadding(rectangleInsets18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        java.lang.Object obj12 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.awt.Color color8 = java.awt.Color.pink;
        int int9 = color8.getBlue();
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color8.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart6.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle17.getMargin();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 175 + "'", int9 == 175);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle10.arrange(graphics2D13, rectangleConstraint14);
        java.awt.Paint paint16 = legendTitle10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        piePlot13.setLabelPadding(rectangleInsets16);
        piePlot9.setInsets(rectangleInsets16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot9.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot22.setLabelLinkStyle(pieLabelLinkStyle23);
        java.awt.Paint paint26 = piePlot22.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement27.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement29.clear();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot22, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement29);
        legendTitle31.setHeight((double) '#');
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str35 = color34.toString();
        legendTitle31.setBackgroundPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle31.getPadding();
        double double39 = rectangleInsets37.extendHeight((double) 100.0f);
        double double41 = rectangleInsets37.calculateRightInset(0.4d);
        piePlot1.setSimpleLabelOffset(rectangleInsets37);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str35.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 102.0d + "'", double39 == 102.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0} version RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0].\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:PieLabelLinkStyle.STANDARD\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0] (PieLabelLinkStyle.STANDARD).\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-246), 0.025d, (double) 100, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, 10.0d, 90.0d, (double) (short) -1, 0.4d);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        java.lang.Object obj26 = jFreeChart6.clone();
        jFreeChart6.setAntiAlias(true);
        boolean boolean29 = jFreeChart6.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot33.setLabelLinkStyle(pieLabelLinkStyle34);
        java.awt.Paint paint36 = piePlot33.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot33);
        org.jfree.chart.title.TextTitle textTitle38 = jFreeChart37.getTitle();
        java.lang.String str39 = textTitle38.getToolTipText();
        java.lang.String str40 = textTitle38.getToolTipText();
        java.awt.Paint paint41 = textTitle38.getBackgroundPaint();
        java.awt.Font font42 = textTitle38.getFont();
        textTitle38.setNotify(true);
        try {
            jFreeChart6.addSubtitle((int) '4', (org.jfree.chart.title.Title) textTitle38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(textTitle38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        blockContainer13.clear();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = piePlot16.getLegendItems();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (-1));
        double double25 = rectangleInsets22.getBottom();
        piePlot16.setLabelPadding(rectangleInsets22);
        blockContainer13.setPadding(rectangleInsets22);
        double double28 = rectangleInsets22.getLeft();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 10.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot1.addChangeListener(plotChangeListener9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        java.lang.String str9 = textTitle7.getToolTipText();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle7.setPaint((java.awt.Paint) color10);
        textTitle7.setToolTipText("ChartChangeEventType.GENERAL");
        java.lang.Object obj14 = null;
        boolean boolean15 = textTitle7.equals(obj14);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        java.awt.Paint paint18 = legendTitle10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray13 = legendTitle10.getSources();
        java.lang.Object obj14 = legendTitle10.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(legendItemSourceArray13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Pie Plot", "java.awt.Color[r=0,g=0,b=192]", "RectangleEdge.LEFT", "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle15.getItemContainer();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(blockContainer17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.block.BlockFrame blockFrame15 = legendTitle10.getFrame();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) (-1));
        double double22 = rectangleInsets18.calculateRightOutset(1.0E-5d);
        legendTitle10.setMargin(rectangleInsets18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor24);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str14 = color13.toString();
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle10.getPadding();
        double double18 = rectangleInsets16.calculateRightOutset((double) (-1L));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str14.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.calculateTopInset((double) (-1));
        double double10 = rectangleInsets7.getBottom();
        piePlot1.setLabelPadding(rectangleInsets7);
        piePlot1.setLabelLinkMargin((double) (byte) 10);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot7 = piePlot2.getParent();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot9.getURLGenerator();
        piePlot9.setCircular(true);
        java.awt.Font font22 = piePlot9.getNoDataMessageFont();
        piePlot2.setLabelFont(font22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset26 = multiplePiePlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font22, (org.jfree.chart.plot.Plot) multiplePiePlot24, true);
        java.lang.String str29 = multiplePiePlot24.getPlotType();
        java.lang.String str30 = multiplePiePlot24.getPlotType();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Multiple Pie Plot" + "'", str29.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Multiple Pie Plot" + "'", str30.equals("Multiple Pie Plot"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        double double6 = rotation5.getFactor();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        java.awt.Paint paint9 = defaultDrawingSupplier7.getNextPaint();
        java.awt.Paint paint10 = defaultDrawingSupplier7.getNextOutlinePaint();
        boolean boolean11 = rotation5.equals((java.lang.Object) defaultDrawingSupplier7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        java.awt.Color color8 = java.awt.Color.gray;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color8);
        piePlot1.setMinimumArcAngleToDraw((double) 192);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(color8);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        boolean boolean2 = projectInfo0.equals((java.lang.Object) 2);
//        java.lang.String str3 = projectInfo0.toString();
//        projectInfo0.setInfo("ChartChangeEventType.GENERAL");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0} version RectangleEdge.TOP.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:PieLabelLinkStyle.STANDARD\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str3.equals("{0} version RectangleEdge.TOP.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:PieLabelLinkStyle.STANDARD\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).hi! poly (RectangleEdge.TOP).hi!  ().hi!  ().hi!  ().{0} RectangleEdge.TOP (PieLabelLinkStyle.STANDARD).\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]"));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot1.getShadowPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean4 = strokeMap0.equals((java.lang.Object) projectInfo3);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getOptionalLibraries();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint11 = piePlot8.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot8);
        java.awt.Paint paint13 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj14 = jFreeChart12.getTextAntiAlias();
        java.lang.Object obj15 = jFreeChart12.getTextAntiAlias();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D16 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list17 = defaultKeyedValues2D16.getColumnKeys();
        jFreeChart12.setSubtitles(list17);
        projectInfo3.setContributors(list17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        java.awt.Paint paint12 = legendTitle10.getBackgroundPaint();
        legendTitle10.setWidth((double) 0L);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        java.awt.Font font18 = legendTitle10.getItemFont();
        java.awt.Paint paint19 = legendTitle10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot1.getInsets();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint18 = piePlot14.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement19.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement21.clear();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) columnArrangement21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle23.setVerticalAlignment(verticalAlignment24);
        java.awt.Font font27 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("", font27);
        legendTitle23.setItemFont(font27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart31 = multiplePiePlot30.getPieChart();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = multiplePiePlot30.getLegendItems();
        double double33 = multiplePiePlot30.getLimit();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]", font27, (org.jfree.chart.plot.Plot) multiplePiePlot30, true);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(jFreeChart31);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        float float3 = jFreeChart1.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart1.getTitle();
        textTitle4.setNotify(false);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(textTitle4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        java.awt.Stroke stroke5 = piePlot1.getLabelLinkStroke();
        piePlot1.setBackgroundImageAlignment(1);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart14.getTitle();
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart14.removeProgressListener(chartProgressListener17);
        java.lang.Object obj19 = jFreeChart14.clone();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        float float21 = jFreeChart14.getBackgroundImageAlpha();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle25 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot24.setLabelLinkStyle(pieLabelLinkStyle25);
        java.awt.Paint paint27 = piePlot24.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot24);
        org.jfree.chart.title.TextTitle textTitle29 = jFreeChart28.getTitle();
        java.lang.String str30 = textTitle29.getURLText();
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle29.setFont(font31);
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) textTitle29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.title.TextTitle@a877477a incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textTitle29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        jFreeChart6.setBackgroundImageAlignment(64);
        java.awt.Image image10 = jFreeChart6.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape10, "poly");
        piePlot1.setLegendItemShape(shape10);
        double double15 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor1.sort();
        int int3 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent9);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke4);
        double double6 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint7 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString8 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel((int) 'a', attributedString8);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.addValue((java.lang.Number) 175, (java.lang.Comparable) 'a', (java.lang.Comparable) "java.awt.Color[r=64,g=255,b=255]");
        try {
            defaultCategoryDataset0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = piePlot1.getLabelLinkStyle();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = piePlot8.getLegendLabelURLGenerator();
        double double10 = piePlot8.getMaximumExplodePercent();
        java.awt.Paint paint11 = piePlot8.getLabelBackgroundPaint();
        java.awt.Stroke stroke12 = piePlot8.getLabelOutlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot8);
        boolean boolean14 = pieLabelLinkStyle6.equals((java.lang.Object) legendTitle13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNull(pieURLGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint11 = piePlot8.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot8);
        java.awt.Paint paint13 = jFreeChart12.getBackgroundPaint();
        int int14 = jFreeChart12.getSubtitleCount();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart12.removeProgressListener(chartProgressListener16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup17 = piePlot1.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = lineBorder21.getInsets();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle26 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot25.setLabelLinkStyle(pieLabelLinkStyle26);
        java.awt.Paint paint29 = piePlot25.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement30.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement32.clear();
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot25, (org.jfree.chart.block.Arrangement) flowArrangement30, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle34.setVerticalAlignment(verticalAlignment35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = null;
        org.jfree.chart.util.Size2D size2D39 = legendTitle34.arrange(graphics2D37, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, (double) (-589829), 0.0d, rectangleAnchor42);
        lineBorder21.draw(graphics2D23, rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets20.createOutsetRectangle(rectangle2D43, false, true);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo48 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str49 = basicProjectInfo48.getVersion();
        try {
            java.lang.Object obj50 = legendTitle18.draw(graphics2D19, rectangle2D47, (java.lang.Object) str49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle26);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color4 = java.awt.Color.blue;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        try {
            piePlot1.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        piePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot9.setLabelLinkStyle(pieLabelLinkStyle10);
        java.awt.Paint paint12 = piePlot9.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart13.getTitle();
        java.lang.String str15 = textTitle14.getToolTipText();
        java.lang.String str16 = textTitle14.getToolTipText();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle14.setPaint((java.awt.Paint) color17);
        java.lang.String str19 = textTitle14.getToolTipText();
        textTitle14.setURLText("UnitType.ABSOLUTE");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle14.setTextAlignment(horizontalAlignment22);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle10.arrange(graphics2D13, rectangleConstraint14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot18.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot18.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        piePlot22.setLabelPadding(rectangleInsets25);
        piePlot18.setInsets(rectangleInsets25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = piePlot18.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = piePlot18.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot18.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = lineBorder31.getInsets();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle36 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot35.setLabelLinkStyle(pieLabelLinkStyle36);
        java.awt.Paint paint39 = piePlot35.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement40.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement42.clear();
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot35, (org.jfree.chart.block.Arrangement) flowArrangement40, (org.jfree.chart.block.Arrangement) columnArrangement42);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle44.setVerticalAlignment(verticalAlignment45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = null;
        org.jfree.chart.util.Size2D size2D49 = legendTitle44.arrange(graphics2D47, rectangleConstraint48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, (double) (-589829), 0.0d, rectangleAnchor52);
        lineBorder31.draw(graphics2D33, rectangle2D53);
        rectangleInsets30.trim(rectangle2D53);
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        piePlot57.addChangeListener(plotChangeListener58);
        piePlot57.setSimpleLabels(true);
        int int62 = piePlot57.getBackgroundImageAlignment();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor63 = piePlot57.getLabelDistributor();
        java.awt.Shape shape64 = piePlot57.getLegendItemShape();
        try {
            java.lang.Object obj65 = legendTitle10.draw(graphics2D16, rectangle2D53, (java.lang.Object) piePlot57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle36);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 15 + "'", int62 == 15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor63);
        org.junit.Assert.assertNotNull(shape64);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) 0.14d, (java.lang.Comparable) "VerticalAlignment.CENTER");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setLabelLinksVisible(false);
        double double11 = piePlot8.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator12 = piePlot8.getToolTipGenerator();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot8.setOutlinePaint(paint13);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot8);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Font font7 = piePlot1.getNoDataMessageFont();
        java.awt.Paint paint9 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.025d);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot1.axisChanged(axisChangeEvent10);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setMinimumArcAngleToDraw(0.0d);
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray10 = color3.getColorComponents(floatArray9);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        double double15 = piePlot13.getMaximumExplodePercent();
        java.awt.Paint paint16 = piePlot13.getLabelBackgroundPaint();
        java.awt.Stroke stroke17 = piePlot13.getLabelOutlineStroke();
        boolean boolean18 = blockBorder1.equals((java.lang.Object) piePlot13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder1.getInsets();
        double double21 = rectangleInsets19.extendWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12.0d + "'", double21 == 12.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        chartEntity4.setToolTipText("{0}");
        chartEntity4.setURLText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        chartEntity4.setURLText("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint6 = piePlot3.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart7.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        java.awt.image.BufferedImage bufferedImage15 = jFreeChart7.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke16);
        multiplePiePlot0.setPieChart(jFreeChart7);
        multiplePiePlot0.setOutlineVisible(false);
        multiplePiePlot0.setLimit((double) (short) 1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(bufferedImage15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick((-16777216), 175, plotRenderingInfo11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        piePlot26.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot26.getLabelGenerator();
        piePlot26.setIgnoreNullValues(true);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot26);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        piePlot1.setDataset(pieDataset35);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        piePlot5.setLabelPadding(rectangleInsets8);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot1.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle19 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle19);
        java.awt.Paint paint22 = piePlot18.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement23.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement25.clear();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18, (org.jfree.chart.block.Arrangement) flowArrangement23, (org.jfree.chart.block.Arrangement) columnArrangement25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle27.setVerticalAlignment(verticalAlignment28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = null;
        org.jfree.chart.util.Size2D size2D32 = legendTitle27.arrange(graphics2D30, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, (double) (-589829), 0.0d, rectangleAnchor35);
        lineBorder14.draw(graphics2D16, rectangle2D36);
        rectangleInsets13.trim(rectangle2D36);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D36, "");
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D36, rectangleEdge41);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        piePlot1.setPieIndex(0);
        double double11 = piePlot1.getMaximumLabelWidth();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        java.awt.Shape shape14 = chartEntity13.getArea();
        piePlot1.setLegendItemShape(shape14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((int) (short) 1, (-589829));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart6.getPadding();
        boolean boolean9 = jFreeChart6.getAntiAlias();
        org.jfree.chart.util.ObjectList objectList15 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color17 = java.awt.Color.orange;
        objectList15.set((int) 'a', (java.lang.Object) color17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 98, 0.0d, (double) (byte) 1, (java.awt.Paint) color17);
        jFreeChart6.setBorderPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM", "RectangleAnchor.BOTTOM", "java.awt.Color[r=64,g=255,b=255]", "hi!", "hi!");
        basicProjectInfo5.setLicenceName("VerticalAlignment.CENTER");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap9 = new org.jfree.chart.StrokeMap();
        boolean boolean11 = strokeMap9.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean13 = strokeMap9.equals((java.lang.Object) projectInfo12);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo12);
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        basicProjectInfo5.addOptionalLibrary("org.jfree.data.general.DatasetChangeEvent[source=PieLabelLinkStyle.QUAD_CURVE]");
        java.lang.String str18 = basicProjectInfo5.getName();
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str18.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        int int8 = piePlot1.getBackgroundImageAlignment();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        piePlot11.setSimpleLabels(true);
        java.awt.Stroke stroke16 = piePlot11.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        piePlot18.setLabelPadding(rectangleInsets21);
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke16, rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = lineBorder23.getInsets();
        piePlot1.setSimpleLabelOffset(rectangleInsets24);
        piePlot1.setNoDataMessage("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
        java.lang.Object obj28 = piePlot1.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.awt.Shape[] shapeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) shapeArray2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint12 = piePlot8.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement13.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement15.clear();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot8, (org.jfree.chart.block.Arrangement) flowArrangement13, (org.jfree.chart.block.Arrangement) columnArrangement15);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = legendTitle17.arrange(graphics2D18);
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle17.getItemContainer();
        boolean boolean21 = blockContainer20.isEmpty();
        java.lang.Object obj22 = blockContainer20.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment24, (double) (byte) 10, (double) (byte) 10);
        blockContainer20.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement27);
        boolean boolean29 = defaultDrawingSupplier4.equals((java.lang.Object) flowArrangement27);
        org.junit.Assert.assertNotNull(shapeArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(blockContainer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint4 = piePlot1.getShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        piePlot1.setStartAngle(2.0d);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.awt.Font font12 = plot11.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        jFreeChart14.setBorderVisible(false);
        piePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        piePlot2.setNoDataMessagePaint((java.awt.Paint) color18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle22 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot21.setLabelLinkStyle(pieLabelLinkStyle22);
        java.awt.Paint paint25 = piePlot21.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot21.setOutlinePaint((java.awt.Paint) color26);
        float[] floatArray36 = new float[] { 1.0f, '#', (byte) 100, 10L, (-1) };
        float[] floatArray37 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 0, (int) (byte) 0, floatArray36);
        float[] floatArray38 = color26.getRGBComponents(floatArray36);
        piePlot2.setLabelPaint((java.awt.Paint) color26);
        java.awt.Color color40 = java.awt.Color.lightGray;
        int int41 = color40.getTransparency();
        float[] floatArray47 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray48 = color40.getRGBColorComponents(floatArray47);
        float[] floatArray49 = color26.getRGBColorComponents(floatArray47);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape0, "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.awt.Shape shape5 = chartEntity4.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart6.getTitle();
        java.lang.Object obj10 = textTitle9.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        multiplePiePlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) 8);
        defaultCategoryDataset0.clear();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint21 = piePlot17.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement22.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement24.clear();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle26.setVerticalAlignment(verticalAlignment27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle26.setLegendItemGraphicAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle26.getLegendItemGraphicLocation();
        boolean boolean32 = defaultCategoryDataset0.equals((java.lang.Object) rectangleAnchor31);
        java.lang.Comparable comparable34 = null;
        try {
            java.lang.Number number35 = defaultCategoryDataset0.getValue((java.lang.Comparable) "UnitType.ABSOLUTE", comparable34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        jFreeChart14.setBorderVisible(false);
        jFreeChart14.setBorderVisible(true);
        jFreeChart14.fireChartChanged();
        java.awt.Color color20 = java.awt.Color.GREEN;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color20);
        int int22 = color20.getGreen();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator24 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNull(pieToolTipGenerator24);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        java.lang.String str6 = datasetGroup5.getID();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NOID" + "'", str6.equals("NOID"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        boolean boolean15 = jFreeChart10.isNotify();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot7 = piePlot2.getParent();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot9.getURLGenerator();
        piePlot9.setCircular(true);
        java.awt.Font font22 = piePlot9.getNoDataMessageFont();
        piePlot2.setLabelFont(font22);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset26 = multiplePiePlot24.getDataset();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font22, (org.jfree.chart.plot.Plot) multiplePiePlot24, true);
        org.jfree.data.category.CategoryDataset categoryDataset29 = multiplePiePlot24.getDataset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        multiplePiePlot24.axisChanged(axisChangeEvent30);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(categoryDataset29);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot4.getLegendLabelURLGenerator();
        double double6 = piePlot4.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot9.setLabelLinkStyle(pieLabelLinkStyle10);
        java.awt.Paint paint12 = piePlot9.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart13.getTitle();
        boolean boolean15 = jFreeChart13.isBorderVisible();
        piePlot4.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart13.createBufferedImage(98, (int) (byte) 1, chartRenderingInfo19);
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("VerticalAlignment.CENTER", "poly", "VerticalAlignment.TOP", (java.awt.Image) bufferedImage20, "Pie Plot", "Pie Plot", "TableOrder.BY_ROW");
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(bufferedImage20);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str6 = rectangleEdge5.toString();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleEdge5);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString10 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) 'a', attributedString10);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        piePlot12.setSimpleLabels(true);
        int int17 = piePlot12.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator18 = piePlot12.getToolTipGenerator();
        java.awt.Stroke stroke19 = piePlot12.getLabelOutlineStroke();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke19, rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.chart.ui.Contributor contributor12 = new org.jfree.chart.ui.Contributor("", "java.awt.Color[r=64,g=255,b=255]");
        boolean boolean13 = pieSectionEntity9.equals((java.lang.Object) "");
        java.lang.String str14 = pieSectionEntity9.getURLText();
        java.lang.String str15 = pieSectionEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: -1, 0(100)" + "'", str15.equals("PieSection: -1, 0(100)"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 175, (double) 10, 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("java.awt.Color[r=0,g=0,b=192]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=0,g=0,b=192]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        int int8 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setOutlineVisible(true);
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "PieLabelLinkStyle.QUAD_CURVE", dataset12);
        org.jfree.data.general.Dataset dataset14 = datasetChangeEvent13.getDataset();
        piePlot1.datasetChanged(datasetChangeEvent13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNull(dataset14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        java.lang.Object obj3 = piePlot1.clone();
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.addValue(1.0d, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 1);
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        java.lang.String str9 = textTitle7.getToolTipText();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle7.setPaint((java.awt.Paint) color10);
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setLabelLinksVisible(false);
        double double17 = piePlot14.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator18 = piePlot14.getToolTipGenerator();
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot14.setOutlinePaint(paint19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color22 = java.awt.Color.lightGray;
        int int23 = color22.getTransparency();
        float[] floatArray29 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray30 = color22.getRGBColorComponents(floatArray29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int32 = color31.getTransparency();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int34 = color33.getTransparency();
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { paint19, color21, color22, color31, color33 };
        java.awt.Paint[] paintArray36 = null;
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray35, paintArray36, strokeArray37, strokeArray38, shapeArray39);
        java.awt.Paint paint41 = defaultDrawingSupplier40.getNextFillPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean44 = defaultDrawingSupplier42.equals((java.lang.Object) rectangleAnchor43);
        java.awt.Paint paint45 = defaultDrawingSupplier42.getNextFillPaint();
        boolean boolean46 = defaultDrawingSupplier40.equals((java.lang.Object) paint45);
        boolean boolean47 = color10.equals((java.lang.Object) paint45);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(shapeArray39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.lang.String str3 = textTitle2.getText();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot5.getLegendLabelURLGenerator();
        double double7 = piePlot5.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        piePlot5.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        int int18 = jFreeChart14.getSubtitleCount();
        java.awt.Color color19 = java.awt.Color.DARK_GRAY;
        jFreeChart14.setBorderPaint((java.awt.Paint) color19);
        textTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        int int8 = piePlot1.getBackgroundImageAlignment();
        double double9 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.14d + "'", double9 == 0.14d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.lang.String str4 = piePlot1.getNoDataMessage();
        piePlot1.setSimpleLabels(false);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList(10);
        java.awt.Color color6 = java.awt.Color.orange;
        objectList4.set((int) 'a', (java.lang.Object) color6);
        java.lang.Object obj9 = objectList4.get((int) '4');
        int int10 = objectList4.size();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        objectList4.set(175, (java.lang.Object) defaultKeyedValues2D12);
        boolean boolean15 = multiplePiePlot2.equals((java.lang.Object) defaultKeyedValues2D12);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 98 + "'", int10 == 98);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.util.Rotation rotation5 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str6 = rotation5.toString();
        piePlot1.setDirection(rotation5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Rotation.CLOCKWISE" + "'", str6.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        boolean boolean14 = defaultCategoryDataset0.equals((java.lang.Object) 8);
        defaultCategoryDataset0.clear();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint21 = piePlot17.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement22.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement24.clear();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17, (org.jfree.chart.block.Arrangement) flowArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle26.setVerticalAlignment(verticalAlignment27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle26.setLegendItemGraphicAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle26.getLegendItemGraphicLocation();
        boolean boolean32 = defaultCategoryDataset0.equals((java.lang.Object) rectangleAnchor31);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        piePlot34.addChangeListener(plotChangeListener35);
        piePlot34.setSimpleLabels(true);
        java.awt.Stroke stroke39 = piePlot34.getLabelLinkStroke();
        java.awt.Image image40 = piePlot34.getBackgroundImage();
        int int41 = piePlot34.getBackgroundImageAlignment();
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        piePlot44.addChangeListener(plotChangeListener45);
        piePlot44.setSimpleLabels(true);
        java.awt.Stroke stroke49 = piePlot44.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot(pieDataset50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = blockBorder53.getInsets();
        piePlot51.setLabelPadding(rectangleInsets54);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color42, stroke49, rectangleInsets54);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = lineBorder56.getInsets();
        piePlot34.setSimpleLabelOffset(rectangleInsets57);
        piePlot34.setNoDataMessage("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot34);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(image40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 8, (double) 'a', (double) '#', (double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        java.awt.Paint paint6 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (-1));
        java.util.List list10 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 10, (double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint10 = piePlot7.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart11.getTitle();
        java.lang.Object obj13 = textTitle12.clone();
        java.awt.Paint paint14 = textTitle12.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle12.setVerticalAlignment(verticalAlignment15);
        boolean boolean17 = horizontalAlignment0.equals((java.lang.Object) verticalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment18, 0.4d, (double) (-16646144));
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap7 = new org.jfree.chart.StrokeMap();
        boolean boolean9 = strokeMap7.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean11 = strokeMap7.equals((java.lang.Object) projectInfo10);
        projectInfo6.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo10);
        java.awt.Image image13 = projectInfo10.getLogo();
        piePlot1.setBackgroundImage(image13);
        java.awt.Paint paint15 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(image13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup17 = piePlot1.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint[] paintArray19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray19, dataset20);
        piePlot1.datasetChanged(datasetChangeEvent21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        piePlot1.setDataset(pieDataset23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(paintArray19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) "");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot5.setLabelLinkStyle(pieLabelLinkStyle6);
        java.awt.Paint paint8 = piePlot5.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        java.lang.String str11 = textTitle10.getToolTipText();
        java.lang.String str12 = textTitle10.getToolTipText();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        textTitle10.setPaint((java.awt.Paint) color13);
        java.lang.String str15 = textTitle10.getToolTipText();
        boolean boolean16 = paintMap0.equals((java.lang.Object) str15);
        java.lang.Object obj17 = null;
        boolean boolean18 = paintMap0.equals(obj17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint7 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement10.clear();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle12.setVerticalAlignment(verticalAlignment13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle12.getLegendItemGraphicEdge();
        textTitle1.setPosition(rectangleEdge15);
        java.lang.String str17 = textTitle1.getURLText();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 100.0f, 37.0d, 0.0d, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str6 = library5.getInfo();
        boolean boolean7 = standardPieSectionLabelGenerator0.equals((java.lang.Object) library5);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset8, (java.lang.Comparable) '#');
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Color color4 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 0, (double) (short) 10, 0.0d, 0.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        java.lang.Object obj26 = jFreeChart6.clone();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = lineBorder29.getInsets();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot33.setLabelLinkStyle(pieLabelLinkStyle34);
        java.awt.Paint paint37 = piePlot33.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement38 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement38.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement40.clear();
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot33, (org.jfree.chart.block.Arrangement) flowArrangement38, (org.jfree.chart.block.Arrangement) columnArrangement40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle42.setVerticalAlignment(verticalAlignment43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = null;
        org.jfree.chart.util.Size2D size2D47 = legendTitle42.arrange(graphics2D45, rectangleConstraint46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D51 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, (double) (-589829), 0.0d, rectangleAnchor50);
        lineBorder29.draw(graphics2D31, rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets28.createOutsetRectangle(rectangle2D51, false, true);
        try {
            jFreeChart6.draw(graphics2D27, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        java.awt.Paint[] paintArray4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray4, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        boolean boolean8 = defaultCategoryDataset0.equals((java.lang.Object) dataset7);
        java.util.List list9 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Number number10 = null;
        java.lang.Comparable comparable11 = null;
        try {
            defaultCategoryDataset0.addValue(number10, comparable11, (java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        java.awt.Paint paint3 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup17 = piePlot1.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint[] paintArray19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray19, dataset20);
        piePlot1.datasetChanged(datasetChangeEvent21);
        org.jfree.data.general.Dataset dataset23 = datasetChangeEvent21.getDataset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNull(dataset23);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setSimpleLabels(true);
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        piePlot9.setLabelPadding(rectangleInsets12);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke7, rectangleInsets12);
        double double15 = rectangleInsets12.getLeft();
        double double16 = rectangleInsets12.getLeft();
        double double18 = rectangleInsets12.calculateLeftInset((double) 0.5f);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier16.getNextOutlinePaint();
        java.awt.Paint paint20 = defaultDrawingSupplier16.getNextOutlinePaint();
        boolean boolean21 = blockContainer13.equals((java.lang.Object) paint20);
        java.util.List list22 = blockContainer13.getBlocks();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        double double7 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getToolTipText();
        double double9 = textTitle7.getWidth();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        textTitle7.draw(graphics2D10, rectangle2D11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot8.setLabelLinkStyle(pieLabelLinkStyle9);
        java.awt.Paint paint11 = piePlot8.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot8);
        java.awt.Paint paint13 = jFreeChart12.getBackgroundPaint();
        int int14 = jFreeChart12.getSubtitleCount();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        jFreeChart12.setTitle("Pie Plot");
        jFreeChart12.clearSubtitles();
        java.awt.Image image19 = jFreeChart12.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        piePlot3.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Font font9 = piePlot3.getNoDataMessageFont();
        boolean boolean10 = lineBorder1.equals((java.lang.Object) font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("", font9);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setTextAntiAlias(true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint17 = piePlot13.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement18.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement20.clear();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13, (org.jfree.chart.block.Arrangement) flowArrangement18, (org.jfree.chart.block.Arrangement) columnArrangement20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle22.setVerticalAlignment(verticalAlignment23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle22.arrange(graphics2D25, rectangleConstraint26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) (-589829), 0.0d, rectangleAnchor30);
        try {
            jFreeChart6.draw(graphics2D11, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 175);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str14 = color13.toString();
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle10.getPadding();
        double double18 = rectangleInsets16.extendWidth((double) 128);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str14.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 130.0d + "'", double18 == 130.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot7.setLabelLinkPaint((java.awt.Paint) color14);
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup17 = piePlot1.getDatasetGroup();
        org.jfree.data.general.DatasetGroup datasetGroup18 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) (-1));
        double double6 = rectangleInsets2.calculateRightOutset(1.0E-5d);
        double double8 = rectangleInsets2.calculateRightInset(2.0d);
        double double10 = rectangleInsets2.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        int int4 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color8);
        java.awt.Paint paint11 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) (byte) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        java.lang.String str15 = standardPieSectionLabelGenerator12.generateSectionLabel(pieDataset13, (java.lang.Comparable) '#');
        java.lang.Object obj16 = standardPieSectionLabelGenerator12.clone();
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.lang.Object obj18 = standardPieSectionLabelGenerator12.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        java.awt.Stroke stroke8 = piePlot1.getLabelOutlineStroke();
        double double9 = piePlot1.getInteriorGap();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.08d + "'", double9 == 0.08d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Paint paint10 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color13 = java.awt.Color.lightGray;
        int int14 = color13.getTransparency();
        float[] floatArray20 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray21 = color13.getRGBColorComponents(floatArray20);
        float[] floatArray22 = java.awt.Color.RGBtoHSB(175, 98, 192, floatArray20);
        float[] floatArray23 = color9.getRGBComponents(floatArray20);
        float[] floatArray24 = color8.getComponents(floatArray20);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        boolean boolean26 = jFreeChart6.isBorderVisible();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleEdge.LEFT");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double22 = rectangleInsets18.getLeft();
        java.awt.Paint paint23 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        piePlot1.setStartAngle(0.025d);
        java.awt.Paint paint27 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray10 = color3.getColorComponents(floatArray9);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot13.getLegendLabelURLGenerator();
        double double15 = piePlot13.getMaximumExplodePercent();
        java.awt.Paint paint16 = piePlot13.getLabelBackgroundPaint();
        java.awt.Stroke stroke17 = piePlot13.getLabelOutlineStroke();
        boolean boolean18 = blockBorder1.equals((java.lang.Object) piePlot13);
        double double19 = piePlot13.getLabelLinkMargin();
        java.awt.Font font20 = piePlot13.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.025d + "'", double19 == 0.025d);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        textTitle7.setURLText("PieLabelLinkStyle.CUBIC_CURVE");
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        piePlot19.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot19);
        java.awt.Font font25 = piePlot19.getNoDataMessageFont();
        boolean boolean26 = lineBorder17.equals((java.lang.Object) font25);
        textTitle7.setFont(font25);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1, (double) 10, (double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot6.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        piePlot10.setLabelPadding(rectangleInsets13);
        piePlot6.setInsets(rectangleInsets13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = piePlot6.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle17 = piePlot6.getLabelLinkStyle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot6.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = lineBorder19.getInsets();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot23.setLabelLinkStyle(pieLabelLinkStyle24);
        java.awt.Paint paint27 = piePlot23.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement28.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement30.clear();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23, (org.jfree.chart.block.Arrangement) flowArrangement28, (org.jfree.chart.block.Arrangement) columnArrangement30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle32.setVerticalAlignment(verticalAlignment33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = null;
        org.jfree.chart.util.Size2D size2D37 = legendTitle32.arrange(graphics2D35, rectangleConstraint36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) (-589829), 0.0d, rectangleAnchor40);
        lineBorder19.draw(graphics2D21, rectangle2D41);
        rectangleInsets18.trim(rectangle2D41);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41, "");
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets4.createInsetRectangle(rectangle2D41);
        double double48 = rectangleInsets4.calculateTopOutset((double) 1.0f);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        java.awt.Stroke stroke18 = piePlot1.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot20.getLegendLabelURLGenerator();
        double double22 = piePlot20.getMaximumExplodePercent();
        java.awt.Paint paint23 = piePlot20.getLabelBackgroundPaint();
        java.awt.Stroke stroke24 = piePlot20.getLabelOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        textTitle7.setPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean14 = unitType12.equals((java.lang.Object) 98);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType12, 0.14d, 0.0d, 4.0d, (double) 10.0f);
        java.lang.String str20 = unitType12.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (byte) 10, 35.0d, (double) 3, 90.0d);
        boolean boolean26 = rectangleEdge11.equals((java.lang.Object) 35.0d);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape28 = defaultDrawingSupplier27.getNextShape();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity35 = new org.jfree.chart.entity.PieSectionEntity(shape28, pieDataset29, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity35.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset38 = null;
        pieSectionEntity35.setDataset(pieDataset38);
        java.lang.String str40 = pieSectionEntity35.getShapeType();
        boolean boolean41 = rectangleEdge11.equals((java.lang.Object) pieSectionEntity35);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.ABSOLUTE" + "'", str20.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "rect" + "'", str40.equals("rect"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        double double7 = rectangleInsets4.calculateBottomInset((double) (short) 0);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint7 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement10.clear();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement10);
        boolean boolean13 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        java.awt.Paint paint14 = piePlot3.getLabelPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        org.jfree.data.UnknownKeyException unknownKeyException6 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.jfree.data.UnknownKeyException unknownKeyException8 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        unknownKeyException6.addSuppressed((java.lang.Throwable) unknownKeyException8);
        unknownKeyException3.addSuppressed((java.lang.Throwable) unknownKeyException8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle7.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment17, (double) 1, (double) (-1.0f));
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment21, (double) 192, (double) 100.0f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(verticalAlignment21);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        double double4 = piePlot1.getLabelLinkMargin();
        boolean boolean5 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setLabelLinksVisible(false);
        double double10 = piePlot7.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot7.setOutlinePaint(paint12);
        piePlot1.setLabelShadowPaint(paint12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        java.awt.Image image7 = projectInfo4.getLogo();
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo4.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(image7);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.lang.Object obj9 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.setBackgroundImageAlignment((int) (byte) 100);
        int int12 = jFreeChart6.getSubtitleCount();
        try {
            org.jfree.chart.plot.XYPlot xYPlot13 = jFreeChart6.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getLegendItemGraphicPadding();
        double double15 = rectangleInsets13.calculateTopOutset((double) 8);
        double double16 = rectangleInsets13.getBottom();
        boolean boolean17 = multiplePiePlot0.equals((java.lang.Object) rectangleInsets13);
        org.jfree.chart.util.TableOrder tableOrder18 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str19 = tableOrder18.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder18);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Paint paint23 = defaultDrawingSupplier21.getNextPaint();
        java.awt.Paint paint24 = defaultDrawingSupplier21.getNextOutlinePaint();
        java.awt.Paint paint25 = defaultDrawingSupplier21.getNextOutlinePaint();
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Paint paint27 = defaultDrawingSupplier21.getNextFillPaint();
        java.awt.Stroke stroke28 = defaultDrawingSupplier21.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tableOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TableOrder.BY_ROW" + "'", str19.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("org.jfree.chart.event.ChartChangeEvent[source=100]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        jFreeChart4.fireChartChanged();
        piePlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        int int7 = jFreeChart4.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = unitType0.equals((java.lang.Object) 98);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.14d, 0.0d, 4.0d, (double) 10.0f);
        java.lang.String str8 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (short) 10, (double) 0, (double) (byte) 0);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot4.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot4.getBaseSectionOutlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str14 = color13.toString();
        legendTitle10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle10.getPadding();
        double double18 = rectangleInsets16.calculateBottomInset(90.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str14.equals("java.awt.Color[r=64,g=255,b=255]"));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        piePlot1.zoom((double) 0.5f);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        int int8 = piePlot1.getBackgroundImageAlignment();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        piePlot11.setSimpleLabels(true);
        java.awt.Stroke stroke16 = piePlot11.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        piePlot18.setLabelPadding(rectangleInsets21);
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke16, rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = lineBorder23.getInsets();
        piePlot1.setSimpleLabelOffset(rectangleInsets24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot27.addChangeListener(plotChangeListener28);
        piePlot27.setSimpleLabels(true);
        int int32 = piePlot27.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator33 = piePlot27.getToolTipGenerator();
        java.awt.Stroke stroke34 = piePlot27.getLabelOutlineStroke();
        java.awt.Color color36 = java.awt.Color.GREEN;
        piePlot27.setSectionOutlinePaint((java.lang.Comparable) 255, (java.awt.Paint) color36);
        java.awt.Color color38 = java.awt.Color.lightGray;
        int int39 = color38.getTransparency();
        float[] floatArray45 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray46 = color38.getRGBColorComponents(floatArray45);
        float[] floatArray47 = color36.getRGBComponents(floatArray46);
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        java.awt.Stroke stroke50 = piePlot49.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle53 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot52.setLabelLinkStyle(pieLabelLinkStyle53);
        java.awt.Paint paint56 = piePlot52.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot52.setOutlinePaint((java.awt.Paint) color57);
        int int59 = piePlot52.getBackgroundImageAlignment();
        piePlot52.setOutlineVisible(true);
        org.jfree.data.general.PieDataset pieDataset62 = null;
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot(pieDataset62);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle64 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot63.setLabelLinkStyle(pieLabelLinkStyle64);
        java.lang.String str66 = pieLabelLinkStyle64.toString();
        java.awt.Shape[] shapeArray67 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean68 = pieLabelLinkStyle64.equals((java.lang.Object) shapeArray67);
        piePlot52.setLabelLinkStyle(pieLabelLinkStyle64);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = piePlot52.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder71 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color36, stroke50, rectangleInsets70);
        piePlot1.setInsets(rectangleInsets70, true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle53);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 15 + "'", int59 == 15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str66.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(shapeArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleInsets70);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        jFreeChart10.setNotify(true);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.lang.Object obj5 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        try {
            java.text.AttributedString attributedString8 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset6, (java.lang.Comparable) "org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        int int3 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint10 = piePlot7.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot7);
        double double12 = piePlot7.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot15.setLabelLinkStyle(pieLabelLinkStyle16);
        java.awt.Paint paint18 = piePlot15.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart19.setBorderVisible(false);
        piePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        piePlot7.setNoDataMessagePaint((java.awt.Paint) color23);
        piePlot1.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockBorder29.getInsets();
        piePlot27.setLabelPadding(rectangleInsets30);
        org.jfree.chart.ChartColor chartColor35 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot27.setLabelPaint((java.awt.Paint) chartColor35);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator37 = piePlot27.getURLGenerator();
        piePlot27.setCircular(true);
        java.awt.Paint paint40 = piePlot27.getLabelLinkPaint();
        piePlot1.setLabelPaint(paint40);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14d + "'", double12 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(pieURLGenerator37);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setLabelLinksVisible(false);
        double double5 = piePlot2.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot2.getToolTipGenerator();
        double double7 = piePlot2.getMaximumExplodePercent();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.fireChartChanged();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart6.getLegend();
        jFreeChart6.setTitle("VerticalAlignment.CENTER");
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        jFreeChart6.setTitle(textTitle14);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(legendTitle9);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        piePlot1.setNoDataMessage("NOID");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset18, (java.lang.Comparable) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        java.lang.String str23 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset21, (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot2.addChangeListener(plotChangeListener5);
        double double7 = piePlot2.getLabelGap();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.CUBIC_CURVE", (org.jfree.chart.plot.Plot) piePlot2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=100]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint5 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.addChangeListener(plotChangeListener4);
        piePlot1.setNoDataMessage("Pie Plot");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.awt.Color color9 = java.awt.Color.lightGray;
        int int10 = color9.getTransparency();
        float[] floatArray16 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray17 = color9.getRGBColorComponents(floatArray16);
        boolean boolean18 = pieLabelLinkStyle8.equals((java.lang.Object) color9);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle8);
        boolean boolean20 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot2.setOutlinePaint((java.awt.Paint) color7);
        float[] floatArray17 = new float[] { 1.0f, '#', (byte) 100, 10L, (-1) };
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 0, (int) (byte) 0, floatArray17);
        float[] floatArray19 = color7.getRGBComponents(floatArray17);
        java.awt.Color color20 = java.awt.Color.getColor("PieSection: -1, 0(100)", color7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        int int2 = pieLabelDistributor1.getItemCount();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.clear();
        java.lang.String str5 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder3 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str4 = tableOrder3.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder3);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke7 = jFreeChart6.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart6.getTitle();
        double double9 = textTitle8.getContentYOffset();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle4);
        java.awt.Paint paint7 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement10.clear();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle12.setVerticalAlignment(verticalAlignment13);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("", font16);
        legendTitle12.setItemFont(font16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot19.getPieChart();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = multiplePiePlot19.getLegendItems();
        double double22 = multiplePiePlot19.getLimit();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]", font16, (org.jfree.chart.plot.Plot) multiplePiePlot19, true);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        piePlot26.setLabelPadding(rectangleInsets29);
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot26.setLabelPaint((java.awt.Paint) chartColor34);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator36 = piePlot26.getURLGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = piePlot26.getSimpleLabelOffset();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("poly", font16, (org.jfree.chart.plot.Plot) piePlot26, false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(pieURLGenerator36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint6 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement9.clear();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getLegendItemGraphicPadding();
        double double15 = rectangleInsets13.calculateTopOutset((double) 8);
        double double16 = rectangleInsets13.getBottom();
        boolean boolean17 = multiplePiePlot0.equals((java.lang.Object) rectangleInsets13);
        java.lang.Comparable comparable18 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "Other" + "'", comparable18.equals("Other"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle15 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot14.setLabelLinkStyle(pieLabelLinkStyle15);
        java.awt.Paint paint17 = piePlot14.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot14);
        java.awt.Paint paint19 = jFreeChart18.getBackgroundPaint();
        java.awt.Paint paint20 = jFreeChart18.getBorderPaint();
        boolean boolean21 = defaultCategoryDataset0.hasListener((java.util.EventListener) jFreeChart18);
        try {
            java.lang.Number number24 = defaultCategoryDataset0.getValue((java.lang.Comparable) "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n", (java.lang.Comparable) "org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: org.jfree.data.UnknownKeyException: org.jfree.chart.event.ChartChangeEvent[source=100]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        java.awt.Font font18 = legendTitle10.getItemFont();
        double double19 = legendTitle10.getWidth();
        java.awt.Paint paint20 = legendTitle10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        java.lang.String str10 = pieSectionEntity9.toString();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity9.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity9.getToolTipText();
        pieSectionEntity9.setSectionKey((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: -1, 0(100)" + "'", str10.equals("PieSection: -1, 0(100)"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.CENTER" + "'", str13.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        java.lang.String str2 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.CLOCKWISE" + "'", str2.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        java.awt.Paint[] paintArray4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray4, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        boolean boolean8 = defaultCategoryDataset0.equals((java.lang.Object) dataset7);
        int int9 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        piePlot1.setCircular(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        piePlot16.setLabelPadding(rectangleInsets19);
        piePlot12.setInsets(rectangleInsets19);
        java.awt.Stroke stroke23 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) (-2.0d));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D9, rectangle2D10, piePlot12, (java.lang.Integer) 3, plotRenderingInfo25);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator27);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(piePlotState26);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.util.List list15 = blockContainer13.getBlocks();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = blockContainer13.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str1.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        int int9 = piePlot1.getPieIndex();
        java.awt.Font font10 = piePlot1.getNoDataMessageFont();
        double double11 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot1.getLabelDistributor();
        java.awt.Color color13 = java.awt.Color.pink;
        int int14 = color13.getBlue();
        piePlot1.setLabelPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 175 + "'", int14 == 175);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        java.awt.Paint paint15 = piePlot1.getBackgroundPaint();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setNoDataMessageFont(font16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        float float6 = piePlot3.getBackgroundAlpha();
        java.awt.Paint paint7 = piePlot3.getLabelShadowPaint();
        boolean boolean8 = blockBorder1.equals((java.lang.Object) paint7);
        java.awt.Paint paint9 = blockBorder1.getPaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.lang.String str14 = pieLabelLinkStyle12.toString();
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean16 = pieLabelLinkStyle12.equals((java.lang.Object) shapeArray15);
        boolean boolean17 = blockBorder1.equals((java.lang.Object) pieLabelLinkStyle12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str14.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        piePlot1.setShadowXOffset((double) ' ');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        java.lang.Object obj3 = piePlot1.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot12.setLabelLinkStyle(pieLabelLinkStyle13);
        java.awt.Paint paint15 = piePlot12.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot12);
        double double17 = piePlot12.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot20.setLabelLinkStyle(pieLabelLinkStyle21);
        java.awt.Paint paint23 = piePlot20.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart24.setBorderVisible(false);
        piePlot12.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        piePlot12.setNoDataMessagePaint((java.awt.Paint) color28);
        piePlot6.setBackgroundPaint((java.awt.Paint) color28);
        piePlot1.setShadowPaint((java.awt.Paint) color28);
        double double32 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMinimumArcAngleToDraw(100.0d);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.14d + "'", double17 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.14d + "'", double32 == 0.14d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) -1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        java.lang.Comparable comparable6 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n" + "'", comparable5.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n" + "'", comparable6.equals("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Comparable comparable9 = defaultKeyedValues2D1.getColumnKey((int) (short) 0);
        java.util.List list10 = defaultKeyedValues2D1.getRowKeys();
        int int12 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 0L);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "TableOrder.BY_COLUMN" + "'", comparable9.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (byte) 10, (double) (byte) 10);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle25 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot24.setLabelLinkStyle(pieLabelLinkStyle25);
        java.awt.Paint paint28 = piePlot24.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement29.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement31 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement31.clear();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot24, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) columnArrangement31);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = legendTitle33.arrange(graphics2D34);
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle33.getItemContainer();
        boolean boolean37 = blockContainer36.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockContainer36.getMargin();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = flowArrangement20.arrange(blockContainer36, graphics2D39, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle25);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(blockContainer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor(175);
        boolean boolean7 = piePlot1.equals((java.lang.Object) 175);
        piePlot1.setMinimumArcAngleToDraw((double) 10.0f);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getRootPlot();
        double double12 = piePlot1.getExplodePercent((java.lang.Comparable) "java.awt.Color[r=64,g=255,b=255]");
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "java.awt.Color[r=64,g=255,b=255]");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 98, 64, (java.lang.Comparable) 1L, "org.jfree.chart.event.ChartChangeEvent[source=100]", "java.awt.Color[r=64,g=64,b=64]");
        java.lang.String str12 = pieSectionEntity11.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str12.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle6);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 10, (double) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement14);
        flowArrangement14.clear();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        float float4 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor(175);
        boolean boolean7 = piePlot1.equals((java.lang.Object) 175);
        piePlot1.zoom(0.14d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint15 = piePlot11.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement16.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement18.clear();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) columnArrangement18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle20.setVerticalAlignment(verticalAlignment21);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("", font24);
        legendTitle20.setItemFont(font24);
        piePlot1.setLabelFont(font24);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = piePlot1.getLabelPadding();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        piePlot1.markerChanged(markerChangeEvent29);
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        int int9 = piePlot1.getPieIndex();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot1.getLegendLabelToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot12.getLegendLabelURLGenerator();
        double double14 = piePlot12.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle18);
        java.awt.Paint paint20 = piePlot17.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.title.TextTitle textTitle22 = jFreeChart21.getTitle();
        boolean boolean23 = jFreeChart21.isBorderVisible();
        piePlot12.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart21.createBufferedImage(98, (int) (byte) 1, chartRenderingInfo27);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage28);
        java.awt.Paint paint31 = piePlot1.getSectionPaint((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textTitle22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        piePlot12.setLabelPadding(rectangleInsets15);
        org.jfree.chart.ChartColor chartColor20 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot12.setLabelPaint((java.awt.Paint) chartColor20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot12.getURLGenerator();
        piePlot12.setCircular(true);
        java.awt.Font font25 = piePlot12.getNoDataMessageFont();
        textTitle7.setFont(font25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        try {
            org.jfree.chart.util.Size2D size2D29 = textTitle7.arrange(graphics2D27, rectangleConstraint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle7.getPosition();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        org.jfree.chart.StrokeMap strokeMap14 = new org.jfree.chart.StrokeMap();
        boolean boolean16 = strokeMap14.containsKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke18 = null;
        strokeMap14.put((java.lang.Comparable) 0.0f, stroke18);
        boolean boolean20 = legendTitle10.equals((java.lang.Object) 0.0f);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle10.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle10.getPosition();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        piePlot1.setLabelPadding(rectangleInsets4);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        piePlot1.setCircular(true);
        java.awt.Paint paint14 = piePlot1.getLabelLinkPaint();
        java.awt.Paint paint15 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        java.lang.Object obj6 = null;
        boolean boolean7 = defaultCategoryDataset0.equals(obj6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        piePlot13.setLabelPadding(rectangleInsets16);
        piePlot9.setInsets(rectangleInsets16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot9.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = piePlot9.getLabelLinkStyle();
        boolean boolean21 = piePlot9.getLabelLinksVisible();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot9);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        org.jfree.data.general.PieDataset pieDataset10 = pieSectionEntity9.getDataset();
        java.lang.String str11 = pieSectionEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: -1, 0(100)" + "'", str11.equals("PieSection: -1, 0(100)"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        double double22 = rectangleInsets18.getLeft();
        double double24 = rectangleInsets18.extendWidth((double) 128);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 132.0d + "'", double24 == 132.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("", font14);
        legendTitle10.setItemFont(font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle10.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.JFreeChart jFreeChart20 = titleChangeEvent19.getChart();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNull(jFreeChart20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, (int) 'a', (int) (byte) 10, (java.lang.Comparable) 35.0d, "poly", "RectangleAnchor.BOTTOM");
        pieSectionEntity8.setURLText("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot13.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Paint paint16 = piePlot13.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (-1));
        textTitle18.setPadding(rectangleInsets21);
        double double26 = rectangleInsets21.calculateRightInset((double) 192);
        boolean boolean27 = pieSectionEntity8.equals((java.lang.Object) rectangleInsets21);
        double double29 = rectangleInsets21.calculateBottomInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle10.getItemContainer();
        boolean boolean19 = legendTitle10.getNotify();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        java.text.NumberFormat numberFormat18 = standardPieSectionLabelGenerator16.getPercentFormat();
        java.awt.Font font20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot22.setLabelLinkStyle(pieLabelLinkStyle23);
        java.awt.Paint paint26 = piePlot22.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement27.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement29.clear();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot22, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement29);
        org.jfree.chart.plot.Plot plot32 = piePlot22.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        piePlot22.setLegendLabelURLGenerator(pieURLGenerator33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        piePlot37.addChangeListener(plotChangeListener38);
        piePlot37.setSimpleLabels(true);
        java.awt.Stroke stroke42 = piePlot37.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = blockBorder46.getInsets();
        piePlot44.setLabelPadding(rectangleInsets47);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color35, stroke42, rectangleInsets47);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = lineBorder49.getInsets();
        double double52 = rectangleInsets50.trimWidth((double) 0L);
        double double53 = rectangleInsets50.getRight();
        piePlot22.setInsets(rectangleInsets50, true);
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("java.awt.Color[r=64,g=64,b=64]", font20, (org.jfree.chart.plot.Plot) piePlot22, true);
        boolean boolean58 = standardPieSectionLabelGenerator16.equals((java.lang.Object) piePlot22);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-2.0d) + "'", double52 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot2.setLabelOutlineStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke5, rectangleInsets7);
        double double10 = rectangleInsets7.calculateBottomInset((double) 0.5f);
        double double12 = rectangleInsets7.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.awt.Color color1 = java.awt.Color.getColor("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle10.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement19 = blockContainer18.getArrangement();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(arrangement19);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.title.Title title15 = titleChangeEvent14.getTitle();
        java.awt.geom.Rectangle2D rectangle2D16 = title15.getBounds();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(title15);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.lang.String str11 = textTitle7.getURLText();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str13 = rectangleEdge12.toString();
        textTitle7.setPosition(rectangleEdge12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.TOP" + "'", str13.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.util.List list2 = defaultKeyedValues2D0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart6.getLegend();
        jFreeChart6.clearSubtitles();
        jFreeChart6.setNotify(true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Color color23 = java.awt.Color.lightGray;
        int int24 = color23.getTransparency();
        float[] floatArray30 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray31 = color23.getRGBColorComponents(floatArray30);
        float[] floatArray32 = java.awt.Color.RGBtoHSB(175, 98, 192, floatArray30);
        float[] floatArray33 = color18.getRGBColorComponents(floatArray32);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(legendTitle14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        java.awt.Stroke stroke18 = piePlot1.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot20.getLegendLabelURLGenerator();
        double double22 = piePlot20.getMaximumExplodePercent();
        java.awt.Paint paint23 = piePlot20.getLabelBackgroundPaint();
        java.awt.Stroke stroke24 = piePlot20.getLabelOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke24);
        java.awt.Stroke stroke27 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0.4d);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        boolean boolean14 = piePlot13.getSectionOutlinesVisible();
        boolean boolean15 = piePlot13.getSectionOutlinesVisible();
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot13);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        piePlot19.setSimpleLabels(true);
        java.awt.Stroke stroke24 = piePlot19.getLabelLinkStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 1, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = piePlot13.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        boolean boolean3 = strokeMap1.containsKey((java.lang.Comparable) (byte) 100);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean5 = strokeMap1.equals((java.lang.Object) projectInfo4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo0.setName("{0}");
        projectInfo0.addOptionalLibrary("java.awt.Color[r=0,g=0,b=192]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        boolean boolean8 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=192]", (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        org.jfree.chart.title.TextTitle textTitle9 = null;
        jFreeChart6.setTitle(textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart6.getLegend((int) 'a');
        java.lang.Object obj13 = jFreeChart6.clone();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(legendTitle12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart10.createBufferedImage((int) (byte) -1, (int) (byte) 100, 0, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart6.setBorderVisible(false);
        jFreeChart6.setBorderVisible(true);
        jFreeChart6.fireChartChanged();
        java.awt.Color color12 = java.awt.Color.GREEN;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot15.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot15.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        piePlot19.setLabelPadding(rectangleInsets22);
        piePlot15.setInsets(rectangleInsets22);
        jFreeChart6.setPadding(rectangleInsets22);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart6.getLegend();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        org.jfree.chart.util.Size2D size2D29 = legendTitle26.arrange(graphics2D27, rectangleConstraint28);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(legendTitle26);
        org.junit.Assert.assertNotNull(size2D29);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) '#');
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) rectangleInsets7);
        java.text.AttributedString attributedString10 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) ' ', attributedString10);
        java.text.NumberFormat numberFormat12 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(numberFormat12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        java.lang.Object obj15 = blockContainer13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (byte) 10, (double) (byte) 10);
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.chart.ui.ProjectInfo projectInfo22 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean23 = flowArrangement20.equals((java.lang.Object) projectInfo22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        piePlot25.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot25);
        boolean boolean31 = projectInfo22.equals((java.lang.Object) piePlot25);
        piePlot25.setBackgroundAlpha(0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(projectInfo22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) multiplePiePlot2);
        java.awt.Paint paint4 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot2.getLegendItems();
        java.awt.Paint[] paintArray6 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray7 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paintArray7, dataset8);
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setLabelLinksVisible(false);
        double double17 = piePlot14.getLabelLinkMargin();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator18 = piePlot14.getToolTipGenerator();
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot14.setOutlinePaint(paint19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color22 = java.awt.Color.lightGray;
        int int23 = color22.getTransparency();
        float[] floatArray29 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray30 = color22.getRGBColorComponents(floatArray29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int32 = color31.getTransparency();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int34 = color33.getTransparency();
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { paint19, color21, color22, color31, color33 };
        java.awt.Paint[] paintArray36 = null;
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray35, paintArray36, strokeArray37, strokeArray38, shapeArray39);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, strokeArray10, strokeArray11, shapeArray39);
        multiplePiePlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNull(pieToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(shapeArray39);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.fireChartChanged();
        java.awt.Image image9 = jFreeChart6.getBackgroundImage();
        java.awt.Image image10 = jFreeChart6.getBackgroundImage();
        jFreeChart6.setBorderVisible(true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "hi!");
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("VerticalAlignment.TOP");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key VerticalAlignment.TOP");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        paintMap0.put((java.lang.Comparable) (-16777216), (java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray13 = new float[] { '#', 0.0f, (byte) 1, 10L, (-1.0f) };
        float[] floatArray14 = color7.getColorComponents(floatArray13);
        boolean boolean15 = blockBorder5.equals((java.lang.Object) color7);
        boolean boolean16 = paintMap0.equals((java.lang.Object) boolean15);
        java.lang.Object obj17 = paintMap0.clone();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (byte) 1, (float) 192, (float) ' ');
        paintMap0.put((java.lang.Comparable) 1L, (java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockFrame blockFrame16 = legendTitle10.getFrame();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(blockFrame16);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.fireChartChanged();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        piePlot4.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot4);
        jFreeChart1.plotChanged(plotChangeEvent9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = plotChangeEvent9.getType();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke4);
        java.lang.Class<?> wildcardClass6 = piePlot1.getClass();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) (-246), (java.lang.Comparable) 100, (java.lang.Comparable) "TableOrder.BY_COLUMN");
        defaultKeyedValues2D1.removeRow((int) (short) 0);
        java.lang.Comparable comparable9 = defaultKeyedValues2D1.getColumnKey((int) (short) 0);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", (java.lang.Comparable) (-246));
        java.util.List list13 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "TableOrder.BY_COLUMN" + "'", comparable9.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setIgnoreNullValues(true);
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        piePlot1.setLabelPaint((java.awt.Paint) color9);
        double double11 = piePlot1.getLabelGap();
        java.awt.Color color12 = java.awt.Color.ORANGE;
        java.awt.Color color13 = color12.brighter();
        piePlot1.setShadowPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        piePlot1.setNoDataMessage("RectangleAnchor.BOTTOM");
        double double8 = piePlot1.getStartAngle();
        piePlot1.setCircular(false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        piePlot4.setSimpleLabels(true);
        int int9 = piePlot4.getBackgroundImageAlignment();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot4.notifyListeners(plotChangeEvent10);
        boolean boolean12 = lineBorder0.equals((java.lang.Object) plotChangeEvent10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset18, (java.lang.Comparable) 10L);
        java.text.AttributedString attributedString22 = standardPieSectionLabelGenerator16.getAttributedLabel((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(attributedString22);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Rotation.CLOCKWISE", "poly", "ChartChangeEventType.GENERAL", "");
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int3 = java.awt.Color.HSBtoRGB((float) 8, (float) (short) 0, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        float float8 = piePlot1.getForegroundAlpha();
        int int9 = piePlot1.getPieIndex();
        java.awt.Font font10 = piePlot1.getNoDataMessageFont();
        double double11 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        piePlot1.handleClick((int) (short) 1, (int) 'a', plotRenderingInfo15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean16 = color14.equals((java.lang.Object) rectangleAnchor15);
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor15);
        java.awt.Font font18 = legendTitle10.getItemFont();
        double double19 = legendTitle10.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle10.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) true);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setSimpleLabels(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot5.getLabelGenerator();
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) pieSectionLabelGenerator10);
        java.util.List list12 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.setValue((java.lang.Number) (-1.0d), (java.lang.Comparable) (-2.0d), (java.lang.Comparable) 8);
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-16777216));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -16777216");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        legendTitle10.setHeight((double) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str17 = rectangleAnchor16.toString();
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str17.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        piePlot1.setStartAngle((double) 1L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color13 = java.awt.Color.lightGray;
        int int14 = color13.getTransparency();
        float[] floatArray20 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray21 = color13.getRGBColorComponents(floatArray20);
        float[] floatArray22 = java.awt.Color.RGBtoHSB(175, 98, 192, floatArray20);
        float[] floatArray23 = color9.getRGBComponents(floatArray20);
        float[] floatArray24 = color8.getComponents(floatArray20);
        jFreeChart6.setBorderPaint((java.awt.Paint) color8);
        float float26 = jFreeChart6.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setURLText("");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        java.lang.String str6 = chartEntity1.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.addValue((java.lang.Number) 192, (java.lang.Comparable) 64, (java.lang.Comparable) (-589829));
        java.lang.Object obj6 = null;
        boolean boolean7 = defaultCategoryDataset0.equals(obj6);
        defaultCategoryDataset0.clear();
        java.util.List list9 = defaultCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        boolean boolean12 = defaultCategoryDataset0.equals((java.lang.Object) "");
        defaultCategoryDataset0.setValue((double) 0.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) 0.0d);
        defaultCategoryDataset0.setValue(12.0d, (java.lang.Comparable) (byte) -1, (java.lang.Comparable) "Pie Plot");
        int int22 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 37.0d);
        org.jfree.data.general.DatasetGroup datasetGroup23 = defaultCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup23);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.awt.Paint paint12 = piePlot1.getNoDataMessagePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
        projectInfo14.setLicenceText("");
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean19 = projectInfo17.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library25 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str26 = library25.getInfo();
        boolean boolean27 = standardPieSectionLabelGenerator20.equals((java.lang.Object) library25);
        projectInfo17.addLibrary(library25);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle32 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot31.setLabelLinkStyle(pieLabelLinkStyle32);
        java.awt.Paint paint34 = piePlot31.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot31);
        jFreeChart35.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart35.createBufferedImage((int) (short) 10, 100, 0.0d, (double) (-1.0f), chartRenderingInfo42);
        projectInfo17.setLogo((java.awt.Image) bufferedImage43);
        projectInfo14.setLogo((java.awt.Image) bufferedImage43);
        piePlot1.setBackgroundImage((java.awt.Image) bufferedImage43);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(projectInfo14);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(bufferedImage43);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 (http://www.jfree.org/jfreechart/index.html).\n{0} LICENCE TERMS:\n");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        java.awt.Paint paint12 = piePlot1.getNoDataMessagePaint();
        java.awt.Image image13 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        java.lang.Object obj3 = piePlot1.clone();
        piePlot1.setShadowYOffset((double) (-1));
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(175);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.sort();
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle10.getItemContainer();
        boolean boolean14 = blockContainer13.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockContainer13.getMargin();
        double double17 = rectangleInsets15.calculateTopOutset((double) (-1.0f));
        double double19 = rectangleInsets15.extendHeight((double) ' ');
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 32.0d + "'", double19 == 32.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot6.setLabelLinkStyle(pieLabelLinkStyle7);
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        int int14 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint15 = null;
        jFreeChart10.setBorderPaint(paint15);
        float float17 = jFreeChart10.getBackgroundImageAlpha();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = null;
        try {
            jFreeChart10.titleChanged(titleChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle11);
        java.awt.Paint paint13 = piePlot10.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot10);
        jFreeChart14.setBorderVisible(false);
        jFreeChart14.setBorderVisible(true);
        jFreeChart14.fireChartChanged();
        java.awt.Color color20 = java.awt.Color.GREEN;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color20);
        int int22 = color20.getGreen();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color20);
        piePlot1.setNoDataMessage("{0} version 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0.\nPieLabelLinkStyle.QUAD_CURVE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().hi!  ().hi!  ().hi!  ().hi!  ().hi!  ().{0} 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0 ().\n{0} LICENCE TERMS:\norg.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        jFreeChart6.setBackgroundImageAlpha((float) 2);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart6.addProgressListener(chartProgressListener11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        textTitle7.setFont(font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle7.setPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        textTitle7.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle7.setTextAlignment(horizontalAlignment15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment17, (double) 1, (double) (-1.0f));
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean22 = horizontalAlignment15.equals((java.lang.Object) color21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getLabelBackgroundPaint();
        java.awt.Font font6 = piePlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity13 = new org.jfree.chart.entity.PieSectionEntity(shape6, pieDataset7, (-1), 0, (java.lang.Comparable) (byte) 100, "VerticalAlignment.CENTER", "");
        piePlot1.setLegendItemShape(shape6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset18, (java.lang.Comparable) 10L);
        java.lang.String str21 = standardPieSectionLabelGenerator16.getLabelFormat();
        java.text.AttributedString attributedString23 = null;
        try {
            standardPieSectionLabelGenerator16.setAttributedLabel((int) (byte) -1, attributedString23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str21.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean7 = projectInfo5.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "", "", "");
        java.lang.String str14 = library13.getInfo();
        boolean boolean15 = standardPieSectionLabelGenerator8.equals((java.lang.Object) library13);
        projectInfo5.addLibrary(library13);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean18 = library13.equals((java.lang.Object) paint17);
        textTitle4.setPaint(paint17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle4);
        textTitle4.setExpandToFitSpace(false);
        java.lang.String str23 = textTitle4.getURLText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        piePlot1.setForegroundAlpha((float) '#');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot9.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        piePlot13.setLabelPadding(rectangleInsets16);
        piePlot9.setInsets(rectangleInsets16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = piePlot9.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier19);
        piePlot1.setSimpleLabels(false);
        piePlot1.setBackgroundImageAlignment((-254));
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(drawingSupplier19);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.plot.Plot plot4 = multiplePiePlot0.getRootPlot();
        org.jfree.data.general.DatasetGroup datasetGroup5 = multiplePiePlot0.getDatasetGroup();
        org.jfree.chart.util.TableOrder tableOrder6 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str7 = tableOrder6.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder6);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TableOrder.BY_ROW" + "'", str7.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        boolean boolean8 = jFreeChart6.isBorderVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        piePlot10.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.plot.Plot plot16 = plotChangeEvent15.getPlot();
        jFreeChart6.plotChanged(plotChangeEvent15);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder20.getInsets();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle25 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot24.setLabelLinkStyle(pieLabelLinkStyle25);
        java.awt.Paint paint28 = piePlot24.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement29.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement31 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement31.clear();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot24, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) columnArrangement31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle33.setVerticalAlignment(verticalAlignment34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = null;
        org.jfree.chart.util.Size2D size2D38 = legendTitle33.arrange(graphics2D36, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) (-589829), 0.0d, rectangleAnchor41);
        lineBorder20.draw(graphics2D22, rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets19.createOutsetRectangle(rectangle2D42, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = lineBorder50.getInsets();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle55 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot54.setLabelLinkStyle(pieLabelLinkStyle55);
        java.awt.Paint paint58 = piePlot54.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement59.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement61 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement61.clear();
        org.jfree.chart.title.LegendTitle legendTitle63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot54, (org.jfree.chart.block.Arrangement) flowArrangement59, (org.jfree.chart.block.Arrangement) columnArrangement61);
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle63.setVerticalAlignment(verticalAlignment64);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = null;
        org.jfree.chart.util.Size2D size2D68 = legendTitle63.arrange(graphics2D66, rectangleConstraint67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, (double) (-589829), 0.0d, rectangleAnchor71);
        lineBorder50.draw(graphics2D52, rectangle2D72);
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets49.createOutsetRectangle(rectangle2D72, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D78 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D72, rectangleAnchor77);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = null;
        try {
            jFreeChart6.draw(graphics2D18, rectangle2D42, point2D78, chartRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle25);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(verticalAlignment64);
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangleAnchor77);
        org.junit.Assert.assertNotNull(point2D78);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getParent();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        piePlot8.setLabelPadding(rectangleInsets11);
        org.jfree.chart.ChartColor chartColor16 = new org.jfree.chart.ChartColor(0, (int) (short) 0, (int) (short) 10);
        piePlot8.setLabelPaint((java.awt.Paint) chartColor16);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = piePlot8.getURLGenerator();
        piePlot8.setCircular(true);
        java.awt.Font font21 = piePlot8.getNoDataMessageFont();
        piePlot1.setLabelFont(font21);
        piePlot1.setBackgroundAlpha(0.0f);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(pieURLGenerator18);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        java.awt.Stroke stroke8 = piePlot1.getLabelOutlineStroke();
        java.awt.Color color10 = java.awt.Color.GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 255, (java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.lightGray;
        int int13 = color12.getTransparency();
        float[] floatArray19 = new float[] { 2, 0L, 0L, (short) 100, (short) 0 };
        float[] floatArray20 = color12.getRGBColorComponents(floatArray19);
        float[] floatArray21 = color10.getRGBComponents(floatArray20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Stroke stroke24 = piePlot23.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot26.setLabelLinkStyle(pieLabelLinkStyle27);
        java.awt.Paint paint30 = piePlot26.getSectionPaint((java.lang.Comparable) (short) 100);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot26.setOutlinePaint((java.awt.Paint) color31);
        int int33 = piePlot26.getBackgroundImageAlignment();
        piePlot26.setOutlineVisible(true);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle38 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot37.setLabelLinkStyle(pieLabelLinkStyle38);
        java.lang.String str40 = pieLabelLinkStyle38.toString();
        java.awt.Shape[] shapeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean42 = pieLabelLinkStyle38.equals((java.lang.Object) shapeArray41);
        piePlot26.setLabelLinkStyle(pieLabelLinkStyle38);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = piePlot26.getLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder45 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke24, rectangleInsets44);
        double double47 = rectangleInsets44.calculateLeftInset(4.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str40.equals("PieLabelLinkStyle.QUAD_CURVE"));
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setSimpleLabels(true);
        int int6 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        java.awt.Image image8 = piePlot1.getBackgroundImage();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            piePlot1.setSimpleLabelOffset(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        java.lang.String str8 = textTitle7.getURLText();
        textTitle7.setURLText("{0}");
        java.awt.Paint paint11 = textTitle7.getPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font8 = piePlot2.getNoDataMessageFont();
        boolean boolean9 = lineBorder0.equals((java.lang.Object) font8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor25 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor25);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle3);
        java.awt.Paint paint5 = piePlot2.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=100]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        org.jfree.chart.title.TextTitle textTitle9 = null;
        jFreeChart6.setTitle(textTitle9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart6.getLegend((int) 'a');
        jFreeChart6.setTitle("hi!");
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(legendTitle12);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle2);
        java.awt.Paint paint5 = piePlot1.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement6.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle10.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle10.getLegendItemGraphicEdge();
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font15);
        java.lang.String str17 = textTitle16.getText();
        java.awt.Paint paint18 = textTitle16.getPaint();
        legendTitle10.setItemPaint(paint18);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder3 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str4 = tableOrder3.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder3);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list8 = defaultCategoryDataset7.getColumnKeys();
        jFreeChart6.setSubtitles(list8);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TableOrder.BY_ROW", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMinimumArcAngleToDraw((double) 100.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle8);
        java.awt.Paint paint11 = piePlot7.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement12.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement14.clear();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getLegendItemGraphicPadding();
        double double20 = rectangleInsets18.calculateTopOutset((double) 8);
        piePlot1.setSimpleLabelOffset(rectangleInsets18);
        piePlot1.zoom((-2.0d));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = piePlot1.getDrawingSupplier();
        piePlot1.setStartAngle(0.025d);
        piePlot1.setExplodePercent((java.lang.Comparable) (-16777216), (double) 10.0f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(drawingSupplier24);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Font font7 = piePlot1.getNoDataMessageFont();
        java.awt.Paint paint9 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.025d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle12);
        java.awt.Paint paint15 = piePlot11.getSectionPaint((java.lang.Comparable) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement16.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement18.clear();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) columnArrangement18);
        org.jfree.chart.plot.Plot plot21 = piePlot11.getRootPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = null;
        piePlot11.setLegendLabelURLGenerator(pieURLGenerator22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        piePlot26.setSimpleLabels(true);
        java.awt.Stroke stroke31 = piePlot26.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockBorder35.getInsets();
        piePlot33.setLabelPadding(rectangleInsets36);
        org.jfree.chart.block.LineBorder lineBorder38 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color24, stroke31, rectangleInsets36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = lineBorder38.getInsets();
        double double41 = rectangleInsets39.trimWidth((double) 0L);
        double double42 = rectangleInsets39.getRight();
        piePlot11.setInsets(rectangleInsets39, true);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle47 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        piePlot46.setLabelLinkStyle(pieLabelLinkStyle47);
        java.awt.Paint paint49 = piePlot46.getLabelLinkPaint();
        java.awt.Stroke stroke50 = piePlot46.getLabelLinkStroke();
        boolean boolean51 = rectangleInsets39.equals((java.lang.Object) piePlot46);
        double double53 = rectangleInsets39.calculateLeftInset((double) 10L);
        piePlot1.setSimpleLabelOffset(rectangleInsets39);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-2.0d) + "'", double41 == (-2.0d));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
    }
}

