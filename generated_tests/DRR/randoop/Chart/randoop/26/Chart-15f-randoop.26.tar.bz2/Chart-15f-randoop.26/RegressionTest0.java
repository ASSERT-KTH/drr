import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis1.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray37);
        try {
            org.jfree.data.general.PieDataset pieDataset40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset38, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        waferMapPlot0.notifyListeners(plotChangeEvent1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=0,b=0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            multiplePiePlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1.0f), (double) (-1), (int) (byte) -1, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=0,b=0]", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double4 = dateAxis0.valueToJava2D((double) (byte) 1, rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = java.awt.Color.red;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Font font2 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '4', (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        double double3 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-5d + "'", double3 == 1.0E-5d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0);
        double double3 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double47 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 0.0d, (java.lang.Comparable) 100.0f, categoryDataset43, (double) (byte) 100, rectangle2D45, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.util.TableOrder tableOrder3 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = numberAxis3D1.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Color color2 = java.awt.Color.red;
        valueMarker1.setPaint((java.awt.Paint) color2);
        boolean boolean5 = color2.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) 2.0f, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=0,b=0]", font2, (java.awt.Paint) color4, (float) (-1L), 15, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (double) 1L, 1.0f, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        try {
            ringPlot0.setSeparatorPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = null;
        try {
            categoryPlot46.addDomainMarker(categoryMarker47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font1);
        java.awt.Paint paint3 = textFragment2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor54 = null;
        try {
            ringPlot47.setLabelDistributor(abstractPieLabelDistributor54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (byte) 10);
        org.jfree.chart.block.Block block5 = null;
        java.lang.Object obj6 = null;
        columnArrangement4.add(block5, obj6);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        try {
            org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset41, (-16711936));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, 2.0f, (float) 1, textBlockAnchor4, (float) 100, (float) 1, 0.0d);
        org.jfree.chart.text.TextLine textLine9 = null;
        textBlock0.addLine(textLine9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        categoryAxis1.setLabelAngle((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double10 = categoryAxis1.getCategoryEnd(10, 100, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Color color2 = java.awt.Color.red;
        valueMarker1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.clearRangeAxes();
        java.awt.Paint paint55 = categoryPlot46.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        multiplePiePlot0.setLimit((double) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        java.awt.Stroke stroke49 = piePlot48.getLabelOutlineStroke();
        categoryPlot46.setRangeCrosshairStroke(stroke49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        boolean boolean55 = categoryPlot46.render(graphics2D51, rectangle2D52, (int) (byte) 1, plotRenderingInfo54);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Color color1 = java.awt.Color.PINK;
        waferMapPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot0.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomDomainAxes((double) 10L, plotRenderingInfo48, point2D49);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = null;
        try {
            categoryPlot46.addDomainMarker(categoryMarker51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.lang.Object obj6 = blockContainer0.draw(graphics2D3, rectangle2D4, (java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        java.lang.String str2 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        java.lang.Object obj3 = legendItemCollection2.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        float float8 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint5 = waferMapPlot4.getBackgroundPaint();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        categoryAxis1.setLabelAngle((double) 0.5f);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) '4');
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=0,b=0]", font2, (java.awt.Paint) color4, (float) '4', 0, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (byte) 10);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        boolean boolean58 = categoryPlot46.render(graphics2D54, rectangle2D55, (int) ' ', plotRenderingInfo57);
        java.awt.Stroke stroke59 = null;
        try {
            categoryPlot46.setRangeCrosshairStroke(stroke59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.6711944E7d), (double) 10L, (double) 11, (double) (byte) 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(0.4d);
        org.jfree.chart.util.Size2D size2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint4.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(4.0d);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, true, true);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rangeType6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16711681) + "'", int1 == (-16711681));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        java.lang.String str1 = range0.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Range[0.0,1.0]" + "'", str1.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0.0f, (double) 100, (double) (-16711936), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot47.getDomainAxisLocation((int) (short) 100);
        boolean boolean50 = chartChangeEventType0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Range[0.0,1.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = blockContainer3.arrange(graphics2D4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint10 = ringPlot8.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke11 = ringPlot8.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color7, stroke11);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer3, (java.lang.Object) valueMarker12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.ValueMarker cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 10L);
        boolean boolean5 = range1.contains((double) (byte) 10);
        dateAxis0.setDefaultAutoRange(range1);
        double double8 = range1.constrain(0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        piePlot1.setStartAngle((double) 0);
        piePlot1.setMaximumLabelWidth((double) 0.0f);
        boolean boolean7 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = categoryPlot46.getDomainAxis(1);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(categoryAxis57);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainZeroBaselineVisible(false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        java.lang.Object obj3 = null;
        boolean boolean4 = textLine2.equals(obj3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker49.setPaint((java.awt.Paint) color50);
        categoryPlot46.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot46.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(sortOrder53);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getLicenceName();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer((int) (byte) 0, xYItemRenderer7, true);
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        java.lang.String str3 = dateAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        java.awt.Shape shape8 = piePlot1.getLegendItemShape();
        piePlot1.setLabelGap((double) (byte) 10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot46.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(sortOrder56);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation55, true);
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace58, false);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color1 = java.awt.Color.getColor("Category Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, (float) (short) 10, (float) '4');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer51);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        categoryPlot52.setRangeCrosshairStroke(stroke55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot52.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot52.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation58);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 4.0d, (double) (-1.0f), (double) 100, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        double double3 = blockContainer0.getWidth();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.zoom((double) 100.0f);
        categoryPlot46.clearAnnotations();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            float float5 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        java.awt.Stroke stroke49 = piePlot48.getLabelOutlineStroke();
        categoryPlot46.setRangeCrosshairStroke(stroke49);
        java.awt.Stroke stroke51 = categoryPlot46.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        projectInfo7.setCopyright("Category Plot");
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "Category Plot", jFreeChart11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = chartChangeEvent12.getType();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) 10L);
        boolean boolean8 = range4.contains((double) (byte) 10);
        dateAxis3.setDefaultAutoRange(range4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint2.toRangeHeight(range4);
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        textBlock11.draw(graphics2D12, 2.0f, (float) 1, textBlockAnchor15, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock11.calculateDimensions(graphics2D20);
        org.jfree.chart.util.Size2D size2D22 = rectangleConstraint2.calculateConstrainedSize(size2D21);
        size2D21.setWidth((double) (short) 10);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        double double5 = dateAxis1.getUpperBound();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 10L);
        dateAxis1.setRange(range6);
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range6, 10.0d, (double) (-1));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment14, 0.0d, (double) (byte) 10);
        java.lang.Object obj18 = null;
        boolean boolean19 = columnArrangement17.equals(obj18);
        boolean boolean20 = range6.equals((java.lang.Object) columnArrangement17);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1.0f), (double) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        java.awt.Paint paint47 = dateAxis44.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double51 = dateAxis44.lengthToJava2D(0.0d, rectangle2D49, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { dateTickUnit3, 1.0E-5d, (short) 1, date6, 100L, 100.0f };
        double[] doubleArray18 = new double[] { 10L, 'a', 100, 0.05d, 10, 0.4d };
        double[][] doubleArray19 = new double[][] { doubleArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "Category Plot", doubleArray19);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray9, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 10L);
        boolean boolean5 = range1.contains((double) (byte) 10);
        dateAxis0.setDefaultAutoRange(range1);
        dateAxis0.setRange(0.0d, (double) 10);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("{0}");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        int int48 = categoryPlot46.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot46.zoomDomainAxes((double) (byte) 1, plotRenderingInfo50, point2D51, false);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker49.setPaint((java.awt.Paint) color50);
        categoryPlot46.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot46.getDomainAxis(0);
        categoryPlot46.setBackgroundImageAlignment(100);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(categoryAxis54);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelURL("");
        java.lang.String str5 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.getSeparatorsVisible();
        java.awt.Shape shape9 = ringPlot7.getLegendItemShape();
        dateAxis6.setRightArrow(shape9);
        ringPlot0.setLegendItemShape(shape9);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape1 = ringPlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        waferMapPlot2.zoom((double) (short) -1);
        waferMapPlot2.zoom(0.0d);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        waferMapPlot2.setRenderer(waferMapRenderer7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        double double10 = rectangleInsets8.calculateLeftOutset(0.0d);
        blockContainer0.setPadding(rectangleInsets8);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        try {
            java.lang.Object obj15 = blockContainer0.draw(graphics2D12, rectangle2D13, (java.lang.Object) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 10L);
        boolean boolean9 = range5.contains((double) (byte) 10);
        dateAxis4.setDefaultAutoRange(range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint3.toRangeHeight(range5);
        boolean boolean12 = lineBorder0.equals((java.lang.Object) range5);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer4, jFreeChart5);
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font8);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer4, (java.lang.Object) textLine9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.text.TextLine cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer0, jFreeChart1);
        boolean boolean3 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 10L);
        boolean boolean5 = range1.contains((double) (byte) 10);
        dateAxis0.setDefaultAutoRange(range1);
        double double7 = range1.getLength();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.awt.Color color4 = java.awt.Color.red;
        java.lang.String str5 = color4.toString();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color4, stroke6);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color4);
        double double9 = multiplePiePlot0.getLimit();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker12.setPaint((java.awt.Paint) color13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Stroke stroke17 = piePlot16.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color13, stroke17);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str5.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        ringPlot0.setShadowXOffset(0.0d);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Color color7 = java.awt.Color.red;
        valueMarker6.setPaint((java.awt.Paint) color7);
        java.awt.Stroke stroke9 = valueMarker6.getOutlineStroke();
        ringPlot0.setBaseSectionOutlineStroke(stroke9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        int int6 = xYPlot0.getRangeAxisCount();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color3, stroke7);
        valueMarker8.setAlpha((float) (byte) 0);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray21, numberArray28, numberArray35, numberArray42, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray50);
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, (org.jfree.chart.axis.ValueAxis) dateAxis55, categoryItemRenderer56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = ringPlot58.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint62 = categoryAxis61.getAxisLinePaint();
        ringPlot58.setLabelOutlinePaint(paint62);
        categoryPlot57.setParent((org.jfree.chart.plot.Plot) ringPlot58);
        categoryPlot57.zoom((double) 100.0f);
        boolean boolean67 = valueMarker8.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        java.awt.Paint paint2 = null;
        try {
            xYPlot0.setDomainGridlinePaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        piePlot1.setCircular(true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Rotation.CLOCKWISE");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        int int7 = xYPlot0.indexOf(xYDataset6);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        java.awt.Stroke stroke9 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        double double10 = rectangleInsets8.calculateLeftOutset(0.0d);
        blockContainer0.setPadding(rectangleInsets8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets8.createInsetRectangle(rectangle2D12, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0);
        double double4 = rectangleInsets0.trimWidth((double) (-16711936));
        double double6 = rectangleInsets0.extendWidth((double) '4');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6711944E7d) + "'", double4 == (-1.6711944E7d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 60.0d + "'", double6 == 60.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        float[] floatArray9 = new float[] { (byte) 0, (-1), 100L, ' ', 0L };
        float[] floatArray10 = color3.getComponents(floatArray9);
        float[] floatArray11 = color2.getColorComponents(floatArray10);
        try {
            float[] floatArray12 = color0.getComponents(colorSpace1, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        boolean boolean4 = textAnchor0.equals((java.lang.Object) "java.awt.Color[r=255,g=0,b=0]");
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image11, "", "", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, (double) 10.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint4 = ringPlot2.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke5 = ringPlot2.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) 10L);
        boolean boolean7 = range3.contains((double) (byte) 10);
        dateAxis1.setRange(range3, true, false);
        boolean boolean11 = dateAxis1.isInverted();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        java.awt.Stroke stroke49 = piePlot48.getLabelOutlineStroke();
        categoryPlot46.setRangeCrosshairStroke(stroke49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D54 = xYPlot53.getQuadrantOrigin();
        categoryPlot46.zoomRangeAxes((double) (byte) -1, plotRenderingInfo52, point2D54, false);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setShadowXOffset((double) 0L);
        ringPlot0.setOuterSeparatorExtension((double) '4');
        double double6 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets12.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray12, numberArray19, numberArray26, numberArray33, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray41);
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer47);
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        java.awt.Stroke stroke51 = piePlot50.getLabelOutlineStroke();
        categoryPlot48.setRangeCrosshairStroke(stroke51);
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke51);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date49 = dateAxis48.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline50 = null;
        dateAxis48.setTimeline(timeline50);
        double double52 = dateAxis48.getUpperBound();
        org.jfree.data.Range range53 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range53, (double) 10L);
        dateAxis48.setRange(range53);
        org.jfree.data.Range range59 = org.jfree.data.Range.expand(range53, 10.0d, (double) (-1));
        dateAxis44.setRangeWithMargins(range53);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(0.4d);
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker49.setPaint((java.awt.Paint) color50);
        categoryPlot46.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis54.setLabelURL("");
        java.util.List list57 = categoryPlot46.getCategoriesForAxis(categoryAxis54);
        java.util.Collection collection58 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list57);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(collection58);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        categoryPlot46.clearAnnotations();
        java.lang.Object obj57 = categoryPlot46.clone();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setFixedDimension(1.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit11, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(tableOrder4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint3 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot1.setNoDataMessageFont(font4);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, categoryItemRenderer55);
        java.awt.Paint paint57 = dateAxis54.getTickMarkPaint();
        org.jfree.chart.block.BlockBorder blockBorder58 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 1, (double) (-16711936), (double) 11, paint57);
        org.jfree.chart.text.TextFragment textFragment60 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font4, paint57, (float) (byte) 1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, 2.0f, (float) 1, textBlockAnchor4, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock0.draw(graphics2D9, (float) 2, 0.0f, textBlockAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = null;
        categoryPlot46.datasetChanged(datasetChangeEvent49);
        boolean boolean51 = categoryPlot46.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, 0.0d, (double) (byte) 10);
        java.lang.Object obj6 = null;
        boolean boolean7 = columnArrangement5.equals(obj6);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        columnArrangement5.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Stroke stroke4 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        double double6 = xYPlot0.getDomainCrosshairValue();
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        boolean boolean5 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(4.0d);
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot47.getDataset();
        java.util.List list49 = categoryPlot47.getAnnotations();
        boolean boolean50 = blockContainer0.equals((java.lang.Object) categoryPlot47);
        java.awt.Font font53 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment54 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font53);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint59 = ringPlot57.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke60 = ringPlot57.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color56, stroke60);
        org.jfree.chart.text.TextFragment textFragment62 = new org.jfree.chart.text.TextFragment("", font53, (java.awt.Paint) color56);
        boolean boolean63 = blockContainer0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.awt.Color color4 = java.awt.Color.red;
        java.lang.String str5 = color4.toString();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color4, stroke6);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color4);
        double double9 = multiplePiePlot0.getLimit();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, categoryItemRenderer55);
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = ringPlot57.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint61 = categoryAxis60.getAxisLinePaint();
        ringPlot57.setLabelOutlinePaint(paint61);
        categoryPlot56.setParent((org.jfree.chart.plot.Plot) ringPlot57);
        categoryPlot56.zoom((double) 100.0f);
        java.awt.Paint paint66 = categoryPlot56.getRangeGridlinePaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint66);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str5.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot0.setNoDataMessageFont(font3);
        double double5 = ringPlot0.getSectionDepth();
        java.awt.Paint paint6 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke49 = categoryAxis48.getTickMarkStroke();
        dateAxis44.setAxisLineStroke(stroke49);
        dateAxis44.setLabelAngle((double) (byte) -1);
        java.lang.Object obj53 = dateAxis44.clone();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(obj53);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis5.configure();
        java.awt.Font font8 = categoryAxis5.getLabelFont();
        categoryAxis1.setLabelFont(font8);
        categoryAxis1.setLabelURL("hi!");
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray26, numberArray33, numberArray40, numberArray47, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray55);
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis60, categoryItemRenderer61);
        org.jfree.chart.plot.RingPlot ringPlot63 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = ringPlot63.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint67 = categoryAxis66.getAxisLinePaint();
        ringPlot63.setLabelOutlinePaint(paint67);
        categoryPlot62.setParent((org.jfree.chart.plot.Plot) ringPlot63);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot62.setRenderer(categoryItemRenderer70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot62.getDomainAxisEdge((int) (byte) -1);
        java.lang.String str74 = rectangleEdge73.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        try {
            org.jfree.chart.axis.AxisState axisState76 = categoryAxis1.draw(graphics2D12, (double) 10L, rectangle2D14, rectangle2D15, rectangleEdge73, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "RectangleEdge.TOP" + "'", str74.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation55, true);
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int62 = xYPlot59.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis61);
        xYPlot0.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) dateAxis61, false);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot46.setRenderer((int) (byte) 0, categoryItemRenderer50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D55 = xYPlot54.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            categoryPlot46.draw(graphics2D52, rectangle2D53, point2D55, plotState56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot46.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        ringPlot0.setSimpleLabelOffset(rectangleInsets10);
        ringPlot0.setOuterSeparatorExtension((double) 0.5f);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        categoryPlot46.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        categoryPlot46.setRenderer(10, categoryItemRenderer56, true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        xYPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot0.getDatasetRenderingOrder();
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        boolean boolean11 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getCopyright();
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image13, "", "", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.getName();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.getSeparatorsVisible();
        java.awt.Shape shape4 = ringPlot2.getLegendItemShape();
        dateAxis1.setRightArrow(shape4);
        double double6 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleConstraintType.RANGE", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Rotation.CLOCKWISE" + "'", str0.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot46.getDomainAxisForDataset((int) '4');
        categoryPlot46.clearRangeMarkers((-16711681));
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot46.getDomainAxisForDataset(100);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNull(categoryAxis54);
        org.junit.Assert.assertNull(categoryAxis58);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        boolean boolean3 = ringPlot0.isCircular();
        java.awt.Paint paint4 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelURL("");
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        ringPlot0.setSeparatorPaint(paint2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.clearRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker56.setPaint((java.awt.Paint) color57);
        valueMarker56.setLabel("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.text.TextBlock textBlock61 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot63 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint65 = ringPlot63.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font66 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot63.setNoDataMessageFont(font66);
        org.jfree.chart.plot.RingPlot ringPlot68 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = ringPlot68.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint72 = categoryAxis71.getAxisLinePaint();
        ringPlot68.setLabelOutlinePaint(paint72);
        textBlock61.addLine("java.awt.Color[r=255,g=0,b=0]", font66, paint72);
        valueMarker56.setPaint(paint72);
        try {
            boolean boolean76 = categoryPlot46.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNull(paint65);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        int int7 = xYPlot0.indexOf(xYDataset6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) (short) 1, layer10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot0.setRenderer(0, xYItemRenderer13, false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        java.awt.Stroke stroke49 = piePlot48.getLabelOutlineStroke();
        categoryPlot46.setRangeCrosshairStroke(stroke49);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot46.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot46.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker55.setPaint((java.awt.Paint) color56);
        org.jfree.data.general.PieDataset pieDataset58 = null;
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot(pieDataset58);
        java.awt.Stroke stroke60 = piePlot59.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color56, stroke60);
        valueMarker61.setAlpha((float) (byte) 0);
        java.awt.Paint paint64 = valueMarker61.getPaint();
        org.jfree.chart.util.Layer layer65 = null;
        try {
            boolean boolean66 = categoryPlot46.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker61, layer65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker49.setPaint((java.awt.Paint) color50);
        categoryPlot46.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        boolean boolean53 = categoryPlot46.isRangeZoomable();
        boolean boolean54 = categoryPlot46.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        java.util.TimeZone timeZone3 = null;
        try {
            dateAxis1.setTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        double double10 = rectangleInsets8.calculateLeftOutset(0.0d);
        blockContainer0.setPadding(rectangleInsets8);
        org.jfree.chart.block.Arrangement arrangement12 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertNotNull(arrangement12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        xYPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot0.getDatasetRenderingOrder();
        boolean boolean10 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = xYPlot0.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.data.general.PieDataset pieDataset54 = null;
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot(pieDataset54);
        java.awt.Stroke stroke56 = piePlot55.getLabelOutlineStroke();
        categoryPlot53.setRangeCrosshairStroke(stroke56);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = categoryPlot53.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot53.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(100, axisLocation59, true);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        categoryAxis4.configure();
        java.awt.Font font7 = categoryAxis4.getLabelFont();
        boolean boolean8 = piePlot2.equals((java.lang.Object) categoryAxis4);
        org.jfree.chart.util.Rotation rotation9 = piePlot2.getDirection();
        java.awt.Color color10 = java.awt.Color.green;
        boolean boolean11 = rotation9.equals((java.lang.Object) color10);
        piePlot0.setDirection(rotation9);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot47.getDataset();
        java.util.List list49 = categoryPlot47.getAnnotations();
        boolean boolean50 = blockContainer0.equals((java.lang.Object) categoryPlot47);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = blockContainer0.getMargin();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        try {
            blockContainer0.draw(graphics2D52, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getCopyright();
        java.lang.String str10 = projectInfo7.getCopyright();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        java.lang.String str14 = textTitle11.getID();
        java.lang.String str15 = textTitle11.getToolTipText();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        textTitle11.setPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation55, true);
        xYPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        xYPlot0.drawBackgroundImage(graphics2D60, rectangle2D61);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent63 = null;
        xYPlot0.rendererChanged(rendererChangeEvent63);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        valueAxis48.setFixedAutoRange((double) (short) 1);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = ringPlot56.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint60 = categoryAxis59.getAxisLinePaint();
        ringPlot56.setLabelOutlinePaint(paint60);
        categoryPlot55.setParent((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        ringPlot56.handleClick(0, (int) (byte) -1, plotRenderingInfo65);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot56);
        java.awt.Shape shape68 = numberAxis1.getLeftArrow();
        java.lang.Object obj69 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        ringPlot0.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Image image12 = ringPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        boolean boolean6 = xYPlot0.isRangeZoomable();
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = categoryPlot53.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker56.setPaint((java.awt.Paint) color57);
        categoryPlot53.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker56);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        java.util.List list48 = categoryPlot46.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot46.setRenderer(categoryItemRenderer49, false);
        categoryPlot46.mapDatasetToRangeAxis((int) ' ', (int) 'a');
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        textTitle11.setMargin((double) 100L, (double) 100, (double) 100L, (double) 1L);
        textTitle11.setExpandToFitSpace(false);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = null;
        try {
            textTitle11.setVerticalAlignment(verticalAlignment21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        xYPlot0.setWeight((int) (byte) 100);
        xYPlot0.setDomainCrosshairValue((double) 10.0f);
        int int11 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        textTitle11.setMargin((double) 100L, (double) 100, (double) 100L, (double) 1L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle11.getHorizontalAlignment();
        java.lang.Object obj20 = textTitle11.clone();
        java.lang.Object obj21 = textTitle11.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot5 = categoryAxis3.getPlot();
        categoryAxis3.setLabelAngle((double) 100L);
        int int8 = categoryAxis3.getMaximumCategoryLabelLines();
        java.awt.Paint paint9 = categoryAxis3.getTickLabelPaint();
        textTitle1.setPaint(paint9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Paint paint0 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = ringPlot48.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint52 = categoryAxis51.getAxisLinePaint();
        ringPlot48.setLabelOutlinePaint(paint52);
        categoryPlot47.setParent((org.jfree.chart.plot.Plot) ringPlot48);
        categoryPlot47.clearRangeAxes();
        java.awt.Stroke stroke56 = categoryPlot47.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double59 = rectangleInsets57.calculateLeftOutset((double) 0);
        double double61 = rectangleInsets57.trimWidth((double) (-16711936));
        try {
            org.jfree.chart.block.LineBorder lineBorder62 = new org.jfree.chart.block.LineBorder(paint0, stroke56, rectangleInsets57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 4.0d + "'", double59 == 4.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-1.6711944E7d) + "'", double61 == (-1.6711944E7d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.getSeparatorsVisible();
        java.awt.Shape shape8 = ringPlot6.getLegendItemShape();
        dateAxis5.setRightArrow(shape8);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5 };
        xYPlot0.setDomainAxes(valueAxisArray10);
        java.awt.Paint paint12 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=0,b=0]");
        categoryAxis1.setLabelToolTip("java.awt.Color[r=255,g=0,b=0]");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = ringPlot54.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint58 = categoryAxis57.getAxisLinePaint();
        ringPlot54.setLabelOutlinePaint(paint58);
        categoryPlot53.setParent((org.jfree.chart.plot.Plot) ringPlot54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot53.setRenderer(categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot53.getDomainAxisEdge((int) (byte) -1);
        try {
            double double65 = categoryAxis1.getCategoryStart(128, (int) (byte) -1, rectangle2D6, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        ringPlot0.setLabelOutlinePaint(paint4);
        ringPlot0.setSectionOutlinesVisible(false);
        double double8 = ringPlot0.getStartAngle();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.awt.Color color4 = java.awt.Color.red;
        java.lang.String str5 = color4.toString();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color4, stroke6);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color4);
        double double9 = multiplePiePlot0.getLimit();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        multiplePiePlot0.setDataset(categoryDataset10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str5.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = ringPlot56.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint60 = categoryAxis59.getAxisLinePaint();
        ringPlot56.setLabelOutlinePaint(paint60);
        categoryPlot55.setParent((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        ringPlot56.handleClick(0, (int) (byte) -1, plotRenderingInfo65);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot56);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str73 = rectangleEdge72.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        try {
            org.jfree.chart.axis.AxisState axisState75 = numberAxis1.draw(graphics2D68, (double) 15, rectangle2D70, rectangle2D71, rectangleEdge72, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "RectangleEdge.LEFT" + "'", str73.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation55, true);
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.lang.Object obj81 = textTitle1.clone();
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNotNull(obj81);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) 10L);
        boolean boolean7 = range3.contains((double) (byte) 10);
        dateAxis1.setRange(range3, true, false);
        double double11 = range3.getCentralValue();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        xYPlot0.setWeight((int) (byte) 100);
        xYPlot0.setDomainCrosshairValue((double) 10.0f);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset(15);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        double double5 = categoryAxis1.getUpperMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (short) 0);
        java.lang.String str8 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint8 = ringPlot6.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke9 = ringPlot6.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color5, stroke9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color5);
        java.awt.Font font12 = textFragment11.getFont();
        java.awt.Paint paint13 = textFragment11.getPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setRange(0.0d, (double) ' ');
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = ringPlot54.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint58 = categoryAxis57.getAxisLinePaint();
        ringPlot54.setLabelOutlinePaint(paint58);
        categoryPlot53.setParent((org.jfree.chart.plot.Plot) ringPlot54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot53.setRenderer(categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot53.getDomainAxisEdge((int) (byte) -1);
        try {
            double double65 = dateAxis1.valueToJava2D((-1.6711944E7d), rectangle2D6, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        double double54 = ringPlot47.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str1.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setShadowXOffset((double) 0L);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        int int7 = xYPlot0.indexOf(xYDataset6);
        java.awt.Stroke stroke8 = xYPlot0.getRangeGridlineStroke();
        java.awt.Stroke stroke9 = xYPlot0.getRangeZeroBaselineStroke();
        int int10 = xYPlot0.getSeriesCount();
        java.awt.Paint paint11 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke49 = categoryAxis48.getTickMarkStroke();
        dateAxis44.setAxisLineStroke(stroke49);
        org.jfree.chart.text.TextBlock textBlock51 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint55 = ringPlot53.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font56 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot53.setNoDataMessageFont(font56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = ringPlot58.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint62 = categoryAxis61.getAxisLinePaint();
        ringPlot58.setLabelOutlinePaint(paint62);
        textBlock51.addLine("java.awt.Color[r=255,g=0,b=0]", font56, paint62);
        dateAxis44.setLabelFont(font56);
        org.jfree.data.Range range66 = dateAxis44.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(range66);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        double double2 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        java.awt.Paint paint4 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot0.getDataExtractOrder();
        java.lang.Comparable comparable6 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(tableOrder5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Other" + "'", comparable6.equals("Other"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray47);
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis52, categoryItemRenderer53);
        java.awt.Paint paint55 = dateAxis52.getTickMarkPaint();
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 1, (double) (-16711936), (double) 11, paint55);
        org.jfree.chart.text.TextFragment textFragment58 = new org.jfree.chart.text.TextFragment("Rotation.CLOCKWISE", font2, paint55, (float) 128);
        java.awt.Font font59 = textFragment58.getFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = ringPlot0.getLegendItems();
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        categoryPlot46.clearAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = null;
        org.jfree.chart.util.Layer layer58 = null;
        try {
            categoryPlot46.addDomainMarker(categoryMarker57, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot47.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation49, false);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNull(valueAxis52);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis3D1.draw(graphics2D3, 45.0d, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        java.awt.Stroke stroke50 = piePlot49.getLabelOutlineStroke();
        categoryPlot47.setRangeCrosshairStroke(stroke50);
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = categoryPlot47.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(plotOrientation52);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        float float7 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 0, (float) 1, (float) '4');
        java.lang.String str4 = color3.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=204,g=0,b=0]" + "'", str4.equals("java.awt.Color[r=204,g=0,b=0]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleEdge.LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator54 = null;
        ringPlot47.setLabelGenerator(pieSectionLabelGenerator54);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.lang.Object obj2 = numberAxis3D1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray47);
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis52, categoryItemRenderer53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryPlot54.getDataset();
        java.util.List list56 = categoryPlot54.getAnnotations();
        boolean boolean57 = blockContainer7.equals((java.lang.Object) categoryPlot54);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot54.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        try {
            org.jfree.chart.axis.AxisState axisState61 = numberAxis3D1.draw(graphics2D3, (double) '#', rectangle2D5, rectangle2D6, rectangleEdge59, plotRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = ringPlot56.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint60 = categoryAxis59.getAxisLinePaint();
        ringPlot56.setLabelOutlinePaint(paint60);
        categoryPlot55.setParent((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        ringPlot56.handleClick(0, (int) (byte) -1, plotRenderingInfo65);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot56);
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        java.awt.Paint paint78 = jFreeChart77.getBorderPaint();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke49 = categoryAxis48.getTickMarkStroke();
        dateAxis44.setAxisLineStroke(stroke49);
        dateAxis44.setLabelAngle((double) (byte) -1);
        dateAxis44.centerRange((-1.0d));
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.zoom((double) 100.0f);
        int int56 = categoryPlot46.getRangeAxisCount();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        ringPlot0.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Stroke stroke12 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double15 = rectangleInsets13.calculateRightInset(4.0d);
        ringPlot0.setSimpleLabelOffset(rectangleInsets13);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        java.util.List list9 = projectInfo7.getContributors();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        textTitle11.setMargin((double) 100L, (double) 100, (double) 100L, (double) 1L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle11.getHorizontalAlignment();
        java.awt.Paint paint20 = null;
        try {
            textTitle11.setPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range9 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Multiple Pie Plot", graphics2D1, 0.5d, (float) (byte) 10, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot47.getDataset();
        int int49 = categoryPlot47.getDomainAxisCount();
        boolean boolean50 = unitType0.equals((java.lang.Object) int49);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray37);
        try {
            org.jfree.data.general.PieDataset pieDataset40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset38, (java.lang.Comparable) "java.awt.Color[r=204,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, 2.0f, (float) 1, textBlockAnchor4, (float) 100, (float) 1, 0.0d);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font10);
        textBlock0.addLine(textLine11);
        org.jfree.chart.text.TextFragment textFragment13 = textLine11.getLastTextFragment();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textFragment13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot47.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation49, false);
        xYPlot0.setForegroundAlpha((float) ' ');
        java.awt.Paint paint54 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 10L);
        boolean boolean9 = range5.contains((double) (byte) 10);
        dateAxis4.setDefaultAutoRange(range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint3.toRangeHeight(range5);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range5, (double) 'a', 0.0d);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range15, (double) 10L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date22 = dateAxis21.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline23 = null;
        dateAxis21.setTimeline(timeline23);
        double double25 = dateAxis21.getUpperBound();
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(range26, (double) 10L);
        dateAxis21.setRange(range26);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range30, (double) 10L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint32.getWidthConstraintType();
        java.lang.String str34 = lengthConstraintType33.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((-7.0d), range14, lengthConstraintType18, 0.0d, range26, lengthConstraintType33);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int39 = xYPlot36.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis38);
        java.awt.Stroke stroke40 = xYPlot36.getDomainGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = xYPlot36.getFixedLegendItems();
        double double42 = xYPlot36.getDomainCrosshairValue();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        xYPlot36.rendererChanged(rendererChangeEvent43);
        boolean boolean45 = lengthConstraintType18.equals((java.lang.Object) rendererChangeEvent43);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleConstraintType.RANGE" + "'", str34.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        categoryPlot46.setDomainGridlinesVisible(false);
        java.lang.Object obj55 = categoryPlot46.clone();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(obj55);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=0.0]", graphics2D1, (double) 15, (float) ' ', (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.resizeRange(0.2d, (-1.6711944E7d));
        java.awt.Paint paint12 = null;
        try {
            numberAxis1.setTickMarkPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        double double2 = numberAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str8 = rectangleEdge7.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = numberAxis1.draw(graphics2D3, (double) 10.0f, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47);
        boolean boolean49 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        textTitle11.setURLText("");
        org.jfree.chart.event.TitleChangeListener titleChangeListener14 = null;
        textTitle11.removeChangeListener(titleChangeListener14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range17, (double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range21, (double) 10L);
        boolean boolean25 = range21.contains((double) (byte) 10);
        dateAxis20.setDefaultAutoRange(range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint19.toRangeHeight(range21);
        org.jfree.chart.text.TextBlock textBlock28 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = null;
        textBlock28.draw(graphics2D29, 2.0f, (float) 1, textBlockAnchor32, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.Size2D size2D38 = textBlock28.calculateDimensions(graphics2D37);
        org.jfree.chart.util.Size2D size2D39 = rectangleConstraint19.calculateConstrainedSize(size2D38);
        try {
            org.jfree.chart.util.Size2D size2D40 = textTitle11.arrange(graphics2D16, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(size2D39);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        boolean boolean78 = jFreeChart77.isBorderVisible();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot79 = jFreeChart77.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = ringPlot54.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint58 = categoryAxis57.getAxisLinePaint();
        ringPlot54.setLabelOutlinePaint(paint58);
        categoryPlot53.setParent((org.jfree.chart.plot.Plot) ringPlot54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot53.setRenderer(categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot53.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        try {
            org.jfree.chart.axis.AxisState axisState66 = categoryAxis1.draw(graphics2D3, 0.2d, rectangle2D5, rectangle2D6, rectangleEdge64, plotRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(0, 0, 0, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomDomainAxes((double) 10L, plotRenderingInfo48, point2D49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = categoryPlot46.getDataset();
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = null;
        try {
            categoryPlot46.addDomainMarker(categoryMarker52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset51);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) '4');
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        textTitle11.setMargin((double) 100L, (double) 100, (double) 100L, (double) 1L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle11.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean22 = horizontalAlignment20.equals((java.lang.Object) plotOrientation21);
        textTitle11.setHorizontalAlignment(horizontalAlignment20);
        java.awt.Paint paint24 = textTitle11.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset41);
        org.jfree.data.Range range49 = org.jfree.data.Range.shift(range47, (double) 100L);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Category Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        ringPlot47.handleClick(0, (int) (byte) -1, plotRenderingInfo56);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator58 = ringPlot47.getLegendLabelToolTipGenerator();
        ringPlot47.setOuterSeparatorExtension(0.0d);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(pieSectionLabelGenerator58);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str9 = rectangleEdge8.toString();
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        try {
            java.util.List list11 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.LEFT" + "'", str9.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = xYPlot0.getFixedDomainAxisSpace();
        double double6 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Color color2 = java.awt.Color.red;
        valueMarker1.setPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets4.trimHeight((double) 1);
        valueMarker1.setLabelOffset(rectangleInsets4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        java.awt.Paint paint49 = categoryPlot46.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryPlot46.getAxisOffset();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.equals((java.lang.Object) (-16711681));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener78 = null;
        try {
            jFreeChart77.removeChangeListener(chartChangeListener78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("Multiple Pie Plot");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getInteriorGap();
        boolean boolean3 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08d + "'", double2 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.red;
        java.lang.String str3 = color2.toString();
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color2, stroke4);
        java.awt.Paint paint6 = valueMarker5.getLabelPaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker5.setOutlinePaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = valueMarker5.getLabelPaint();
        boolean boolean10 = color0.equals((java.lang.Object) valueMarker5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        ringPlot47.handleClick(0, (int) (byte) -1, plotRenderingInfo56);
        java.awt.Paint paint58 = ringPlot47.getSeparatorPaint();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker1.setPaint((java.awt.Paint) color2);
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = null;
        textBlock4.draw(graphics2D5, 2.0f, (float) 1, textBlockAnchor8, (float) 100, (float) 1, 0.0d);
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font14);
        textBlock4.addLine(textLine15);
        boolean boolean17 = color2.equals((java.lang.Object) textBlock4);
        int int18 = color2.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image3, "", "", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getCopyright();
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("", "java.awt.Color[r=255,g=0,b=0]", "", image13, "", "", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image19 = projectInfo17.getLogo();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 0, plotRenderingInfo8, point2D9);
        xYPlot6.clearDomainMarkers((-16711936));
        xYPlot6.setWeight((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot6.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        java.awt.Paint paint3 = paintMap0.getPaint((java.lang.Comparable) "java.awt.Color[r=128,g=128,b=255]");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer51);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        categoryPlot52.setRangeCrosshairStroke(stroke55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot52.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot52.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(11, axisLocation58, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        try {
            xYPlot0.setRenderer((int) (short) -1, xYItemRenderer62, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.awt.Image image81 = jFreeChart79.getBackgroundImage();
        java.awt.Image image82 = jFreeChart79.getBackgroundImage();
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(image81);
        org.junit.Assert.assertNull(image82);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint8 = ringPlot6.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke9 = ringPlot6.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color5, stroke9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color5);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray22, numberArray29, numberArray36, numberArray43, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray51);
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis62.setLabelURL("");
        int int65 = categoryPlot58.getDomainAxisIndex(categoryAxis62);
        boolean boolean66 = color5.equals((java.lang.Object) categoryPlot58);
        java.awt.Stroke stroke67 = categoryPlot58.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint70 = categoryAxis69.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot71 = categoryAxis69.getPlot();
        categoryAxis69.setLabelAngle((double) 100L);
        int int74 = categoryAxis69.getMaximumCategoryLabelLines();
        int int75 = categoryPlot58.getDomainAxisIndex(categoryAxis69);
        categoryPlot58.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(plot71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        piePlot1.setSectionOutlinesVisible(true);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        java.awt.Paint paint11 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot46.getRangeAxisLocation();
        categoryPlot46.setWeight(0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        ringPlot0.setLabelOutlinePaint(paint4);
        ringPlot0.setStartAngle(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.awt.Image image81 = jFreeChart79.getBackgroundImage();
        boolean boolean82 = jFreeChart79.isBorderVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis85 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke86 = categoryAxis85.getTickMarkStroke();
        categoryAxis85.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke90 = categoryAxis89.getTickMarkStroke();
        categoryAxis89.configure();
        java.awt.Font font92 = categoryAxis89.getLabelFont();
        categoryAxis85.setLabelFont(font92);
        org.jfree.chart.title.TextTitle textTitle94 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font92);
        textTitle94.setURLText("");
        org.jfree.chart.event.TitleChangeListener titleChangeListener97 = null;
        textTitle94.removeChangeListener(titleChangeListener97);
        jFreeChart79.setTitle(textTitle94);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(image81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(font92);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        java.lang.String str49 = categoryPlot46.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        categoryPlot46.setRangeGridlineStroke(stroke52);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Category Plot" + "'", str49.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(point2D1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot47.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation49, false);
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        ringPlot0.setLabelOutlinePaint(paint4);
        ringPlot0.setInnerSeparatorExtension((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        xYPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot0.rendererChanged(rendererChangeEvent9);
        xYPlot0.setRangeGridlinesVisible(false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        categoryPlot46.setFixedDomainAxisSpace(axisSpace49);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        int int6 = xYPlot0.getRangeAxisCount();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot0.setDomainTickBandPaint(paint7);
        java.awt.Paint paint9 = xYPlot0.getRangeTickBandPaint();
        java.awt.Color color11 = java.awt.Color.red;
        java.lang.String str12 = color11.toString();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color11, stroke13);
        java.awt.Paint paint15 = valueMarker14.getLabelPaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker14.setOutlinePaint((java.awt.Paint) color16);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str12.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, 2.0f, (float) 1, textBlockAnchor4, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = null;
        textBlock12.draw(graphics2D13, 2.0f, (float) 1, textBlockAnchor16, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = textBlock12.calculateDimensions(graphics2D21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.awt.Shape shape30 = textBlock12.calculateBounds(graphics2D23, 2.0f, (float) (-16711681), textBlockAnchor26, (float) (-16711681), (float) (-1L), 0.0d);
        java.awt.Shape shape34 = textBlock0.calculateBounds(graphics2D9, 2.0f, (float) '4', textBlockAnchor26, (float) '#', (float) 10, (double) '4');
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLowerBound(0.4d);
        boolean boolean7 = dateAxis2.isHiddenValue((long) (short) 0);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str13 = rectangleEdge12.toString();
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.axis.AxisState axisState16 = dateAxis2.draw(graphics2D8, (double) 8, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.LEFT" + "'", str13.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.awt.Image image81 = jFreeChart79.getBackgroundImage();
        boolean boolean82 = jFreeChart79.isBorderVisible();
        jFreeChart79.setTitle("");
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(image81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.configure();
        java.awt.Font font10 = categoryAxis7.getLabelFont();
        categoryAxis3.setLabelFont(font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font10);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("Range[0.0,1.0]", font10);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textFragment14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        double double5 = dateAxis1.getUpperBound();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 10L);
        dateAxis1.setRange(range6);
        dateAxis1.setFixedDimension((double) '4');
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomDomainAxes((double) 10L, plotRenderingInfo48, point2D49);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = null;
        org.jfree.chart.util.Layer layer52 = null;
        try {
            categoryPlot46.addDomainMarker(categoryMarker51, layer52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        double double5 = dateAxis1.getUpperBound();
        dateAxis1.setPositiveArrowVisible(false);
        boolean boolean8 = dateAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getRangeMarkers(layer7);
        java.awt.Paint paint9 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        categoryPlot46.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("Category Plot");
        java.awt.Paint paint60 = categoryAxis3D58.getTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=0]");
        int int61 = categoryAxis3D58.getMaximumCategoryLabelLines();
        java.util.List list62 = categoryPlot46.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=128,g=128,b=255]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        ringPlot0.setShadowXOffset(0.0d);
        java.awt.Paint paint5 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator4);
        double double6 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.resizeRange(0.2d, (-1.6711944E7d));
        numberAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.awt.Image image81 = jFreeChart79.getBackgroundImage();
        boolean boolean82 = jFreeChart79.isBorderVisible();
        org.jfree.chart.event.ChartChangeListener chartChangeListener83 = null;
        try {
            jFreeChart79.removeChangeListener(chartChangeListener83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(image81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Size2D[width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomDomainAxes((double) 10L, plotRenderingInfo48, point2D49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = categoryPlot46.getDataset();
        try {
            org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset51, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset51);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        int int7 = xYPlot0.indexOf(xYDataset6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getRangeMarkers((int) (short) 1, layer10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        try {
            xYPlot0.setRenderer((-16711681), xYItemRenderer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        piePlot1.setStartAngle((double) 0);
        java.awt.Paint paint5 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("{0}");
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color3, stroke7);
        java.awt.color.ColorSpace colorSpace9 = null;
        float[] floatArray13 = new float[] { 1.0f, (-1.0f), 8 };
        try {
            float[] floatArray14 = color3.getComponents(colorSpace9, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint5 = waferMapPlot4.getBackgroundPaint();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot4);
        java.lang.Comparable comparable7 = null;
        java.awt.Color color8 = java.awt.Color.CYAN;
        try {
            categoryAxis1.setTickLabelPaint(comparable7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        org.jfree.chart.title.LegendTitle legendTitle78 = jFreeChart77.getLegend();
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        try {
            legendTitle78.draw(graphics2D79, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(legendTitle78);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot46.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis50.setLabelURL("");
        int int53 = categoryPlot46.getDomainAxisIndex(categoryAxis50);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent54 = null;
        categoryPlot46.datasetChanged(datasetChangeEvent54);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray56 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot46.setRenderers(categoryItemRendererArray56);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererArray56);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(categoryItemRenderer54);
        double double56 = categoryPlot46.getAnchorValue();
        categoryPlot46.configureDomainAxes();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke84 = categoryAxis83.getTickMarkStroke();
        categoryAxis83.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis87 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke88 = categoryAxis87.getTickMarkStroke();
        categoryAxis87.configure();
        java.awt.Font font90 = categoryAxis87.getLabelFont();
        categoryAxis83.setLabelFont(font90);
        org.jfree.chart.title.TextTitle textTitle92 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font90);
        textTitle92.setURLText("");
        jFreeChart79.setTitle(textTitle92);
        java.awt.Paint paint96 = jFreeChart79.getBackgroundPaint();
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(font90);
        org.junit.Assert.assertNotNull(paint96);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        categoryAxis1.setLabelAngle((double) 100L);
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint();
        double double8 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        ringPlot0.setSectionDepth((double) 100.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.getSeparatorsVisible();
        java.awt.Shape shape8 = ringPlot6.getLegendItemShape();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 100, plotRenderingInfo10);
        org.jfree.chart.entity.EntityCollection entityCollection12 = piePlotState11.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = piePlotState11.getInfo();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNull(entityCollection12);
        org.junit.Assert.assertNull(plotRenderingInfo13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot0.setNoDataMessageFont(font3);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0.2d, stroke6);
        double double8 = ringPlot0.getStartAngle();
        ringPlot0.setMinimumArcAngleToDraw((double) (short) 100);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        double double5 = dateAxis1.getUpperBound();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 10L);
        dateAxis1.setRange(range6);
        java.awt.Paint paint10 = dateAxis1.getLabelPaint();
        java.text.DateFormat dateFormat11 = null;
        dateAxis1.setDateFormatOverride(dateFormat11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        ringPlot0.setLabelShadowPaint(paint3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) 10L);
        boolean boolean8 = range4.contains((double) (byte) 10);
        dateAxis3.setDefaultAutoRange(range4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint2.toRangeHeight(range4);
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        textBlock11.draw(graphics2D12, 2.0f, (float) 1, textBlockAnchor15, (float) 100, (float) 1, 0.0d);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock11.calculateDimensions(graphics2D20);
        org.jfree.chart.util.Size2D size2D22 = rectangleConstraint2.calculateConstrainedSize(size2D21);
        double double23 = size2D21.getHeight();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        java.lang.String str14 = textTitle11.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle11.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (short) 10, (double) (byte) 1, (double) (short) 100);
        double double10 = rectangleInsets8.calculateLeftOutset(0.0d);
        blockContainer0.setPadding(rectangleInsets8);
        double double13 = rectangleInsets8.calculateRightOutset((-1.0d));
        double double15 = rectangleInsets8.trimHeight((-1.6711944E7d));
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.6711955E7d) + "'", double15 == (-1.6711955E7d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        textTitle11.setURLText("");
        org.jfree.chart.event.TitleChangeListener titleChangeListener14 = null;
        textTitle11.removeChangeListener(titleChangeListener14);
        java.lang.String str16 = textTitle11.getURLText();
        java.lang.String str17 = textTitle11.getID();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        org.jfree.chart.title.LegendTitle legendTitle78 = jFreeChart77.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = legendTitle78.getItemLabelPadding();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(legendTitle78);
        org.junit.Assert.assertNotNull(rectangleInsets79);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelOutlineStroke();
        piePlot1.setStartAngle((double) 0);
        piePlot1.setMaximumLabelWidth((double) 0.0f);
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) '4');
        boolean boolean6 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        int int6 = xYPlot0.getRangeAxisCount();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot0.setDomainTickBandPaint(paint7);
        java.awt.Paint paint9 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot0.rendererChanged(rendererChangeEvent10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = ringPlot56.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint60 = categoryAxis59.getAxisLinePaint();
        ringPlot56.setLabelOutlinePaint(paint60);
        categoryPlot55.setParent((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        ringPlot56.handleClick(0, (int) (byte) -1, plotRenderingInfo65);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = numberAxis1.getTickLabelInsets();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand69 = null;
        numberAxis1.setMarkerBand(markerAxisBand69);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleInsets68);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray79 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray86 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray87 = new java.lang.Number[][] { numberArray58, numberArray65, numberArray72, numberArray79, numberArray86 };
        org.jfree.data.category.CategoryDataset categoryDataset88 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray87);
        org.jfree.data.category.CategoryDataset categoryDataset89 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray87);
        org.jfree.chart.axis.CategoryAxis categoryAxis90 = null;
        org.jfree.chart.axis.DateAxis dateAxis92 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer93 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot94 = new org.jfree.chart.plot.CategoryPlot(categoryDataset89, categoryAxis90, (org.jfree.chart.axis.ValueAxis) dateAxis92, categoryItemRenderer93);
        org.jfree.chart.axis.AxisLocation axisLocation96 = categoryPlot94.getDomainAxisLocation((int) (short) 100);
        categoryPlot46.setDomainAxisLocation((int) (byte) 0, axisLocation96);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray86);
        org.junit.Assert.assertNotNull(numberArray87);
        org.junit.Assert.assertNotNull(categoryDataset88);
        org.junit.Assert.assertNotNull(categoryDataset89);
        org.junit.Assert.assertNotNull(axisLocation96);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Range[0.0,1.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Range[0.0,1.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        java.awt.Image image81 = jFreeChart79.getBackgroundImage();
        jFreeChart79.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(image81);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.configure();
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        double double5 = categoryAxis1.getUpperMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (short) 0);
        float float8 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        boolean boolean3 = blockContainer1.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer1.getPadding();
        boolean boolean5 = color0.equals((java.lang.Object) rectangleInsets4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color3, stroke7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        int int10 = multiplePiePlot9.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset11 = multiplePiePlot9.getDataset();
        java.awt.Color color13 = java.awt.Color.red;
        java.lang.String str14 = color13.toString();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color13, stroke15);
        multiplePiePlot9.setAggregatedItemsPaint((java.awt.Paint) color13);
        valueMarker8.setOutlinePaint((java.awt.Paint) color13);
        int int19 = color13.getBlue();
        int int20 = color13.getTransparency();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint8 = ringPlot6.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke9 = ringPlot6.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color5, stroke9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color5);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray22, numberArray29, numberArray36, numberArray43, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray51);
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis62.setLabelURL("");
        int int65 = categoryPlot58.getDomainAxisIndex(categoryAxis62);
        boolean boolean66 = color5.equals((java.lang.Object) categoryPlot58);
        java.awt.Stroke stroke67 = categoryPlot58.getOutlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot58.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setFixedDimension(1.0d);
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray26, numberArray33, numberArray40, numberArray47, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray55);
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis60, categoryItemRenderer61);
        org.jfree.data.category.CategoryDataset categoryDataset63 = categoryPlot62.getDataset();
        java.util.List list64 = categoryPlot62.getAnnotations();
        boolean boolean65 = blockContainer15.equals((java.lang.Object) categoryPlot62);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot62.getDomainAxisEdge(0);
        try {
            java.util.List list68 = numberAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setLabelToolTip("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        java.lang.Object obj11 = numberAxis1.clone();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes((double) 0, plotRenderingInfo14, point2D15);
        xYPlot12.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray58 = new java.lang.Number[][] { numberArray29, numberArray36, numberArray43, numberArray50, numberArray57 };
        org.jfree.data.category.CategoryDataset categoryDataset59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray58);
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray58);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, (org.jfree.chart.axis.ValueAxis) dateAxis63, categoryItemRenderer64);
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot65.getDomainAxisLocation((int) (short) 100);
        xYPlot12.setRangeAxisLocation(axisLocation67, true);
        xYPlot12.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        xYPlot12.drawBackgroundImage(graphics2D72, rectangle2D73);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.plot.ValueMarker valueMarker78 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color79 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker78.setPaint((java.awt.Paint) color79);
        valueMarker78.setLabel("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.text.TextBlock textBlock83 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot85 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint87 = ringPlot85.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font88 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot85.setNoDataMessageFont(font88);
        org.jfree.chart.plot.RingPlot ringPlot90 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets91 = ringPlot90.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis93 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint94 = categoryAxis93.getAxisLinePaint();
        ringPlot90.setLabelOutlinePaint(paint94);
        textBlock83.addLine("java.awt.Color[r=255,g=0,b=0]", font88, paint94);
        valueMarker78.setPaint(paint94);
        org.jfree.chart.util.Layer layer98 = null;
        try {
            boolean boolean99 = xYPlot12.removeRangeMarker(1, (org.jfree.chart.plot.Marker) valueMarker78, layer98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(categoryDataset59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNull(paint87);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(rectangleInsets91);
        org.junit.Assert.assertNotNull(paint94);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        piePlot1.setSectionOutlinesVisible(true);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setFixedDimension(1.0d);
        java.text.NumberFormat numberFormat11 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNull(numberFormat11);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.awt.Color color9 = java.awt.Color.red;
        java.lang.String str10 = color9.toString();
        numberAxis1.setTickLabelPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str10.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot46.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot46.setRenderer((int) (byte) 0, categoryItemRenderer50);
        int int52 = categoryPlot46.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        try {
            categoryPlot46.drawOutline(graphics2D53, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 15 + "'", int52 == 15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot46.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis50.setLabelURL("");
        int int53 = categoryPlot46.getDomainAxisIndex(categoryAxis50);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent54 = null;
        categoryPlot46.datasetChanged(datasetChangeEvent54);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color59 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker58.setPaint((java.awt.Paint) color59);
        org.jfree.data.general.PieDataset pieDataset61 = null;
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot(pieDataset61);
        java.awt.Stroke stroke63 = piePlot62.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color59, stroke63);
        categoryPlot46.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker64);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke84 = categoryAxis83.getTickMarkStroke();
        categoryAxis83.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis87 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke88 = categoryAxis87.getTickMarkStroke();
        categoryAxis87.configure();
        java.awt.Font font90 = categoryAxis87.getLabelFont();
        categoryAxis83.setLabelFont(font90);
        org.jfree.chart.title.TextTitle textTitle92 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font90);
        textTitle92.setURLText("");
        jFreeChart79.setTitle(textTitle92);
        jFreeChart79.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(font90);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke3 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 100);
        boolean boolean4 = piePlot1.isCircular();
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        ringPlot0.setSectionDepth((double) 100.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.getSeparatorsVisible();
        java.awt.Shape shape8 = ringPlot6.getLegendItemShape();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 100, plotRenderingInfo10);
        org.jfree.chart.entity.EntityCollection entityCollection12 = piePlotState11.getEntityCollection();
        piePlotState11.setPieCenterY((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNull(entityCollection12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        java.lang.String str3 = size2D2.toString();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray14, numberArray21, numberArray28, numberArray35, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer49);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        java.awt.Stroke stroke53 = piePlot52.getLabelOutlineStroke();
        categoryPlot50.setRangeCrosshairStroke(stroke53);
        boolean boolean55 = size2D2.equals((java.lang.Object) stroke53);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str3.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.zoom((double) 100.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot46.getDomainAxis();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(categoryAxis56);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        int int6 = xYPlot0.getRangeAxisCount();
        double double7 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 0, plotRenderingInfo10, point2D11);
        xYPlot8.clearDomainMarkers((-16711936));
        xYPlot8.setWeight((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = xYPlot8.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        java.awt.Paint paint56 = dateAxis53.getTickMarkPaint();
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 1, (double) (-16711936), (double) 11, paint56);
        org.jfree.chart.text.TextFragment textFragment59 = new org.jfree.chart.text.TextFragment("Rotation.CLOCKWISE", font3, paint56, (float) 128);
        java.awt.Color color60 = java.awt.Color.GREEN;
        int int61 = color60.getRGB();
        java.lang.String str62 = color60.toString();
        org.jfree.chart.text.TextBlock textBlock63 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.TOP_CENTER", font3, (java.awt.Paint) color60);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-16711936) + "'", int61 == (-16711936));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str62.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(textBlock63);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer54);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = ringPlot56.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint60 = categoryAxis59.getAxisLinePaint();
        ringPlot56.setLabelOutlinePaint(paint60);
        categoryPlot55.setParent((org.jfree.chart.plot.Plot) ringPlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        ringPlot56.handleClick(0, (int) (byte) -1, plotRenderingInfo65);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot56);
        java.text.NumberFormat numberFormat68 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(numberFormat68);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        java.awt.Color color2 = java.awt.Color.darkGray;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        xYPlot0.mapDatasetToRangeAxis(0, (int) (short) 10);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = ringPlot47.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint51 = categoryAxis50.getAxisLinePaint();
        ringPlot47.setLabelOutlinePaint(paint51);
        categoryPlot46.setParent((org.jfree.chart.plot.Plot) ringPlot47);
        categoryPlot46.clearRangeAxes();
        java.awt.Stroke stroke55 = categoryPlot46.getRangeCrosshairStroke();
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot46.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(sortOrder56);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.getSeparatorsVisible();
        java.awt.Shape shape4 = ringPlot2.getLegendItemShape();
        dateAxis1.setRightArrow(shape4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset6, (int) (short) 10, 1, (java.lang.Comparable) 2.0d, "Category Plot", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.jfree.data.general.PieDataset pieDataset13 = pieSectionEntity12.getDataset();
        org.jfree.data.general.PieDataset pieDataset14 = pieSectionEntity12.getDataset();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        try {
            java.lang.String str17 = pieSectionEntity12.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(pieDataset13);
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        xYPlot0.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker8.setPaint((java.awt.Paint) color9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Stroke stroke13 = piePlot12.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color9, stroke13);
        valueMarker14.setAlpha((float) (byte) 0);
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) valueMarker14, layer17);
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.lang.Object obj2 = numberAxis3D1.clone();
        numberAxis3D1.setFixedAutoRange(100.0d);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        int int1 = multiplePiePlot0.getBackgroundImageAlignment();
        java.lang.Object obj2 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        java.awt.Paint paint4 = multiplePiePlot0.getNoDataMessagePaint();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke55 = categoryAxis54.getTickMarkStroke();
        dateAxis50.setAxisLineStroke(stroke55);
        org.jfree.chart.text.TextBlock textBlock57 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint61 = ringPlot59.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font62 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot59.setNoDataMessageFont(font62);
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = ringPlot64.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint68 = categoryAxis67.getAxisLinePaint();
        ringPlot64.setLabelOutlinePaint(paint68);
        textBlock57.addLine("java.awt.Color[r=255,g=0,b=0]", font62, paint68);
        dateAxis50.setLabelFont(font62);
        org.jfree.data.general.PieDataset pieDataset72 = null;
        org.jfree.chart.plot.PiePlot piePlot73 = new org.jfree.chart.plot.PiePlot(pieDataset72);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke76 = categoryAxis75.getTickMarkStroke();
        categoryAxis75.configure();
        java.awt.Font font78 = categoryAxis75.getLabelFont();
        boolean boolean79 = piePlot73.equals((java.lang.Object) categoryAxis75);
        org.jfree.chart.util.Rotation rotation80 = piePlot73.getDirection();
        org.jfree.chart.JFreeChart jFreeChart82 = new org.jfree.chart.JFreeChart("", font62, (org.jfree.chart.plot.Plot) piePlot73, true);
        org.jfree.chart.title.LegendTitle legendTitle83 = jFreeChart82.getLegend();
        multiplePiePlot0.setPieChart(jFreeChart82);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(rotation80);
        org.junit.Assert.assertNotNull(legendTitle83);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot46.getDomainAxisForDataset((int) '4');
        categoryPlot46.clearRangeAxes();
        int int56 = categoryPlot46.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        try {
            categoryPlot46.handleClick((int) (byte) 0, 2, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNull(categoryAxis54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10L);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        double double5 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        xYPlot0.clearDomainMarkers((-16711936));
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray17, numberArray24, numberArray31, numberArray38, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation((int) (short) 100);
        xYPlot0.setRangeAxisLocation(axisLocation55, true);
        xYPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        xYPlot0.drawBackgroundImage(graphics2D60, rectangle2D61);
        org.jfree.chart.axis.AxisSpace axisSpace63 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNull(axisSpace63);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = dateAxis0.getTimeline();
        boolean boolean2 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(timeline1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        boolean boolean78 = jFreeChart77.isBorderVisible();
        org.jfree.chart.title.Title title80 = jFreeChart77.getSubtitle((int) (short) 0);
        java.awt.Stroke stroke81 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        jFreeChart77.setBorderStroke(stroke81);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(title80);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot46.getDomainAxisLocation((int) (short) 100);
        boolean boolean49 = categoryPlot46.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(15, categoryItemRenderer54, false);
        categoryPlot46.setAnchorValue(0.4d, true);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot60.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis63, false);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        xYPlot66.zoomDomainAxes((double) 0, plotRenderingInfo68, point2D69);
        xYPlot66.clearDomainMarkers((-16711936));
        xYPlot66.setWeight((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder75 = xYPlot66.getDatasetRenderingOrder();
        xYPlot60.setDatasetRenderingOrder(datasetRenderingOrder75);
        categoryPlot46.setDatasetRenderingOrder(datasetRenderingOrder75);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(datasetRenderingOrder75);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot46.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot46.setDomainAxisLocation((int) (short) 10, axisLocation50, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot46.setRenderer(15, categoryItemRenderer54, false);
        categoryPlot46.setAnchorValue(0.4d, true);
        org.jfree.chart.axis.AxisSpace axisSpace60 = categoryPlot46.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker63.setPaint((java.awt.Paint) color64);
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = categoryPlot46.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker63, layer66);
        java.lang.String str68 = categoryPlot46.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Point2D point2D71 = null;
        categoryPlot46.zoomDomainAxes((double) (byte) -1, plotRenderingInfo70, point2D71);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNull(axisSpace60);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Category Plot" + "'", str68.equals("Category Plot"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        boolean boolean5 = dateAxis1.isAxisLineVisible();
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8355840) + "'", int1 == (-8355840));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.Paint paint8 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.Range range9 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray10, numberArray17, numberArray24, numberArray31, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot46.getDataset();
        java.util.List list48 = categoryPlot46.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot46.setRenderer(categoryItemRenderer49, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        categoryPlot46.setRenderer(categoryItemRenderer52);
        categoryPlot46.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        int int3 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot6.getSeparatorsVisible();
        java.awt.Shape shape8 = ringPlot6.getLegendItemShape();
        dateAxis5.setRightArrow(shape8);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5 };
        xYPlot0.setDomainAxes(valueAxisArray10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRenderer(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        xYPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis3, false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=0,b=0]", font2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint8 = ringPlot6.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke9 = ringPlot6.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color5, stroke9);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color5);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray22, numberArray29, numberArray36, numberArray43, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray51);
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis62.setLabelURL("");
        int int65 = categoryPlot58.getDomainAxisIndex(categoryAxis62);
        boolean boolean66 = color5.equals((java.lang.Object) categoryPlot58);
        java.awt.Stroke stroke67 = categoryPlot58.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint70 = categoryAxis69.getAxisLinePaint();
        org.jfree.chart.plot.Plot plot71 = categoryAxis69.getPlot();
        categoryAxis69.setLabelAngle((double) 100L);
        int int74 = categoryAxis69.getMaximumCategoryLabelLines();
        int int75 = categoryPlot58.getDomainAxisIndex(categoryAxis69);
        org.jfree.chart.plot.RingPlot ringPlot76 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint78 = ringPlot76.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font79 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot76.setNoDataMessageFont(font79);
        boolean boolean81 = categoryAxis69.equals((java.lang.Object) font79);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(plot71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNull(paint78);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setFixedDimension(1.0d);
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setLowerBound(0.08d);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str19 = rectangleEdge18.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = numberAxis1.draw(graphics2D14, (double) 0.5f, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleEdge.LEFT" + "'", str19.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        ringPlot0.setSectionOutlinesVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        jFreeChart77.clearSubtitles();
        org.jfree.chart.title.TextTitle textTitle79 = jFreeChart77.getTitle();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(textTitle79);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        double double5 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot8.getSeparatorsVisible();
        java.awt.Shape shape10 = ringPlot8.getLegendItemShape();
        dateAxis7.setRightArrow(shape10);
        dateAxis1.setDownArrow(shape10);
        java.util.TimeZone timeZone13 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.PINK;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=0,b=0]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, true, true);
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setLabelToolTip("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        java.lang.Object obj11 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit12, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Category Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker1.setPaint((java.awt.Paint) color2);
        valueMarker1.setLabel("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint10 = ringPlot8.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot8.setNoDataMessageFont(font11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = ringPlot13.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint17 = categoryAxis16.getAxisLinePaint();
        ringPlot13.setLabelOutlinePaint(paint17);
        textBlock6.addLine("java.awt.Color[r=255,g=0,b=0]", font11, paint17);
        valueMarker1.setPaint(paint17);
        float float21 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.8f + "'", float21 == 0.8f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = ringPlot0.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis3.getAxisLinePaint();
        ringPlot0.setLabelOutlinePaint(paint4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        ringPlot0.notifyListeners(plotChangeEvent6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateLeftOutset((double) 0);
        double double12 = rectangleInsets8.trimWidth((double) (-16711936));
        ringPlot0.setLabelPadding(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.6711944E7d) + "'", double12 == (-1.6711944E7d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(100.0d, 4.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        int int7 = xYPlot0.indexOf(xYDataset6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D12 = xYPlot11.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes(0.08d, plotRenderingInfo10, point2D12, false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            xYPlot0.drawBackground(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        java.awt.Stroke stroke78 = jFreeChart77.getBorderStroke();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer51);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        java.awt.Stroke stroke55 = piePlot54.getLabelOutlineStroke();
        categoryPlot52.setRangeCrosshairStroke(stroke55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot52.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot52.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(11, axisLocation58, false);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo2, point2D3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace7, true);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline3 = null;
        dateAxis1.setTimeline(timeline3);
        boolean boolean5 = dateAxis1.isAxisLineVisible();
        dateAxis1.setAutoRange(true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        java.awt.Shape shape78 = piePlot68.getLegendItemShape();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(shape78);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27, numberArray34, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        dateAxis47.setAxisLineStroke(stroke52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint58 = ringPlot56.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot56.setNoDataMessageFont(font59);
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot61.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint65 = categoryAxis64.getAxisLinePaint();
        ringPlot61.setLabelOutlinePaint(paint65);
        textBlock54.addLine("java.awt.Color[r=255,g=0,b=0]", font59, paint65);
        dateAxis47.setLabelFont(font59);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        categoryAxis72.configure();
        java.awt.Font font75 = categoryAxis72.getLabelFont();
        boolean boolean76 = piePlot70.equals((java.lang.Object) categoryAxis72);
        org.jfree.chart.util.Rotation rotation77 = piePlot70.getDirection();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font59, (org.jfree.chart.plot.Plot) piePlot70, true);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke84 = categoryAxis83.getTickMarkStroke();
        categoryAxis83.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis87 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke88 = categoryAxis87.getTickMarkStroke();
        categoryAxis87.configure();
        java.awt.Font font90 = categoryAxis87.getLabelFont();
        categoryAxis83.setLabelFont(font90);
        org.jfree.chart.title.TextTitle textTitle92 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font90);
        textTitle92.setURLText("");
        jFreeChart79.setTitle(textTitle92);
        java.lang.String str96 = textTitle92.getID();
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(font90);
        org.junit.Assert.assertNull(str96);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        dateAxis45.setAxisLineStroke(stroke50);
        org.jfree.chart.text.TextBlock textBlock52 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint56 = ringPlot54.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font57 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot54.setNoDataMessageFont(font57);
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = ringPlot59.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint63 = categoryAxis62.getAxisLinePaint();
        ringPlot59.setLabelOutlinePaint(paint63);
        textBlock52.addLine("java.awt.Color[r=255,g=0,b=0]", font57, paint63);
        dateAxis45.setLabelFont(font57);
        org.jfree.data.general.PieDataset pieDataset67 = null;
        org.jfree.chart.plot.PiePlot piePlot68 = new org.jfree.chart.plot.PiePlot(pieDataset67);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.configure();
        java.awt.Font font73 = categoryAxis70.getLabelFont();
        boolean boolean74 = piePlot68.equals((java.lang.Object) categoryAxis70);
        org.jfree.chart.util.Rotation rotation75 = piePlot68.getDirection();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", font57, (org.jfree.chart.plot.Plot) piePlot68, true);
        org.jfree.chart.title.LegendTitle legendTitle78 = jFreeChart77.getLegend();
        java.awt.Font font79 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        legendTitle78.setItemFont(font79);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rotation75);
        org.junit.Assert.assertNotNull(legendTitle78);
        org.junit.Assert.assertNotNull(font79);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        java.awt.Shape shape2 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.getSeparatorsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = ringPlot5.getLegendItems();
        boolean boolean8 = ringPlot5.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot13 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Color color14 = java.awt.Color.PINK;
        waferMapPlot13.setOutlinePaint((java.awt.Paint) color14);
        ringPlot5.setSectionOutlinePaint((java.lang.Comparable) 0.5d, (java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.configure();
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        boolean boolean7 = piePlot1.equals((java.lang.Object) categoryAxis3);
        java.awt.Shape shape8 = piePlot1.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "Multiple Pie Plot");
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset11, (int) (byte) 0, 1, (java.lang.Comparable) "java.awt.Color[r=0,g=255,b=0]", "java.awt.Color[r=0,g=255,b=0]", "Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.getSeparatorsVisible();
        java.awt.Shape shape4 = ringPlot2.getLegendItemShape();
        dateAxis1.setRightArrow(shape4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset6, (int) (short) 10, 1, (java.lang.Comparable) 2.0d, "Category Plot", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.jfree.data.general.PieDataset pieDataset13 = pieSectionEntity12.getDataset();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        boolean boolean15 = pieSectionEntity12.equals((java.lang.Object) paint14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(pieDataset13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.configure();
        java.awt.Font font9 = categoryAxis6.getLabelFont();
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        textTitle11.setPadding(rectangleInsets12);
        textTitle11.setMargin((double) 100L, (double) 100, (double) 100L, (double) 1L);
        textTitle11.setHeight((double) (short) 0);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        textTitle11.draw(graphics2D21, rectangle2D22);
        boolean boolean24 = textTitle11.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        textTitle11.setPosition(rectangleEdge25);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.getSeparatorsVisible();
        java.awt.Shape shape4 = ringPlot2.getLegendItemShape();
        dateAxis1.setRightArrow(shape4);
        dateAxis1.setPositiveArrowVisible(false);
        dateAxis1.centerRange((double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray10 = new double[] { 10L, 'a', 100, 0.05d, 10, 0.4d };
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "Category Plot", doubleArray11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "", doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }
}

