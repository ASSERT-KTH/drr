import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = barRenderer3D0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D0.getURLGenerator(2019, (int) '#', false);
        double double8 = barRenderer3D0.getLowerClip();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        boolean boolean16 = piePlot14.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke17 = piePlot14.getBaseSectionOutlineStroke();
        boolean boolean18 = chartRenderingInfo12.equals((java.lang.Object) piePlot14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo12.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo12.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 3, (double) 4, rectangle2D21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = barRenderer3D0.initialise(graphics2D9, rectangle2D21, categoryPlot23, 2, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (-1));
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline2.getAdjustForDaylightSaving();
        long long4 = segmentedTimeline2.getSegmentsGroupSize();
        long long5 = segmentedTimeline2.getSegmentsGroupSize();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        projectInfo6.setName("");
        projectInfo6.setCopyright("item");
        java.lang.String str11 = projectInfo6.getLicenceText();
        java.util.List list12 = projectInfo6.getContributors();
        segmentedTimeline2.setExceptionSegments(list12);
        projectInfo0.setContributors(list12);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 86400000L + "'", long5 == 86400000L);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        java.lang.Object obj20 = null;
        boolean boolean21 = legendItemEntity19.equals(obj20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        legendItemEntity19.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection23);
        try {
            java.lang.Number number27 = timeSeriesCollection23.getX(2019, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYAreaRenderer3.setBasePaint((java.awt.Paint) color13);
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list20 = axisCollection19.getAxesAtTop();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17, list20, range21, false);
        org.jfree.data.Range range24 = xYAreaRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        double double26 = timeSeriesCollection17.getDomainUpperBound(true);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy(6, 52);
        int int32 = timeSeriesCollection17.indexOf(timeSeries28);
        timeSeries28.setMaximumItemCount((int) (short) 1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) numberAxis28);
        numberAxis28.setRangeAboutValue((double) 5, (double) 9999);
        java.awt.Paint paint39 = numberAxis28.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(6, 52);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 10, year7);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year7, (double) 31, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        java.lang.Object obj20 = null;
        boolean boolean21 = legendItemEntity19.equals(obj20);
        java.lang.String str22 = legendItemEntity19.getToolTipText();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean28 = combinedRangeXYPlot27.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace29 = combinedRangeXYPlot27.getFixedRangeAxisSpace();
        java.awt.Stroke stroke30 = combinedRangeXYPlot27.getDomainCrosshairStroke();
        categoryPlot19.setDomainGridlineStroke(stroke30);
        int int32 = categoryPlot19.getDatasetCount();
        java.awt.Stroke stroke33 = categoryPlot19.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        xYSeriesCollection0.setIntervalWidth((double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double10 = timeSeriesCollection6.getDomainLowerBound(true);
        double double12 = timeSeriesCollection6.getDomainUpperBound(true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6, false);
        double double15 = intervalXYDelegate14.getIntervalWidth();
        try {
            double double18 = intervalXYDelegate14.getStartXValue(8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.CYAN;
        legendItem26.setFillPaint((java.awt.Paint) color27);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = legendItem26.getFillPaintTransformer();
        legendItem26.setDatasetIndex((-1));
        boolean boolean32 = legendItem26.isLineVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        combinedRangeXYPlot11.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis14, false);
        combinedRangeXYPlot11.clearDomainAxes();
        java.awt.Color color19 = java.awt.Color.ORANGE;
        combinedRangeXYPlot11.setRangeMinorGridlinePaint((java.awt.Paint) color19);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, 8);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot11.setRangeGridlineStroke(stroke23);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        java.lang.String[] strArray6 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("?series=6&amp;item=5", strArray6);
        org.jfree.chart.axis.SymbolAxis symbolAxis9 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme13.setLargeFont(font14);
        xYAreaRenderer3.setSeriesItemLabelFont((int) (short) 1, font14, true);
        java.awt.Paint paint19 = null;
        xYAreaRenderer3.setLegendTextPaint(10, paint19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        boolean boolean22 = xYAreaRenderer3.removeAnnotation(xYAnnotation21);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItem26.equals(obj27);
        legendItem26.setSeriesIndex(0);
        java.lang.String str31 = legendItem26.getToolTipText();
        legendItem26.setURLText("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }
}

