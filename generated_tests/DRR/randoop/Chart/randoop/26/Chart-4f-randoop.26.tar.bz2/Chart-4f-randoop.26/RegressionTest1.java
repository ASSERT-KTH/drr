import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.LegendItem legendItem10 = xYAreaRenderer3.getLegendItem((int) '4', (int) (byte) 0);
        boolean boolean12 = xYAreaRenderer3.isSeriesVisible((int) (short) 10);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2692527886132L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        java.awt.Color color2 = java.awt.Color.darkGray;
        piePlot3D0.setBackgroundPaint((java.awt.Paint) color2);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3D0.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String[] strArray4 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.Object obj6 = null;
        boolean boolean7 = symbolAxis5.equals(obj6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate2.setDescription("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLowerMargin((double) (-2208960000000L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.CYAN;
        legendItem26.setFillPaint((java.awt.Paint) color27);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = legendItem26.getFillPaintTransformer();
        legendItem26.setDatasetIndex((-1));
        java.awt.Color color32 = java.awt.Color.YELLOW;
        legendItem26.setLabelPaint((java.awt.Paint) color32);
        java.lang.Object obj34 = legendItem26.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = rendererChangeEvent1.getType();
        java.lang.String str3 = rendererChangeEvent1.toString();
        java.lang.Object obj4 = rendererChangeEvent1.getRenderer();
        boolean boolean5 = rendererChangeEvent1.getSeriesVisibilityChanged();
        java.lang.Object obj6 = rendererChangeEvent1.getRenderer();
        org.junit.Assert.assertNotNull(stroke0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        xYAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer9.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean19 = legendTitle1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalPositionFactor();
        try {
            double double4 = xYSeriesCollection0.getEndXValue((int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        categoryPlot19.clearDomainMarkers((int) '4');
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray29, numberArray32, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str41 = numberAxis40.getLabelToolTip();
        java.lang.String str42 = numberAxis40.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D38, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer43);
        double double45 = categoryPlot44.getRangeCrosshairValue();
        categoryPlot44.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot44.getRangeAxisLocation(9999);
        categoryPlot19.setRangeAxisLocation(axisLocation49, false);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItem26.equals(obj27);
        java.lang.String str29 = legendItem26.getLabel();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint32 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis31.setLabelPaint(paint32);
        legendItem26.setFillPaint(paint32);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "item" + "'", str29.equals("item"));
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        java.awt.Paint paint30 = legendTitle20.getItemPaint();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint33 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis32.setLabelPaint(paint33);
        boolean boolean35 = numberAxis32.isAutoRange();
        java.awt.Stroke stroke36 = numberAxis32.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str39 = numberAxis38.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis38.setLabelInsets(rectangleInsets40);
        numberAxis32.setTickLabelInsets(rectangleInsets40);
        legendTitle20.setMargin(rectangleInsets40);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        double double45 = ringPlot44.getOuterSeparatorExtension();
        java.awt.Color color46 = java.awt.Color.GREEN;
        ringPlot44.setSeparatorPaint((java.awt.Paint) color46);
        java.awt.Shape shape48 = ringPlot44.getLegendItemShape();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean52 = piePlot3D51.getSimpleLabels();
        java.awt.Color color53 = java.awt.Color.darkGray;
        piePlot3D51.setBackgroundPaint((java.awt.Paint) color53);
        piePlot3D51.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset59 = null;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot(pieDataset59);
        boolean boolean62 = piePlot60.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke63 = piePlot60.getBaseSectionOutlineStroke();
        boolean boolean64 = chartRenderingInfo58.equals((java.lang.Object) piePlot60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = chartRenderingInfo58.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        plotRenderingInfo65.setPlotArea(rectangle2D66);
        org.jfree.chart.plot.PiePlotState piePlotState68 = ringPlot44.initialise(graphics2D49, rectangle2D50, (org.jfree.chart.plot.PiePlot) piePlot3D51, (java.lang.Integer) 0, plotRenderingInfo65);
        org.jfree.chart.StandardChartTheme standardChartTheme70 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font71 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme70.setLargeFont(font71);
        java.awt.Paint paint73 = standardChartTheme70.getCrosshairPaint();
        java.awt.Paint paint74 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme70.setAxisLabelPaint(paint74);
        ringPlot44.setBaseSectionOutlinePaint(paint74);
        boolean boolean77 = rectangleInsets40.equals((java.lang.Object) paint74);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.2d + "'", double45 == 0.2d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
        org.junit.Assert.assertNotNull(piePlotState68);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean6 = piePlot3D5.getSimpleLabels();
        java.awt.Color color7 = java.awt.Color.darkGray;
        piePlot3D5.setBackgroundPaint((java.awt.Paint) color7);
        piePlot3D5.setIgnoreZeroValues(false);
        piePlot3D5.setIgnoreNullValues(true);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D5);
        numberAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        boolean boolean23 = categoryPlot19.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable24 = categoryPlot19.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis3D25.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis3D25.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray37, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelToolTip();
        java.lang.String str47 = numberAxis45.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D43, (org.jfree.chart.axis.ValueAxis) numberAxis45, categoryItemRenderer48);
        categoryAxis3D43.setTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = categoryAxis3D52.getCategoryLabelPositions();
        categoryAxis3D52.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions56 = categoryAxis3D55.getCategoryLabelPositions();
        categoryAxis3D55.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray59 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D25, categoryAxis3D28, categoryAxis3D29, categoryAxis3D43, categoryAxis3D52, categoryAxis3D55 };
        categoryPlot19.setDomainAxes(categoryAxisArray59);
        java.awt.Color color61 = java.awt.Color.white;
        categoryPlot19.setDomainCrosshairPaint((java.awt.Paint) color61);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(comparable24);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(categoryLabelPositions56);
        org.junit.Assert.assertNotNull(categoryAxisArray59);
        org.junit.Assert.assertNotNull(color61);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme1.setAxisLabelPaint(paint5);
        java.awt.Paint paint7 = standardChartTheme1.getTitlePaint();
        java.awt.Font font8 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot19.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        java.awt.Paint paint9 = intervalMarker2.getPaint();
        float float10 = intervalMarker2.getAlpha();
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        intervalMarker2.setLabelPaint(paint11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline2.getAdjustForDaylightSaving();
        long long4 = segmentedTimeline2.getSegmentsGroupSize();
        java.util.Date date6 = segmentedTimeline2.getDate((long) (short) -1);
        long long7 = segmentedTimeline0.toTimelineValue(date6);
        long long8 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 644288399999L + "'", long7 == 644288399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25200000L + "'", long8 == 25200000L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        combinedRangeXYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis24.setLabelPaint(paint25);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        java.awt.Paint paint36 = xYAreaRenderer30.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint41 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis40.setLabelPaint(paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis40.setLabelInsets(rectangleInsets43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYAreaRenderer30.drawDomainGridLine(graphics2D37, xYPlot38, (org.jfree.chart.axis.ValueAxis) numberAxis40, rectangle2D45, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator49, xYURLGenerator50);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator52 = null;
        xYAreaRenderer51.setLegendItemURLGenerator(xYSeriesLabelGenerator52);
        java.awt.Paint paint57 = xYAreaRenderer51.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint62 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis61.setLabelPaint(paint62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis61.setLabelInsets(rectangleInsets64);
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        xYAreaRenderer51.drawDomainGridLine(graphics2D58, xYPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, rectangle2D66, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator70 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator71 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer72 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator70, xYURLGenerator71);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator73 = null;
        xYAreaRenderer72.setLegendItemURLGenerator(xYSeriesLabelGenerator73);
        java.awt.Paint paint78 = xYAreaRenderer72.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = null;
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint83 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis82.setLabelPaint(paint83);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis82.setLabelInsets(rectangleInsets85);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        xYAreaRenderer72.drawDomainGridLine(graphics2D79, xYPlot80, (org.jfree.chart.axis.ValueAxis) numberAxis82, rectangle2D87, (double) 3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray90 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis40, numberAxis61, numberAxis82 };
        categoryPlot19.setRangeAxes(valueAxisArray90);
        categoryPlot19.setCrosshairDatasetIndex(6);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNotNull(valueAxisArray90);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        axisState0.moveCursor((double) 1L, rectangleEdge4);
        axisState0.cursorUp(0.5d);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 0.025d);
        org.jfree.chart.plot.CrosshairState crosshairState6 = new org.jfree.chart.plot.CrosshairState(true);
        double double7 = crosshairState6.getCrosshairDistance();
        crosshairState6.setCrosshairDistance((double) 1.0f);
        boolean boolean10 = flowArrangement4.equals((java.lang.Object) 1.0f);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = combinedRangeXYPlot1.getDomainMarkers((int) (short) 0, layer5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot1.getDomainMinorGridlineStroke();
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot1, (int) (short) 1);
        java.awt.Stroke stroke10 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray18, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        java.lang.String str28 = numberAxis26.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        double double31 = categoryPlot30.getRangeCrosshairValue();
        categoryPlot30.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot30.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        combinedRangeXYPlot36.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis39, false);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke43);
        combinedRangeXYPlot36.setDomainGridlineStroke(stroke43);
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray50, numberArray53, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray57);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D59 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str62 = numberAxis61.getLabelToolTip();
        java.lang.String str63 = numberAxis61.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D59, (org.jfree.chart.axis.ValueAxis) numberAxis61, categoryItemRenderer64);
        double double66 = categoryPlot65.getRangeCrosshairValue();
        categoryPlot65.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation70 = categoryPlot65.getRangeAxisLocation(9999);
        combinedRangeXYPlot36.setDomainAxisLocation(axisLocation70, false);
        categoryPlot30.setRangeAxisLocation(axisLocation70);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation70, false);
        java.awt.Stroke stroke76 = combinedRangeXYPlot1.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint23 = standardChartTheme22.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = standardChartTheme22.getDrawingSupplier();
        categoryPlot19.setDrawingSupplier(drawingSupplier24, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        xYAreaRenderer30.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer30.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.data.Range range41 = xYAreaRenderer30.findRangeBounds(xYDataset40);
        java.awt.Shape shape45 = xYAreaRenderer30.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = legendTitle49.getLegendItemGraphicEdge();
        legendTitle47.setPosition(rectangleEdge50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double53 = rectangleInsets52.getTop();
        legendTitle47.setPadding(rectangleInsets52);
        org.jfree.chart.entity.TitleEntity titleEntity56 = new org.jfree.chart.entity.TitleEntity(shape45, (org.jfree.chart.title.Title) legendTitle47, "");
        java.awt.Paint paint57 = legendTitle47.getItemPaint();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint60 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis59.setLabelPaint(paint60);
        boolean boolean62 = numberAxis59.isAutoRange();
        java.awt.Stroke stroke63 = numberAxis59.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis65.setLabelInsets(rectangleInsets67);
        numberAxis59.setTickLabelInsets(rectangleInsets67);
        legendTitle47.setMargin(rectangleInsets67);
        categoryPlot19.setInsets(rectangleInsets67);
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(drawingSupplier24);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        java.awt.Font font22 = categoryAxis3D14.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean24 = combinedRangeXYPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = combinedRangeXYPlot23.getFixedRangeAxisSpace();
        combinedRangeXYPlot23.setWeight(0);
        java.util.List list28 = combinedRangeXYPlot23.getSubplots();
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        double double30 = ringPlot29.getOuterSeparatorExtension();
        java.awt.Stroke stroke31 = ringPlot29.getLabelLinkStroke();
        combinedRangeXYPlot23.setDomainZeroBaselineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font22, (org.jfree.chart.plot.Plot) combinedRangeXYPlot23, true);
        int int35 = jFreeChart34.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        waferMapPlot1.setRenderer(waferMapRenderer5);
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 8, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemPaint((int) (short) 0, 10, false);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean17 = piePlot15.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        piePlot15.axisChanged(axisChangeEvent18);
        boolean boolean20 = piePlot15.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot15.setLabelOutlineStroke(stroke21);
        xYAreaRenderer3.setBaseStroke(stroke21, false);
        java.awt.Paint paint28 = xYAreaRenderer3.getItemLabelPaint(9999, 6, false);
        boolean boolean29 = xYAreaRenderer3.getPlotShapes();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = standardChartTheme1.getExtraLargeFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Object obj0 = null;
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray6, numberArray9, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelToolTip();
        java.lang.String str19 = numberAxis17.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        java.awt.Font font23 = categoryAxis3D15.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean25 = combinedRangeXYPlot24.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace26 = combinedRangeXYPlot24.getFixedRangeAxisSpace();
        combinedRangeXYPlot24.setWeight(0);
        java.util.List list29 = combinedRangeXYPlot24.getSubplots();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        double double31 = ringPlot30.getOuterSeparatorExtension();
        java.awt.Stroke stroke32 = ringPlot30.getLabelLinkStroke();
        combinedRangeXYPlot24.setDomainZeroBaselineStroke(stroke32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font23, (org.jfree.chart.plot.Plot) combinedRangeXYPlot24, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart35, chartChangeEventType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedRangeXYPlot0.getRangeAxis(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        double double6 = numberAxis1.getUpperMargin();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean10 = piePlot8.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot8.axisChanged(axisChangeEvent11);
        boolean boolean13 = piePlot8.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot8.setLabelOutlineStroke(stroke14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot8.setLabelBackgroundPaint((java.awt.Paint) color16);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot8);
        piePlot8.setShadowYOffset((double) 86400000L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        java.lang.Object obj10 = combinedRangeXYPlot0.clone();
        boolean boolean11 = combinedRangeXYPlot0.isRangePannable();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 1);
        boolean boolean10 = piePlot2.equals((java.lang.Object) 1);
        double double11 = piePlot2.getLabelLinkMargin();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        boolean boolean14 = pieLabelLinkStyle12.equals((java.lang.Object) (short) 1);
        piePlot2.setLabelLinkStyle(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.025d + "'", double11 == 0.025d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries2.add((-1.0d), (java.lang.Number) (-6.0d), true);
        xYSeries2.fireSeriesChanged();
        xYSeries2.add(0.0d, (java.lang.Number) (short) 100, false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Font font3 = null;
        try {
            categoryAxis3D0.setLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        java.lang.String str22 = numberAxis20.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.awt.Font font26 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D18, "");
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape4, "RectangleAnchor.BOTTOM_RIGHT", "");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean22 = categoryPlot19.removeAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) waferMapPlot2);
        java.lang.String str4 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ItemLabelAnchor.INSIDE3" + "'", str4.equals("ItemLabelAnchor.INSIDE3"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange4);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint5.toRangeWidth((org.jfree.data.Range) dateRange7);
        try {
            org.jfree.chart.util.Size2D size2D10 = legendTitle1.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        boolean boolean3 = xYSeriesCollection0.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset12, false);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset12, false);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        xYBarRenderer1.setDrawBarOutline(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent8);
        boolean boolean10 = combinedRangeXYPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("?series=0&amp;item=10");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        xYSeriesCollection0.validateObject();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add(0.2d, (double) (byte) 1, false);
        xYSeriesCollection0.addSeries(xYSeries11);
        org.jfree.data.time.TimeSeries timeSeries17 = null;
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeSeries17, timeZone18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        xYSeries11.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot19.axisChanged(axisChangeEvent23);
        categoryPlot19.setRangeZeroBaselineVisible(false);
        java.awt.Paint paint27 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        categoryPlot19.setRangeZeroBaselinePaint(paint27);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        java.awt.Paint paint30 = legendTitle20.getItemPaint();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.awt.Paint paint33 = piePlot32.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot32);
        legendTitle20.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart34);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        java.awt.Color color2 = java.awt.Color.darkGray;
        piePlot3D0.setBackgroundPaint((java.awt.Paint) color2);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean7 = combinedRangeXYPlot6.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection11 = combinedRangeXYPlot6.getDomainMarkers((int) (short) 0, layer10);
        combinedRangeXYPlot6.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke14 = combinedRangeXYPlot6.getDomainZeroBaselineStroke();
        boolean boolean15 = piePlot3D0.equals((java.lang.Object) stroke14);
        double double16 = piePlot3D0.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        java.awt.Paint paint17 = xYAreaRenderer3.getItemOutlinePaint(2, (int) (byte) 1, true);
        xYAreaRenderer3.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double10 = timeSeriesCollection6.getDomainLowerBound(true);
        double double12 = timeSeriesCollection6.getDomainUpperBound(true);
        try {
            int int14 = timeSeriesCollection6.getItemCount(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelToolTip();
        combinedRangeXYPlot1.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis4, false);
        combinedRangeXYPlot1.setRangeCrosshairVisible(false);
        boolean boolean10 = dateTickUnitType0.equals((java.lang.Object) combinedRangeXYPlot1);
        java.lang.String str11 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTickUnitType.HOUR" + "'", str11.equals("DateTickUnitType.HOUR"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Image image4 = jFreeChart3.getBackgroundImage();
        float float5 = jFreeChart3.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        piePlot1.setBackgroundImageAlignment((int) (short) 100);
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYBarRenderer1.getURLGenerator(10, 255, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYURLGenerator7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint5 = ringPlot0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        int int63 = categoryPlot19.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation64 = categoryPlot19.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(axisLocation64);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint3 = intervalMarker2.getPaint();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint6 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis5.setLabelPaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis5.setLabelInsets(rectangleInsets8);
        intervalMarker2.setLabelOffset(rectangleInsets8);
        double double12 = rectangleInsets8.extendHeight((double) 64);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 70.0d + "'", double12 == 70.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        int int5 = numberAxis1.getMinorTickCount();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        xYAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer9.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.data.Range range20 = xYAreaRenderer9.findRangeBounds(xYDataset19);
        java.awt.Shape shape24 = xYAreaRenderer9.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle28.getLegendItemGraphicEdge();
        legendTitle26.setPosition(rectangleEdge29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double32 = rectangleInsets31.getTop();
        legendTitle26.setPadding(rectangleInsets31);
        org.jfree.chart.entity.TitleEntity titleEntity35 = new org.jfree.chart.entity.TitleEntity(shape24, (org.jfree.chart.title.Title) legendTitle26, "");
        numberAxis1.setRightArrow(shape24);
        numberAxis1.setAutoTickUnitSelection(true, false);
        numberAxis1.setLabelAngle((double) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("0", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        boolean boolean24 = piePlot22.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke25 = piePlot22.getBaseSectionOutlineStroke();
        boolean boolean26 = chartRenderingInfo20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo20.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        plotRenderingInfo27.setPlotArea(rectangle2D28);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo27);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean33 = xYBarRenderer32.isDrawBarOutline();
        java.lang.Object obj34 = xYBarRenderer32.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection(timeSeries35, timeZone36);
        boolean boolean38 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        org.jfree.data.Range range39 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        xYItemRendererState30.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection37);
        boolean boolean41 = legendItemEntity19.equals((java.lang.Object) xYItemRendererState30);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState42 = null;
        xYItemRendererState30.setCrosshairState(xYCrosshairState42);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = standardChartTheme1.getLabelLinkStyle();
        java.lang.String str5 = pieLabelLinkStyle4.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str5.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke2 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) numberAxis2, seriesChangeInfo5);
        boolean boolean7 = rangeType0.equals((java.lang.Object) seriesChangeEvent6);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long4 = segmentedTimeline2.toTimelineValue(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2692527886132L + "'", long4 == 2692527886132L);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYAreaRenderer3.getToolTipGenerator((int) (byte) 10, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator16, xYURLGenerator17);
        boolean boolean19 = xYAreaRenderer18.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke21 = xYAreaRenderer18.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer18.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition25);
        xYAreaRenderer3.setSeriesPositiveItemLabelPosition((int) (byte) 1, itemLabelPosition25, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYAreaRenderer3.notifyListeners(rendererChangeEvent29);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setAutoPopulateSeriesOutlineStroke(true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer1.getToolTipGenerator(2, 8, false);
        boolean boolean8 = xYBarRenderer1.getBaseSeriesVisibleInLegend();
        xYBarRenderer1.setShadowVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItem26.equals(obj27);
        java.lang.String str29 = legendItem26.getLabel();
        legendItem26.setShapeVisible(true);
        legendItem26.setDescription("{0}: ({1}, {2})");
        java.lang.String str34 = legendItem26.getURLText();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "item" + "'", str29.equals("item"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(52, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.awt.Image image16 = combinedRangeXYPlot11.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot11.getRangeAxisLocation((int) (byte) 100);
        combinedRangeXYPlot0.setRangeAxisLocation(0, axisLocation18);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis27.setLabelPaint(paint28);
        boolean boolean30 = numberAxis27.isAutoRange();
        java.awt.Stroke stroke31 = numberAxis27.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis33.setLabelInsets(rectangleInsets35);
        numberAxis27.setTickLabelInsets(rectangleInsets35);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        boolean boolean42 = piePlot40.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke43 = piePlot40.getBaseSectionOutlineStroke();
        boolean boolean44 = chartRenderingInfo38.equals((java.lang.Object) piePlot40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo38.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection46 = chartRenderingInfo38.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D47 = chartRenderingInfo38.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets35.createInsetRectangle(rectangle2D47, true, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot51 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelToolTip();
        combinedRangeXYPlot51.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis54, false);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent59 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke58);
        combinedRangeXYPlot51.setDomainGridlineStroke(stroke58);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = null;
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor62);
        combinedRangeXYPlot51.setQuadrantOrigin(point2D63);
        org.jfree.chart.plot.PlotState plotState65 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot66 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str70 = numberAxis69.getLabelToolTip();
        combinedRangeXYPlot66.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis69, false);
        combinedRangeXYPlot66.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str80 = numberAxis79.getLabelToolTip();
        java.lang.String str81 = numberAxis79.getLabelToolTip();
        boolean boolean82 = textTitle77.equals((java.lang.Object) numberAxis79);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor83 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean84 = textTitle77.equals((java.lang.Object) itemLabelAnchor83);
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo87 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset88 = null;
        org.jfree.chart.plot.PiePlot piePlot89 = new org.jfree.chart.plot.PiePlot(pieDataset88);
        boolean boolean91 = piePlot89.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke92 = piePlot89.getBaseSectionOutlineStroke();
        boolean boolean93 = chartRenderingInfo87.equals((java.lang.Object) piePlot89);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = chartRenderingInfo87.getPlotInfo();
        java.lang.Object obj95 = textTitle77.draw(graphics2D85, rectangle2D86, (java.lang.Object) plotRenderingInfo94);
        combinedRangeXYPlot66.drawAnnotations(graphics2D75, rectangle2D76, plotRenderingInfo94);
        try {
            piePlot3D7.draw(graphics2D25, rectangle2D47, point2D63, plotState65, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
        org.junit.Assert.assertNotNull(entityCollection46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(point2D63);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo94);
        org.junit.Assert.assertNull(obj95);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = xYAreaRenderer3.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        try {
            boolean boolean18 = xYSeriesCollection14.isSelected(52, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint4 = standardChartTheme1.getErrorIndicatorPaint();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        standardChartTheme1.setShadowPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean5 = combinedRangeXYPlot4.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedRangeXYPlot4.getFixedRangeAxisSpace();
        combinedRangeXYPlot4.setWeight(0);
        java.util.List list9 = combinedRangeXYPlot4.getSubplots();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, list9, true);
        xYSeriesCollection3.validateObject();
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) xYSeriesCollection3, (int) (short) 10, (int) '4', "", "ThreadContext");
        try {
            org.jfree.data.xy.XYSeries xYSeries19 = xYSeriesCollection3.getSeries((java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: false");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        java.awt.Font font22 = categoryAxis3D14.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean24 = combinedRangeXYPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = combinedRangeXYPlot23.getFixedRangeAxisSpace();
        combinedRangeXYPlot23.setWeight(0);
        java.util.List list28 = combinedRangeXYPlot23.getSubplots();
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        double double30 = ringPlot29.getOuterSeparatorExtension();
        java.awt.Stroke stroke31 = ringPlot29.getLabelLinkStroke();
        combinedRangeXYPlot23.setDomainZeroBaselineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font22, (org.jfree.chart.plot.Plot) combinedRangeXYPlot23, true);
        java.awt.Paint paint35 = jFreeChart34.getBorderPaint();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardPieToolTipGenerator0.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getLabelGap();
        boolean boolean5 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray10, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str19 = numberAxis18.getLabelToolTip();
        java.lang.String str20 = numberAxis18.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer21);
        boolean boolean23 = intervalMarker2.equals((java.lang.Object) categoryItemRenderer21);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        intervalMarker2.setLabelFont(font24);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        boolean boolean4 = numberAxis1.isAutoRange();
        java.awt.Stroke stroke5 = numberAxis1.getTickMarkStroke();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelToolTip();
        java.lang.String str23 = numberAxis21.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18);
        numberAxis1.setRangeWithMargins(range26, false, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) (byte) 1);
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = color8.brighter();
        piePlot1.setSectionPaint((java.lang.Comparable) 10.0f, (java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = xYAreaRenderer3.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        java.awt.Shape shape16 = xYAreaRenderer3.getLegendArea();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator19, xYURLGenerator20);
        xYAreaRenderer21.clearSeriesPaints(true);
        boolean boolean24 = xYAreaRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer21.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator27, true);
        xYAreaRenderer3.setSeriesURLGenerator((int) (short) 1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator27, true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = combinedRangeXYPlot0.indexOf(xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelToolTip();
        java.lang.String str21 = numberAxis19.getLabelToolTip();
        boolean boolean22 = textTitle17.equals((java.lang.Object) numberAxis19);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean24 = textTitle17.equals((java.lang.Object) itemLabelAnchor23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean31 = piePlot29.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke32 = piePlot29.getBaseSectionOutlineStroke();
        boolean boolean33 = chartRenderingInfo27.equals((java.lang.Object) piePlot29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = chartRenderingInfo27.getPlotInfo();
        java.lang.Object obj35 = textTitle17.draw(graphics2D25, rectangle2D26, (java.lang.Object) plotRenderingInfo34);
        try {
            combinedRangeXYPlot0.draw(graphics2D11, rectangle2D12, point2D15, plotState16, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo34);
        org.junit.Assert.assertNull(obj35);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter9 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        xYBarRenderer1.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter9);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator(10, xYItemLabelGenerator12, false);
        boolean boolean15 = xYBarRenderer1.getShadowsVisible();
        boolean boolean16 = xYBarRenderer1.getShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint6 = standardChartTheme5.getItemLabelPaint();
        standardChartTheme1.setLabelLinkPaint(paint6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = standardChartTheme1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        java.awt.Paint paint17 = xYAreaRenderer3.getItemOutlinePaint(2, (int) (byte) 1, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean20 = combinedRangeXYPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace21 = combinedRangeXYPlot19.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = combinedRangeXYPlot19.getDomainMarkers((int) (short) 0, layer23);
        try {
            xYAreaRenderer3.addAnnotation(xYAnnotation18, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.lang.Object obj2 = xYStepAreaRenderer1.clone();
        java.lang.Object obj3 = xYStepAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        double double6 = legendTitle1.getContentXOffset();
        double double7 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle1.getItemContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean10 = blockContainer8.equals((java.lang.Object) itemLabelAnchor9);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke5 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Paint paint11 = piePlot10.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot10);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = ringPlot0.getInsets();
        java.awt.Stroke stroke26 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = ringPlot0.getLabelGenerator();
        double double28 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset12);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10.0d + "'", number20.equals(10.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis8.setLabelPaint(paint9);
        boolean boolean11 = numberAxis8.isAutoRange();
        java.awt.Stroke stroke12 = numberAxis8.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis14.setLabelInsets(rectangleInsets16);
        numberAxis8.setTickLabelInsets(rectangleInsets16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean23 = piePlot21.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke24 = piePlot21.getBaseSectionOutlineStroke();
        boolean boolean25 = chartRenderingInfo19.equals((java.lang.Object) piePlot21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection27 = chartRenderingInfo19.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo19.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets16.createInsetRectangle(rectangle2D28, true, true);
        try {
            legendTitle1.draw(graphics2D6, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertNotNull(entityCollection27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        java.lang.String str3 = numberAxis1.getLabelToolTip();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) numberAxis1, seriesChangeInfo4);
        numberAxis1.setFixedDimension((double) 255);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        boolean boolean6 = objectList1.equals((java.lang.Object) boolean5);
        org.jfree.data.UnknownKeyException unknownKeyException8 = new org.jfree.data.UnknownKeyException("ThreadContext");
        java.lang.Throwable[] throwableArray9 = unknownKeyException8.getSuppressed();
        int int10 = objectList1.indexOf((java.lang.Object) throwableArray9);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYAreaRenderer10.setLegendItemURLGenerator(xYSeriesLabelGenerator11);
        xYAreaRenderer10.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        boolean boolean18 = xYAreaRenderer10.isSeriesVisible(10);
        java.awt.Stroke stroke22 = xYAreaRenderer10.getItemOutlineStroke(64, 500, false);
        try {
            xYAreaRenderer3.setSeriesStroke((int) (short) -1, stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        combinedRangeXYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        java.awt.Font font19 = null;
        xYAreaRenderer16.setBaseItemLabelFont(font19, false);
        java.awt.Font font23 = xYAreaRenderer16.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator24 = xYAreaRenderer16.getBaseToolTipGenerator();
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNull(xYToolTipGenerator24);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.lang.Object obj2 = xYStepAreaRenderer1.clone();
        double double3 = xYStepAreaRenderer1.getRangeBase();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemFillPaint(2, 2, true);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = rendererChangeEvent15.getType();
        xYAreaRenderer3.notifyListeners(rendererChangeEvent15);
        xYAreaRenderer3.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.brighter();
        standardChartTheme1.setWallPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator8, xYURLGenerator9);
        boolean boolean11 = xYAreaRenderer10.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke13 = xYAreaRenderer10.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        double double20 = ringPlot19.getOuterSeparatorExtension();
        java.awt.Color color21 = java.awt.Color.GREEN;
        ringPlot19.setSeparatorPaint((java.awt.Paint) color21);
        java.awt.Shape shape23 = ringPlot19.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme25 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint26 = standardChartTheme25.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        boolean boolean30 = piePlot28.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = null;
        piePlot28.axisChanged(axisChangeEvent31);
        boolean boolean33 = piePlot28.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot28.setLabelOutlineStroke(stroke34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        intervalMarker38.setOutlinePaint((java.awt.Paint) color39);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("item", "item", "", "", shape23, paint26, stroke34, (java.awt.Paint) color39);
        xYAreaRenderer10.setSeriesItemLabelPaint(1, paint26);
        standardChartTheme1.setWallPaint(paint26);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter44 = standardChartTheme1.getXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter44);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(xYBarPainter44);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) legendItem26, (java.lang.Object) numberAxis28);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("?series=6&amp;item=5", strArray6);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend9 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        xYAreaRenderer3.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.util.List list8 = combinedRangeXYPlot0.getAnnotations();
        java.awt.Color color9 = java.awt.Color.WHITE;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        double double5 = ringPlot0.getShadowXOffset();
        org.jfree.chart.util.Rotation rotation6 = org.jfree.chart.util.Rotation.CLOCKWISE;
        ringPlot0.setDirection(rotation6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        combinedRangeXYPlot0.setRangePannable(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean23 = combinedRangeXYPlot22.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace24 = combinedRangeXYPlot22.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = combinedRangeXYPlot22.getDomainMarkers((int) (short) 0, layer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = combinedRangeXYPlot22.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelToolTip();
        java.lang.String str35 = numberAxis33.getLabelToolTip();
        boolean boolean36 = textTitle31.equals((java.lang.Object) numberAxis33);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean38 = textTitle31.equals((java.lang.Object) itemLabelAnchor37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        boolean boolean45 = piePlot43.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke46 = piePlot43.getBaseSectionOutlineStroke();
        boolean boolean47 = chartRenderingInfo41.equals((java.lang.Object) piePlot43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = chartRenderingInfo41.getPlotInfo();
        java.lang.Object obj49 = textTitle31.draw(graphics2D39, rectangle2D40, (java.lang.Object) plotRenderingInfo48);
        combinedRangeXYPlot22.handleClick((int) (short) 100, 2, plotRenderingInfo48);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 1, plotRenderingInfo48);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo48);
        org.junit.Assert.assertNull(obj49);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        java.awt.Font font19 = xYAreaRenderer3.getLegendTextFont((int) '#');
        java.lang.Boolean boolean21 = xYAreaRenderer3.getSeriesItemLabelsVisible(1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer22 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer3.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer22);
        java.lang.Boolean boolean25 = xYAreaRenderer3.getSeriesCreateEntities((int) '4');
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21.equals(false));
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        numberFormat0.setMinimumFractionDigits((int) (short) 100);
        boolean boolean3 = numberFormat0.isGroupingUsed();
        java.math.RoundingMode roundingMode4 = numberFormat0.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("PieSection: 0, 100(item)");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        xYAreaRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(6, 52);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        timeSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYStepAreaRenderer1.setShapesVisible(false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getPlotArea();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator7);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = null;
        xYAreaRenderer3.setSeriesItemLabelGenerator(64, xYItemLabelGenerator10);
        boolean boolean12 = xYAreaRenderer3.isOutline();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double10 = timeSeriesCollection6.getDomainLowerBound(true);
        double double12 = timeSeriesCollection6.getDomainUpperBound(true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6, false);
        try {
            java.lang.Number number17 = intervalXYDelegate14.getEndX(2147483647, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean3 = legendTitle1.visible;
        boolean boolean4 = legendTitle1.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getPosition();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        boolean boolean13 = piePlot11.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean15 = chartRenderingInfo9.equals((java.lang.Object) piePlot11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo9.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection17 = chartRenderingInfo9.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo9.getChartArea();
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 3, (double) 4, rectangle2D18);
        try {
            legendTitle1.draw(graphics2D6, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNotNull(entityCollection17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("{0}");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme13.setLargeFont(font14);
        xYAreaRenderer3.setSeriesItemLabelFont((int) (short) 1, font14, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean22 = piePlot20.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke23 = piePlot20.getBaseSectionOutlineStroke();
        boolean boolean24 = chartRenderingInfo18.equals((java.lang.Object) piePlot20);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator25);
        java.awt.Paint paint27 = piePlot20.getLabelShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator28 = null;
        piePlot20.setLegendLabelURLGenerator(pieURLGenerator28);
        boolean boolean30 = xYAreaRenderer3.hasListener((java.util.EventListener) piePlot20);
        xYAreaRenderer3.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.axis.AxisCollection axisCollection8 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list9 = axisCollection8.getAxesAtTop();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list9, range10, false);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list9, true);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(6, 52);
        timeSeries19.setRangeDescription("0");
        int int22 = timeSeriesCollection2.indexOf(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float4 = jFreeChart3.getBackgroundImageAlpha();
        try {
            org.jfree.chart.title.Title title6 = jFreeChart3.getSubtitle((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setUpperBound(0.025d);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        java.awt.Paint paint9 = intervalMarker2.getPaint();
        java.awt.Paint paint10 = intervalMarker2.getPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        jFreeChart3.setBackgroundImageAlignment(500);
        jFreeChart3.setNotify(true);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot10 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint6 = standardChartTheme5.getItemLabelPaint();
        standardChartTheme1.setLabelLinkPaint(paint6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        java.lang.String str63 = axisLocation59.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation64 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation59, plotOrientation64);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str63.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 10);
        boolean boolean3 = numberFormat0.isGroupingUsed();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        double double5 = ringPlot0.getShadowXOffset();
        java.awt.Paint paint6 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        intervalMarker4.setOutlinePaint((java.awt.Paint) color5);
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean9 = piePlot7.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        intervalMarker5.setStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color2, stroke10, (java.awt.Paint) color12, stroke13, (float) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Object obj17 = null;
        boolean boolean18 = textAnchor16.equals(obj17);
        intervalMarker15.setLabelTextAnchor(textAnchor16);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        intervalMarker15.removeChangeListener(markerChangeListener20);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint3 = standardChartTheme2.getItemLabelPaint();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.brighter();
        standardChartTheme2.setWallPaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = standardChartTheme2.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator9, xYURLGenerator10);
        boolean boolean12 = xYAreaRenderer11.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke14 = xYAreaRenderer11.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        double double21 = ringPlot20.getOuterSeparatorExtension();
        java.awt.Color color22 = java.awt.Color.GREEN;
        ringPlot20.setSeparatorPaint((java.awt.Paint) color22);
        java.awt.Shape shape24 = ringPlot20.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme26 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint27 = standardChartTheme26.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean31 = piePlot29.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = null;
        piePlot29.axisChanged(axisChangeEvent32);
        boolean boolean34 = piePlot29.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot29.setLabelOutlineStroke(stroke35);
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color40 = java.awt.Color.LIGHT_GRAY;
        intervalMarker39.setOutlinePaint((java.awt.Paint) color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("item", "item", "", "", shape24, paint27, stroke35, (java.awt.Paint) color40);
        xYAreaRenderer11.setSeriesItemLabelPaint(1, paint27);
        standardChartTheme2.setWallPaint(paint27);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter45 = standardChartTheme2.getXYBarPainter();
        boolean boolean46 = lengthConstraintType0.equals((java.lang.Object) standardChartTheme2);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(xYBarPainter45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme1.setAxisLabelPaint(paint5);
        java.awt.Paint paint7 = standardChartTheme1.getTitlePaint();
        java.awt.Font font8 = standardChartTheme1.getExtraLargeFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline3.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline5.getSegment((long) (-1));
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 100, (java.lang.Object) segment7);
        boolean boolean10 = segment7.contains((-2208959999900L));
        boolean boolean13 = segment7.contained(0L, (long) '#');
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        double double6 = piePlot1.getMaximumExplodePercent();
        double double7 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        xYSeriesCollection0.validateObject();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add(0.2d, (double) (byte) 1, false);
        xYSeriesCollection0.addSeries(xYSeries11);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer20.setLegendItemURLGenerator(xYSeriesLabelGenerator21);
        java.awt.Paint paint26 = xYAreaRenderer20.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        boolean boolean27 = xYSeriesCollection0.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        titleEntity29.setURLText("ThreadContext");
        org.jfree.chart.title.Title title32 = titleEntity29.getTitle();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(title32);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        boolean boolean9 = xYBarRenderer1.getItemVisible((int) (short) 10, 8);
        java.awt.Paint paint11 = xYBarRenderer1.getSeriesOutlinePaint((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        int int5 = numberAxis1.getMinorTickCount();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) 100, (double) 3);
        java.lang.String str12 = verticalAlignment8.toString();
        boolean boolean13 = numberAxis1.equals((java.lang.Object) verticalAlignment8);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str12.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries2.add((java.lang.Number) 1.0d, (java.lang.Number) 2.0f, false);
        xYSeries2.setDescription("ItemLabelAnchor.INSIDE3");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PieSection: 0, 100(item)");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name PieSection: 0, 100(item), locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getCrosshairDistance();
        crosshairState1.setCrosshairY((double) (-1));
        crosshairState1.setDatasetIndex((int) '#');
        double double7 = crosshairState1.getAnchorY();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Font font1 = piePlot3D0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.brighter();
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str2.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot19.getRowRenderingOrder();
        int int21 = categoryPlot19.getRendererCount();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace22, true);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYAreaRenderer3.setBasePaint((java.awt.Paint) color13);
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list20 = axisCollection19.getAxesAtTop();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17, list20, range21, false);
        org.jfree.data.Range range24 = xYAreaRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        double double26 = timeSeriesCollection17.getDomainUpperBound(true);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy(6, 52);
        int int32 = timeSeriesCollection17.indexOf(timeSeries28);
        java.lang.Class class33 = timeSeries28.getTimePeriodClass();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(class33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        java.lang.Object obj5 = ringPlot0.clone();
        ringPlot0.setSimpleLabels(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean9 = combinedRangeXYPlot8.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = combinedRangeXYPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection13 = combinedRangeXYPlot8.getDomainMarkers((int) (short) 0, layer12);
        java.awt.Stroke stroke14 = combinedRangeXYPlot8.getDomainMinorGridlineStroke();
        boolean boolean15 = ringPlot0.equals((java.lang.Object) stroke14);
        ringPlot0.setAutoPopulateSectionPaint(false);
        java.awt.Shape shape18 = ringPlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        boolean boolean11 = xYAreaRenderer3.isSeriesVisible(10);
        java.awt.Stroke stroke15 = xYAreaRenderer3.getItemOutlineStroke(64, 500, false);
        boolean boolean17 = xYAreaRenderer3.isSeriesVisible(4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke0);
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart3 = rendererChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(stroke0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getName();
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("AxisLocation.BOTTOM_OR_RIGHT", "ThreadContext", "?series=6&amp;item=5", "ThreadContext");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(64);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalPositionFactor();
        try {
            int int5 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection0, 0, (double) (short) 10, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Color color2 = java.awt.Color.CYAN;
        combinedRangeXYPlot0.setQuadrantPaint(3, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline7.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = segmentedTimeline7.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline9.getSegment((long) (-1));
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 100, (java.lang.Object) segment11);
        java.lang.String str13 = standardPieToolTipGenerator1.generateToolTip(pieDataset3, (java.lang.Comparable) boolean12);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange4);
        numberAxis1.setRange((org.jfree.data.Range) dateRange4, true, true);
        double double9 = dateRange4.getLowerBound();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font5);
        java.awt.Font font7 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        boolean boolean24 = piePlot22.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke25 = piePlot22.getBaseSectionOutlineStroke();
        boolean boolean26 = chartRenderingInfo20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo20.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        plotRenderingInfo27.setPlotArea(rectangle2D28);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo27);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean33 = xYBarRenderer32.isDrawBarOutline();
        java.lang.Object obj34 = xYBarRenderer32.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection(timeSeries35, timeZone36);
        boolean boolean38 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        org.jfree.data.Range range39 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        xYItemRendererState30.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection37);
        boolean boolean41 = legendItemEntity19.equals((java.lang.Object) xYItemRendererState30);
        java.lang.Object obj42 = legendItemEntity19.clone();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = numberAxis15.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setMinorTickCount(8);
        org.jfree.chart.StandardChartTheme standardChartTheme27 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint28 = standardChartTheme27.getItemLabelPaint();
        java.awt.Color color29 = java.awt.Color.WHITE;
        java.awt.Color color30 = color29.brighter();
        standardChartTheme27.setWallPaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = standardChartTheme27.getTitlePaint();
        numberAxis23.setAxisLinePaint(paint32);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = legendTitle38.getLegendItemGraphicEdge();
        legendTitle36.setPosition(rectangleEdge39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets41.getTop();
        legendTitle36.setPadding(rectangleInsets41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint46 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis45.setLabelPaint(paint46);
        boolean boolean48 = numberAxis45.isAutoRange();
        java.awt.Stroke stroke49 = numberAxis45.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str52 = numberAxis51.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis51.setLabelInsets(rectangleInsets53);
        numberAxis45.setTickLabelInsets(rectangleInsets53);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        boolean boolean60 = piePlot58.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke61 = piePlot58.getBaseSectionOutlineStroke();
        boolean boolean62 = chartRenderingInfo56.equals((java.lang.Object) piePlot58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = chartRenderingInfo56.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection64 = chartRenderingInfo56.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D65 = chartRenderingInfo56.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets53.createInsetRectangle(rectangle2D65, true, true);
        rectangleInsets41.trim(rectangle2D68);
        org.jfree.chart.LegendItemSource legendItemSource70 = null;
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle(legendItemSource70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = legendTitle71.getLegendItemGraphicEdge();
        boolean boolean73 = legendTitle71.visible;
        boolean boolean74 = legendTitle71.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = legendTitle71.getPosition();
        double double76 = numberAxis23.valueToJava2D((double) (short) 100, rectangle2D68, rectangleEdge75);
        org.jfree.chart.LegendItemSource legendItemSource77 = null;
        org.jfree.chart.title.LegendTitle legendTitle78 = new org.jfree.chart.title.LegendTitle(legendItemSource77);
        org.jfree.chart.LegendItemSource legendItemSource79 = null;
        org.jfree.chart.title.LegendTitle legendTitle80 = new org.jfree.chart.title.LegendTitle(legendItemSource79);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = legendTitle80.getLegendItemGraphicEdge();
        legendTitle78.setPosition(rectangleEdge81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = legendTitle78.getLegendItemGraphicEdge();
        double double84 = numberAxis15.lengthToJava2D(0.0d, rectangle2D68, rectangleEdge83);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo63);
        org.junit.Assert.assertNotNull(entityCollection64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-1194.0d) + "'", double76 == (-1194.0d));
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean30 = combinedRangeXYPlot29.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace31 = combinedRangeXYPlot29.getFixedRangeAxisSpace();
        combinedRangeXYPlot29.setWeight(0);
        java.awt.Image image34 = combinedRangeXYPlot29.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation36 = combinedRangeXYPlot29.getRangeAxisLocation((int) (byte) 100);
        categoryPlot19.setRangeAxisLocation(axisLocation36, false);
        int int39 = categoryPlot19.getRendererCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelToolTip();
        combinedRangeXYPlot40.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis43, false);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke47);
        combinedRangeXYPlot40.setDomainGridlineStroke(stroke47);
        categoryPlot19.setRangeCrosshairStroke(stroke47);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 0, (float) 4);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity8 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart6, "item");
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart6.getLegend();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) 10, (double) (short) 100, 3.0d);
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder8.getInsets();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        xYAreaRenderer3.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator10 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator13, xYURLGenerator14);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYAreaRenderer15.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        java.awt.Paint paint21 = xYAreaRenderer15.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator22 = null;
        xYAreaRenderer15.setLegendItemURLGenerator(xYSeriesLabelGenerator22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean25 = combinedRangeXYPlot24.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace26 = combinedRangeXYPlot24.getFixedRangeAxisSpace();
        combinedRangeXYPlot24.setWeight(0);
        java.util.List list29 = combinedRangeXYPlot24.getSubplots();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        double double31 = ringPlot30.getOuterSeparatorExtension();
        java.awt.Stroke stroke32 = ringPlot30.getLabelLinkStroke();
        combinedRangeXYPlot24.setDomainZeroBaselineStroke(stroke32);
        xYAreaRenderer15.setBaseStroke(stroke32);
        piePlot1.setLabelOutlineStroke(stroke32);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 10, year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.next();
        java.awt.Paint paint41 = piePlot1.getSectionPaint((java.lang.Comparable) year38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNull(paint41);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        try {
            double double19 = xYSeriesCollection0.getEndYValue(9999, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        xYBarRenderer1.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 1);
        boolean boolean10 = piePlot2.equals((java.lang.Object) 1);
        piePlot2.setExplodePercent((java.lang.Comparable) 0.05d, 3.0d);
        piePlot2.setLabelLinkMargin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(255, serialDate2);
        java.lang.String str4 = serialDate2.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        timeSeriesCollection2.clearSelection();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        double double21 = categoryPlot20.getRangeCrosshairValue();
        categoryPlot20.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot20.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        combinedRangeXYPlot26.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis29, false);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke33);
        combinedRangeXYPlot26.setDomainGridlineStroke(stroke33);
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray40, numberArray43, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str52 = numberAxis51.getLabelToolTip();
        java.lang.String str53 = numberAxis51.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer54);
        double double56 = categoryPlot55.getRangeCrosshairValue();
        categoryPlot55.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot55.getRangeAxisLocation(9999);
        combinedRangeXYPlot26.setDomainAxisLocation(axisLocation60, false);
        categoryPlot20.setRangeAxisLocation(axisLocation60);
        categoryPlot20.setRangeCrosshairValue((double) (byte) 10, false);
        org.jfree.chart.JFreeChart jFreeChart67 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot20);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis25);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation60);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        java.lang.String str2 = numberFormat0.format(0.0d);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer6.setLegendItemURLGenerator(xYSeriesLabelGenerator7);
        java.awt.Paint paint12 = xYAreaRenderer6.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator14 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer6.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator14, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYAreaRenderer6.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        java.lang.String str36 = numberAxis34.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer37);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        boolean boolean40 = xYSeriesCollection17.equals((java.lang.Object) categoryPlot38);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator41 = numberFormat0.formatToCharacterIterator((java.lang.Object) boolean40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = barRenderer3D0.getIncludeBaseInRange();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D0.setSeriesToolTipGenerator(1, categoryToolTipGenerator5, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) blockContainer3, false);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        boolean boolean9 = legendTitle7.visible;
        boolean boolean10 = legendTitle7.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle7.getPosition();
        blockContainer3.add((org.jfree.chart.block.Block) legendTitle7);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        jFreeChart3.setBackgroundImageAlignment(500);
        java.awt.Stroke stroke8 = jFreeChart3.getBorderStroke();
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        boolean boolean5 = textTitle0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean7 = textTitle0.equals((java.lang.Object) itemLabelAnchor6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean17 = piePlot15.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke18 = piePlot15.getBaseSectionOutlineStroke();
        intervalMarker13.setStroke(stroke18);
        java.awt.Color color20 = java.awt.Color.CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color20, stroke21, (float) (short) 0);
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray28, numberArray31, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        java.lang.String str41 = numberAxis39.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer42);
        java.awt.Font font45 = categoryAxis3D37.getTickLabelFont((java.lang.Comparable) "hi!");
        intervalMarker23.setLabelFont(font45);
        textTitle0.setFont(font45);
        int int48 = textTitle0.getMaximumLinesToDisplay();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2147483647 + "'", int48 == 2147483647);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        boolean boolean11 = xYAreaRenderer3.isSeriesVisible(10);
        java.awt.Stroke stroke15 = xYAreaRenderer3.getItemOutlineStroke(64, 500, false);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator16 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYAreaRenderer3.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator5, xYURLGenerator6);
        boolean boolean8 = xYAreaRenderer7.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke10 = xYAreaRenderer7.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer7.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer1.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYBarRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        xYBarRenderer1.setShadowXOffset((double) ' ');
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean22 = combinedRangeXYPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace23 = combinedRangeXYPlot21.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection26 = combinedRangeXYPlot21.getDomainMarkers((int) (short) 0, layer25);
        try {
            xYBarRenderer1.addAnnotation(xYAnnotation20, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        java.awt.Paint paint7 = piePlot2.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries2.fireSeriesChanged();
        xYSeries2.fireSeriesChanged();
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.CYAN;
        legendItem26.setFillPaint((java.awt.Paint) color27);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = legendItem26.getFillPaintTransformer();
        legendItem26.setDatasetIndex((-1));
        legendItem26.setShapeVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.CYAN;
        legendItem26.setFillPaint((java.awt.Paint) color27);
        boolean boolean29 = legendItem26.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass6 = serialDate5.getClass();
        boolean boolean7 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.BOTTOM", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        java.util.Date date11 = month9.getStart();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone12);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        double double9 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        boolean boolean9 = combinedRangeXYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedRangeXYPlot0.getDomainAxis(100);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        xYSeriesCollection0.validateObject();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add(0.2d, (double) (byte) 1, false);
        xYSeriesCollection0.addSeries(xYSeries11);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator9, xYURLGenerator10);
        boolean boolean13 = xYAreaRenderer11.equals((java.lang.Object) (-1));
        xYAreaRenderer11.setDefaultEntityRadius(2);
        combinedRangeXYPlot0.setRenderer(4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer11);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis19);
        combinedRangeXYPlot0.setRangeCrosshairValue((double) 0.8f, true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getPercentInstance();
        numberFormat2.setMinimumFractionDigits((int) (byte) 10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Other", numberFormat1, numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean28 = combinedRangeXYPlot27.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace29 = combinedRangeXYPlot27.getFixedRangeAxisSpace();
        java.awt.Stroke stroke30 = combinedRangeXYPlot27.getDomainCrosshairStroke();
        categoryPlot19.setDomainGridlineStroke(stroke30);
        int int32 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot19.getRangeAxis();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(valueAxis33);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        boolean boolean6 = jFreeChart3.getAntiAlias();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("?series=0&amp;item=10");
        java.lang.String str2 = textFragment1.getText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "?series=0&amp;item=10" + "'", str2.equals("?series=0&amp;item=10"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getLabelLinkMargin();
        double double2 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        double double18 = xYSeriesCollection0.getDomainLowerBound(true);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean25 = piePlot23.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke26 = piePlot23.getBaseSectionOutlineStroke();
        intervalMarker21.setStroke(stroke26);
        java.awt.Paint paint28 = intervalMarker21.getPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        boolean boolean33 = piePlot31.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke34 = piePlot31.getBaseSectionOutlineStroke();
        boolean boolean35 = chartRenderingInfo29.equals((java.lang.Object) piePlot31);
        intervalMarker21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot31);
        xYSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.brighter();
        standardChartTheme1.setWallPaint((java.awt.Paint) color3);
        java.awt.Font font6 = standardChartTheme1.getExtraLargeFont();
        java.awt.Paint paint7 = standardChartTheme1.getBaselinePaint();
        java.awt.Paint paint8 = standardChartTheme1.getCrosshairPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot19.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        combinedRangeXYPlot0.setWeight(0);
        java.awt.Image image5 = combinedRangeXYPlot0.getBackgroundImage();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedRangeXYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        piePlot2.axisChanged(axisChangeEvent5);
        boolean boolean7 = piePlot2.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot2.setLabelOutlineStroke(stroke8);
        org.jfree.chart.util.Rotation rotation10 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot2.setDirection(rotation10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PieSection: 0, 100(item)");
        piePlot2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        boolean boolean15 = lengthAdjustmentType0.equals((java.lang.Object) standardPieToolTipGenerator13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.lang.String str2 = month0.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        boolean boolean3 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke2 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setSectionDepth((double) 1.0f);
        ringPlot0.setLabelGap((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean5 = combinedRangeXYPlot4.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedRangeXYPlot4.getFixedRangeAxisSpace();
        combinedRangeXYPlot4.setWeight(0);
        java.util.List list9 = combinedRangeXYPlot4.getSubplots();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, list9, true);
        xYSeriesCollection3.validateObject();
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) xYSeriesCollection3, (int) (short) 10, (int) '4', "", "ThreadContext");
        int int18 = xYItemEntity17.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme13.setLargeFont(font14);
        xYAreaRenderer3.setSeriesItemLabelFont((int) (short) 1, font14, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean22 = piePlot20.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke23 = piePlot20.getBaseSectionOutlineStroke();
        boolean boolean24 = chartRenderingInfo18.equals((java.lang.Object) piePlot20);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator25);
        java.awt.Paint paint27 = piePlot20.getLabelShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator28 = null;
        piePlot20.setLegendLabelURLGenerator(pieURLGenerator28);
        boolean boolean30 = xYAreaRenderer3.hasListener((java.util.EventListener) piePlot20);
        java.awt.Paint paint31 = piePlot20.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator10 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator10);
        java.awt.Paint paint12 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) 1560668399999L, paint3);
        categoryAxis3D0.setCategoryMargin((double) 0.5f);
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        java.lang.String str14 = numberAxis12.getLabelToolTip();
        boolean boolean15 = textTitle10.equals((java.lang.Object) numberAxis12);
        textTitle10.setText("");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator19, xYURLGenerator20);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator22 = null;
        xYAreaRenderer21.setLegendItemURLGenerator(xYSeriesLabelGenerator22);
        xYAreaRenderer21.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer21.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.data.Range range32 = xYAreaRenderer21.findRangeBounds(xYDataset31);
        java.awt.Shape shape36 = xYAreaRenderer21.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = legendTitle40.getLegendItemGraphicEdge();
        legendTitle38.setPosition(rectangleEdge41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double44 = rectangleInsets43.getTop();
        legendTitle38.setPadding(rectangleInsets43);
        org.jfree.chart.entity.TitleEntity titleEntity47 = new org.jfree.chart.entity.TitleEntity(shape36, (org.jfree.chart.title.Title) legendTitle38, "");
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = legendTitle38.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment48);
        int int50 = textTitle10.getMaximumLinesToDisplay();
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint54 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis53.setLabelPaint(paint54);
        double double56 = numberAxis53.getAutoRangeMinimumSize();
        java.lang.Object obj57 = numberAxis53.clone();
        numberAxis53.setLabelToolTip("");
        numberAxis53.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint65 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis64.setLabelPaint(paint65);
        boolean boolean67 = numberAxis64.isAutoRange();
        java.awt.Stroke stroke68 = numberAxis64.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str71 = numberAxis70.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis70.setLabelInsets(rectangleInsets72);
        numberAxis64.setTickLabelInsets(rectangleInsets72);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo75 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset76 = null;
        org.jfree.chart.plot.PiePlot piePlot77 = new org.jfree.chart.plot.PiePlot(pieDataset76);
        boolean boolean79 = piePlot77.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke80 = piePlot77.getBaseSectionOutlineStroke();
        boolean boolean81 = chartRenderingInfo75.equals((java.lang.Object) piePlot77);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = chartRenderingInfo75.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection83 = chartRenderingInfo75.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D84 = chartRenderingInfo75.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets72.createInsetRectangle(rectangle2D84, true, true);
        org.jfree.chart.LegendItemSource legendItemSource88 = null;
        org.jfree.chart.title.LegendTitle legendTitle89 = new org.jfree.chart.title.LegendTitle(legendItemSource88);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = legendTitle89.getLegendItemGraphicEdge();
        boolean boolean91 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge90);
        double double92 = numberAxis53.java2DToValue((double) 100.0f, rectangle2D84, rectangleEdge90);
        textTitle10.draw(graphics2D51, rectangle2D84);
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = null;
        org.jfree.chart.axis.AxisState axisState95 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D0.drawTickMarks(graphics2D8, 2.0d, rectangle2D84, rectangleEdge94, axisState95);
        categoryAxis3D0.setMaximumCategoryLabelLines(2);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.0d + "'", double44 == 3.0d);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2147483647 + "'", int50 == 2147483647);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0E-8d + "'", double56 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo82);
        org.junit.Assert.assertNotNull(entityCollection83);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + Double.POSITIVE_INFINITY + "'", double92 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = rendererChangeEvent21.getType();
        java.lang.String str23 = rendererChangeEvent21.toString();
        java.lang.Object obj24 = rendererChangeEvent21.getRenderer();
        categoryPlot19.rendererChanged(rendererChangeEvent21);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String[] strArray5 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis6 = new org.jfree.chart.axis.SymbolAxis("", strArray5);
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("?series=6&amp;item=5", strArray5);
        java.lang.String str9 = symbolAxis7.valueToString(0.0d);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "item" + "'", str9.equals("item"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        java.awt.Font font22 = categoryAxis3D14.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean24 = combinedRangeXYPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = combinedRangeXYPlot23.getFixedRangeAxisSpace();
        combinedRangeXYPlot23.setWeight(0);
        java.util.List list28 = combinedRangeXYPlot23.getSubplots();
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        double double30 = ringPlot29.getOuterSeparatorExtension();
        java.awt.Stroke stroke31 = ringPlot29.getLabelLinkStroke();
        combinedRangeXYPlot23.setDomainZeroBaselineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font22, (org.jfree.chart.plot.Plot) combinedRangeXYPlot23, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection36 = new org.jfree.data.xy.XYSeriesCollection();
        double double37 = xYSeriesCollection36.getIntervalPositionFactor();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray42, numberArray45, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray49);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str54 = numberAxis53.getLabelToolTip();
        java.lang.String str55 = numberAxis53.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer56);
        double double58 = categoryPlot57.getRangeCrosshairValue();
        categoryPlot57.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis62 = categoryPlot57.getRangeAxisForDataset(0);
        boolean boolean63 = categoryPlot57.getDrawSharedDomainAxis();
        xYSeriesCollection36.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot57);
        try {
            combinedRangeXYPlot23.setDataset((int) (short) -1, (org.jfree.data.xy.XYDataset) xYSeriesCollection36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.5d + "'", double37 == 0.5d);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        combinedRangeXYPlot11.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis14, false);
        combinedRangeXYPlot11.clearDomainAxes();
        java.awt.Color color19 = java.awt.Color.ORANGE;
        combinedRangeXYPlot11.setRangeMinorGridlinePaint((java.awt.Paint) color19);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, 8);
        org.jfree.chart.axis.AxisSpace axisSpace23 = combinedRangeXYPlot11.getFixedDomainAxisSpace();
        java.awt.Paint paint24 = combinedRangeXYPlot11.getDomainGridlinePaint();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        double double18 = xYSeriesCollection0.getDomainLowerBound(true);
        double double19 = xYSeriesCollection0.getIntervalWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = barRenderer3D0.getLegendItems();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D0.getURLGenerator(2019, (int) '#', false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        combinedRangeXYPlot9.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis12, false);
        combinedRangeXYPlot9.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean21 = combinedRangeXYPlot20.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = combinedRangeXYPlot20.getFixedRangeAxisSpace();
        combinedRangeXYPlot20.setWeight(0);
        java.util.List list25 = combinedRangeXYPlot20.getSubplots();
        combinedRangeXYPlot9.drawRangeTickBands(graphics2D18, rectangle2D19, list25);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState28 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle31.getLegendItemGraphicEdge();
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge32);
        axisState28.moveCursor((double) (byte) 100, rectangleEdge32);
        boolean boolean35 = textAnchor27.equals((java.lang.Object) rectangleEdge32);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint39 = intervalMarker38.getPaint();
        boolean boolean40 = textAnchor27.equals((java.lang.Object) intervalMarker38);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean42 = combinedRangeXYPlot41.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace43 = combinedRangeXYPlot41.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection46 = combinedRangeXYPlot41.getDomainMarkers((int) (short) 0, layer45);
        combinedRangeXYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer45);
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation8, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        xYSeries11.add((double) 1.0f, (double) (-2208960000000L), true);
        org.jfree.data.xy.XYDataItem xYDataItem23 = xYSeries11.addOrUpdate((double) 0.0f, (double) 64);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
        org.junit.Assert.assertNull(xYDataItem23);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo7.getPlotArea();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertNull(rectangle2D10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        axisState19.moveCursor((double) (byte) 100, rectangleEdge23);
        boolean boolean26 = textAnchor18.equals((java.lang.Object) rectangleEdge23);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint30 = intervalMarker29.getPaint();
        boolean boolean31 = textAnchor18.equals((java.lang.Object) intervalMarker29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean33 = combinedRangeXYPlot32.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace34 = combinedRangeXYPlot32.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = combinedRangeXYPlot32.getDomainMarkers((int) (short) 0, layer36);
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker29, layer36);
        org.jfree.chart.axis.ValueAxis valueAxis40 = combinedRangeXYPlot0.getRangeAxis(1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNull(valueAxis40);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryMargin((double) 0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint7 = intervalMarker6.getPaint();
        categoryAxis3D0.setTickLabelPaint(paint7);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.util.List list8 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        combinedRangeXYPlot10.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke17);
        combinedRangeXYPlot10.setDomainGridlineStroke(stroke17);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray24, numberArray27, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        java.lang.String str37 = numberAxis35.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer38);
        double double40 = categoryPlot39.getRangeCrosshairValue();
        categoryPlot39.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot39.getRangeAxisLocation(9999);
        combinedRangeXYPlot10.setDomainAxisLocation(axisLocation44, false);
        combinedRangeXYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation44, true);
        boolean boolean49 = combinedRangeXYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean3 = legendTitle1.visible;
        boolean boolean4 = legendTitle1.isVisible();
        java.awt.Paint paint5 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (-1));
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segment4.copy();
        segment4.dec();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Object obj20 = categoryPlot19.clone();
        categoryPlot19.mapDatasetToDomainAxis(15, 0);
        java.awt.Stroke stroke24 = categoryPlot19.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Following", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.util.Rotation rotation9 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation9);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PieSection: 0, 100(item)");
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        java.lang.String str16 = standardPieToolTipGenerator12.generateToolTip(pieDataset14, (java.lang.Comparable) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        boolean boolean23 = categoryPlot19.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable24 = categoryPlot19.getDomainCrosshairRowKey();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis26.setLabelPaint(paint27);
        boolean boolean29 = numberAxis26.isAutoRange();
        java.awt.Stroke stroke30 = numberAxis26.getTickMarkStroke();
        org.jfree.data.Range range31 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis26);
        numberAxis26.zoomRange((-6.0d), (double) 0.8f);
        numberAxis26.setAutoRangeMinimumSize((double) 'a', false);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str41 = numberAxis40.getLabelToolTip();
        java.lang.String str42 = numberAxis40.getLabelToolTip();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator44 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator45 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer46 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator44, xYURLGenerator45);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator47 = null;
        xYAreaRenderer46.setLegendItemURLGenerator(xYSeriesLabelGenerator47);
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        double double50 = ringPlot49.getOuterSeparatorExtension();
        java.awt.Color color51 = java.awt.Color.GREEN;
        ringPlot49.setSeparatorPaint((java.awt.Paint) color51);
        java.awt.Shape shape53 = ringPlot49.getLegendItemShape();
        java.awt.Font font54 = ringPlot49.getLabelFont();
        xYAreaRenderer46.setBaseItemLabelFont(font54, true);
        numberAxis40.setTickLabelFont(font54);
        java.awt.Color color58 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment60 = new org.jfree.chart.text.TextFragment("http://www.jfree.org/jfreechart/index.html", font54, (java.awt.Paint) color58, (float) 6);
        numberAxis26.setTickLabelFont(font54);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(comparable24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        combinedRangeXYPlot0.setDomainTickBandPaint(paint7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator10, xYURLGenerator11);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer12.setLegendItemURLGenerator(xYSeriesLabelGenerator13);
        java.awt.Paint paint18 = xYAreaRenderer12.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint22 = xYAreaRenderer12.getItemPaint((int) (short) 0, 10, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        boolean boolean26 = piePlot24.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        piePlot24.axisChanged(axisChangeEvent27);
        boolean boolean29 = piePlot24.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot24.setLabelOutlineStroke(stroke30);
        xYAreaRenderer12.setBaseStroke(stroke30, false);
        boolean boolean34 = xYAreaRenderer12.getAutoPopulateSeriesShape();
        xYAreaRenderer12.setSeriesItemLabelsVisible(6, (java.lang.Boolean) true);
        java.awt.Shape shape38 = xYAreaRenderer12.getBaseLegendShape();
        int int39 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        boolean boolean23 = categoryPlot19.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable24 = categoryPlot19.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis3D25.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis3D25.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray37, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelToolTip();
        java.lang.String str47 = numberAxis45.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D43, (org.jfree.chart.axis.ValueAxis) numberAxis45, categoryItemRenderer48);
        categoryAxis3D43.setTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = categoryAxis3D52.getCategoryLabelPositions();
        categoryAxis3D52.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions56 = categoryAxis3D55.getCategoryLabelPositions();
        categoryAxis3D55.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray59 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D25, categoryAxis3D28, categoryAxis3D29, categoryAxis3D43, categoryAxis3D52, categoryAxis3D55 };
        categoryPlot19.setDomainAxes(categoryAxisArray59);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelToolTip();
        combinedRangeXYPlot62.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis65, false);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent70 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke69);
        combinedRangeXYPlot62.setDomainGridlineStroke(stroke69);
        java.awt.Paint paint72 = combinedRangeXYPlot62.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke76 = numberAxis75.getAxisLineStroke();
        combinedRangeXYPlot62.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis75);
        categoryPlot19.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) numberAxis75, true);
        org.jfree.chart.axis.AxisLocation axisLocation80 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(axisLocation80, true);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(comparable24);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(categoryLabelPositions56);
        org.junit.Assert.assertNotNull(categoryAxisArray59);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(axisLocation80);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Stroke stroke16 = xYAreaRenderer3.getItemStroke((int) (byte) 1, 0, true);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets4);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.brighter();
        standardChartTheme1.setSubtitlePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter6 = standardChartTheme1.getXYBarPainter();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(xYBarPainter6);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long4 = segmentedTimeline2.toTimelineValue(date3);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline2.getBaseTimeline();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2692527886132L + "'", long4 == 2692527886132L);
//        org.junit.Assert.assertNull(segmentedTimeline5);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(6, 52);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        boolean boolean7 = combinedRangeXYPlot0.canSelectByPoint();
        boolean boolean8 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelToolTip();
        java.lang.String str26 = numberAxis24.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        double double29 = categoryPlot28.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis((int) (byte) -1);
        boolean boolean32 = categoryPlot28.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable33 = categoryPlot28.getDomainCrosshairRowKey();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint36 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis35.setLabelPaint(paint36);
        boolean boolean38 = numberAxis35.isAutoRange();
        java.awt.Stroke stroke39 = numberAxis35.getTickMarkStroke();
        org.jfree.data.Range range40 = categoryPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis35);
        int int41 = combinedRangeXYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = combinedRangeXYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(comparable33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(legendItemCollection42);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) (byte) 100, (int) (byte) -1);
        segmentedTimeline3.setAdjustForDaylightSaving(true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) numberAxis28);
        numberAxis28.setRangeAboutValue((double) 5, (double) 9999);
        numberAxis28.setLabel("PieSection: 0, 100(item)");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        boolean boolean3 = numberAxis1.isAutoTickUnitSelection();
        java.awt.Paint paint4 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        numberAxis1.setLabelPaint(paint4);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setBaseSeriesVisibleInLegend(false);
        java.lang.Object obj8 = xYAreaRenderer3.clone();
        java.awt.Font font10 = null;
        xYAreaRenderer3.setSeriesItemLabelFont((int) (short) 10, font10, false);
        java.awt.Paint paint13 = xYAreaRenderer3.getBaseFillPaint();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = xYAreaRenderer3.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle4.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle4.getItemContainer();
        org.jfree.chart.block.Block block7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelToolTip();
        java.lang.String str12 = numberAxis10.getLabelToolTip();
        boolean boolean13 = textTitle8.equals((java.lang.Object) numberAxis10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean15 = textTitle8.equals((java.lang.Object) itemLabelAnchor14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean22 = piePlot20.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke23 = piePlot20.getBaseSectionOutlineStroke();
        boolean boolean24 = chartRenderingInfo18.equals((java.lang.Object) piePlot20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = chartRenderingInfo18.getPlotInfo();
        java.lang.Object obj26 = textTitle8.draw(graphics2D16, rectangle2D17, (java.lang.Object) plotRenderingInfo25);
        blockContainer6.add(block7, obj26);
        legendTitle1.setWrapper(blockContainer6);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange31);
        try {
            org.jfree.chart.util.Size2D size2D33 = legendTitle1.arrange(graphics2D29, rectangleConstraint32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo25);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        java.awt.Stroke stroke26 = categoryPlot19.getDomainCrosshairStroke();
        int int27 = categoryPlot19.getRendererCount();
        java.awt.Paint paint28 = categoryPlot19.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("");
        projectInfo0.setCopyright("item");
        java.lang.String str5 = projectInfo0.getInfo();
        java.awt.Image image6 = null;
        projectInfo0.setLogo(image6);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        int int21 = categoryPlot19.getRangeAxisCount();
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(0, axisLocation24);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        try {
            java.awt.Paint paint2 = combinedRangeXYPlot0.getQuadrantPaint((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (32) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean12 = piePlot10.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke13 = piePlot10.getBaseSectionOutlineStroke();
        intervalMarker8.setStroke(stroke13);
        java.awt.Color color15 = java.awt.Color.CYAN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color5, stroke13, (java.awt.Paint) color15, stroke16, (float) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color1, stroke16);
        double double20 = valueMarker19.getValue();
        double double21 = valueMarker19.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Font font7 = xYAreaRenderer3.getSeriesItemLabelFont((int) '4');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator8, false);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke6 = xYAreaRenderer3.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        double double13 = ringPlot12.getOuterSeparatorExtension();
        java.awt.Color color14 = java.awt.Color.GREEN;
        ringPlot12.setSeparatorPaint((java.awt.Paint) color14);
        java.awt.Shape shape16 = ringPlot12.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme18 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint19 = standardChartTheme18.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean23 = piePlot21.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot21.axisChanged(axisChangeEvent24);
        boolean boolean26 = piePlot21.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot21.setLabelOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        intervalMarker31.setOutlinePaint((java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("item", "item", "", "", shape16, paint19, stroke27, (java.awt.Paint) color32);
        xYAreaRenderer3.setSeriesItemLabelPaint(1, paint19);
        xYAreaRenderer3.setUseFillPaint(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator38 = null;
        xYAreaRenderer3.setBaseToolTipGenerator(xYToolTipGenerator38, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertNull(timeSeries3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        boolean boolean4 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass3);
        boolean boolean5 = itemLabelAnchor0.equals((java.lang.Object) wildcardClass3);
        boolean boolean6 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = combinedRangeXYPlot0.canSelectByPoint();
        boolean boolean9 = combinedRangeXYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        org.jfree.chart.LegendItem legendItem12 = xYAreaRenderer3.getLegendItem(0, 9999);
        boolean boolean13 = xYAreaRenderer3.getBaseSeriesVisible();
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset12);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset12);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset12);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.util.Rotation rotation9 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation9);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PieSection: 0, 100(item)");
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator12);
        java.text.NumberFormat numberFormat14 = standardPieToolTipGenerator12.getPercentFormat();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNotNull(numberFormat14);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis24.setLabelPaint(paint25);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        java.awt.Paint paint36 = xYAreaRenderer30.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint41 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis40.setLabelPaint(paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis40.setLabelInsets(rectangleInsets43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYAreaRenderer30.drawDomainGridLine(graphics2D37, xYPlot38, (org.jfree.chart.axis.ValueAxis) numberAxis40, rectangle2D45, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator49, xYURLGenerator50);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator52 = null;
        xYAreaRenderer51.setLegendItemURLGenerator(xYSeriesLabelGenerator52);
        java.awt.Paint paint57 = xYAreaRenderer51.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint62 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis61.setLabelPaint(paint62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis61.setLabelInsets(rectangleInsets64);
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        xYAreaRenderer51.drawDomainGridLine(graphics2D58, xYPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, rectangle2D66, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator70 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator71 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer72 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator70, xYURLGenerator71);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator73 = null;
        xYAreaRenderer72.setLegendItemURLGenerator(xYSeriesLabelGenerator73);
        java.awt.Paint paint78 = xYAreaRenderer72.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = null;
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint83 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis82.setLabelPaint(paint83);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis82.setLabelInsets(rectangleInsets85);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        xYAreaRenderer72.drawDomainGridLine(graphics2D79, xYPlot80, (org.jfree.chart.axis.ValueAxis) numberAxis82, rectangle2D87, (double) 3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray90 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis40, numberAxis61, numberAxis82 };
        categoryPlot19.setRangeAxes(valueAxisArray90);
        org.jfree.chart.util.SortOrder sortOrder92 = categoryPlot19.getColumnRenderingOrder();
        int int93 = categoryPlot19.getDatasetCount();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNotNull(valueAxisArray90);
        org.junit.Assert.assertNotNull(sortOrder92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        chartRenderingInfo0.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        jFreeChart3.setTitle("VerticalAlignment.BOTTOM");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str12 = numberAxis11.getLabelToolTip();
        java.lang.String str13 = numberAxis11.getLabelToolTip();
        boolean boolean14 = textTitle9.equals((java.lang.Object) numberAxis11);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean16 = textTitle9.equals((java.lang.Object) itemLabelAnchor15);
        jFreeChart3.setTitle(textTitle9);
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries20.add((-1.0d), (java.lang.Number) (-6.0d), true);
        org.jfree.data.xy.XYDataItem xYDataItem27 = xYSeries20.addOrUpdate((double) 52, (double) 100L);
        boolean boolean28 = jFreeChart3.equals((java.lang.Object) 52);
        java.awt.RenderingHints renderingHints29 = jFreeChart3.getRenderingHints();
        jFreeChart3.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(textTitle6);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(xYDataItem27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(renderingHints29);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        numberAxis1.setAutoTickUnitSelection(true, true);
        java.awt.Font font9 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean5 = xYAreaRenderer3.equals((java.lang.Object) (-1));
        java.awt.Paint paint7 = xYAreaRenderer3.lookupSeriesOutlinePaint((int) (short) -1);
        java.awt.Shape shape11 = xYAreaRenderer3.getItemShape((int) '#', 0, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        intervalMarker3.setOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = intervalMarker3.getLabelAnchor();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) intervalMarker3, false);
        polarPlot0.rendererChanged(rendererChangeEvent8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        double double3 = dateRange1.constrain(0.05d);
        double double4 = dateRange1.getLength();
        double double5 = dateRange1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray14, numberArray17, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str26 = numberAxis25.getLabelToolTip();
        java.lang.String str27 = numberAxis25.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        double double30 = categoryPlot29.getRangeCrosshairValue();
        categoryPlot29.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot29.getRangeAxisLocation(9999);
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation34, false);
        org.jfree.chart.plot.Plot plot37 = combinedRangeXYPlot0.getParent();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(plot37);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        numberFormat0.setMinimumFractionDigits((int) (short) 100);
        numberFormat0.setParseIntegerOnly(false);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        int int1 = numberFormat0.getMinimumIntegerDigits();
        java.util.Currency currency2 = numberFormat0.getCurrency();
        int int3 = numberFormat0.getMaximumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(currency2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = barRenderer3D0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D4 = null;
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        java.lang.String str22 = numberAxis20.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot24.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot24.getRangeAxis((int) (byte) -1);
        categoryPlot24.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot24.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot24.getRangeAxisForDataset(255);
        java.lang.Object obj34 = categoryPlot24.clone();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState37 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = legendTitle40.getLegendItemGraphicEdge();
        boolean boolean42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge41);
        axisState37.moveCursor((double) (byte) 100, rectangleEdge41);
        boolean boolean44 = textAnchor36.equals((java.lang.Object) rectangleEdge41);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint48 = intervalMarker47.getPaint();
        boolean boolean49 = textAnchor36.equals((java.lang.Object) intervalMarker47);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot piePlot56 = new org.jfree.chart.plot.PiePlot(pieDataset55);
        boolean boolean58 = piePlot56.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke59 = piePlot56.getBaseSectionOutlineStroke();
        boolean boolean60 = chartRenderingInfo54.equals((java.lang.Object) piePlot56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = chartRenderingInfo54.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection62 = chartRenderingInfo54.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D63 = chartRenderingInfo54.getChartArea();
        boolean boolean64 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 3, (double) 4, rectangle2D63);
        java.awt.geom.Point2D point2D65 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(90.0d, (double) (short) 10, rectangle2D63);
        try {
            barRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot24, valueAxis35, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo61);
        org.junit.Assert.assertNotNull(entityCollection62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(point2D65);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        try {
            java.lang.Number number3 = xYSeries1.getY(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        xYBarRenderer1.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        java.awt.Font font19 = xYAreaRenderer3.getLegendTextFont((int) '#');
        java.awt.Font font21 = null;
        xYAreaRenderer3.setSeriesItemLabelFont(0, font21, false);
        org.jfree.chart.StandardChartTheme standardChartTheme26 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint27 = standardChartTheme26.getAxisLabelPaint();
        xYAreaRenderer3.setSeriesPaint(0, paint27);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        long long3 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo4.setName("");
        projectInfo4.setCopyright("item");
        java.lang.String str9 = projectInfo4.getLicenceText();
        java.util.List list10 = projectInfo4.getContributors();
        segmentedTimeline0.setExceptionSegments(list10);
        long long12 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400000L + "'", long12 == 86400000L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        boolean boolean25 = categoryPlot19.getDrawSharedDomainAxis();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent26);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            categoryPlot19.addAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        numberFormat1.setMinimumFractionDigits((int) (short) 100);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("http://www.jfree.org/jfreechart/index.html", numberFormat1, numberFormat4);
        java.text.NumberFormat numberFormat6 = standardPieToolTipGenerator5.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        combinedRangeXYPlot0.setWeight(0);
        java.awt.Image image5 = combinedRangeXYPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot0.getRangeAxisLocation((int) (byte) 100);
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        boolean boolean26 = categoryPlot19.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) combinedRangeXYPlot0, false);
        java.awt.Font font12 = combinedRangeXYPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.Size2D size2D3 = rectangleConstraint0.calculateConstrainedSize(size2D2);
        java.lang.String str4 = size2D2.toString();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str9 = numberAxis8.getLabelToolTip();
        combinedRangeXYPlot5.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        combinedRangeXYPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        int int15 = combinedRangeXYPlot5.indexOf(xYDataset14);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray20, numberArray23, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        java.lang.String str33 = numberAxis31.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D29, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer34);
        double double36 = numberAxis31.getLowerMargin();
        combinedRangeXYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean40 = xYBarRenderer39.isDrawBarOutline();
        java.lang.Object obj41 = xYBarRenderer39.clone();
        org.jfree.data.time.TimeSeries timeSeries42 = null;
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection44 = new org.jfree.data.time.TimeSeriesCollection(timeSeries42, timeZone43);
        boolean boolean45 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection44);
        org.jfree.data.Range range46 = xYBarRenderer39.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection44);
        int int47 = combinedRangeXYPlot5.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection44);
        boolean boolean48 = size2D2.equals((java.lang.Object) timeSeriesCollection44);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str4.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        boolean boolean25 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        numberAxis1.setLabelToolTip("");
        numberAxis1.setAutoRangeIncludesZero(false);
        boolean boolean10 = numberAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color27);
        boolean boolean29 = categoryPlot19.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 255, Double.POSITIVE_INFINITY);
        double double3 = xYDataItem2.getYValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        numberAxis1.setMinorTickMarksVisible(false);
        java.lang.Object obj7 = numberAxis1.clone();
        java.awt.Color color8 = java.awt.Color.cyan;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color8);
        double double10 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        java.lang.Object obj17 = xYSeries11.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String[] strArray4 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean7 = combinedRangeXYPlot6.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot6.getFixedRangeAxisSpace();
        combinedRangeXYPlot6.setWeight(0);
        boolean boolean11 = symbolAxis5.equals((java.lang.Object) combinedRangeXYPlot6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(6, 52);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        int int12 = year9.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 10, year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year9, (org.jfree.data.time.RegularTimePeriod) year15);
        java.util.TimeZone timeZone19 = null;
        java.util.Locale locale20 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("PieSection: 0, 100(item)", (org.jfree.data.time.RegularTimePeriod) year1, (org.jfree.data.time.RegularTimePeriod) year15, timeZone19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        java.awt.Paint paint9 = intervalMarker2.getPaint();
        float float10 = intervalMarker2.getAlpha();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        combinedRangeXYPlot11.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis14, false);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke18);
        combinedRangeXYPlot11.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint21 = combinedRangeXYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke25 = numberAxis24.getAxisLineStroke();
        combinedRangeXYPlot11.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.awt.Stroke stroke27 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        intervalMarker2.setStroke(stroke27);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (-1));
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segment4.copy();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segment5.intersect(10L, (long) 500);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedRangeXYPlot9.getDomainAxisForDataset((int) (byte) 0);
        try {
            int int12 = segment5.compareTo((java.lang.Object) combinedRangeXYPlot9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CombinedRangeXYPlot cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNull(segment8);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getOuterSeparatorExtension();
        java.awt.Color color8 = java.awt.Color.GREEN;
        ringPlot6.setSeparatorPaint((java.awt.Paint) color8);
        java.awt.Shape shape10 = ringPlot6.getLegendItemShape();
        java.awt.Font font11 = ringPlot6.getLabelFont();
        xYAreaRenderer3.setBaseItemLabelFont(font11, true);
        java.lang.Object obj14 = null;
        boolean boolean15 = xYAreaRenderer3.equals(obj14);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxisForDataset(255);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        boolean boolean35 = piePlot33.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke36 = piePlot33.getBaseSectionOutlineStroke();
        intervalMarker31.setStroke(stroke36);
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray43, numberArray46, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelToolTip();
        java.lang.String str56 = numberAxis54.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D52, (org.jfree.chart.axis.ValueAxis) numberAxis54, categoryItemRenderer57);
        org.jfree.chart.util.SortOrder sortOrder59 = categoryPlot58.getRowRenderingOrder();
        categoryPlot19.setColumnRenderingOrder(sortOrder59);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(sortOrder59);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        java.util.Locale locale4 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 6, (double) 100, (double) ' ');
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean12 = piePlot3D11.getSimpleLabels();
        java.awt.Color color13 = java.awt.Color.darkGray;
        piePlot3D11.setBackgroundPaint((java.awt.Paint) color13);
        piePlot3D11.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean22 = piePlot20.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke23 = piePlot20.getBaseSectionOutlineStroke();
        boolean boolean24 = chartRenderingInfo18.equals((java.lang.Object) piePlot20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = chartRenderingInfo18.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        plotRenderingInfo25.setPlotArea(rectangle2D26);
        org.jfree.chart.plot.PiePlotState piePlotState28 = ringPlot4.initialise(graphics2D9, rectangle2D10, (org.jfree.chart.plot.PiePlot) piePlot3D11, (java.lang.Integer) 0, plotRenderingInfo25);
        org.jfree.chart.StandardChartTheme standardChartTheme30 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme30.setLargeFont(font31);
        java.awt.Paint paint33 = standardChartTheme30.getCrosshairPaint();
        java.awt.Paint paint34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme30.setAxisLabelPaint(paint34);
        ringPlot4.setBaseSectionOutlinePaint(paint34);
        boolean boolean37 = gradientXYBarPainter3.equals((java.lang.Object) paint34);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo25);
        org.junit.Assert.assertNotNull(piePlotState28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) combinedRangeXYPlot0, false);
        int int12 = combinedRangeXYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot19.getRangeAxisLocation(9999);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis26.setLabelInsets(rectangleInsets28);
        int int30 = numberAxis26.getMinorTickCount();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint33 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis32.setLabelPaint(paint33);
        double double35 = numberAxis32.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint38 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis37.setLabelPaint(paint38);
        double double40 = numberAxis37.getAutoRangeMinimumSize();
        java.lang.Object obj41 = numberAxis37.clone();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis43.setLabelInsets(rectangleInsets45);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis48.setLabelInsets(rectangleInsets50);
        int int52 = numberAxis48.getMinorTickCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray53 = new org.jfree.chart.axis.ValueAxis[] { numberAxis26, numberAxis32, numberAxis37, numberAxis43, numberAxis48 };
        categoryPlot19.setRangeAxes(valueAxisArray53);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation55 = null;
        try {
            categoryPlot19.addAnnotation(categoryAnnotation55, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0E-8d + "'", double40 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray53);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemFillPaint(2, 2, true);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = rendererChangeEvent15.getType();
        xYAreaRenderer3.notifyListeners(rendererChangeEvent15);
        java.awt.Paint paint19 = xYAreaRenderer3.lookupSeriesOutlinePaint(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator21 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean24 = xYBarRenderer23.isDrawBarOutline();
        boolean boolean25 = standardXYURLGenerator21.equals((java.lang.Object) xYBarRenderer23);
        xYAreaRenderer3.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator21);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = xYAreaRenderer3.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator27);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 3.0d, (double) 100, (double) 2, 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.05d, (double) 644288399999L, 0.0d, (double) (short) -1);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        boolean boolean3 = combinedRangeXYPlot0.isRangeZeroBaselineVisible();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        java.lang.String str22 = numberAxis20.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        categoryPlot24.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot24.getRangeAxisLocation(9999);
        combinedRangeXYPlot0.setDomainAxisLocation(0, axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '4', (float) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getOuterSeparatorExtension();
        java.awt.Color color5 = java.awt.Color.GREEN;
        ringPlot3.setSeparatorPaint((java.awt.Paint) color5);
        java.awt.Shape shape7 = ringPlot3.getLegendItemShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (-1.0d), (double) 2);
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape11);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        boolean boolean8 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtTop();
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, list10, range11, false);
        segmentedTimeline2.addExceptions(list10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean30 = combinedRangeXYPlot29.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace31 = combinedRangeXYPlot29.getFixedRangeAxisSpace();
        combinedRangeXYPlot29.setWeight(0);
        java.awt.Image image34 = combinedRangeXYPlot29.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation36 = combinedRangeXYPlot29.getRangeAxisLocation((int) (byte) 100);
        categoryPlot19.setRangeAxisLocation(axisLocation36, false);
        java.lang.Comparable comparable39 = categoryPlot19.getDomainCrosshairRowKey();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(comparable39);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean24 = segmentedTimeline23.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean26 = segmentedTimeline25.getAdjustForDaylightSaving();
        long long27 = segmentedTimeline25.getSegmentsGroupSize();
        java.util.Date date29 = segmentedTimeline25.getDate((long) (short) -1);
        long long30 = segmentedTimeline23.toTimelineValue(date29);
        categoryPlot19.setDomainCrosshairColumnKey((java.lang.Comparable) date29, false);
        categoryPlot19.setCrosshairDatasetIndex((int) '4');
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 644288399999L + "'", long30 == 644288399999L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        jFreeChart3.setTitle("VerticalAlignment.BOTTOM");
        jFreeChart3.setBackgroundImageAlpha((float) 100L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        chartRenderingInfo14.clear();
        org.jfree.chart.entity.EntityCollection entityCollection23 = chartRenderingInfo14.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart3.createBufferedImage(6, (int) (short) -1, (int) 'a', chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(textTitle6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(entityCollection23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairX((double) 100L);
        double double4 = crosshairState1.getAnchorX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.util.Rotation rotation9 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation9);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PieSection: 0, 100(item)");
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator12);
        piePlot1.setBackgroundAlpha((float) 255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer1.getToolTipGenerator(2, 8, false);
        boolean boolean8 = xYBarRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Font font10 = xYBarRenderer1.lookupLegendTextFont(100);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) (byte) 1, xYItemLabelGenerator12, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = legendTitle2.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle2.getItemContainer();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) 10, (double) (short) 100, 3.0d);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle12.getLegendItemGraphicEdge();
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray12, numberArray15, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str24 = numberAxis23.getLabelToolTip();
        java.lang.String str25 = numberAxis23.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot27.getRangeAxis((int) (byte) -1);
        categoryPlot27.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot27.setRenderer(categoryItemRenderer34, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean38 = combinedRangeXYPlot37.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace39 = combinedRangeXYPlot37.getFixedRangeAxisSpace();
        combinedRangeXYPlot37.setWeight(0);
        java.awt.Image image42 = combinedRangeXYPlot37.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation44 = combinedRangeXYPlot37.getRangeAxisLocation((int) (byte) 100);
        categoryPlot27.setRangeAxisLocation(axisLocation44, false);
        combinedRangeXYPlot0.setRangeAxisLocation(31, axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNull(image42);
        org.junit.Assert.assertNotNull(axisLocation44);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        org.jfree.data.xy.XYSeries xYSeries19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries19.add((-1.0d), (java.lang.Number) (-6.0d), true);
        xYSeriesCollection0.removeSeries(xYSeries19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = legendTitle20.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = legendTitle20.getVerticalAlignment();
        java.lang.Object obj32 = null;
        boolean boolean33 = verticalAlignment31.equals(obj32);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        boolean boolean5 = textTitle0.equals((java.lang.Object) numberAxis2);
        java.lang.String str6 = textTitle0.getURLText();
        java.lang.Object obj7 = textTitle0.clone();
        java.lang.String str8 = textTitle0.getURLText();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis11.setMinorTickCount(8);
        org.jfree.chart.StandardChartTheme standardChartTheme15 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint16 = standardChartTheme15.getItemLabelPaint();
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.brighter();
        standardChartTheme15.setWallPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = standardChartTheme15.getTitlePaint();
        numberAxis11.setAxisLinePaint(paint20);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle26.getLegendItemGraphicEdge();
        legendTitle24.setPosition(rectangleEdge27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets29.getTop();
        legendTitle24.setPadding(rectangleInsets29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint34 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis33.setLabelPaint(paint34);
        boolean boolean36 = numberAxis33.isAutoRange();
        java.awt.Stroke stroke37 = numberAxis33.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis39.setLabelInsets(rectangleInsets41);
        numberAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        boolean boolean48 = piePlot46.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke49 = piePlot46.getBaseSectionOutlineStroke();
        boolean boolean50 = chartRenderingInfo44.equals((java.lang.Object) piePlot46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection52 = chartRenderingInfo44.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo44.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets41.createInsetRectangle(rectangle2D53, true, true);
        rectangleInsets29.trim(rectangle2D56);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = legendTitle59.getLegendItemGraphicEdge();
        boolean boolean61 = legendTitle59.visible;
        boolean boolean62 = legendTitle59.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = legendTitle59.getPosition();
        double double64 = numberAxis11.valueToJava2D((double) (short) 100, rectangle2D56, rectangleEdge63);
        textTitle0.draw(graphics2D9, rectangle2D56);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo51);
        org.junit.Assert.assertNotNull(entityCollection52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-1194.0d) + "'", double64 == (-1194.0d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        java.awt.Paint paint9 = intervalMarker2.getPaint();
        float float10 = intervalMarker2.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor11 = intervalMarker2.getLabelTextAnchor();
        java.lang.String str12 = intervalMarker2.getLabel();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = ringPlot0.getInsets();
        ringPlot0.setLabelLinkMargin((double) 2);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelToolTip();
        combinedRangeXYPlot30.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis33, false);
        combinedRangeXYPlot30.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelToolTip();
        java.lang.String str45 = numberAxis43.getLabelToolTip();
        boolean boolean46 = textTitle41.equals((java.lang.Object) numberAxis43);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor47 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean48 = textTitle41.equals((java.lang.Object) itemLabelAnchor47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        boolean boolean55 = piePlot53.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke56 = piePlot53.getBaseSectionOutlineStroke();
        boolean boolean57 = chartRenderingInfo51.equals((java.lang.Object) piePlot53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = chartRenderingInfo51.getPlotInfo();
        java.lang.Object obj59 = textTitle41.draw(graphics2D49, rectangle2D50, (java.lang.Object) plotRenderingInfo58);
        combinedRangeXYPlot30.drawAnnotations(graphics2D39, rectangle2D40, plotRenderingInfo58);
        boolean boolean61 = combinedRangeXYPlot30.isDomainCrosshairVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean63 = combinedRangeXYPlot62.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace64 = combinedRangeXYPlot62.getFixedRangeAxisSpace();
        boolean boolean65 = combinedRangeXYPlot30.equals((java.lang.Object) combinedRangeXYPlot62);
        java.awt.geom.Point2D point2D66 = combinedRangeXYPlot30.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState67 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        try {
            ringPlot0.draw(graphics2D28, rectangle2D29, point2D66, plotState67, plotRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo58);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(point2D66);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        boolean boolean9 = xYBarRenderer1.getItemVisible((int) (short) 10, 8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = barRenderer3D0.getIncludeBaseInRange();
        java.lang.Boolean boolean5 = barRenderer3D0.getSeriesItemLabelsVisible((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Paint paint9 = piePlot2.getBaseSectionPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean5 = segmentedTimeline4.getAdjustForDaylightSaving();
        long long6 = segmentedTimeline4.getSegmentsGroupSize();
        java.util.Date date8 = segmentedTimeline4.getDate((long) (short) -1);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) (short) -1, "http://www.jfree.org/jfreechart/index.html");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray29);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelToolTip();
        java.lang.String str35 = numberAxis33.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        java.awt.Font font39 = categoryAxis3D31.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        java.awt.Paint paint42 = piePlot41.getLabelLinkPaint();
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = legendTitle44.getLegendItemGraphicEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment47, verticalAlignment48, (double) 100, (double) 3);
        java.lang.String str52 = verticalAlignment48.toString();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint55 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis54.setLabelPaint(paint55);
        boolean boolean57 = numberAxis54.isAutoRange();
        java.awt.Stroke stroke58 = numberAxis54.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str61 = numberAxis60.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis60.setLabelInsets(rectangleInsets62);
        numberAxis54.setTickLabelInsets(rectangleInsets62);
        double double65 = rectangleInsets62.getTop();
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("", font39, paint42, rectangleEdge45, horizontalAlignment46, verticalAlignment48, rectangleInsets62);
        try {
            double double67 = categoryAxis3D0.getCategorySeriesMiddle(5, (int) (byte) 10, (int) '4', 2, (double) (short) 100, rectangle2D16, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str52.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.0d + "'", double65 == 3.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 0, (float) 4);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity8 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart6, "item");
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart6.addProgressListener(chartProgressListener9);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.brighter();
        standardChartTheme1.setWallPaint((java.awt.Paint) color3);
        java.awt.Font font6 = standardChartTheme1.getExtraLargeFont();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = standardChartTheme1.getXYBarPainter();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelToolTip();
        java.lang.String str12 = numberAxis10.getLabelToolTip();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator14, xYURLGenerator15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer16.setLegendItemURLGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        double double20 = ringPlot19.getOuterSeparatorExtension();
        java.awt.Color color21 = java.awt.Color.GREEN;
        ringPlot19.setSeparatorPaint((java.awt.Paint) color21);
        java.awt.Shape shape23 = ringPlot19.getLegendItemShape();
        java.awt.Font font24 = ringPlot19.getLabelFont();
        xYAreaRenderer16.setBaseItemLabelFont(font24, true);
        numberAxis10.setTickLabelFont(font24);
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("http://www.jfree.org/jfreechart/index.html", font24, (java.awt.Paint) color28, (float) 6);
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color28);
        java.awt.Color color33 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        int int34 = color33.getGreen();
        org.jfree.chart.StandardChartTheme standardChartTheme36 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint37 = standardChartTheme36.getLabelLinkPaint();
        java.awt.Color color38 = java.awt.Color.WHITE;
        java.awt.Color color39 = color38.brighter();
        standardChartTheme36.setSubtitlePaint((java.awt.Paint) color39);
        java.awt.color.ColorSpace colorSpace41 = color39.getColorSpace();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelToolTip();
        combinedRangeXYPlot42.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis45, false);
        combinedRangeXYPlot42.clearDomainAxes();
        java.awt.Color color50 = java.awt.Color.ORANGE;
        combinedRangeXYPlot42.setRangeMinorGridlinePaint((java.awt.Paint) color50);
        float[] floatArray52 = null;
        float[] floatArray53 = color50.getColorComponents(floatArray52);
        float[] floatArray54 = color33.getComponents(colorSpace41, floatArray52);
        float[] floatArray55 = color28.getColorComponents(floatArray52);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        piePlot1.clearSectionOutlinePaints(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        combinedRangeXYPlot0.setDomainTickBandPaint(paint7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke10 = ringPlot9.getSeparatorStroke();
        combinedRangeXYPlot0.setRangeZeroBaselineStroke(stroke10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (-1));
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segment4.copy();
        boolean boolean6 = segment5.inExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getOuterSeparatorExtension();
        java.awt.Color color7 = java.awt.Color.GREEN;
        ringPlot5.setSeparatorPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = ringPlot5.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint12 = standardChartTheme11.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        boolean boolean16 = piePlot14.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot14.axisChanged(axisChangeEvent17);
        boolean boolean19 = piePlot14.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot14.setLabelOutlineStroke(stroke20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        intervalMarker24.setOutlinePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("item", "item", "", "", shape9, paint12, stroke20, (java.awt.Paint) color25);
        java.awt.Color color28 = java.awt.Color.CYAN;
        legendItem27.setFillPaint((java.awt.Paint) color28);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendItem27.getFillPaintTransformer();
        legendItem27.setDatasetIndex((-1));
        java.awt.Color color33 = java.awt.Color.YELLOW;
        legendItem27.setLabelPaint((java.awt.Paint) color33);
        java.awt.Color color35 = java.awt.Color.getColor("http://www.jfree.org/jfreechart/index.html", color33);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean3 = combinedRangeXYPlot2.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace4 = combinedRangeXYPlot2.getFixedRangeAxisSpace();
        int int5 = year1.compareTo((java.lang.Object) axisSpace4);
        int int6 = year1.getYear();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        int int21 = categoryPlot19.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean24 = combinedRangeXYPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = combinedRangeXYPlot23.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection28 = combinedRangeXYPlot23.getDomainMarkers((int) (short) 0, layer27);
        java.util.Collection collection29 = categoryPlot19.getDomainMarkers((int) (byte) 1, layer27);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint3 = standardChartTheme1.getItemLabelPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean8 = piePlot6.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot6.axisChanged(axisChangeEvent9);
        boolean boolean11 = piePlot6.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot6.setLabelOutlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot6.setLabelBackgroundPaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1, (java.awt.Paint) color14, stroke16);
        standardChartTheme1.setGridBandAlternatePaint((java.awt.Paint) color14);
        float[] floatArray19 = null;
        float[] floatArray20 = color14.getRGBComponents(floatArray19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYAreaRenderer3.setBasePaint((java.awt.Paint) color13);
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list20 = axisCollection19.getAxesAtTop();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17, list20, range21, false);
        org.jfree.data.Range range24 = xYAreaRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        java.lang.Object obj25 = timeSeriesCollection17.clone();
        timeSeriesCollection17.validateObject();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        titleEntity29.setToolTipText("?series=0&amp;item=10");
        java.lang.String str32 = titleEntity29.toString();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TitleEntity: tooltip = ?series=0&amp;item=10" + "'", str32.equals("TitleEntity: tooltip = ?series=0&amp;item=10"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        long long3 = segmentedTimeline0.getSegmentsGroupSize();
        java.util.Date date5 = segmentedTimeline0.getDate((-1L));
        java.util.List list6 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = combinedRangeXYPlot0.indexOf(xYDataset9);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray18, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        java.lang.String str28 = numberAxis26.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        double double31 = numberAxis26.getLowerMargin();
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis26);
        boolean boolean33 = combinedRangeXYPlot0.canSelectByRegion();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        categoryPlot19.clearDomainMarkers((int) '4');
        categoryPlot19.setRangeCrosshairValue(70.0d, false);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryPlot19.setDomainGridlinePaint(paint28);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 0.0d);
        categoryPlot19.setRenderer((int) '4', (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D33);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toRangeWidth((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis8.setLabelPaint(paint9);
        boolean boolean11 = numberAxis8.isAutoRange();
        java.awt.Stroke stroke12 = numberAxis8.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis14.setLabelInsets(rectangleInsets16);
        numberAxis8.setTickLabelInsets(rectangleInsets16);
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange();
        numberAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint6.toRangeWidth((org.jfree.data.Range) dateRange19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange19, (double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis10.setLabelPaint(paint11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis10.setLabelInsets(rectangleInsets13);
        intervalMarker2.setLabelOffset(rectangleInsets13);
        double double16 = rectangleInsets13.getBottom();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean4 = xYBarRenderer3.isDrawBarOutline();
        java.lang.Object obj5 = xYBarRenderer3.clone();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range10 = xYBarRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.lang.String str13 = standardXYURLGenerator1.generateURL((org.jfree.data.xy.XYDataset) timeSeriesCollection8, 0, (int) (byte) 10);
        try {
            java.lang.Number number16 = timeSeriesCollection8.getX((int) (byte) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "?series=0&amp;item=10" + "'", str13.equals("?series=0&amp;item=10"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis3D13.getCategoryLabelPositions();
        double double21 = categoryAxis3D13.getCategoryMargin();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PieSection: 0, 100(item)");
        java.lang.String str2 = standardPieToolTipGenerator1.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieSection: 0, 100(item)" + "'", str2.equals("PieSection: 0, 100(item)"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 0.8f;
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean21 = categoryPlot19.removeAnnotation(categoryAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        java.awt.Paint paint25 = categoryPlot19.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        java.awt.Font font6 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        java.util.List list63 = categoryPlot19.getAnnotations();
        int int64 = categoryPlot19.getRendererCount();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) 1560668399999L, paint3);
        categoryAxis3D0.setCategoryMargin((double) 0.5f);
        categoryAxis3D0.clearCategoryLabelToolTips();
        boolean boolean8 = categoryAxis3D0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.String str27 = legendItem26.getURLText();
        java.lang.String str28 = legendItem26.getURLText();
        java.awt.Color color29 = java.awt.Color.GRAY;
        legendItem26.setLinePaint((java.awt.Paint) color29);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        boolean boolean7 = piePlot5.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke8 = piePlot5.getBaseSectionOutlineStroke();
        boolean boolean9 = chartRenderingInfo3.equals((java.lang.Object) piePlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = chartRenderingInfo3.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        plotRenderingInfo10.setPlotArea(rectangle2D11);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray18, numberArray21, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        java.lang.String str31 = numberAxis29.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer32);
        double double34 = categoryPlot33.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot33.getRangeAxis((int) (byte) -1);
        boolean boolean37 = categoryPlot33.isRangeMinorGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        boolean boolean43 = piePlot41.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke44 = piePlot41.getBaseSectionOutlineStroke();
        boolean boolean45 = chartRenderingInfo39.equals((java.lang.Object) piePlot41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo39.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        plotRenderingInfo46.setPlotArea(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = null;
        java.awt.geom.Point2D point2D51 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor50);
        categoryPlot33.panDomainAxes((double) (-1.0f), plotRenderingInfo46, point2D51);
        try {
            polarPlot0.zoomRangeAxes((double) 6, plotRenderingInfo10, point2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.mapDatasetToDomainAxis(0, (int) '4');
        boolean boolean11 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        combinedRangeXYPlot13.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis16, false);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke20);
        combinedRangeXYPlot13.setDomainGridlineStroke(stroke20);
        java.awt.Paint paint23 = combinedRangeXYPlot13.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getAxisLineStroke();
        combinedRangeXYPlot13.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis26);
        combinedRangeXYPlot0.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis26, true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier63 = categoryPlot19.getDrawingSupplier();
        categoryPlot19.configureDomainAxes();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(drawingSupplier63);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = categoryPlot19.getOutlineStroke();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        boolean boolean5 = textTitle0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean7 = textTitle0.equals((java.lang.Object) itemLabelAnchor6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean14 = piePlot12.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke15 = piePlot12.getBaseSectionOutlineStroke();
        boolean boolean16 = chartRenderingInfo10.equals((java.lang.Object) piePlot12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = chartRenderingInfo10.getPlotInfo();
        java.lang.Object obj18 = textTitle0.draw(graphics2D8, rectangle2D9, (java.lang.Object) plotRenderingInfo17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        ringPlot0.setShadowPaint(paint4);
        boolean boolean6 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator5, xYURLGenerator6);
        boolean boolean8 = xYAreaRenderer7.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke10 = xYAreaRenderer7.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer7.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer1.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYBarRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator16);
        xYBarRenderer1.setShadowXOffset((double) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        java.awt.Font font19 = xYAreaRenderer3.getLegendTextFont((int) '#');
        java.awt.Font font21 = null;
        xYAreaRenderer3.setSeriesItemLabelFont(0, font21, false);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font19);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        axisState19.moveCursor((double) (byte) 100, rectangleEdge23);
        boolean boolean26 = textAnchor18.equals((java.lang.Object) rectangleEdge23);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint30 = intervalMarker29.getPaint();
        boolean boolean31 = textAnchor18.equals((java.lang.Object) intervalMarker29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean33 = combinedRangeXYPlot32.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace34 = combinedRangeXYPlot32.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = combinedRangeXYPlot32.getDomainMarkers((int) (short) 0, layer36);
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker29, layer36);
        java.awt.Stroke stroke39 = intervalMarker29.getOutlineStroke();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        long long5 = segmentedTimeline0.getExceptionSegmentCount((long) 3, (long) (-1));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = segmentedTimeline0.getBaseTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot1.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        boolean boolean7 = piePlot5.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke8 = piePlot5.getBaseSectionOutlineStroke();
        combinedRangeXYPlot1.setRangeMinorGridlineStroke(stroke8);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = combinedRangeXYPlot1.getOrientation();
        boolean boolean11 = rangeType0.equals((java.lang.Object) combinedRangeXYPlot1);
        int int12 = combinedRangeXYPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean2 = numberAxis3D1.isAxisLineVisible();
        numberAxis3D1.setLabelAngle((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        axisState0.moveCursor((double) 1L, rectangleEdge4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis3D0.getCategoryLabelPositions();
        java.awt.Font font4 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("{0}: ({1}, {2})");
        java.awt.Paint paint2 = standardChartTheme1.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYAreaRenderer3.getToolTipGenerator((int) (byte) 10, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator16, xYURLGenerator17);
        boolean boolean19 = xYAreaRenderer18.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke21 = xYAreaRenderer18.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer18.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition25);
        xYAreaRenderer3.setSeriesPositiveItemLabelPosition((int) (byte) 1, itemLabelPosition25, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = combinedRangeXYPlot29.getDomainAxisForDataset((int) (byte) 0);
        boolean boolean32 = xYAreaRenderer3.hasListener((java.util.EventListener) combinedRangeXYPlot29);
        boolean boolean36 = xYAreaRenderer3.isItemLabelVisible((-1), (-1), false);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        axisState4.moveCursor((double) (short) 10, rectangleEdge8);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge16);
        axisState12.moveCursor((double) (byte) 100, rectangleEdge16);
        boolean boolean19 = textAnchor11.equals((java.lang.Object) rectangleEdge16);
        axisState4.moveCursor(0.025d, rectangleEdge16);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis22.setLabelPaint(paint23);
        boolean boolean25 = numberAxis22.isAutoRange();
        java.awt.Stroke stroke26 = numberAxis22.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        boolean boolean37 = piePlot35.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke38 = piePlot35.getBaseSectionOutlineStroke();
        boolean boolean39 = chartRenderingInfo33.equals((java.lang.Object) piePlot35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo33.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection41 = chartRenderingInfo33.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D42 = chartRenderingInfo33.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets30.createInsetRectangle(rectangle2D42, true, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list47 = categoryAxis3D0.refreshTicks(graphics2D2, axisState4, rectangle2D42, rectangleEdge46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertNotNull(entityCollection41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        categoryPlot19.setCrosshairDatasetIndex((int) (byte) 1);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYAreaRenderer3.getURLGenerator(0, (int) (short) 0, false);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(xYURLGenerator22);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = legendTitle25.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer27 = legendTitle25.getItemContainer();
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) 10, (double) (short) 100, 3.0d);
        legendTitle25.setFrame((org.jfree.chart.block.BlockFrame) blockBorder32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint36 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis35.setLabelPaint(paint36);
        double double38 = numberAxis35.getAutoRangeMinimumSize();
        java.lang.Object obj39 = numberAxis35.clone();
        numberAxis35.setLabelToolTip("");
        numberAxis35.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint47 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis46.setLabelPaint(paint47);
        boolean boolean49 = numberAxis46.isAutoRange();
        java.awt.Stroke stroke50 = numberAxis46.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str53 = numberAxis52.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis52.setLabelInsets(rectangleInsets54);
        numberAxis46.setTickLabelInsets(rectangleInsets54);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset58 = null;
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot(pieDataset58);
        boolean boolean61 = piePlot59.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke62 = piePlot59.getBaseSectionOutlineStroke();
        boolean boolean63 = chartRenderingInfo57.equals((java.lang.Object) piePlot59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = chartRenderingInfo57.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection65 = chartRenderingInfo57.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D66 = chartRenderingInfo57.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets54.createInsetRectangle(rectangle2D66, true, true);
        org.jfree.chart.LegendItemSource legendItemSource70 = null;
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle(legendItemSource70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = legendTitle71.getLegendItemGraphicEdge();
        boolean boolean73 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge72);
        double double74 = numberAxis35.java2DToValue((double) 100.0f, rectangle2D66, rectangleEdge72);
        legendTitle25.setBounds(rectangle2D66);
        try {
            categoryPlot19.drawBackground(graphics2D23, rectangle2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(blockContainer27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0E-8d + "'", double38 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo64);
        org.junit.Assert.assertNotNull(entityCollection65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + Double.POSITIVE_INFINITY + "'", double74 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemPaint((int) (short) 0, 10, false);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean17 = piePlot15.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        piePlot15.axisChanged(axisChangeEvent18);
        boolean boolean20 = piePlot15.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot15.setLabelOutlineStroke(stroke21);
        xYAreaRenderer3.setBaseStroke(stroke21, false);
        java.awt.Stroke stroke26 = xYAreaRenderer3.lookupSeriesStroke(64);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxisForDataset(255);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        boolean boolean35 = piePlot33.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke36 = piePlot33.getBaseSectionOutlineStroke();
        intervalMarker31.setStroke(stroke36);
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        boolean boolean39 = categoryPlot19.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Paint paint9 = piePlot2.getLabelShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot2.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3-February-1900" + "'", str4.equals("3-February-1900"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries1.add(0.2d, (double) (byte) 1, false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener6);
        xYSeries1.add((double) 8, (java.lang.Number) (short) -1, false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        org.jfree.chart.util.Rotation rotation9 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot1.setDirection(rotation9);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(pieToolTipGenerator11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis13.setLabelPaint(paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis13.setLabelInsets(rectangleInsets16);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYAreaRenderer3.drawDomainGridLine(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis13, rectangle2D18, (double) 3);
        double double21 = numberAxis13.getFixedDimension();
        numberAxis13.resizeRange((double) (byte) -1, (double) 2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator4.getAttributedLabel(10);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator4.generateSectionLabel(pieDataset8, (java.lang.Comparable) 1.0d);
        java.lang.Object obj11 = standardPieSectionLabelGenerator4.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        xYSeries2.fireSeriesChanged();
        double[][] doubleArray4 = xYSeries2.toArray();
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        xYAreaRenderer3.setSeriesShape((int) '#', shape18, false);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        xYAreaRenderer3.setSeriesPaint(6, paint22);
        java.awt.Paint paint27 = xYAreaRenderer3.getItemLabelPaint(3, 31, false);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        double double8 = rectangleInsets6.calculateRightOutset((double) 0.8f);
        double double10 = rectangleInsets6.calculateTopOutset(0.0d);
        double double12 = rectangleInsets6.extendWidth((double) 31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 39.0d + "'", double12 == 39.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset12);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset12);
        try {
            org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset12, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        barRenderer3D0.setPlot(categoryPlot3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYAreaRenderer3.getToolTipGenerator((int) (byte) 10, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator16, xYURLGenerator17);
        boolean boolean19 = xYAreaRenderer18.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke21 = xYAreaRenderer18.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer18.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition25);
        xYAreaRenderer3.setSeriesPositiveItemLabelPosition((int) (byte) 1, itemLabelPosition25, false);
        xYAreaRenderer3.clearSeriesPaints(false);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getCategoryLabelPositionOffset();
        categoryAxis3D0.setLowerMargin((double) 10);
        java.awt.Stroke stroke4 = null;
        try {
            categoryAxis3D0.setTickMarkStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        int int1 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        numberAxis1.setAutoTickUnitSelection(true, true);
        double double9 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection1, (java.lang.Comparable) 3.0d);
        java.lang.String str4 = legendItemBlockContainer3.getURLText();
        legendItemBlockContainer3.setURLText("ItemLabelAnchor.INSIDE3");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate3.setDescription("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(33, serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) (-1194.0d), (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot19.axisChanged(axisChangeEvent23);
        categoryPlot19.setRangeZeroBaselineVisible(false);
        try {
            categoryPlot19.setBackgroundImageAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float4 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        xYAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer9.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.data.Range range20 = xYAreaRenderer9.findRangeBounds(xYDataset19);
        java.awt.Shape shape24 = xYAreaRenderer9.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle28.getLegendItemGraphicEdge();
        legendTitle26.setPosition(rectangleEdge29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double32 = rectangleInsets31.getTop();
        legendTitle26.setPadding(rectangleInsets31);
        org.jfree.chart.entity.TitleEntity titleEntity35 = new org.jfree.chart.entity.TitleEntity(shape24, (org.jfree.chart.title.Title) legendTitle26, "");
        java.awt.Paint paint36 = legendTitle26.getItemPaint();
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = legendTitle40.getLegendItemGraphicEdge();
        legendTitle38.setPosition(rectangleEdge41);
        double double43 = legendTitle38.getContentXOffset();
        double double44 = legendTitle38.getHeight();
        flowArrangement5.add((org.jfree.chart.block.Block) legendTitle26, (java.lang.Object) legendTitle38);
        jFreeChart3.addLegend(legendTitle26);
        java.awt.Paint paint47 = jFreeChart3.getBorderPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Font font8 = null;
        xYAreaRenderer5.setBaseItemLabelFont(font8, false);
        java.awt.Font font12 = xYAreaRenderer5.getSeriesItemLabelFont(3);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot19.getRowRenderingOrder();
        int int21 = categoryPlot19.getRendererCount();
        java.lang.String str22 = categoryPlot19.getPlotType();
        int int23 = categoryPlot19.getRangeAxisCount();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis3D2.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D2.getCategoryLabelPositions();
        java.awt.Font font5 = categoryAxis3D2.getTickLabelFont();
        xYBarRenderer1.setBaseLegendTextFont(font5);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.setCrosshairX(70.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean24 = segmentedTimeline23.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean26 = segmentedTimeline25.getAdjustForDaylightSaving();
        long long27 = segmentedTimeline25.getSegmentsGroupSize();
        java.util.Date date29 = segmentedTimeline25.getDate((long) (short) -1);
        long long30 = segmentedTimeline23.toTimelineValue(date29);
        categoryPlot19.setDomainCrosshairColumnKey((java.lang.Comparable) date29, false);
        java.lang.Comparable comparable33 = categoryPlot19.getDomainCrosshairRowKey();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot19.getDomainAxisLocation(2);
        categoryPlot19.mapDatasetToRangeAxis(0, (int) (short) -1);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 644288399999L + "'", long30 == 644288399999L);
        org.junit.Assert.assertNull(comparable33);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) numberAxis28);
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray40, numberArray43, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str52 = numberAxis51.getLabelToolTip();
        java.lang.String str53 = numberAxis51.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer54);
        double double56 = categoryPlot55.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent57 = null;
        categoryPlot55.datasetChanged(datasetChangeEvent57);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        categoryPlot55.datasetChanged(datasetChangeEvent59);
        org.jfree.chart.entity.PlotEntity plotEntity61 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot55);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setMinorTickCount(8);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.awt.Shape shape6 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        double double21 = categoryPlot20.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis((int) (byte) -1);
        boolean boolean24 = categoryPlot20.isRangeMinorGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        boolean boolean30 = piePlot28.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke31 = piePlot28.getBaseSectionOutlineStroke();
        boolean boolean32 = chartRenderingInfo26.equals((java.lang.Object) piePlot28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo26.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        plotRenderingInfo33.setPlotArea(rectangle2D34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        categoryPlot20.panDomainAxes((double) (-1.0f), plotRenderingInfo33, point2D38);
        java.util.List list40 = categoryPlot20.getCategories();
        projectInfo0.setContributors(list40);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType30 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean31 = titleEntity29.equals((java.lang.Object) gradientPaintTransformType30);
        java.awt.Shape shape32 = titleEntity29.getArea();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) 100);
        java.lang.Object obj3 = shapeList0.clone();
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        size2D4.height = (byte) 10;
        boolean boolean7 = shapeList0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1);
        double double3 = dateRange1.getUpperBound();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange5);
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toRangeWidth((org.jfree.data.Range) dateRange8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis12.setLabelPaint(paint13);
        boolean boolean15 = numberAxis12.isAutoRange();
        java.awt.Stroke stroke16 = numberAxis12.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str19 = numberAxis18.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis18.setLabelInsets(rectangleInsets20);
        numberAxis12.setTickLabelInsets(rectangleInsets20);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange();
        numberAxis12.setRangeWithMargins((org.jfree.data.Range) dateRange23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange23);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange27);
        boolean boolean29 = dateRange1.intersects((org.jfree.data.Range) dateRange27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator4, xYURLGenerator5);
        boolean boolean7 = xYAreaRenderer6.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke9 = xYAreaRenderer6.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        double double16 = ringPlot15.getOuterSeparatorExtension();
        java.awt.Color color17 = java.awt.Color.GREEN;
        ringPlot15.setSeparatorPaint((java.awt.Paint) color17);
        java.awt.Shape shape19 = ringPlot15.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme21 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint22 = standardChartTheme21.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        boolean boolean26 = piePlot24.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        piePlot24.axisChanged(axisChangeEvent27);
        boolean boolean29 = piePlot24.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot24.setLabelOutlineStroke(stroke30);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        intervalMarker34.setOutlinePaint((java.awt.Paint) color35);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("item", "item", "", "", shape19, paint22, stroke30, (java.awt.Paint) color35);
        xYAreaRenderer6.setSeriesItemLabelPaint(1, paint22);
        standardChartTheme1.setThermometerPaint(paint22);
        java.awt.Paint paint40 = standardChartTheme1.getWallPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        double double6 = legendTitle1.getContentXOffset();
        double double7 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle1.getItemContainer();
        blockContainer8.setPadding((-6.0d), 1.0E-5d, (double) 0.0f, (double) 86400000L);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator16, xYURLGenerator17);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYAreaRenderer18.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        xYAreaRenderer18.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer18.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.data.Range range29 = xYAreaRenderer18.findRangeBounds(xYDataset28);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        xYAreaRenderer18.setSeriesShape((int) '#', shape33, false);
        java.awt.Paint paint37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        xYAreaRenderer18.setSeriesPaint(6, paint37);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis40.setMinorTickCount(8);
        org.jfree.chart.StandardChartTheme standardChartTheme44 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint45 = standardChartTheme44.getItemLabelPaint();
        java.awt.Color color46 = java.awt.Color.WHITE;
        java.awt.Color color47 = color46.brighter();
        standardChartTheme44.setWallPaint((java.awt.Paint) color46);
        java.awt.Paint paint49 = standardChartTheme44.getTitlePaint();
        numberAxis40.setAxisLinePaint(paint49);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = legendTitle55.getLegendItemGraphicEdge();
        legendTitle53.setPosition(rectangleEdge56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double59 = rectangleInsets58.getTop();
        legendTitle53.setPadding(rectangleInsets58);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint63 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis62.setLabelPaint(paint63);
        boolean boolean65 = numberAxis62.isAutoRange();
        java.awt.Stroke stroke66 = numberAxis62.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str69 = numberAxis68.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis68.setLabelInsets(rectangleInsets70);
        numberAxis62.setTickLabelInsets(rectangleInsets70);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset74 = null;
        org.jfree.chart.plot.PiePlot piePlot75 = new org.jfree.chart.plot.PiePlot(pieDataset74);
        boolean boolean77 = piePlot75.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke78 = piePlot75.getBaseSectionOutlineStroke();
        boolean boolean79 = chartRenderingInfo73.equals((java.lang.Object) piePlot75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = chartRenderingInfo73.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection81 = chartRenderingInfo73.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D82 = chartRenderingInfo73.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D85 = rectangleInsets70.createInsetRectangle(rectangle2D82, true, true);
        rectangleInsets58.trim(rectangle2D85);
        org.jfree.chart.LegendItemSource legendItemSource87 = null;
        org.jfree.chart.title.LegendTitle legendTitle88 = new org.jfree.chart.title.LegendTitle(legendItemSource87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = legendTitle88.getLegendItemGraphicEdge();
        boolean boolean90 = legendTitle88.visible;
        boolean boolean91 = legendTitle88.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = legendTitle88.getPosition();
        double double93 = numberAxis40.valueToJava2D((double) (short) 100, rectangle2D85, rectangleEdge92);
        xYAreaRenderer18.setBaseShape((java.awt.Shape) rectangle2D85, false);
        try {
            blockContainer8.draw(graphics2D14, rectangle2D85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo80);
        org.junit.Assert.assertNotNull(entityCollection81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(rectangleEdge92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + (-1194.0d) + "'", double93 == (-1194.0d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Other");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        java.lang.Object obj5 = ringPlot0.clone();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean7 = piePlot3D6.getSimpleLabels();
        java.awt.Color color8 = java.awt.Color.darkGray;
        piePlot3D6.setBackgroundPaint((java.awt.Paint) color8);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean13 = combinedRangeXYPlot12.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace14 = combinedRangeXYPlot12.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = combinedRangeXYPlot12.getDomainMarkers((int) (short) 0, layer16);
        combinedRangeXYPlot12.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke20 = combinedRangeXYPlot12.getDomainZeroBaselineStroke();
        boolean boolean21 = piePlot3D6.equals((java.lang.Object) stroke20);
        ringPlot0.setLabelLinkStroke(stroke20);
        ringPlot0.setAutoPopulateSectionPaint(false);
        java.awt.Shape shape25 = ringPlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        numberFormat1.setMinimumFractionDigits((int) (short) 100);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("http://www.jfree.org/jfreechart/index.html", numberFormat1, numberFormat4);
        boolean boolean6 = numberFormat1.isGroupingUsed();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        boolean boolean24 = piePlot22.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke25 = piePlot22.getBaseSectionOutlineStroke();
        boolean boolean26 = chartRenderingInfo20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo20.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        plotRenderingInfo27.setPlotArea(rectangle2D28);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo27);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean33 = xYBarRenderer32.isDrawBarOutline();
        java.lang.Object obj34 = xYBarRenderer32.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection(timeSeries35, timeZone36);
        boolean boolean38 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        org.jfree.data.Range range39 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        xYItemRendererState30.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection37);
        boolean boolean41 = legendItemEntity19.equals((java.lang.Object) xYItemRendererState30);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelToolTip();
        combinedRangeXYPlot42.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis45, false);
        combinedRangeXYPlot42.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset51 = combinedRangeXYPlot42.getDataset();
        org.jfree.data.time.TimeSeries timeSeries52 = null;
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection54 = new org.jfree.data.time.TimeSeriesCollection(timeSeries52, timeZone53);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection54);
        combinedRangeXYPlot42.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection54);
        xYItemRendererState30.endSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection54, (int) (short) 0, 100, 10, (int) (short) 100, 52);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(xYDataset51);
        org.junit.Assert.assertNull(range55);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = ringPlot0.getInsets();
        java.awt.Stroke stroke26 = ringPlot0.getSeparatorStroke();
        java.awt.Paint paint27 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray11, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelToolTip();
        java.lang.String str21 = numberAxis19.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        double double24 = categoryPlot23.getRangeCrosshairValue();
        categoryPlot23.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot23.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelToolTip();
        combinedRangeXYPlot29.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis32, false);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke36);
        combinedRangeXYPlot29.setDomainGridlineStroke(stroke36);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray43, numberArray46, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelToolTip();
        java.lang.String str56 = numberAxis54.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D52, (org.jfree.chart.axis.ValueAxis) numberAxis54, categoryItemRenderer57);
        double double59 = categoryPlot58.getRangeCrosshairValue();
        categoryPlot58.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot58.getRangeAxisLocation(9999);
        combinedRangeXYPlot29.setDomainAxisLocation(axisLocation63, false);
        categoryPlot23.setRangeAxisLocation(axisLocation63);
        int int67 = categoryPlot23.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str70 = numberAxis69.getLabelToolTip();
        boolean boolean71 = numberAxis69.isAutoTickUnitSelection();
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker(30.0d);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis69, (org.jfree.chart.plot.Marker) valueMarker73, rectangle2D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9, true);
        java.awt.Font font15 = xYAreaRenderer3.getItemLabelFont((int) (short) 100, 0, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        polarPlot0.setRadiusGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.setMinorTickCount(8);
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint12 = standardChartTheme11.getItemLabelPaint();
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.Color color14 = color13.brighter();
        standardChartTheme11.setWallPaint((java.awt.Paint) color13);
        java.awt.Paint paint16 = standardChartTheme11.getTitlePaint();
        numberAxis7.setAxisLinePaint(paint16);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint30 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis29.setLabelPaint(paint30);
        boolean boolean32 = numberAxis29.isAutoRange();
        java.awt.Stroke stroke33 = numberAxis29.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis35.setLabelInsets(rectangleInsets37);
        numberAxis29.setTickLabelInsets(rectangleInsets37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        boolean boolean44 = piePlot42.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke45 = piePlot42.getBaseSectionOutlineStroke();
        boolean boolean46 = chartRenderingInfo40.equals((java.lang.Object) piePlot42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = chartRenderingInfo40.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection48 = chartRenderingInfo40.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D49 = chartRenderingInfo40.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets37.createInsetRectangle(rectangle2D49, true, true);
        rectangleInsets25.trim(rectangle2D52);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = legendTitle55.getLegendItemGraphicEdge();
        boolean boolean57 = legendTitle55.visible;
        boolean boolean58 = legendTitle55.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = legendTitle55.getPosition();
        double double60 = numberAxis7.valueToJava2D((double) (short) 100, rectangle2D52, rectangleEdge59);
        try {
            java.awt.Point point61 = polarPlot0.translateValueThetaRadiusToJava2D((double) (byte) -1, 1.0E-8d, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo47);
        org.junit.Assert.assertNotNull(entityCollection48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1194.0d) + "'", double60 == (-1194.0d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY((double) 86400000L);
        crosshairState1.updateCrosshairX((double) 10.0f, 0);
        int int7 = crosshairState1.getRangeAxisIndex();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = null;
        crosshairState1.updateCrosshairPoint(4.0d, 8.0d, (int) (byte) 0, (int) (short) -1, 2.0d, (double) 9999, plotOrientation14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) numberAxis28);
        java.text.NumberFormat numberFormat36 = numberAxis28.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNull(numberFormat36);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        axisState19.moveCursor((double) (byte) 100, rectangleEdge23);
        boolean boolean26 = textAnchor18.equals((java.lang.Object) rectangleEdge23);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint30 = intervalMarker29.getPaint();
        boolean boolean31 = textAnchor18.equals((java.lang.Object) intervalMarker29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean33 = combinedRangeXYPlot32.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace34 = combinedRangeXYPlot32.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = combinedRangeXYPlot32.getDomainMarkers((int) (short) 0, layer36);
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker29, layer36);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        boolean boolean43 = piePlot41.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = null;
        piePlot41.axisChanged(axisChangeEvent44);
        boolean boolean46 = piePlot41.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot41.setLabelOutlineStroke(stroke47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot41.setLabelBackgroundPaint((java.awt.Paint) color49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1, (java.awt.Paint) color49, stroke51);
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke51);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 1);
        boolean boolean10 = piePlot2.equals((java.lang.Object) 1);
        java.awt.Paint paint12 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 0);
        java.awt.Stroke stroke13 = piePlot2.getLabelOutlineStroke();
        java.awt.Stroke stroke14 = piePlot2.getLabelLinkStroke();
        piePlot2.setShadowYOffset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Paint paint9 = piePlot2.getLabelShadowPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        boolean boolean17 = chartRenderingInfo11.equals((java.lang.Object) piePlot13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo11.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection19 = chartRenderingInfo11.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo11.getChartArea();
        java.awt.geom.Point2D point2D21 = null;
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        combinedRangeXYPlot23.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        combinedRangeXYPlot23.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean35 = combinedRangeXYPlot34.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace36 = combinedRangeXYPlot34.getFixedRangeAxisSpace();
        combinedRangeXYPlot34.setWeight(0);
        java.util.List list39 = combinedRangeXYPlot34.getSubplots();
        combinedRangeXYPlot23.drawRangeTickBands(graphics2D32, rectangle2D33, list39);
        boolean boolean41 = combinedRangeXYPlot23.canSelectByRegion();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray48, numberArray51, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray55);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelToolTip();
        java.lang.String str61 = numberAxis59.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer62);
        double double64 = categoryPlot63.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis66 = categoryPlot63.getRangeAxis((int) (byte) -1);
        boolean boolean67 = categoryPlot63.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable68 = categoryPlot63.getDomainCrosshairRowKey();
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str74 = numberAxis73.getLabelToolTip();
        java.lang.String str75 = numberAxis73.getLabelToolTip();
        boolean boolean76 = textTitle71.equals((java.lang.Object) numberAxis73);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor77 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean78 = textTitle71.equals((java.lang.Object) itemLabelAnchor77);
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset82 = null;
        org.jfree.chart.plot.PiePlot piePlot83 = new org.jfree.chart.plot.PiePlot(pieDataset82);
        boolean boolean85 = piePlot83.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke86 = piePlot83.getBaseSectionOutlineStroke();
        boolean boolean87 = chartRenderingInfo81.equals((java.lang.Object) piePlot83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = chartRenderingInfo81.getPlotInfo();
        java.lang.Object obj89 = textTitle71.draw(graphics2D79, rectangle2D80, (java.lang.Object) plotRenderingInfo88);
        categoryPlot63.handleClick(6, (int) (byte) 0, plotRenderingInfo88);
        int int91 = plotRenderingInfo88.getSubplotCount();
        combinedRangeXYPlot23.handleClick((int) '4', 0, plotRenderingInfo88);
        try {
            piePlot2.draw(graphics2D10, rectangle2D20, point2D21, plotState22, plotRenderingInfo88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertNotNull(entityCollection19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(comparable68);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo88);
        org.junit.Assert.assertNull(obj89);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter9 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        xYBarRenderer1.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter9);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator(10, xYItemLabelGenerator12, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator(0, xYItemLabelGenerator16, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean21 = combinedRangeXYPlot20.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = combinedRangeXYPlot20.getFixedRangeAxisSpace();
        combinedRangeXYPlot20.setWeight(0);
        java.util.List list25 = combinedRangeXYPlot20.getSubplots();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection19, list25, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState28 = xYSeriesCollection19.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries30 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries30.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection19.removeSeries(xYSeries30);
        org.jfree.data.Range range37 = xYSeriesCollection19.getRangeBounds(false);
        org.jfree.data.Range range38 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState28);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNull(range38);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("June 2019");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator5, xYURLGenerator6);
        boolean boolean8 = xYAreaRenderer7.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke10 = xYAreaRenderer7.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer7.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer1.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Paint paint16 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Stroke stroke18 = xYBarRenderer1.lookupSeriesOutlineStroke((int) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis24.setLabelPaint(paint25);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer30.setLegendItemURLGenerator(xYSeriesLabelGenerator31);
        java.awt.Paint paint36 = xYAreaRenderer30.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint41 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis40.setLabelPaint(paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis40.setLabelInsets(rectangleInsets43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYAreaRenderer30.drawDomainGridLine(graphics2D37, xYPlot38, (org.jfree.chart.axis.ValueAxis) numberAxis40, rectangle2D45, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator49, xYURLGenerator50);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator52 = null;
        xYAreaRenderer51.setLegendItemURLGenerator(xYSeriesLabelGenerator52);
        java.awt.Paint paint57 = xYAreaRenderer51.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint62 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis61.setLabelPaint(paint62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis61.setLabelInsets(rectangleInsets64);
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        xYAreaRenderer51.drawDomainGridLine(graphics2D58, xYPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, rectangle2D66, (double) 3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator70 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator71 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer72 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator70, xYURLGenerator71);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator73 = null;
        xYAreaRenderer72.setLegendItemURLGenerator(xYSeriesLabelGenerator73);
        java.awt.Paint paint78 = xYAreaRenderer72.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = null;
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint83 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis82.setLabelPaint(paint83);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis82.setLabelInsets(rectangleInsets85);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        xYAreaRenderer72.drawDomainGridLine(graphics2D79, xYPlot80, (org.jfree.chart.axis.ValueAxis) numberAxis82, rectangle2D87, (double) 3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray90 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis40, numberAxis61, numberAxis82 };
        categoryPlot19.setRangeAxes(valueAxisArray90);
        try {
            categoryPlot19.mapDatasetToDomainAxis((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNotNull(valueAxisArray90);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) 10, (double) (short) 100, 3.0d);
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        java.awt.Paint paint10 = blockBorder8.getPaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme13.setLargeFont(font14);
        xYAreaRenderer3.setSeriesItemLabelFont((int) (short) 1, font14, true);
        xYAreaRenderer3.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean23 = xYAreaRenderer3.isItemLabelVisible((int) 'a', 52, true);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        java.awt.Color color2 = java.awt.Color.darkGray;
        piePlot3D0.setBackgroundPaint((java.awt.Paint) color2);
        piePlot3D0.setIgnoreZeroValues(false);
        piePlot3D0.setIgnoreNullValues(true);
        piePlot3D0.setDepthFactor(100.0d);
        java.awt.Paint paint10 = piePlot3D0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        xYSeries11.add((double) 1.0f, (double) (-2208960000000L), true);
        org.jfree.data.xy.XYDataItem xYDataItem23 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (byte) 100, (java.lang.Number) 0L);
        xYDataItem23.setY((-1.0d));
        boolean boolean26 = xYDataItem23.isSelected();
        org.jfree.data.xy.XYDataItem xYDataItem27 = xYSeries11.addOrUpdate(xYDataItem23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(xYDataItem27);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator2, xYURLGenerator3);
        boolean boolean5 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke7 = xYAreaRenderer4.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer4.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer4.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        boolean boolean15 = xYAreaRenderer4.getItemCreateEntity(6, 10, true);
        java.awt.Paint paint19 = xYAreaRenderer4.getItemOutlinePaint((int) (byte) 0, 100, true);
        java.awt.Font font23 = xYAreaRenderer4.getItemLabelFont(10, (int) (short) 1, false);
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("PieSection: 0, 100(item)", font23);
        labelBlock24.setURLText("Value");
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        labelBlock24.setFont(font27);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        java.lang.String str15 = numberAxis13.getLabelToolTip();
        boolean boolean16 = textTitle11.equals((java.lang.Object) numberAxis13);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean18 = textTitle11.equals((java.lang.Object) itemLabelAnchor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean25 = piePlot23.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke26 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) piePlot23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        java.lang.Object obj29 = textTitle11.draw(graphics2D19, rectangle2D20, (java.lang.Object) plotRenderingInfo28);
        combinedRangeXYPlot0.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo28);
        boolean boolean31 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean33 = combinedRangeXYPlot32.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace34 = combinedRangeXYPlot32.getFixedRangeAxisSpace();
        boolean boolean35 = combinedRangeXYPlot0.equals((java.lang.Object) combinedRangeXYPlot32);
        combinedRangeXYPlot32.setDomainPannable(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        combinedRangeXYPlot32.plotChanged(plotChangeEvent38);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator9, xYURLGenerator10);
        boolean boolean13 = xYAreaRenderer11.equals((java.lang.Object) (-1));
        xYAreaRenderer11.setDefaultEntityRadius(2);
        combinedRangeXYPlot0.setRenderer(4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean19 = combinedRangeXYPlot18.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace20 = combinedRangeXYPlot18.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = combinedRangeXYPlot18.getDomainMarkers((int) (short) 0, layer22);
        java.util.Collection collection24 = combinedRangeXYPlot0.getDomainMarkers(3, layer22);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
    }
}

