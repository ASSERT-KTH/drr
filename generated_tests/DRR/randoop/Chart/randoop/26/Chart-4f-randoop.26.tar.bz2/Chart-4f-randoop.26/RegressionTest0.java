import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity2 = new org.jfree.chart.entity.TitleEntity(shape0, title1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, dataset1, (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(xYDataset0, (int) (byte) 10, (double) (-1), (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (int) (byte) 10, (double) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        org.jfree.data.Range range2 = null;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, list1, range2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.GREEN;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Shape shape0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = legendTitle2.getLegendItemGraphicEdge();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity5 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle2, "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.scale(range0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean10 = piePlot8.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke11 = piePlot8.getBaseSectionOutlineStroke();
        try {
            xYAreaRenderer3.setSeriesStroke((int) (short) -1, stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 0.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Font font7 = xYAreaRenderer3.getSeriesItemLabelFont((int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        try {
            xYAreaRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        float float7 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        try {
            xYAreaRenderer3.setGradientTransformer(gradientPaintTransformer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateTickUnitType2, (-1), dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) ' ', (float) (byte) 0, (double) 100L, (float) (short) -1, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(xYDataset0, list1, (org.jfree.data.Range) dateRange2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, 100.0f, (float) ' ', textAnchor4, (double) (short) 0, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean5 = xYAreaRenderer3.equals((java.lang.Object) (-1));
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis9.setLabelPaint(paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis9.setLabelInsets(rectangleInsets12);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        boolean boolean20 = piePlot18.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke21 = piePlot18.getBaseSectionOutlineStroke();
        intervalMarker16.setStroke(stroke21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            xYAreaRenderer3.drawDomainMarker(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.plot.Marker) intervalMarker16, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("item");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name item, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            numberAxis1.setLabelInsets(rectangleInsets2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean11 = piePlot9.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke12 = piePlot9.getBaseSectionOutlineStroke();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) piePlot9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        try {
            combinedRangeXYPlot0.draw(graphics2D1, rectangle2D2, point2D5, plotState6, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (short) 10, (float) (byte) 100, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        try {
            java.util.List list9 = numberAxis1.refreshTicks(graphics2D2, axisState4, rectangle2D5, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape shape0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = legendTitle2.getLegendItemGraphicEdge();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("ThreadContext", "hi!", "ThreadContext");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle26.getLegendItemGraphicEdge();
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        axisState23.moveCursor((double) (byte) 100, rectangleEdge27);
        try {
            double double30 = categoryAxis3D13.getCategoryEnd(2, (int) (byte) -1, rectangle2D22, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("item", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer8.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        xYAreaRenderer8.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer8.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.data.Range range19 = xYAreaRenderer8.findRangeBounds(xYDataset18);
        java.awt.Shape shape23 = xYAreaRenderer8.getItemShape((int) (short) 1, (int) ' ', true);
        java.awt.Color color25 = java.awt.Color.CYAN;
        java.awt.Color color27 = java.awt.Color.WHITE;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        boolean boolean37 = piePlot35.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke38 = piePlot35.getBaseSectionOutlineStroke();
        intervalMarker33.setStroke(stroke38);
        java.awt.Color color40 = java.awt.Color.CYAN;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color30, stroke38, (java.awt.Paint) color40, stroke41, (float) (short) 0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator46 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator47 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer48 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator46, xYURLGenerator47);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator49 = null;
        xYAreaRenderer48.setLegendItemURLGenerator(xYSeriesLabelGenerator49);
        xYAreaRenderer48.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer48.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.data.Range range59 = xYAreaRenderer48.findRangeBounds(xYDataset58);
        java.awt.Shape shape63 = xYAreaRenderer48.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke65 = ringPlot64.getSeparatorStroke();
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker71 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset72 = null;
        org.jfree.chart.plot.PiePlot piePlot73 = new org.jfree.chart.plot.PiePlot(pieDataset72);
        boolean boolean75 = piePlot73.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke76 = piePlot73.getBaseSectionOutlineStroke();
        intervalMarker71.setStroke(stroke76);
        java.awt.Color color78 = java.awt.Color.CYAN;
        java.awt.Stroke stroke79 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker81 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color68, stroke76, (java.awt.Paint) color78, stroke79, (float) (short) 0);
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "", "hi!", true, shape23, true, (java.awt.Paint) color25, false, (java.awt.Paint) color27, stroke41, true, shape63, stroke65, (java.awt.Paint) color68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke79);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Object obj20 = categoryPlot19.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = null;
        try {
            categoryPlot19.setDomainGridlinePosition(categoryAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = legendTitle24.getLegendItemGraphicEdge();
        try {
            double double26 = categoryAxis3D13.getCategoryStart((int) 'a', (int) (byte) -1, rectangle2D22, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) -1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets3.createOutsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean5 = xYAreaRenderer3.equals((java.lang.Object) (-1));
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYAreaRenderer3.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = null;
        try {
            combinedRangeXYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        java.lang.String str3 = numberAxis1.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        java.lang.Comparable comparable2 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray11, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset16);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        boolean boolean25 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge24);
        axisState20.moveCursor((double) (byte) 100, rectangleEdge24);
        try {
            double double27 = categoryAxis3D0.getCategorySeriesMiddle(comparable2, (java.lang.Comparable) 8, categoryDataset16, (double) 3, rectangle2D19, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 30.0d + "'", number17.equals(30.0d));
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) ' ');
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (-1), 100.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        boolean boolean7 = xYAreaRenderer3.isSeriesVisibleInLegend((int) (short) 10);
        java.awt.Color color9 = java.awt.Color.magenta;
        xYAreaRenderer3.setLegendTextPaint(0, (java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        java.awt.Paint paint14 = xYAreaRenderer3.getBasePaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = null;
        try {
            standardChartTheme1.setXYBarPainter(xYBarPainter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.Marker marker23 = null;
        try {
            boolean boolean24 = categoryPlot19.removeRangeMarker(marker23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = combinedRangeXYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getSeparatorStroke();
        double double2 = ringPlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("item", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        xYAreaRenderer3.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 10.0f, 0.0f, textAnchor4, 0.0d, (float) 10L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = null;
        try {
            xYBarRenderer1.setBarPainter(xYBarPainter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Object obj20 = categoryPlot19.clone();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace21, false);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) '#', (double) 0L, 0, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset12, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        boolean boolean16 = range14.equals((java.lang.Object) color15);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 0L, "ThreadContext", textAnchor3, textAnchor4, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        java.lang.Object obj4 = standardChartTheme1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Object obj20 = categoryPlot19.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        try {
            categoryPlot19.addDomainMarker(categoryMarker21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke2 = ringPlot0.getLabelLinkStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        boolean boolean13 = piePlot11.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        boolean boolean15 = chartRenderingInfo9.equals((java.lang.Object) piePlot11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo9.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        plotRenderingInfo16.setPlotArea(rectangle2D17);
        try {
            ringPlot0.draw(graphics2D3, rectangle2D4, point2D7, plotState8, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Font font7 = xYAreaRenderer3.getSeriesItemLabelFont((int) '4');
        xYAreaRenderer3.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("item", "ThreadContext");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1);
        java.lang.String str3 = dateRange1.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color6 = java.awt.Color.ORANGE;
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal(paint5, (java.awt.Paint) color6);
        standardChartTheme1.setErrorIndicatorPaint(paint5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemPaint((int) (short) 0, 10, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean9 = piePlot7.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        intervalMarker5.setStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color2, stroke10, (java.awt.Paint) color12, stroke13, (float) (short) 0);
        java.awt.Stroke stroke16 = intervalMarker15.getOutlineStroke();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        intervalMarker15.setPaint(paint17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(0.2d, (org.jfree.data.Range) dateRange1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        java.awt.Paint paint7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke9 = ringPlot8.getSeparatorStroke();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = color11.brighter();
        ringPlot10.setSeparatorPaint((java.awt.Paint) color12);
        try {
            org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "item", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", shape6, paint7, stroke9, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getOuterSeparatorExtension();
        java.awt.Color color7 = java.awt.Color.GREEN;
        ringPlot5.setSeparatorPaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = ringPlot5.getLegendItemShape();
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean12 = piePlot3D11.getSimpleLabels();
        java.awt.Color color13 = java.awt.Color.darkGray;
        piePlot3D11.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle17.getLegendItemGraphicEdge();
        boolean boolean19 = legendTitle17.visible;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets20.getTop();
        legendTitle17.setLegendItemGraphicPadding(rectangleInsets20);
        java.awt.Paint paint23 = legendTitle17.getItemPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator25, xYURLGenerator26);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator28 = null;
        xYAreaRenderer27.setLegendItemURLGenerator(xYSeriesLabelGenerator28);
        java.awt.Paint paint33 = xYAreaRenderer27.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint37 = xYAreaRenderer27.getItemPaint((int) (short) 0, 10, false);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        boolean boolean41 = piePlot39.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = null;
        piePlot39.axisChanged(axisChangeEvent42);
        boolean boolean44 = piePlot39.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot39.setLabelOutlineStroke(stroke45);
        xYAreaRenderer27.setBaseStroke(stroke45, false);
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 0, (float) 4);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint55 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis54.setLabelPaint(paint55);
        boolean boolean57 = numberAxis54.isAutoRange();
        java.awt.Stroke stroke58 = numberAxis54.getTickMarkStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme60 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint61 = standardChartTheme60.getItemLabelPaint();
        java.awt.Color color62 = java.awt.Color.WHITE;
        java.awt.Color color63 = color62.brighter();
        standardChartTheme60.setWallPaint((java.awt.Paint) color62);
        java.awt.Paint paint65 = standardChartTheme60.getTitlePaint();
        try {
            org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "ThreadContext", true, shape9, false, (java.awt.Paint) color13, true, paint23, stroke45, true, shape52, stroke58, paint65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paint65);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.lang.Object obj20 = categoryPlot19.clone();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        combinedRangeXYPlot23.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke30);
        combinedRangeXYPlot23.setDomainGridlineStroke(stroke30);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        combinedRangeXYPlot23.setQuadrantOrigin(point2D35);
        org.jfree.chart.plot.PlotState plotState37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        boolean boolean42 = piePlot40.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke43 = piePlot40.getBaseSectionOutlineStroke();
        boolean boolean44 = chartRenderingInfo38.equals((java.lang.Object) piePlot40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo38.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        plotRenderingInfo45.setPlotArea(rectangle2D46);
        try {
            categoryPlot19.draw(graphics2D21, rectangle2D22, point2D35, plotState37, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme2.setLargeFont(font3);
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Color color6 = color5.brighter();
        org.jfree.chart.text.TextMeasurer textMeasurer8 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font3, (java.awt.Paint) color6, (float) 1L, textMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        java.awt.Paint paint4 = piePlot1.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        double double9 = ringPlot8.getOuterSeparatorExtension();
        java.awt.Color color10 = java.awt.Color.GREEN;
        ringPlot8.setSeparatorPaint((java.awt.Paint) color10);
        java.awt.Shape shape12 = ringPlot8.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme14 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint15 = standardChartTheme14.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        boolean boolean19 = piePlot17.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot17.axisChanged(axisChangeEvent20);
        boolean boolean22 = piePlot17.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot17.setLabelOutlineStroke(stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        intervalMarker27.setOutlinePaint((java.awt.Paint) color28);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("item", "item", "", "", shape12, paint15, stroke23, (java.awt.Paint) color28);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        double double36 = ringPlot35.getOuterSeparatorExtension();
        java.awt.Color color37 = java.awt.Color.GREEN;
        ringPlot35.setSeparatorPaint((java.awt.Paint) color37);
        java.awt.Shape shape39 = ringPlot35.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme41 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint42 = standardChartTheme41.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        boolean boolean46 = piePlot44.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent47 = null;
        piePlot44.axisChanged(axisChangeEvent47);
        boolean boolean49 = piePlot44.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot44.setLabelOutlineStroke(stroke50);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color55 = java.awt.Color.LIGHT_GRAY;
        intervalMarker54.setOutlinePaint((java.awt.Paint) color55);
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("item", "item", "", "", shape39, paint42, stroke50, (java.awt.Paint) color55);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        double double59 = ringPlot58.getOuterSeparatorExtension();
        java.awt.Stroke stroke60 = ringPlot58.getLabelLinkStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator62 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator63 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer64 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator62, xYURLGenerator63);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator65 = null;
        xYAreaRenderer64.setLegendItemURLGenerator(xYSeriesLabelGenerator65);
        java.awt.Paint paint70 = xYAreaRenderer64.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator72 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer64.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator72, false);
        java.awt.Paint paint78 = xYAreaRenderer64.getItemOutlinePaint(2, (int) (byte) 1, true);
        try {
            org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem(attributedString0, "http://www.jfree.org/jfreechart/index.html", "item", "http://www.jfree.org/jfreechart/index.html", shape12, (java.awt.Paint) color55, stroke60, paint78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.2d + "'", double59 == 0.2d);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            legendTitle1.setBounds(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) -1, (double) (-2208960000000L), (double) (short) 100);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean3 = legendTitle1.visible;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange6);
        try {
            org.jfree.chart.util.Size2D size2D8 = legendTitle1.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        try {
            double double11 = timeSeriesCollection6.getXValue(6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = xYBarRenderer1.getMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.20896E12d) + "'", double9 == (-2.20896E12d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        boolean boolean7 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle9.getLegendItemGraphicEdge();
        try {
            double double11 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor4, (int) (byte) 0, 1, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        try {
            boolean boolean5 = segmentedTimeline0.containsDomainRange(10L, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (4) < domainValueStart (10)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", graphics2D1, (float) 0, (float) 10, (double) 9999, (float) 3, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        combinedRangeXYPlot0.setRangePannable(false);
        java.awt.Stroke stroke11 = null;
        try {
            combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float4 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean11 = piePlot9.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke12 = piePlot9.getBaseSectionOutlineStroke();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) piePlot9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection15 = chartRenderingInfo7.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart3.createBufferedImage((int) '#', (int) (short) -1, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (35) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(entityCollection15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(pieURLGenerator2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "", 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            int int4 = timeSeriesCollection2.getItemCount((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            xYAreaRenderer3.drawDomainGridLine(graphics2D15, xYPlot16, valueAxis17, rectangle2D18, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = null;
        try {
            combinedRangeXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        segmentedTimeline0.addBaseTimelineExclusions((long) (short) -1, (long) '4');
        java.util.List list6 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font5);
        java.awt.Paint paint7 = standardChartTheme1.getBaselinePaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        java.awt.Color color7 = java.awt.Color.orange;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean9 = combinedRangeXYPlot8.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = combinedRangeXYPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection13 = combinedRangeXYPlot8.getDomainMarkers((int) (short) 0, layer12);
        java.awt.Stroke stroke14 = combinedRangeXYPlot8.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color16 = java.awt.Color.WHITE;
        java.awt.Color color17 = color16.brighter();
        ringPlot15.setSeparatorPaint((java.awt.Paint) color17);
        try {
            org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "{0}", "hi!", shape6, (java.awt.Paint) color7, stroke14, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = xYAreaRenderer3.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYAreaRenderer3.setBaseLegendTextFont(font16);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.awt.Font font21 = categoryAxis3D13.getTickLabelFont((java.lang.Comparable) "hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = legendTitle29.getLegendItemGraphicEdge();
        boolean boolean31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge30);
        try {
            double double32 = categoryAxis3D13.getCategorySeriesMiddle(4, (-1), 0, (int) (byte) 100, 0.025d, rectangle2D27, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color25);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        try {
            categoryPlot19.addDomainMarker(categoryMarker27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        legendTitle1.setPosition(rectangleEdge4);
        double double6 = legendTitle1.getWidth();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            boolean boolean3 = segmentedTimeline0.containsDomainRange(date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        boolean boolean4 = numberAxis1.isAutoRange();
        java.awt.Stroke stroke5 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis7.setLabelInsets(rectangleInsets9);
        numberAxis1.setTickLabelInsets(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets9.createOutsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color25);
        int int27 = color25.getGreen();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 64 + "'", int27 == 64);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean12 = piePlot10.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke13 = piePlot10.getBaseSectionOutlineStroke();
        intervalMarker8.setStroke(stroke13);
        java.awt.Color color15 = java.awt.Color.CYAN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color5, stroke13, (java.awt.Paint) color15, stroke16, (float) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color1, stroke16);
        int int20 = color1.getBlue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("http://www.jfree.org/jfreechart/index.html", regularTimePeriod1, regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.mapDatasetToDomainAxis(0, (int) '4');
        boolean boolean11 = combinedRangeXYPlot0.isRangePannable();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint6 = standardChartTheme5.getItemLabelPaint();
        standardChartTheme1.setLabelLinkPaint(paint6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color8);
        java.awt.Font font10 = standardChartTheme1.getSmallFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        categoryAxis3D13.setTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = legendTitle29.getLegendItemGraphicEdge();
        boolean boolean31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge30);
        axisState26.moveCursor((double) (byte) 100, rectangleEdge30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType33 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        boolean boolean34 = rectangleEdge30.equals((java.lang.Object) gradientPaintTransformType33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        boolean boolean39 = piePlot37.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke40 = piePlot37.getBaseSectionOutlineStroke();
        boolean boolean41 = chartRenderingInfo35.equals((java.lang.Object) piePlot37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = chartRenderingInfo35.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        plotRenderingInfo42.setPlotArea(rectangle2D43);
        try {
            org.jfree.chart.axis.AxisState axisState45 = categoryAxis3D13.draw(graphics2D22, (double) 4, rectangle2D24, rectangle2D25, rectangleEdge30, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo42);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent6);
        boolean boolean8 = combinedRangeXYPlot0.canSelectByPoint();
        org.jfree.data.general.DatasetGroup datasetGroup9 = combinedRangeXYPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(datasetGroup9);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            timeSeriesCollection2.setSelected(4, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle4.getLegendItemGraphicEdge();
        axisState1.moveCursor((double) (short) 10, rectangleEdge5);
        axisState1.cursorLeft(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        try {
            org.jfree.chart.plot.XYPlot xYPlot7 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(textTitle6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        combinedRangeXYPlot12.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis15, false);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke19);
        combinedRangeXYPlot12.setDomainGridlineStroke(stroke19);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray29, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelToolTip();
        java.lang.String str39 = numberAxis37.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        double double42 = categoryPlot41.getRangeCrosshairValue();
        categoryPlot41.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot41.getRangeAxisLocation(9999);
        combinedRangeXYPlot12.setDomainAxisLocation(axisLocation46, false);
        try {
            combinedRangeXYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj2 = datasetGroup1.clone();
        java.lang.Object obj3 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        xYSeriesCollection0.validateObject();
        try {
            org.jfree.data.xy.XYSeries xYSeries11 = xYSeriesCollection0.getSeries((java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: false");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("http://www.jfree.org/jfreechart/index.html");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key http://www.jfree.org/jfreechart/index.html");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ThreadContext");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("item");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer1.getToolTipGenerator(2, 8, false);
        boolean boolean8 = xYBarRenderer1.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYBarRenderer1.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot19.getRowRenderingOrder();
        categoryPlot19.clearRangeMarkers((int) (short) 100);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sortOrder20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYSeriesCollection0.setIntervalPositionFactor((double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = legendTitle27.getLegendItemGraphicEdge();
        axisState24.moveCursor((double) (short) 10, rectangleEdge28);
        try {
            double double30 = categoryAxis3D13.getCategoryStart(4, (int) 'a', rectangle2D22, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color1 = java.awt.Color.getColor("item");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint3 = standardChartTheme1.getGridBandPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj3 = datasetGroup2.clone();
        boolean boolean4 = shapeList0.equals((java.lang.Object) datasetGroup2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        try {
            combinedRangeXYPlot0.setBackgroundImageAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean5 = xYAreaRenderer3.equals((java.lang.Object) (-1));
        xYAreaRenderer3.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        double double26 = ringPlot25.getOuterSeparatorExtension();
        java.awt.Color color27 = java.awt.Color.GREEN;
        ringPlot25.setSeparatorPaint((java.awt.Paint) color27);
        java.awt.Shape shape29 = ringPlot25.getLegendItemShape();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean33 = piePlot3D32.getSimpleLabels();
        java.awt.Color color34 = java.awt.Color.darkGray;
        piePlot3D32.setBackgroundPaint((java.awt.Paint) color34);
        piePlot3D32.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        boolean boolean43 = piePlot41.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke44 = piePlot41.getBaseSectionOutlineStroke();
        boolean boolean45 = chartRenderingInfo39.equals((java.lang.Object) piePlot41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo39.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        plotRenderingInfo46.setPlotArea(rectangle2D47);
        org.jfree.chart.plot.PiePlotState piePlotState49 = ringPlot25.initialise(graphics2D30, rectangle2D31, (org.jfree.chart.plot.PiePlot) piePlot3D32, (java.lang.Integer) 0, plotRenderingInfo46);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray54, numberArray57, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray61);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D63 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelToolTip();
        java.lang.String str67 = numberAxis65.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D63, (org.jfree.chart.axis.ValueAxis) numberAxis65, categoryItemRenderer68);
        double double70 = categoryPlot69.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis72 = categoryPlot69.getRangeAxis((int) (byte) -1);
        boolean boolean73 = categoryPlot69.isRangeMinorGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo75 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset76 = null;
        org.jfree.chart.plot.PiePlot piePlot77 = new org.jfree.chart.plot.PiePlot(pieDataset76);
        boolean boolean79 = piePlot77.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke80 = piePlot77.getBaseSectionOutlineStroke();
        boolean boolean81 = chartRenderingInfo75.equals((java.lang.Object) piePlot77);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = chartRenderingInfo75.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        plotRenderingInfo82.setPlotArea(rectangle2D83);
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor86 = null;
        java.awt.geom.Point2D point2D87 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D85, rectangleAnchor86);
        categoryPlot69.panDomainAxes((double) (-1.0f), plotRenderingInfo82, point2D87);
        try {
            categoryPlot19.zoomRangeAxes(0.0d, (double) (-1L), plotRenderingInfo46, point2D87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.05).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo82);
        org.junit.Assert.assertNotNull(point2D87);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot19.getRangeAxisForDataset((int) (short) 100);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(valueAxis26);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getEndX((int) '4', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke8 = ringPlot7.getSeparatorStroke();
        combinedRangeXYPlot0.setRangeZeroBaselineStroke(stroke8);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        boolean boolean5 = textTitle0.equals((java.lang.Object) numberAxis2);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle9.getLegendItemGraphicEdge();
        try {
            double double11 = numberAxis2.valueToJava2D(0.0d, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator11, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = xYAreaRenderer3.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = null;
        try {
            xYSeriesCollection14.setGroup(datasetGroup16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        boolean boolean8 = xYAreaRenderer3.isSeriesVisibleInLegend(0);
        java.awt.Paint paint10 = xYAreaRenderer3.getLegendTextPaint((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer3.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.String str15 = standardXYURLGenerator9.generateURL((org.jfree.data.xy.XYDataset) xYSeriesCollection12, 6, 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "?series=6&amp;item=5" + "'", str15.equals("?series=6&amp;item=5"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = legendItem26.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ', dateTickUnitType2, 0, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis3D0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D3.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.HOUR" + "'", str1.equals("DateTickUnitType.HOUR"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        java.awt.Color color2 = java.awt.Color.darkGray;
        piePlot3D0.setBackgroundPaint((java.awt.Paint) color2);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean7 = combinedRangeXYPlot6.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection11 = combinedRangeXYPlot6.getDomainMarkers((int) (short) 0, layer10);
        combinedRangeXYPlot6.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke14 = combinedRangeXYPlot6.getDomainZeroBaselineStroke();
        boolean boolean15 = piePlot3D0.equals((java.lang.Object) stroke14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        piePlot3D0.setDataset(pieDataset16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean5 = combinedRangeXYPlot4.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedRangeXYPlot4.getFixedRangeAxisSpace();
        combinedRangeXYPlot4.setWeight(0);
        java.util.List list9 = combinedRangeXYPlot4.getSubplots();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, list9, true);
        xYSeriesCollection3.validateObject();
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) xYSeriesCollection3, (int) (short) 10, (int) '4', "", "ThreadContext");
        try {
            org.jfree.data.xy.XYSeries xYSeries19 = xYSeriesCollection3.getSeries((java.lang.Comparable) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: -2208960000000");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.addOrUpdate((double) (byte) -1, 1.0d);
        try {
            java.lang.Number number7 = xYSeries2.getY((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint14 = null;
        xYAreaRenderer3.setSeriesOutlinePaint((int) ' ', paint14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, 10.0f, (float) (byte) 0, 4.0d, (float) 'a', 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(uRL5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        boolean boolean4 = numberAxis1.isAutoRange();
        double double5 = numberAxis1.getLabelAngle();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYAreaRenderer9.setSeriesToolTipGenerator(0, xYToolTipGenerator13, false);
        java.util.Collection collection16 = xYAreaRenderer9.getAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator18, xYURLGenerator19);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer20.setLegendItemURLGenerator(xYSeriesLabelGenerator21);
        xYAreaRenderer20.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer20.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.data.Range range31 = xYAreaRenderer20.findRangeBounds(xYDataset30);
        java.awt.Shape shape35 = xYAreaRenderer20.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = legendTitle39.getLegendItemGraphicEdge();
        legendTitle37.setPosition(rectangleEdge40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double43 = rectangleInsets42.getTop();
        legendTitle37.setPadding(rectangleInsets42);
        org.jfree.chart.entity.TitleEntity titleEntity46 = new org.jfree.chart.entity.TitleEntity(shape35, (org.jfree.chart.title.Title) legendTitle37, "");
        xYAreaRenderer9.setLegendArea(shape35);
        numberAxis1.setDownArrow(shape35);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43 == 3.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getLabelGap();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke6 = xYAreaRenderer3.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer3.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYAreaRenderer3.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("?series=0&amp;item=10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        boolean boolean8 = xYAreaRenderer3.isSeriesVisibleInLegend(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        combinedRangeXYPlot9.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis12, false);
        xYAreaRenderer3.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke6 = xYAreaRenderer3.getSeriesOutlineStroke((int) 'a');
        java.awt.Color color7 = java.awt.Color.gray;
        xYAreaRenderer3.setBaseItemLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        int int63 = categoryPlot19.getDatasetCount();
        java.util.List list64 = categoryPlot19.getAnnotations();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(list64);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        xYBarRenderer1.setShadowXOffset((double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis10 = combinedRangeXYPlot0.getRangeAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getSimpleLabels();
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D7.setBackgroundPaint((java.awt.Paint) color9);
        piePlot3D7.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean18 = piePlot16.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke19 = piePlot16.getBaseSectionOutlineStroke();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) piePlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        plotRenderingInfo21.setPlotArea(rectangle2D22);
        org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 0, plotRenderingInfo21);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = plotRenderingInfo21.getSubplotInfo((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState24);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYAreaRenderer3.setBasePaint((java.awt.Paint) color13);
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list20 = axisCollection19.getAxesAtTop();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17, list20, range21, false);
        org.jfree.data.Range range24 = xYAreaRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        try {
            java.lang.Comparable comparable26 = timeSeriesCollection17.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke3);
        java.lang.Object obj5 = rendererChangeEvent4.getRenderer();
        waferMapPlot2.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.jfree.data.Range range3 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange0, 30.0d);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 1);
        boolean boolean10 = piePlot2.equals((java.lang.Object) 1);
        java.awt.Paint paint12 = piePlot2.getSectionPaint((java.lang.Comparable) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot2.getSimpleLabelOffset();
        piePlot2.setCircular(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace27, true);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getStart();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        java.util.Date date4 = segmentedTimeline0.getDate((long) (short) -1);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getOuterSeparatorExtension();
        java.awt.Color color4 = java.awt.Color.GREEN;
        ringPlot2.setSeparatorPaint((java.awt.Paint) color4);
        java.awt.Shape shape6 = ringPlot2.getLegendItemShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray14, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        java.lang.String str24 = numberAxis22.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        java.awt.Font font28 = categoryAxis3D20.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D20, "");
        try {
            java.awt.GradientPaint gradientPaint31 = standardGradientPaintTransformer0.transform(gradientPaint1, shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeriesCollection6.getSeries((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        java.awt.Paint paint10 = xYAreaRenderer3.getItemPaint((int) (byte) 1, (int) (short) 0, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list5 = axisCollection4.getAxesAtTop();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list5, range6, false);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) number9, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Paint paint5 = null;
        try {
            numberAxis1.setTickLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = itemLabelAnchor0.equals((java.lang.Object) numberAxis16);
        boolean boolean22 = numberAxis16.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) ' ');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        jFreeChart3.fireChartChanged();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.brighter();
        standardChartTheme1.setWallPaint((java.awt.Paint) color3);
        java.awt.Font font6 = standardChartTheme1.getExtraLargeFont();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            int[] intArray5 = timeSeriesCollection2.getSurroundingItems(64, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (64).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        xYAreaRenderer3.setSeriesShape((int) '#', shape18, false);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        boolean boolean24 = piePlot22.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke25 = piePlot22.getBaseSectionOutlineStroke();
        java.awt.Paint paint27 = piePlot22.getSectionOutlinePaint((java.lang.Comparable) (byte) 1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator28 = piePlot22.getURLGenerator();
        boolean boolean29 = xYAreaRenderer3.hasListener((java.util.EventListener) piePlot22);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(pieURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection1, (java.lang.Comparable) 3.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean9 = piePlot7.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        boolean boolean11 = chartRenderingInfo5.equals((java.lang.Object) piePlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo5.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection13 = chartRenderingInfo5.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo5.getChartArea();
        try {
            legendItemBlockContainer3.draw(graphics2D4, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertNotNull(entityCollection13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        legendTitle20.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getTop();
        legendTitle20.setPadding(rectangleInsets25);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) legendTitle20, "");
        org.jfree.chart.title.Title title30 = titleEntity29.getTitle();
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        titleEntity29.setArea(shape33);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(title30);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass2 = serialDate1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        boolean boolean4 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItem26.equals(obj27);
        org.jfree.data.general.Dataset dataset29 = legendItem26.getDataset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(dataset29);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        int int21 = categoryPlot19.getRangeAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            categoryPlot19.addAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean8 = piePlot6.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke9 = piePlot6.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        double double11 = ringPlot10.getOuterSeparatorExtension();
        java.awt.Color color12 = java.awt.Color.GREEN;
        ringPlot10.setSeparatorPaint((java.awt.Paint) color12);
        java.awt.Shape shape14 = ringPlot10.getLegendItemShape();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean18 = piePlot3D17.getSimpleLabels();
        java.awt.Color color19 = java.awt.Color.darkGray;
        piePlot3D17.setBackgroundPaint((java.awt.Paint) color19);
        piePlot3D17.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        boolean boolean28 = piePlot26.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke29 = piePlot26.getBaseSectionOutlineStroke();
        boolean boolean30 = chartRenderingInfo24.equals((java.lang.Object) piePlot26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo24.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        plotRenderingInfo31.setPlotArea(rectangle2D32);
        org.jfree.chart.plot.PiePlotState piePlotState34 = ringPlot10.initialise(graphics2D15, rectangle2D16, (org.jfree.chart.plot.PiePlot) piePlot3D17, (java.lang.Integer) 0, plotRenderingInfo31);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = ringPlot10.getInsets();
        java.awt.Stroke stroke36 = ringPlot10.getSeparatorStroke();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_CYAN;
        ringPlot10.setBackgroundPaint((java.awt.Paint) color37);
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem(attributedString0, "VerticalAlignment.BOTTOM", "http://www.jfree.org/jfreechart/index.html", "DateTickUnitType.HOUR", shape4, stroke9, (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        double double9 = ringPlot8.getOuterSeparatorExtension();
        java.awt.Color color10 = java.awt.Color.GREEN;
        ringPlot8.setSeparatorPaint((java.awt.Paint) color10);
        java.awt.Shape shape12 = ringPlot8.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme14 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint15 = standardChartTheme14.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        boolean boolean19 = piePlot17.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot17.axisChanged(axisChangeEvent20);
        boolean boolean22 = piePlot17.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot17.setLabelOutlineStroke(stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        intervalMarker27.setOutlinePaint((java.awt.Paint) color28);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("item", "item", "", "", shape12, paint15, stroke23, (java.awt.Paint) color28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 0, 0.0d, (double) 255, paint15);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemPaint((int) (short) 0, 10, false);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean17 = piePlot15.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        piePlot15.axisChanged(axisChangeEvent18);
        boolean boolean20 = piePlot15.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot15.setLabelOutlineStroke(stroke21);
        xYAreaRenderer3.setBaseStroke(stroke21, false);
        boolean boolean25 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelToolTip();
        combinedRangeXYPlot27.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis30, false);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke34);
        combinedRangeXYPlot27.setDomainGridlineStroke(stroke34);
        java.awt.Paint paint37 = combinedRangeXYPlot27.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke41 = numberAxis40.getAxisLineStroke();
        combinedRangeXYPlot27.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.awt.Stroke stroke43 = combinedRangeXYPlot27.getRangeMinorGridlineStroke();
        xYAreaRenderer3.setSeriesStroke((int) (byte) 100, stroke43, false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke14 = numberAxis13.getAxisLineStroke();
        combinedRangeXYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelToolTip();
        combinedRangeXYPlot16.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis19, false);
        combinedRangeXYPlot16.clearDomainAxes();
        java.awt.Stroke stroke24 = combinedRangeXYPlot16.getRangeZeroBaselineStroke();
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke24);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        double double3 = legendTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            legendTitle1.setItemLabelPadding(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean9 = piePlot7.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        intervalMarker5.setStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d, (java.awt.Paint) color2, stroke10, (java.awt.Paint) color12, stroke13, (float) (short) 0);
        double double16 = intervalMarker15.getEndValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemPaint((int) (short) 0, 10, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        try {
            xYAreaRenderer3.setLegendItemLabelGenerator(xYSeriesLabelGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        combinedRangeXYPlot0.setWeight(0);
        java.awt.Image image5 = combinedRangeXYPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        org.jfree.chart.block.Block block4 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelToolTip();
        java.lang.String str9 = numberAxis7.getLabelToolTip();
        boolean boolean10 = textTitle5.equals((java.lang.Object) numberAxis7);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean12 = textTitle5.equals((java.lang.Object) itemLabelAnchor11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        boolean boolean19 = piePlot17.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke20 = piePlot17.getBaseSectionOutlineStroke();
        boolean boolean21 = chartRenderingInfo15.equals((java.lang.Object) piePlot17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = chartRenderingInfo15.getPlotInfo();
        java.lang.Object obj23 = textTitle5.draw(graphics2D13, rectangle2D14, (java.lang.Object) plotRenderingInfo22);
        blockContainer3.add(block4, obj23);
        java.lang.Object obj25 = blockContainer3.clone();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean31 = piePlot29.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke32 = piePlot29.getBaseSectionOutlineStroke();
        boolean boolean33 = chartRenderingInfo27.equals((java.lang.Object) piePlot29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = chartRenderingInfo27.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection35 = chartRenderingInfo27.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo27.getChartArea();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        double double38 = ringPlot37.getOuterSeparatorExtension();
        java.awt.Color color39 = java.awt.Color.GREEN;
        ringPlot37.setSeparatorPaint((java.awt.Paint) color39);
        java.awt.Shape shape41 = ringPlot37.getLegendItemShape();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean45 = piePlot3D44.getSimpleLabels();
        java.awt.Color color46 = java.awt.Color.darkGray;
        piePlot3D44.setBackgroundPaint((java.awt.Paint) color46);
        piePlot3D44.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        boolean boolean55 = piePlot53.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke56 = piePlot53.getBaseSectionOutlineStroke();
        boolean boolean57 = chartRenderingInfo51.equals((java.lang.Object) piePlot53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = chartRenderingInfo51.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        plotRenderingInfo58.setPlotArea(rectangle2D59);
        org.jfree.chart.plot.PiePlotState piePlotState61 = ringPlot37.initialise(graphics2D42, rectangle2D43, (org.jfree.chart.plot.PiePlot) piePlot3D44, (java.lang.Integer) 0, plotRenderingInfo58);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = ringPlot37.getInsets();
        java.awt.Stroke stroke63 = ringPlot37.getSeparatorStroke();
        try {
            java.lang.Object obj64 = blockContainer3.draw(graphics2D26, rectangle2D36, (java.lang.Object) stroke63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo34);
        org.junit.Assert.assertNotNull(entityCollection35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo58);
        org.junit.Assert.assertNotNull(piePlotState61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.Range range19 = xYBarRenderer12.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        xYItemRendererState10.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection17);
        try {
            java.lang.Number number23 = timeSeriesCollection17.getEndY((int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        java.awt.Paint paint13 = xYAreaRenderer3.getItemFillPaint(2, 2, true);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = rendererChangeEvent15.getType();
        xYAreaRenderer3.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        rendererChangeEvent15.setType(chartChangeEventType18);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection1, (java.lang.Comparable) 3.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean9 = piePlot7.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        boolean boolean11 = chartRenderingInfo5.equals((java.lang.Object) piePlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo5.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection13 = chartRenderingInfo5.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo5.getChartArea();
        java.lang.Object obj15 = null;
        try {
            java.lang.Object obj16 = legendItemBlockContainer3.draw(graphics2D4, rectangle2D14, obj15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertNotNull(entityCollection13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxis((int) (byte) -1);
        categoryPlot19.clearDomainAxes();
        categoryPlot19.setCrosshairDatasetIndex(0, false);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 0L;
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Stroke stroke3 = null;
        strokeList0.setStroke((int) 'a', stroke3);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItem26.equals(obj27);
        legendItem26.setToolTipText("ThreadContext");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot1.markerChanged(markerChangeEvent3);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Color color1 = java.awt.Color.getColor("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj5 = numberAxis1.clone();
        numberAxis1.setLabelToolTip("");
        int int8 = numberAxis1.getMinorTickCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        long long3 = segmentedTimeline0.getSegmentsGroupSize();
        java.util.List list4 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate((long) 100);
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray12, numberArray15, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str24 = numberAxis23.getLabelToolTip();
        java.lang.String str25 = numberAxis23.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        categoryPlot27.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline31 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean32 = segmentedTimeline31.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean34 = segmentedTimeline33.getAdjustForDaylightSaving();
        long long35 = segmentedTimeline33.getSegmentsGroupSize();
        java.util.Date date37 = segmentedTimeline33.getDate((long) (short) -1);
        long long38 = segmentedTimeline31.toTimelineValue(date37);
        categoryPlot27.setDomainCrosshairColumnKey((java.lang.Comparable) date37, false);
        try {
            boolean boolean41 = segmentedTimeline0.containsDomainRange(date7, date37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (-1) < domainValueStart (100)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 644288399999L + "'", long38 == 644288399999L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        java.lang.String str18 = numberAxis16.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        boolean boolean21 = itemLabelAnchor0.equals((java.lang.Object) numberAxis16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis16.getTickLabelInsets();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("item");
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        double double9 = intervalMarker2.getStartValue();
        java.awt.Font font10 = null;
        try {
            intervalMarker2.setLabelFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        java.lang.String str22 = numberAxis20.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.awt.Font font26 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D18, "");
        java.awt.Font font30 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) 4);
        java.lang.String str32 = categoryAxis3D18.getCategoryLabelToolTip((java.lang.Comparable) 2.0d);
        categoryAxis3D18.removeCategoryLabelToolTip((java.lang.Comparable) "hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean5 = piePlot3.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        boolean boolean7 = chartRenderingInfo1.equals((java.lang.Object) piePlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection9 = chartRenderingInfo1.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo1.getChartArea();
        try {
            boolean boolean11 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo8);
        org.junit.Assert.assertNotNull(entityCollection9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean11 = piePlot9.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke12 = piePlot9.getBaseSectionOutlineStroke();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) piePlot9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection15 = chartRenderingInfo7.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = combinedRangeXYPlot17.getDomainAxisEdge(6);
        try {
            java.util.List list20 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D16, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(entityCollection15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        double double7 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        categoryPlot19.setRangeCrosshairValue((double) (byte) 10, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent66 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent66);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator5, xYURLGenerator6);
        boolean boolean8 = xYAreaRenderer7.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke10 = xYAreaRenderer7.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer7.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer7.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer1.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition14.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        intervalMarker3.setOutlinePaint((java.awt.Paint) color4);
        boolean boolean6 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), 30.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 1560668399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color4 = java.awt.Color.WHITE;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart3.getTitle();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(textTitle6);
        org.junit.Assert.assertNull(textTitle7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        boolean boolean2 = centerArrangement0.equals((java.lang.Object) dateFormatSymbols1);
        java.lang.Object obj3 = null;
        boolean boolean4 = centerArrangement0.equals(obj3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        double double8 = legendTitle6.getContentYOffset();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelToolTip();
        java.lang.String str26 = numberAxis24.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot28.getRowRenderingOrder();
        org.jfree.chart.StandardChartTheme standardChartTheme31 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint32 = standardChartTheme31.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator34 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator34, xYURLGenerator35);
        boolean boolean37 = xYAreaRenderer36.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke39 = xYAreaRenderer36.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        double double46 = ringPlot45.getOuterSeparatorExtension();
        java.awt.Color color47 = java.awt.Color.GREEN;
        ringPlot45.setSeparatorPaint((java.awt.Paint) color47);
        java.awt.Shape shape49 = ringPlot45.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme51 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint52 = standardChartTheme51.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        boolean boolean56 = piePlot54.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent57 = null;
        piePlot54.axisChanged(axisChangeEvent57);
        boolean boolean59 = piePlot54.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot54.setLabelOutlineStroke(stroke60);
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color65 = java.awt.Color.LIGHT_GRAY;
        intervalMarker64.setOutlinePaint((java.awt.Paint) color65);
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("item", "item", "", "", shape49, paint52, stroke60, (java.awt.Paint) color65);
        xYAreaRenderer36.setSeriesItemLabelPaint(1, paint52);
        standardChartTheme31.setThermometerPaint(paint52);
        categoryPlot28.setRangeCrosshairPaint(paint52);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) paint52);
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.2d + "'", double46 == 0.2d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (short) 100, (java.lang.Comparable) "item", "VerticalAlignment.BOTTOM", "item");
        int int12 = pieSectionEntity11.getSectionIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean3 = piePlot1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot1.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelOutlineStroke(stroke7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange2, lengthConstraintType4, (-1.0d), range6, lengthConstraintType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getOuterSeparatorExtension();
        java.awt.Color color8 = java.awt.Color.GREEN;
        ringPlot6.setSeparatorPaint((java.awt.Paint) color8);
        java.awt.Shape shape10 = ringPlot6.getLegendItemShape();
        java.awt.Font font11 = ringPlot6.getLabelFont();
        xYAreaRenderer3.setBaseItemLabelFont(font11, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator15 = null;
        try {
            xYAreaRenderer3.setSeriesItemLabelGenerator((int) (byte) -1, xYItemLabelGenerator15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        boolean boolean4 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(uRL5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.clearSeriesPaints(true);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesShape();
        boolean boolean8 = xYAreaRenderer3.isSeriesVisibleInLegend(0);
        java.awt.Stroke stroke10 = xYAreaRenderer3.lookupSeriesStroke((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str12 = numberAxis11.getLabelToolTip();
        java.lang.String str13 = numberAxis11.getLabelToolTip();
        boolean boolean14 = textTitle9.equals((java.lang.Object) numberAxis11);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean16 = textTitle9.equals((java.lang.Object) itemLabelAnchor15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean23 = piePlot21.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke24 = piePlot21.getBaseSectionOutlineStroke();
        boolean boolean25 = chartRenderingInfo19.equals((java.lang.Object) piePlot21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo19.getPlotInfo();
        java.lang.Object obj27 = textTitle9.draw(graphics2D17, rectangle2D18, (java.lang.Object) plotRenderingInfo26);
        combinedRangeXYPlot0.handleClick((int) (short) 100, 2, plotRenderingInfo26);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray14, numberArray17, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str26 = numberAxis25.getLabelToolTip();
        java.lang.String str27 = numberAxis25.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        double double30 = categoryPlot29.getRangeCrosshairValue();
        categoryPlot29.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot29.getRangeAxisLocation(9999);
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation34, false);
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot19.axisChanged(axisChangeEvent23);
        categoryPlot19.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxis(9999);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer1.getToolTipGenerator(2, 8, false);
        boolean boolean8 = xYBarRenderer1.getUseYInterval();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.Object obj2 = numberAxis1.clone();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double10 = timeSeriesCollection6.getDomainLowerBound(true);
        double double12 = timeSeriesCollection6.getDomainUpperBound(true);
        try {
            timeSeriesCollection6.setSelected(0, (int) '4', true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        java.awt.Font font4 = standardChartTheme1.getLargeFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        try {
            java.lang.Number number4 = xYSeries2.getX((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke6 = xYAreaRenderer3.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        double double13 = ringPlot12.getOuterSeparatorExtension();
        java.awt.Color color14 = java.awt.Color.GREEN;
        ringPlot12.setSeparatorPaint((java.awt.Paint) color14);
        java.awt.Shape shape16 = ringPlot12.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme18 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint19 = standardChartTheme18.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean23 = piePlot21.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot21.axisChanged(axisChangeEvent24);
        boolean boolean26 = piePlot21.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot21.setLabelOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        intervalMarker31.setOutlinePaint((java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("item", "item", "", "", shape16, paint19, stroke27, (java.awt.Paint) color32);
        xYAreaRenderer3.setSeriesItemLabelPaint(1, paint19);
        java.lang.Boolean boolean37 = xYAreaRenderer3.getSeriesItemLabelsVisible(255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(boolean37);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        java.awt.Font font19 = xYAreaRenderer3.getLegendTextFont((int) '#');
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        boolean boolean21 = xYAreaRenderer3.removeAnnotation(xYAnnotation20);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '4', 0, (int) (byte) 10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        try {
            standardPieSectionLabelGenerator0.setAttributedLabel((int) (byte) -1, attributedString2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator4.getAttributedLabel(10);
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator4.setAttributedLabel(2, attributedString9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(attributedString7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean12 = combinedRangeXYPlot11.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = combinedRangeXYPlot11.getFixedRangeAxisSpace();
        combinedRangeXYPlot11.setWeight(0);
        java.util.List list16 = combinedRangeXYPlot11.getSubplots();
        combinedRangeXYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list16);
        combinedRangeXYPlot0.setRangePannable(false);
        combinedRangeXYPlot0.clearRangeMarkers((int) '4');
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean6 = piePlot3D5.getSimpleLabels();
        java.awt.Color color7 = java.awt.Color.darkGray;
        piePlot3D5.setBackgroundPaint((java.awt.Paint) color7);
        piePlot3D5.setIgnoreZeroValues(false);
        piePlot3D5.setIgnoreNullValues(true);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D5);
        piePlot3D5.setCircular(false, true);
        double double17 = piePlot3D5.getLabelGap();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot19.axisChanged(axisChangeEvent23);
        java.awt.Stroke stroke25 = categoryPlot19.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { long1, "AxisLocation.BOTTOM_OR_RIGHT" };
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] {};
        double[] doubleArray7 = new double[] { 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 0.0f, ' ' };
        double[] doubleArray19 = new double[] { 0.0f, ' ' };
        double[] doubleArray22 = new double[] { 0.0f, ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19, doubleArray22 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray4, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle1.getItemContainer();
        java.lang.Object obj4 = legendTitle1.clone();
        java.lang.Object obj5 = legendTitle1.clone();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis((int) (byte) -1);
        boolean boolean23 = categoryPlot19.isRangeMinorGridlinesVisible();
        boolean boolean24 = categoryPlot19.isDomainPannable();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier63 = categoryPlot19.getDrawingSupplier();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation64 = null;
        try {
            boolean boolean66 = categoryPlot19.removeAnnotation(categoryAnnotation64, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(drawingSupplier63);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYAreaRenderer3.getToolTipGenerator((int) (byte) 10, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator16, xYURLGenerator17);
        boolean boolean19 = xYAreaRenderer18.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke21 = xYAreaRenderer18.getSeriesOutlineStroke((int) 'a');
        xYAreaRenderer18.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        xYBarRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition25);
        xYAreaRenderer3.setSeriesPositiveItemLabelPosition((int) (byte) 1, itemLabelPosition25, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = combinedRangeXYPlot29.getDomainAxisForDataset((int) (byte) 0);
        boolean boolean32 = xYAreaRenderer3.hasListener((java.util.EventListener) combinedRangeXYPlot29);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        boolean boolean42 = piePlot40.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke43 = piePlot40.getBaseSectionOutlineStroke();
        boolean boolean44 = chartRenderingInfo38.equals((java.lang.Object) piePlot40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo38.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection46 = chartRenderingInfo38.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D47 = chartRenderingInfo38.getChartArea();
        boolean boolean48 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 3, (double) 4, rectangle2D47);
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(90.0d, (double) (short) 10, rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        org.jfree.chart.plot.PlotState plotState53 = null;
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        double double55 = ringPlot54.getOuterSeparatorExtension();
        java.awt.Color color56 = java.awt.Color.GREEN;
        ringPlot54.setSeparatorPaint((java.awt.Paint) color56);
        java.awt.Shape shape58 = ringPlot54.getLegendItemShape();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D61 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean62 = piePlot3D61.getSimpleLabels();
        java.awt.Color color63 = java.awt.Color.darkGray;
        piePlot3D61.setBackgroundPaint((java.awt.Paint) color63);
        piePlot3D61.setDarkerSides(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        boolean boolean72 = piePlot70.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke73 = piePlot70.getBaseSectionOutlineStroke();
        boolean boolean74 = chartRenderingInfo68.equals((java.lang.Object) piePlot70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = chartRenderingInfo68.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        plotRenderingInfo75.setPlotArea(rectangle2D76);
        org.jfree.chart.plot.PiePlotState piePlotState78 = ringPlot54.initialise(graphics2D59, rectangle2D60, (org.jfree.chart.plot.PiePlot) piePlot3D61, (java.lang.Integer) 0, plotRenderingInfo75);
        try {
            combinedRangeXYPlot29.draw(graphics2D33, rectangle2D47, point2D52, plotState53, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
        org.junit.Assert.assertNotNull(entityCollection46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.2d + "'", double55 == 0.2d);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo75);
        org.junit.Assert.assertNotNull(piePlotState78);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer4.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        xYAreaRenderer4.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer4.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.data.Range range15 = xYAreaRenderer4.findRangeBounds(xYDataset14);
        java.awt.Shape shape19 = xYAreaRenderer4.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        legendTitle21.setPosition(rectangleEdge24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double27 = rectangleInsets26.getTop();
        legendTitle21.setPadding(rectangleInsets26);
        org.jfree.chart.entity.TitleEntity titleEntity30 = new org.jfree.chart.entity.TitleEntity(shape19, (org.jfree.chart.title.Title) legendTitle21, "");
        java.awt.Paint paint31 = legendTitle21.getItemPaint();
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = legendTitle35.getLegendItemGraphicEdge();
        legendTitle33.setPosition(rectangleEdge36);
        double double38 = legendTitle33.getContentXOffset();
        double double39 = legendTitle33.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) legendTitle33);
        legendTitle33.setWidth((double) 1L);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 3, (java.lang.Number) 1L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = size2D0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        try {
            java.lang.String str4 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        numberAxis1.setMinorTickMarksVisible(false);
        java.lang.Object obj7 = numberAxis1.clone();
        numberAxis1.setMinorTickCount((int) (byte) 1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate16.setDescription("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate16);
        try {
            org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset12, (java.lang.Comparable) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 30.0d + "'", number13.equals(30.0d));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.clearDomainAxes();
        java.awt.Color color8 = java.awt.Color.ORANGE;
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color8);
        java.lang.Object obj10 = combinedRangeXYPlot0.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        intervalMarker14.setOutlinePaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean19 = combinedRangeXYPlot0.removeRangeMarker(100, (org.jfree.chart.plot.Marker) intervalMarker14, layer17, false);
        int int20 = combinedRangeXYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        standardChartTheme1.setLargeFont(font2);
        java.awt.Paint paint4 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme1.setAxisLabelPaint(paint5);
        java.awt.Paint paint7 = standardChartTheme1.getTitlePaint();
        java.awt.Paint paint8 = standardChartTheme1.getPlotOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double10 = rectangleInsets9.getTop();
        standardChartTheme1.setAxisOffset(rectangleInsets9);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        double double6 = rectangleInsets3.trimHeight(0.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("VerticalAlignment.BOTTOM");
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot19.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        combinedRangeXYPlot25.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke32);
        combinedRangeXYPlot25.setDomainGridlineStroke(stroke32);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray39, numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        java.lang.String str52 = numberAxis50.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer53);
        double double55 = categoryPlot54.getRangeCrosshairValue();
        categoryPlot54.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot54.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation(axisLocation59, false);
        categoryPlot19.setRangeAxisLocation(axisLocation59);
        org.jfree.chart.StandardChartTheme standardChartTheme64 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint65 = standardChartTheme64.getItemLabelPaint();
        java.awt.Color color66 = java.awt.Color.WHITE;
        java.awt.Color color67 = color66.brighter();
        standardChartTheme64.setWallPaint((java.awt.Paint) color66);
        java.awt.Paint paint69 = standardChartTheme64.getTitlePaint();
        boolean boolean70 = axisLocation59.equals((java.lang.Object) standardChartTheme64);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setName("");
        projectInfo0.setCopyright("item");
        projectInfo0.setLicenceName("Following");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        ringPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Image image7 = ringPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ThreadContext");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("Following");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Following");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.2d, false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.addOrUpdate((double) (byte) -1, 1.0d);
        java.lang.Comparable comparable6 = xYSeries2.getKey();
        xYSeries2.clear();
        org.junit.Assert.assertNull(xYDataItem5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.2d + "'", comparable6.equals(0.2d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        java.awt.Font font19 = xYAreaRenderer3.getLegendTextFont((int) '#');
        java.lang.Boolean boolean21 = xYAreaRenderer3.getSeriesItemLabelsVisible(1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer22 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer3.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer22);
        boolean boolean24 = xYAreaRenderer3.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21.equals(false));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalPositionFactor();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray6, numberArray9, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelToolTip();
        java.lang.String str19 = numberAxis17.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        double double22 = categoryPlot21.getRangeCrosshairValue();
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot21.getRangeAxisForDataset(0);
        boolean boolean27 = categoryPlot21.getDrawSharedDomainAxis();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot21);
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray33, numberArray36, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray40);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelToolTip();
        java.lang.String str46 = numberAxis44.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer47);
        double double49 = categoryPlot48.getRangeCrosshairValue();
        categoryPlot48.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot48.getRangeAxisForDataset(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str58 = numberAxis57.getLabelToolTip();
        combinedRangeXYPlot54.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis57, false);
        java.awt.Stroke stroke61 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke61);
        combinedRangeXYPlot54.setDomainGridlineStroke(stroke61);
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray68, numberArray71, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray75);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D77 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str80 = numberAxis79.getLabelToolTip();
        java.lang.String str81 = numberAxis79.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset76, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D77, (org.jfree.chart.axis.ValueAxis) numberAxis79, categoryItemRenderer82);
        double double84 = categoryPlot83.getRangeCrosshairValue();
        categoryPlot83.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation88 = categoryPlot83.getRangeAxisLocation(9999);
        combinedRangeXYPlot54.setDomainAxisLocation(axisLocation88, false);
        categoryPlot48.setRangeAxisLocation(axisLocation88);
        categoryPlot21.setRangeAxisLocation(axisLocation88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis53);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation88);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        ringPlot0.setBackgroundImageAlpha(0.0f);
        boolean boolean7 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        java.lang.String str22 = numberAxis20.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.awt.Font font26 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) "hi!");
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D18, "");
        java.awt.Font font30 = categoryAxis3D18.getTickLabelFont((java.lang.Comparable) 4);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray38, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray42);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str47 = numberAxis46.getLabelToolTip();
        java.lang.String str48 = numberAxis46.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis46, categoryItemRenderer49);
        double double51 = categoryPlot50.getRangeCrosshairValue();
        categoryPlot50.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot50.getRangeAxisForDataset(0);
        boolean boolean56 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor57 = categoryPlot50.getDomainGridlinePosition();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = legendTitle62.getLegendItemGraphicEdge();
        boolean boolean64 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge63);
        try {
            double double65 = categoryAxis3D18.getCategoryJava2DCoordinate(categoryAnchor57, 2, (int) ' ', rectangle2D60, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(categoryAnchor57);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            java.lang.Number number5 = timeSeriesCollection2.getEndX(6, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalPositionFactor();
        try {
            int int3 = xYSeriesCollection0.getItemCount(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (org.jfree.data.Range) dateRange1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        double double4 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean6 = piePlot3D5.getSimpleLabels();
        java.awt.Color color7 = java.awt.Color.darkGray;
        piePlot3D5.setBackgroundPaint((java.awt.Paint) color7);
        piePlot3D5.setIgnoreZeroValues(false);
        piePlot3D5.setIgnoreNullValues(true);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D5);
        numberAxis1.setTickLabelsVisible(false);
        boolean boolean16 = numberAxis1.isVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        java.util.Calendar calendar4 = null;
        try {
            year2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean4 = piePlot2.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean13 = xYBarRenderer12.isDrawBarOutline();
        java.lang.Object obj14 = xYBarRenderer12.clone();
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15, timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.Range range19 = xYBarRenderer12.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        xYItemRendererState10.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection17);
        try {
            java.lang.Number number23 = timeSeriesCollection17.getX((int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis6.setLabelPaint(paint7);
        boolean boolean9 = numberAxis6.isAutoRange();
        java.awt.Stroke stroke10 = numberAxis6.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis12.setLabelInsets(rectangleInsets14);
        numberAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        boolean boolean21 = piePlot19.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke22 = piePlot19.getBaseSectionOutlineStroke();
        boolean boolean23 = chartRenderingInfo17.equals((java.lang.Object) piePlot19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo17.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection25 = chartRenderingInfo17.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo17.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets14.createInsetRectangle(rectangle2D26, true, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint32 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis31.setLabelPaint(paint32);
        boolean boolean34 = numberAxis31.isAutoRange();
        java.awt.Stroke stroke35 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis37.setLabelInsets(rectangleInsets39);
        numberAxis31.setTickLabelInsets(rectangleInsets39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        boolean boolean46 = piePlot44.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke47 = piePlot44.getBaseSectionOutlineStroke();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) piePlot44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection50 = chartRenderingInfo42.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo42.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets39.createInsetRectangle(rectangle2D51, true, true);
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle56.getLegendItemGraphicEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            org.jfree.chart.axis.AxisState axisState59 = categoryAxis3D0.draw(graphics2D3, (double) (short) 100, rectangle2D29, rectangle2D54, rectangleEdge57, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertNotNull(entityCollection25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(entityCollection50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        java.lang.String str15 = numberAxis13.getLabelToolTip();
        boolean boolean16 = textTitle11.equals((java.lang.Object) numberAxis13);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean18 = textTitle11.equals((java.lang.Object) itemLabelAnchor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean25 = piePlot23.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke26 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) piePlot23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        java.lang.Object obj29 = textTitle11.draw(graphics2D19, rectangle2D20, (java.lang.Object) plotRenderingInfo28);
        combinedRangeXYPlot0.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo28);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint34 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis33.setLabelPaint(paint34);
        boolean boolean36 = numberAxis33.isAutoRange();
        java.awt.Stroke stroke37 = numberAxis33.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis39.setLabelInsets(rectangleInsets41);
        numberAxis33.setTickLabelInsets(rectangleInsets41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        boolean boolean48 = piePlot46.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke49 = piePlot46.getBaseSectionOutlineStroke();
        boolean boolean50 = chartRenderingInfo44.equals((java.lang.Object) piePlot46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection52 = chartRenderingInfo44.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo44.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets41.createInsetRectangle(rectangle2D53, true, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str61 = numberAxis60.getLabelToolTip();
        combinedRangeXYPlot57.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis60, false);
        java.awt.Stroke stroke64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke64);
        combinedRangeXYPlot57.setDomainGridlineStroke(stroke64);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = null;
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor68);
        combinedRangeXYPlot57.setQuadrantOrigin(point2D69);
        org.jfree.chart.plot.PlotState plotState71 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset73 = null;
        org.jfree.chart.plot.PiePlot piePlot74 = new org.jfree.chart.plot.PiePlot(pieDataset73);
        boolean boolean76 = piePlot74.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke77 = piePlot74.getBaseSectionOutlineStroke();
        boolean boolean78 = chartRenderingInfo72.equals((java.lang.Object) piePlot74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = chartRenderingInfo72.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        plotRenderingInfo79.setPlotArea(rectangle2D80);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState82 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo79);
        try {
            combinedRangeXYPlot0.draw(graphics2D31, rectangle2D53, point2D69, plotState71, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo51);
        org.junit.Assert.assertNotNull(entityCollection52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo79);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis28.setLabelInsets(rectangleInsets30);
        numberAxis28.setMinorTickMarksVisible(false);
        java.lang.Object obj34 = numberAxis28.clone();
        org.jfree.chart.entity.AxisEntity axisEntity35 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) numberAxis28);
        org.jfree.chart.axis.Axis axis36 = axisEntity35.getAxis();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(axis36);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        try {
            numberAxis1.setRangeWithMargins((double) 2692527886132L, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.692527886132E12) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double10 = timeSeriesCollection6.getDomainLowerBound(true);
        double double12 = timeSeriesCollection6.getDomainUpperBound(true);
        try {
            double double15 = timeSeriesCollection6.getXValue(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer8.setLegendItemURLGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getOuterSeparatorExtension();
        java.awt.Color color13 = java.awt.Color.GREEN;
        ringPlot11.setSeparatorPaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = ringPlot11.getLegendItemShape();
        java.awt.Font font16 = ringPlot11.getLabelFont();
        xYAreaRenderer8.setBaseItemLabelFont(font16, true);
        numberAxis2.setTickLabelFont(font16);
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("http://www.jfree.org/jfreechart/index.html", font16, (java.awt.Paint) color20, (float) 6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean24 = textFragment22.equals((java.lang.Object) lengthAdjustmentType23);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        xYAreaRenderer3.setSeriesShape((int) '#', shape18, false);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        xYAreaRenderer3.setSeriesPaint(6, paint22);
        boolean boolean24 = xYAreaRenderer3.getUseFillPaint();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries1.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.remove((java.lang.Number) 0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        java.lang.String str15 = numberAxis13.getLabelToolTip();
        boolean boolean16 = textTitle11.equals((java.lang.Object) numberAxis13);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean18 = textTitle11.equals((java.lang.Object) itemLabelAnchor17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean25 = piePlot23.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke26 = piePlot23.getBaseSectionOutlineStroke();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) piePlot23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        java.lang.Object obj29 = textTitle11.draw(graphics2D19, rectangle2D20, (java.lang.Object) plotRenderingInfo28);
        combinedRangeXYPlot0.drawAnnotations(graphics2D9, rectangle2D10, plotRenderingInfo28);
        boolean boolean31 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        java.awt.Paint paint32 = combinedRangeXYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator(0, xYToolTipGenerator7, false);
        java.util.Collection collection10 = xYAreaRenderer3.getAnnotations();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint14 = xYAreaRenderer3.lookupSeriesFillPaint(4);
        xYAreaRenderer3.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.plot.XYPlot xYPlot18 = xYAreaRenderer3.getPlot();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(xYPlot18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.addException((long) 255);
        long long4 = segmentedTimeline0.toMillisecond((long) (byte) 100);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208959999900L) + "'", long4 == (-2208959999900L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1, (float) (-1L));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean5 = combinedRangeXYPlot4.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedRangeXYPlot4.getFixedRangeAxisSpace();
        combinedRangeXYPlot4.setWeight(0);
        java.util.List list9 = combinedRangeXYPlot4.getSubplots();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, list9, true);
        xYSeriesCollection3.validateObject();
        org.jfree.chart.entity.XYItemEntity xYItemEntity17 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) xYSeriesCollection3, (int) (short) 10, (int) '4', "", "ThreadContext");
        int int18 = xYItemEntity17.getItem();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.String[] strArray4 = new java.lang.String[] { "item", "hi!", "" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Color color10 = java.awt.Color.WHITE;
        jFreeChart9.setBorderPaint((java.awt.Paint) color10);
        symbolAxis5.setGridBandPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator2, xYURLGenerator3);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer4.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYAreaRenderer4.setSeriesToolTipGenerator(0, xYToolTipGenerator8, false);
        java.util.Collection collection11 = xYAreaRenderer4.getAnnotations();
        xYAreaRenderer4.setItemLabelAnchorOffset((double) 86400000L);
        java.awt.Paint paint15 = xYAreaRenderer4.lookupSeriesFillPaint(4);
        xYAreaRenderer4.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        boolean boolean19 = textBlockAnchor0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer1.getToolTipGenerator(2, 8, false);
        boolean boolean8 = xYBarRenderer1.getBaseSeriesVisibleInLegend();
        xYBarRenderer1.setSeriesVisible(52, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY((double) 86400000L);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        crosshairState1.updateCrosshairPoint((double) (-2208960000000L), (double) 100.0f, 100.0d, (double) 1L, plotOrientation8);
        crosshairState1.setCrosshairY((double) 52);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedRangeXYPlot0.getAxisOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        boolean boolean16 = piePlot14.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke17 = piePlot14.getBaseSectionOutlineStroke();
        boolean boolean18 = chartRenderingInfo12.equals((java.lang.Object) piePlot14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo12.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo12.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 3, (double) 4, rectangle2D21);
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(90.0d, (double) (short) 10, rectangle2D21);
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D7, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        categoryPlot19.setWeight(500);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot19.getRowRenderingOrder();
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint23 = standardChartTheme22.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator25, xYURLGenerator26);
        boolean boolean28 = xYAreaRenderer27.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke30 = xYAreaRenderer27.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        double double37 = ringPlot36.getOuterSeparatorExtension();
        java.awt.Color color38 = java.awt.Color.GREEN;
        ringPlot36.setSeparatorPaint((java.awt.Paint) color38);
        java.awt.Shape shape40 = ringPlot36.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme42 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint43 = standardChartTheme42.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        boolean boolean47 = piePlot45.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = null;
        piePlot45.axisChanged(axisChangeEvent48);
        boolean boolean50 = piePlot45.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot45.setLabelOutlineStroke(stroke51);
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color56 = java.awt.Color.LIGHT_GRAY;
        intervalMarker55.setOutlinePaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("item", "item", "", "", shape40, paint43, stroke51, (java.awt.Paint) color56);
        xYAreaRenderer27.setSeriesItemLabelPaint(1, paint43);
        standardChartTheme22.setThermometerPaint(paint43);
        categoryPlot19.setRangeCrosshairPaint(paint43);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions63 = categoryAxis3D62.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions64 = categoryAxis3D62.getCategoryLabelPositions();
        int int65 = categoryPlot19.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D62);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(categoryLabelPositions63);
        org.junit.Assert.assertNotNull(categoryLabelPositions64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        axisState3.moveCursor((double) (byte) 100, rectangleEdge7);
        boolean boolean10 = textAnchor2.equals((java.lang.Object) rectangleEdge7);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Paint paint14 = intervalMarker13.getPaint();
        boolean boolean15 = textAnchor2.equals((java.lang.Object) intervalMarker13);
        boolean boolean16 = blockBorder0.equals((java.lang.Object) intervalMarker13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint9 = xYAreaRenderer3.getItemOutlinePaint((int) (short) 1, (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis13.setLabelPaint(paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis13.setLabelInsets(rectangleInsets16);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYAreaRenderer3.drawDomainGridLine(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis13, rectangle2D18, (double) 3);
        double double21 = numberAxis13.getUpperMargin();
        numberAxis13.zoomRange(0.025d, (double) (short) 100);
        java.lang.Object obj25 = numberAxis13.clone();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean6 = piePlot4.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke7 = piePlot4.getBaseSectionOutlineStroke();
        intervalMarker2.setStroke(stroke7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis10.setLabelPaint(paint11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis10.setLabelInsets(rectangleInsets13);
        intervalMarker2.setLabelOffset(rectangleInsets13);
        double double17 = rectangleInsets13.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.setAnchorY((double) 10L);
        java.awt.geom.Point2D point2D4 = crosshairState1.getAnchor();
        org.junit.Assert.assertNull(point2D4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        combinedRangeXYPlot0.setWeight(0);
        combinedRangeXYPlot0.clearDomainAxes();
        boolean boolean6 = combinedRangeXYPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-2208960000000L));
        boolean boolean2 = xYBarRenderer1.isDrawBarOutline();
        java.lang.Object obj3 = xYBarRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYBarRenderer1.getLegendItem(8, (int) ' ');
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = null;
        try {
            xYBarRenderer1.setBarPainter(xYBarPainter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean2 = combinedRangeXYPlot1.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setWeight(0);
        java.util.List list6 = combinedRangeXYPlot1.getSubplots();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list6, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0d);
        xYSeries11.add((java.lang.Number) 100, (java.lang.Number) 9999, false);
        xYSeriesCollection0.removeSeries(xYSeries11);
        java.lang.Comparable comparable17 = null;
        try {
            xYSeries11.setKey(comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator4);
        xYAreaRenderer3.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYAreaRenderer3.findRangeBounds(xYDataset13);
        java.awt.Shape shape18 = xYAreaRenderer3.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        java.lang.Object obj20 = null;
        boolean boolean21 = legendItemEntity19.equals(obj20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        legendItemEntity19.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection23);
        try {
            int int26 = timeSeriesCollection23.getItemCount(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        java.awt.Paint paint4 = standardChartTheme1.getErrorIndicatorPaint();
        java.awt.Paint paint5 = standardChartTheme1.getLegendBackgroundPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass3 = serialDate2.getClass();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.Class<?> wildcardClass6 = serialDate5.getClass();
        boolean boolean7 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.BOTTOM", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(classLoader9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = combinedRangeXYPlot0.getDomainMarkers((int) (short) 0, layer4);
        java.awt.Color color6 = java.awt.Color.darkGray;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace8);
        java.util.List list11 = null;
        try {
            combinedRangeXYPlot0.mapDatasetToRangeAxes((int) 'a', list11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        java.math.RoundingMode roundingMode1 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis1.setLabelInsets(rectangleInsets3);
        int int5 = numberAxis1.getMinorTickCount();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer9.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        xYAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, true);
        xYAreaRenderer9.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.data.Range range20 = xYAreaRenderer9.findRangeBounds(xYDataset19);
        java.awt.Shape shape24 = xYAreaRenderer9.getItemShape((int) (short) 1, (int) ' ', true);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle28.getLegendItemGraphicEdge();
        legendTitle26.setPosition(rectangleEdge29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double32 = rectangleInsets31.getTop();
        legendTitle26.setPadding(rectangleInsets31);
        org.jfree.chart.entity.TitleEntity titleEntity35 = new org.jfree.chart.entity.TitleEntity(shape24, (org.jfree.chart.title.Title) legendTitle26, "");
        numberAxis1.setRightArrow(shape24);
        numberAxis1.setAutoTickUnitSelection(true, false);
        numberAxis1.configure();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        try {
            org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset12, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stroke7);
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        combinedRangeXYPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot0.getLegendItems();
        boolean boolean14 = legendItemCollection12.equals((java.lang.Object) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(52);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float4 = jFreeChart3.getBackgroundImageAlpha();
        boolean boolean5 = jFreeChart3.getAntiAlias();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot6 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        combinedRangeXYPlot0.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
        boolean boolean7 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color2 = java.awt.Color.GREEN;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getLabelGap();
        double double5 = ringPlot0.getLabelGap();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        timeSeriesCollection2.removeAllSeries();
        try {
            double double7 = timeSeriesCollection2.getEndXValue(255, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        axisState0.moveCursor((double) (byte) 100, rectangleEdge4);
        axisState0.setMax(30.0d);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        boolean boolean4 = numberAxis1.isAutoRange();
        double double5 = numberAxis1.getLabelAngle();
        numberAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke2 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color6 = java.awt.Color.GREEN;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color6);
        java.awt.Shape shape8 = ringPlot4.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint11 = standardChartTheme10.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean15 = piePlot13.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot13.axisChanged(axisChangeEvent16);
        boolean boolean18 = piePlot13.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot13.setLabelOutlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        intervalMarker23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("item", "item", "", "", shape8, paint11, stroke19, (java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.CYAN;
        legendItem26.setFillPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = legendItem26.getLineStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = categoryPlot19.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint2 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint3 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        numberAxis1.setLabelPaint(paint2);
        boolean boolean4 = numberAxis1.isAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit5, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        numberFormat0.setMinimumFractionDigits((int) (short) 100);
        numberFormat0.setMinimumIntegerDigits(0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0f, 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        java.lang.String str17 = numberAxis15.getLabelToolTip();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot19.getRowRenderingOrder();
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint23 = standardChartTheme22.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) -1, xYToolTipGenerator25, xYURLGenerator26);
        boolean boolean28 = xYAreaRenderer27.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke30 = xYAreaRenderer27.getSeriesOutlineStroke((int) 'a');
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        double double37 = ringPlot36.getOuterSeparatorExtension();
        java.awt.Color color38 = java.awt.Color.GREEN;
        ringPlot36.setSeparatorPaint((java.awt.Paint) color38);
        java.awt.Shape shape40 = ringPlot36.getLegendItemShape();
        org.jfree.chart.StandardChartTheme standardChartTheme42 = new org.jfree.chart.StandardChartTheme("item");
        java.awt.Paint paint43 = standardChartTheme42.getTitlePaint();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        boolean boolean47 = piePlot45.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = null;
        piePlot45.axisChanged(axisChangeEvent48);
        boolean boolean50 = piePlot45.getAutoPopulateSectionOutlineStroke();
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot45.setLabelOutlineStroke(stroke51);
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, (double) ' ');
        java.awt.Color color56 = java.awt.Color.LIGHT_GRAY;
        intervalMarker55.setOutlinePaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("item", "item", "", "", shape40, paint43, stroke51, (java.awt.Paint) color56);
        xYAreaRenderer27.setSeriesItemLabelPaint(1, paint43);
        standardChartTheme22.setThermometerPaint(paint43);
        categoryPlot19.setRangeCrosshairPaint(paint43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            categoryPlot19.handleClick(500, 2, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        java.lang.Object obj5 = ringPlot0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        java.lang.String str4 = numberAxis2.getLabelToolTip();
        boolean boolean5 = textTitle0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean7 = textTitle0.equals((java.lang.Object) itemLabelAnchor6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean14 = piePlot12.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke15 = piePlot12.getBaseSectionOutlineStroke();
        boolean boolean16 = chartRenderingInfo10.equals((java.lang.Object) piePlot12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = chartRenderingInfo10.getPlotInfo();
        java.lang.Object obj18 = textTitle0.draw(graphics2D8, rectangle2D9, (java.lang.Object) plotRenderingInfo17);
        textTitle0.setNotify(true);
        textTitle0.setExpandToFitSpace(false);
        double double23 = textTitle0.getWidth();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelToolTip();
        java.lang.String str6 = numberAxis4.getLabelToolTip();
        boolean boolean7 = textTitle2.equals((java.lang.Object) numberAxis4);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        boolean boolean9 = textTitle2.equals((java.lang.Object) itemLabelAnchor8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        boolean boolean16 = piePlot14.equals((java.lang.Object) (byte) 10);
        java.awt.Stroke stroke17 = piePlot14.getBaseSectionOutlineStroke();
        boolean boolean18 = chartRenderingInfo12.equals((java.lang.Object) piePlot14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = chartRenderingInfo12.getPlotInfo();
        java.lang.Object obj20 = textTitle2.draw(graphics2D10, rectangle2D11, (java.lang.Object) plotRenderingInfo19);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
        org.junit.Assert.assertNull(obj20);
    }
}

