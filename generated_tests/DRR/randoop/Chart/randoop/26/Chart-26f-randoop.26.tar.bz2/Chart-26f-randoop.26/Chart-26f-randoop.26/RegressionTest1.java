import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        boolean boolean9 = stackedBarRenderer3D1.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke7);
        stackedBarRenderer3D0.setBaseCreateEntities(false);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.String str6 = dateAxis1.getLabelToolTip();
        dateAxis1.setRangeAboutValue((double) (-1.0f), 0.25d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        categoryPlot36.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxis(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D42.setIncludeBaseInRange(false);
        stackedBarRenderer3D42.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem50 = stackedBarRenderer3D42.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke52 = piePlot51.getLabelLinkStroke();
        stackedBarRenderer3D42.setBaseOutlineStroke(stroke52);
        boolean boolean54 = stackedBarRenderer3D42.getBaseCreateEntities();
        categoryPlot36.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D42, true);
        java.awt.Paint paint58 = stackedBarRenderer3D42.getSeriesItemLabelPaint(12);
        java.lang.Object obj59 = null;
        boolean boolean60 = stackedBarRenderer3D42.equals(obj59);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(legendItem50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.String str8 = chartEntity7.getShapeType();
        java.lang.String str9 = chartEntity7.toString();
        java.lang.String str10 = chartEntity7.toString();
        java.lang.String str11 = chartEntity7.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "rect" + "'", str8.equals("rect"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = null" + "'", str9.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = null" + "'", str10.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartEntity: tooltip = null" + "'", str11.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D6.setFixedAutoRange(0.0d);
        java.awt.Shape shape9 = numberAxis3D6.getDownArrow();
        numberAxis3D6.setAutoTickUnitSelection(false, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, categoryItemRenderer13);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 8.0d, (java.lang.Number) 5);
        defaultKeyedValue2.setValue((java.lang.Number) (short) 0);
        java.lang.Comparable comparable5 = defaultKeyedValue2.getKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 8.0d + "'", comparable5.equals(8.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        stackedBarRenderer3D0.setBaseItemLabelsVisible(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) color8);
        double double10 = stackedBarRenderer3D7.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D7.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition11);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        int int8 = month6.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        boxAndWhiskerRenderer0.setFillBox(false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        boolean boolean8 = stackedBarRenderer3D1.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int3 = dateTickUnit2.getUnit();
        double double4 = dateTickUnit2.getSize();
        java.lang.Class class5 = null;
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean11 = simpleTimePeriod9.equals((java.lang.Object) 9999);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date12, timeZone15);
        java.lang.Class class17 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean22 = simpleTimePeriod20.equals((java.lang.Object) 9999);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date12, date23);
        java.lang.String str27 = dateTickUnit2.dateToString(date23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.6784E11d + "'", double4 == 2.6784E11d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "12/31/69" + "'", str27.equals("12/31/69"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D6.setFixedAutoRange(0.0d);
        java.awt.Shape shape9 = numberAxis3D6.getDownArrow();
        numberAxis3D6.setAutoTickUnitSelection(false, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, categoryItemRenderer13);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray37 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray42 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray43 = new double[][] { doubleArray22, doubleArray27, doubleArray32, doubleArray37, doubleArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray43);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D47.setIncludeBaseInRange(false);
        java.awt.Paint paint51 = stackedBarRenderer3D47.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D47);
        categoryPlot52.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str58 = categoryAxis57.getLabelToolTip();
        boolean boolean59 = categoryAxis57.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis57.getTickLabelInsets();
        double double62 = rectangleInsets60.calculateLeftInset((double) 10);
        categoryPlot52.setAxisOffset(rectangleInsets60);
        xYPlot0.setAxisOffset(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation3 = xYPlot0.getRangeAxisLocation(9999);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke5);
        xYPlot0.clearDomainMarkers(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        java.awt.Stroke stroke2 = piePlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        xYPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str41 = categoryAxis40.getLabelToolTip();
        boolean boolean42 = categoryAxis40.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis40.getTickLabelInsets();
        double double45 = rectangleInsets43.calculateLeftInset((double) 10);
        double double46 = rectangleInsets43.getRight();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj49 = null;
        boolean boolean50 = dateAxis48.equals(obj49);
        java.awt.Color color51 = java.awt.Color.cyan;
        dateAxis48.setAxisLinePaint((java.awt.Paint) color51);
        java.awt.Font font54 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("hi!", font54);
        org.jfree.chart.plot.PlotState plotState56 = new org.jfree.chart.plot.PlotState();
        java.util.Map map57 = plotState56.getSharedAxisStates();
        boolean boolean58 = textTitle55.equals((java.lang.Object) map57);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.block.LineBorder lineBorder60 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean62 = lineBorder60.equals((java.lang.Object) stackedBarRenderer3D61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.Font font65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font65);
        java.lang.String str67 = textTitle66.getURLText();
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor70 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition71 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor69, textBlockAnchor70);
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D68, rectangleAnchor69);
        lineBorder60.draw(graphics2D63, rectangle2D68);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D74 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D74.setBaseItemLabelPaint((java.awt.Paint) color75);
        double double77 = stackedBarRenderer3D74.getUpperClip();
        java.awt.Shape shape80 = stackedBarRenderer3D74.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity81 = new org.jfree.chart.entity.ChartEntity(shape80);
        java.lang.Object obj82 = textTitle55.draw(graphics2D59, rectangle2D68, (java.lang.Object) chartEntity81);
        dateAxis48.setUpArrow((java.awt.Shape) rectangle2D68);
        java.awt.geom.Rectangle2D rectangle2D86 = rectangleInsets43.createInsetRectangle(rectangle2D68, true, true);
        org.jfree.chart.text.TextBlock textBlock87 = new org.jfree.chart.text.TextBlock();
        java.util.List list88 = textBlock87.getLines();
        xYPlot0.drawDomainTickBands(graphics2D38, rectangle2D68, list88);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(map57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(textBlockAnchor70);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNull(obj82);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(list88);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        boolean boolean4 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj7 = null;
        boolean boolean8 = dateAxis6.equals(obj7);
        java.awt.Color color9 = java.awt.Color.cyan;
        dateAxis6.setAxisLinePaint((java.awt.Paint) color9);
        java.lang.String str11 = dateAxis6.getLabelToolTip();
        org.jfree.data.Range range12 = dateAxis6.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range12, false, false);
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot39.setRangeAxisLocation(axisLocation40, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot39.getDomainAxisForDataset(0);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        float float46 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNull(categoryAxis44);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        java.awt.Font font5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        labelBlock2.setFont(font5);
        java.lang.String str8 = labelBlock2.getURLText();
        java.awt.Paint paint9 = labelBlock2.getPaint();
        org.jfree.chart.block.BlockFrame blockFrame10 = labelBlock2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(blockFrame10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.plot.Plot plot44 = categoryPlot36.getParent();
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot36.setFixedRangeAxisSpace(axisSpace45);
        boolean boolean47 = categoryPlot36.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        xYPlot0.setBackgroundImageAlignment((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        double double4 = stackedBarRenderer3D0.getLowerClip();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class4 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean9 = simpleTimePeriod7.equals((java.lang.Object) 9999);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone11);
        java.util.Date date13 = dateTickUnit3.addToDate(date10);
        keyedObjects2D0.setObject((java.lang.Object) date10, (java.lang.Comparable) 0.05d, (java.lang.Comparable) "hi!");
        try {
            keyedObjects2D0.removeRow(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Comparable comparable3 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean9 = simpleTimePeriod7.equals((java.lang.Object) 9999);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone11);
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) 2.0d, comparable3, (java.lang.Comparable) regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        piePlot0.setBackgroundAlpha((float) (short) 10);
        int int4 = piePlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ChartEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setIncludeBaseInRange(false);
        java.awt.Paint paint7 = stackedBarRenderer3D3.getSeriesFillPaint((int) (byte) 0);
        stackedBarRenderer3D3.setAutoPopulateSeriesStroke(true);
        stackedBarRenderer3D3.setItemLabelAnchorOffset(10.0d);
        boolean boolean12 = categoryAxis0.equals((java.lang.Object) stackedBarRenderer3D3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle2.getMargin();
        java.lang.String str7 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setRangeAxisLocation(axisLocation46, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot45.getDomainAxisForDataset(0);
        categoryPlot45.setNoDataMessage("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = numberAxis3D54.getMarkerBand();
        java.awt.Color color59 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke61 = piePlot60.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color59, stroke61);
        java.awt.Paint paint63 = categoryMarker62.getLabelPaint();
        java.awt.Font font65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font65);
        java.lang.String str67 = textTitle66.getURLText();
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        stackedBarRenderer3D1.drawRangeMarker(graphics2D8, categoryPlot45, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, (org.jfree.chart.plot.Marker) categoryMarker62, rectangle2D68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        try {
            boolean boolean71 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D68, rectangle2D70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNull(markerAxisBand57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) simpleTimePeriod5);
        java.awt.Paint paint7 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font15 = categoryAxis10.getTickLabelFont((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod14);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer17 = new org.jfree.chart.renderer.category.LevelRenderer();
        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) levelRenderer17);
        java.lang.String str19 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) simpleTimePeriod14);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font7 = categoryAxis2.getTickLabelFont((java.lang.Comparable) simpleTimePeriod6);
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod6);
        task8.setPercentComplete((double) 1.0f);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean15 = simpleTimePeriod13.equals((java.lang.Object) 9999);
        java.util.Date date16 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        task8.setDuration((org.jfree.data.time.TimePeriod) regularTimePeriod18);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot36.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot36.getRangeAxisForDataset((int) (short) 10);
        java.awt.Stroke stroke45 = categoryPlot36.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(categoryItemRenderer42);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Shape shape5 = stackedBarRenderer3D0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getSeriesPositiveItemLabelPosition(3);
        boolean boolean8 = stackedBarRenderer3D0.getRenderAsPercentages();
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Number number3 = null;
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        java.util.List list9 = textBlock8.getLines();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 192, (java.lang.Number) 6, (java.lang.Number) 86400000L, number3, (java.lang.Number) 86400000L, (java.lang.Number) 100L, (java.lang.Number) (short) 1, (java.lang.Number) 0.0d, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMinRegularValue();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 86400000L + "'", number11.equals(86400000L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.awt.Graphics2D graphics2D37 = null;
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray64 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray65 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray65);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D69.setIncludeBaseInRange(false);
        java.awt.Paint paint73 = stackedBarRenderer3D69.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D69);
        categoryPlot74.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = categoryPlot74.getDomainAxis(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator80 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D82 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D82.setFixedAutoRange(0.0d);
        boolean boolean85 = standardCategorySeriesLabelGenerator80.equals((java.lang.Object) numberAxis3D82);
        java.awt.Color color87 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot88 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke89 = piePlot88.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker90 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color87, stroke89);
        java.awt.Font font92 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle("hi!", font92);
        java.lang.String str94 = textTitle93.getURLText();
        java.awt.geom.Rectangle2D rectangle2D95 = textTitle93.getBounds();
        stackedBarRenderer3D31.drawRangeMarker(graphics2D37, categoryPlot74, (org.jfree.chart.axis.ValueAxis) numberAxis3D82, (org.jfree.chart.plot.Marker) categoryMarker90, rectangle2D95);
        categoryPlot74.clearDomainMarkers();
        java.awt.Stroke stroke98 = categoryPlot74.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertNull(categoryAxis79);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(rectangle2D95);
        org.junit.Assert.assertNotNull(stroke98);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        int int40 = categoryPlot36.getBackgroundImageAlignment();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = categoryPlot36.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) "VerticalAlignment.BOTTOM", (double) (-1.0f));
        defaultKeyedValues0.setValue((java.lang.Comparable) (-1), 3.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean4 = lineBorder2.equals((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D6.setBaseItemLabelPaint((java.awt.Paint) color7);
        stackedBarRenderer3D3.setSeriesPaint(0, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D11.setIncludeBaseInRange(false);
        java.awt.Paint paint15 = stackedBarRenderer3D11.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedBarRenderer3D11.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedBarRenderer3D11.getPositiveItemLabelPositionFallback();
        boolean boolean20 = stackedBarRenderer3D11.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D11.setBaseFillPaint(paint21);
        stackedBarRenderer3D3.setSeriesOutlinePaint(3, paint21);
        boolean boolean24 = shapeList0.equals((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        double double2 = piePlot0.getStartAngle();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean5 = simpleTimePeriod3.equals((java.lang.Object) 9999);
        java.util.Date date6 = simpleTimePeriod3.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        serialDate9.setDescription("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate9.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        java.awt.Paint paint47 = stackedBarRenderer3D0.getBasePaint();
        stackedBarRenderer3D0.setMaximumBarWidth(Double.NaN);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset40);
        boolean boolean42 = defaultCategoryDataset39.hasListener((java.util.EventListener) ringPlot41);
        boolean boolean43 = stackedBarRenderer3D31.equals((java.lang.Object) defaultCategoryDataset39);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class48 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean53 = simpleTimePeriod51.equals((java.lang.Object) 9999);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone55);
        java.util.Date date57 = dateTickUnit47.addToDate(date54);
        defaultCategoryDataset39.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date54, (java.lang.Comparable) 4.0d);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        int int62 = xYPlot61.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis64 = xYPlot61.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot61.getDomainAxisForDataset(0);
        defaultCategoryDataset39.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot61);
        defaultCategoryDataset39.addValue(0.25d, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_RIGHT", (java.lang.Comparable) "Size2D[width=8.0, height=0.0]");
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 4.0d + "'", number60.equals(4.0d));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(valueAxis64);
        org.junit.Assert.assertNull(valueAxis66);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        java.lang.String str46 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray47 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot36.setDomainAxes(categoryAxisArray47);
        categoryPlot36.setAnchorValue((double) 6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Category Plot" + "'", str46.equals("Category Plot"));
        org.junit.Assert.assertNotNull(categoryAxisArray47);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        double double41 = legendTitle37.getWidth();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D42.setBaseItemLabelPaint((java.awt.Paint) color43);
        legendTitle37.setItemPaint((java.awt.Paint) color43);
        java.awt.Color color46 = java.awt.Color.WHITE;
        int int47 = color46.getGreen();
        legendTitle37.setBackgroundPaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedBarRenderer3D0.getBasePositiveItemLabelPosition();
        stackedBarRenderer3D0.setBaseCreateEntities(true);
        boolean boolean52 = stackedBarRenderer3D0.getItemCreateEntity(2, (int) (byte) 10);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setVersion("LGPL");
        java.awt.Image image5 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(image5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) "VerticalAlignment.BOTTOM", (double) (-1.0f));
        org.jfree.data.KeyedObjects keyedObjects5 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class9 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean14 = simpleTimePeriod12.equals((java.lang.Object) 9999);
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date15, timeZone16);
        java.util.Date date18 = dateTickUnit8.addToDate(date15);
        int int19 = keyedObjects5.getIndex((java.lang.Comparable) date15);
        try {
            defaultKeyedValues0.insertValue((-1), (java.lang.Comparable) int19, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray39 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray40 = new double[][] { doubleArray19, doubleArray24, doubleArray29, doubleArray34, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D44.setIncludeBaseInRange(false);
        java.awt.Paint paint48 = stackedBarRenderer3D44.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D44);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot49.setRangeAxisLocation(axisLocation50, false);
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        categoryPlot49.setFixedDomainAxisSpace(axisSpace53);
        java.awt.Paint paint55 = categoryPlot49.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        categoryAxis57.setLabelURL("");
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range62 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis61.setRange(range62);
        boolean boolean64 = dateAxis61.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit67 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int68 = dateTickUnit67.getRollCount();
        dateAxis61.setTickUnit(dateTickUnit67);
        java.lang.String[] strArray71 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray72 = null;
        java.lang.Number[][] numberArray73 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset74 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray71, numberArray72, numberArray73);
        java.util.List list75 = defaultIntervalCategoryDataset74.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup76 = defaultIntervalCategoryDataset74.getGroup();
        int int77 = defaultIntervalCategoryDataset74.getCategoryCount();
        try {
            stackedBarRenderer3D0.drawItem(graphics2D10, categoryItemRendererState11, rectangle2D12, categoryPlot49, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis61, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset74, (int) (byte) 0, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(datasetGroup76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean9 = lineBorder7.equals((java.lang.Object) stackedBarRenderer3D8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.lang.String str14 = textTitle13.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle13.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17);
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        lineBorder7.draw(graphics2D10, rectangle2D15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D21.setBaseItemLabelPaint((java.awt.Paint) color22);
        double double24 = stackedBarRenderer3D21.getUpperClip();
        java.awt.Shape shape27 = stackedBarRenderer3D21.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape27);
        java.lang.Object obj29 = textTitle2.draw(graphics2D6, rectangle2D15, (java.lang.Object) chartEntity28);
        java.lang.String str30 = chartEntity28.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ChartEntity: tooltip = null" + "'", str30.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setRangeAxisLocation(axisLocation46, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot45.getDomainAxisForDataset(0);
        categoryPlot45.setNoDataMessage("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = numberAxis3D54.getMarkerBand();
        java.awt.Color color59 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke61 = piePlot60.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color59, stroke61);
        java.awt.Paint paint63 = categoryMarker62.getLabelPaint();
        java.awt.Font font65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font65);
        java.lang.String str67 = textTitle66.getURLText();
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        stackedBarRenderer3D1.drawRangeMarker(graphics2D8, categoryPlot45, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, (org.jfree.chart.plot.Marker) categoryMarker62, rectangle2D68);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator71 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj72 = standardCategoryToolTipGenerator71.clone();
        stackedBarRenderer3D1.setSeriesToolTipGenerator((int) (byte) 1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator71, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset75 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset76 = null;
        org.jfree.chart.plot.RingPlot ringPlot77 = new org.jfree.chart.plot.RingPlot(pieDataset76);
        boolean boolean78 = defaultCategoryDataset75.hasListener((java.util.EventListener) ringPlot77);
        try {
            java.lang.String str80 = standardCategoryToolTipGenerator71.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset75, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNull(markerAxisBand57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = categoryPlot36.getRangeMarkers(layer46);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot36.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(legendItemCollection48);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        java.lang.Comparable comparable6 = null;
        try {
            int int7 = defaultIntervalCategoryDataset4.getRowIndex(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(categoryDataset2);
        org.junit.Assert.assertNotNull(tableOrder3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot36.setDomainGridlinePaint(paint40);
        categoryPlot36.setRangeCrosshairValue((double) 1.0f);
        java.awt.Font font44 = categoryPlot36.getNoDataMessageFont();
        boolean boolean45 = categoryPlot36.isOutlineVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.validateObject();
        defaultCategoryDataset47.validateObject();
        defaultCategoryDataset47.validateObject();
        categoryPlot36.setDataset(1969, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        textBlock1.draw(graphics2D2, (float) 9999, 1.0f, textBlockAnchor6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setIncludeBaseInRange(false);
        java.awt.Paint paint13 = stackedBarRenderer3D9.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D9.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition16.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType19 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str20 = categoryLabelWidthType19.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor6, textAnchor17, (double) 10, categoryLabelWidthType19, (float) 3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D24.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = numberAxis3D24.getMarkerBand();
        java.lang.Object obj28 = numberAxis3D24.clone();
        boolean boolean29 = numberAxis3D24.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D31.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = numberAxis3D31.getMarkerBand();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D31.setRange(range35, false, true);
        java.lang.String str39 = range35.toString();
        numberAxis3D24.setRangeWithMargins(range35, true, true);
        boolean boolean43 = categoryLabelWidthType19.equals((java.lang.Object) numberAxis3D24);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelWidthType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str20.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNull(markerAxisBand27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(markerAxisBand34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Range[0.0,1.0]" + "'", str39.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D4.setFixedAutoRange(0.0d);
        boolean boolean7 = standardCategorySeriesLabelGenerator2.equals((java.lang.Object) numberAxis3D4);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedBarRenderer3D0.setSeriesURLGenerator(11, categoryURLGenerator13);
        org.jfree.chart.LegendItem legendItem17 = stackedBarRenderer3D0.getLegendItem(2, 4);
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray39 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray45 = new double[][] { doubleArray24, doubleArray29, doubleArray34, doubleArray39, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D49.setIncludeBaseInRange(false);
        java.awt.Paint paint53 = stackedBarRenderer3D49.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D49);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = stackedBarRenderer3D49.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection56 = stackedBarRenderer3D49.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset57 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset58 = null;
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot(pieDataset58);
        boolean boolean60 = defaultCategoryDataset57.hasListener((java.util.EventListener) ringPlot59);
        boolean boolean61 = stackedBarRenderer3D49.equals((java.lang.Object) defaultCategoryDataset57);
        org.jfree.data.Range range62 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset57);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertNotNull(legendItemCollection56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(range62);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2);
        serialDate1.setDescription("");
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        ringPlot1.setBaseSectionOutlineStroke(stroke3);
        java.awt.Paint paint5 = ringPlot1.getLabelOutlinePaint();
        double double6 = ringPlot1.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setTickMarkOutsideLength((float) 100);
        java.awt.Color color5 = java.awt.Color.blue;
        java.awt.Color color6 = color5.brighter();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        textTitle2.setID("RangeType.NEGATIVE");
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getURLText();
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor17, textBlockAnchor18);
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        lineBorder10.draw(graphics2D11, rectangle2D16);
        java.awt.Paint paint22 = lineBorder10.getPaint();
        textTitle2.setPaint(paint22);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = legendTitle37.arrange(graphics2D39, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int7 = dateTickUnit6.getRollCount();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        java.awt.Paint paint10 = ringPlot9.getSeparatorPaint();
        int int11 = dateTickUnit6.compareTo((java.lang.Object) paint10);
        stackedBarRenderer3D0.setSeriesFillPaint(255, paint10, false);
        java.awt.Stroke stroke14 = stackedBarRenderer3D0.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str45 = categoryAxis44.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font49 = categoryAxis44.getTickLabelFont((java.lang.Comparable) simpleTimePeriod48);
        java.awt.Paint paint50 = categoryAxis44.getAxisLinePaint();
        categoryPlot36.setDomainAxis(categoryAxis44);
        boolean boolean53 = categoryPlot36.equals((java.lang.Object) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj56 = null;
        boolean boolean57 = dateAxis55.equals(obj56);
        java.awt.Color color58 = java.awt.Color.cyan;
        dateAxis55.setAxisLinePaint((java.awt.Paint) color58);
        java.awt.Color color60 = java.awt.Color.BLACK;
        dateAxis55.setTickLabelPaint((java.awt.Paint) color60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) dateAxis55);
        categoryPlot36.rendererChanged(rendererChangeEvent62);
        java.lang.String str64 = rendererChangeEvent62.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D1.setRange(range5, false, true);
        java.awt.Shape shape9 = null;
        try {
            numberAxis3D1.setRightArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        java.awt.Paint paint3 = piePlot0.getSectionPaint((java.lang.Comparable) 5);
        java.awt.Stroke stroke4 = piePlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        jFreeChart53.setBorderVisible(true);
        org.jfree.chart.plot.Plot plot57 = jFreeChart53.getPlot();
        java.awt.Color color58 = java.awt.Color.RED;
        int int59 = color58.getBlue();
        jFreeChart53.setBorderPaint((java.awt.Paint) color58);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(plot57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.awt.Graphics2D graphics2D37 = null;
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray64 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray65 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray65);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D69.setIncludeBaseInRange(false);
        java.awt.Paint paint73 = stackedBarRenderer3D69.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D69);
        categoryPlot74.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = categoryPlot74.getDomainAxis(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator80 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D82 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D82.setFixedAutoRange(0.0d);
        boolean boolean85 = standardCategorySeriesLabelGenerator80.equals((java.lang.Object) numberAxis3D82);
        java.awt.Color color87 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot88 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke89 = piePlot88.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker90 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color87, stroke89);
        java.awt.Font font92 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle("hi!", font92);
        java.lang.String str94 = textTitle93.getURLText();
        java.awt.geom.Rectangle2D rectangle2D95 = textTitle93.getBounds();
        stackedBarRenderer3D31.drawRangeMarker(graphics2D37, categoryPlot74, (org.jfree.chart.axis.ValueAxis) numberAxis3D82, (org.jfree.chart.plot.Marker) categoryMarker90, rectangle2D95);
        categoryPlot74.clearDomainMarkers();
        java.awt.Font font98 = categoryPlot74.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets99 = categoryPlot74.getAxisOffset();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertNull(categoryAxis79);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(rectangle2D95);
        org.junit.Assert.assertNotNull(font98);
        org.junit.Assert.assertNotNull(rectangleInsets99);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj8 = null;
        boolean boolean9 = dateAxis7.equals(obj8);
        java.awt.Color color10 = java.awt.Color.cyan;
        dateAxis7.setAxisLinePaint((java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.BLACK;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color12);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.awt.Image image3 = null;
        projectInfo1.setLogo(image3);
        java.lang.String str5 = projectInfo1.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart" + "'", str5.equals("JFreeChart"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick46 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor43, textAnchor44, (double) 0);
        double double47 = numberTick46.getValue();
        boolean boolean48 = legendTitle37.equals((java.lang.Object) double47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getLabelLinkStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator2);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color5);
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color5 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D8.setIncludeBaseInRange(false);
        java.awt.Shape shape12 = stackedBarRenderer3D8.getSeriesShape(0);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D8.setBasePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setIncludeBaseInRange(false);
        java.awt.Shape shape19 = stackedBarRenderer3D15.getSeriesShape(0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D15.setBasePaint((java.awt.Paint) color20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color13, color20, color22 };
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray23, paintArray24, strokeArray25, strokeArray26, shapeArray27);
        java.lang.Object obj29 = defaultDrawingSupplier28.clone();
        java.lang.Object obj30 = defaultDrawingSupplier28.clone();
        try {
            java.awt.Paint paint31 = defaultDrawingSupplier28.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(10, axisLocation38);
        xYPlot0.setForegroundAlpha((float) (byte) -1);
        java.awt.Paint paint43 = xYPlot0.getQuadrantPaint((int) (byte) 0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        java.awt.Shape shape6 = stackedBarRenderer3D2.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) color8);
        double double10 = stackedBarRenderer3D7.getUpperClip();
        java.awt.Shape shape13 = stackedBarRenderer3D7.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D2.setBaseShape(shape13);
        double double15 = stackedBarRenderer3D2.getItemMargin();
        java.awt.Font font16 = stackedBarRenderer3D2.getBaseItemLabelFont();
        valueMarker1.setLabelFont(font16);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str7 = categoryAxis6.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font11 = categoryAxis6.getTickLabelFont((java.lang.Comparable) simpleTimePeriod10);
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod10);
        task2.removeSubtask(task12);
        org.jfree.data.time.TimePeriod timePeriod15 = null;
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod15);
        task12.addSubtask(task16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.lang.Object obj1 = null;
        boolean boolean2 = textLine0.equals(obj1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(textFragment3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        boolean boolean3 = piePlot0.isCircular();
        double double4 = piePlot0.getLabelGap();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font7 = categoryAxis2.getTickLabelFont((java.lang.Comparable) simpleTimePeriod6);
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle45.setItemPaint(paint46);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint46, (float) 10, 3, textMeasurer50);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        stackedBarRenderer3D52.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem60 = stackedBarRenderer3D52.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke62 = piePlot61.getLabelLinkStroke();
        stackedBarRenderer3D52.setBaseOutlineStroke(stroke62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str66 = categoryAxis65.getLabelToolTip();
        boolean boolean67 = categoryAxis65.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryAxis65.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder(paint46, stroke62, rectangleInsets68);
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D71 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D71.setIncludeBaseInRange(false);
        java.awt.Paint paint75 = stackedBarRenderer3D71.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = stackedBarRenderer3D71.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = stackedBarRenderer3D71.getPositiveItemLabelPositionFallback();
        boolean boolean80 = stackedBarRenderer3D71.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint81 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D71.setBaseFillPaint(paint81);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot();
        int int84 = xYPlot83.getSeriesCount();
        java.awt.Paint paint85 = xYPlot83.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer86 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint46, (java.awt.Paint) color70, paint81, paint85);
        java.awt.Paint paint87 = waterfallBarRenderer86.getPositiveBarPaint();
        java.awt.Paint paint88 = waterfallBarRenderer86.getLastBarPaint();
        java.awt.Paint paint89 = waterfallBarRenderer86.getLastBarPaint();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(itemLabelPosition78);
        org.junit.Assert.assertNull(itemLabelPosition79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        java.awt.Color color12 = java.awt.Color.lightGray;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color12, true);
        java.awt.Stroke stroke17 = stackedBarRenderer3D0.getItemOutlineStroke(1969, 10);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setDomainCrosshairValue((double) ' ', true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint4.toRangeWidth(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D13.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis3D13.getMarkerBand();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D13.setRange(range17, false, true);
        java.lang.String str21 = range17.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint4.toRangeHeight(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Range[0.0,1.0]" + "'", str21.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 6, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker4.getLabelOffsetType();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("hi!", font8);
        java.lang.String str10 = labelBlock9.getToolTipText();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        labelBlock9.setFont(font12);
        java.lang.String str15 = labelBlock9.getURLText();
        java.awt.Paint paint16 = labelBlock9.getPaint();
        valueMarker4.setPaint(paint16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.0d + "'", double5 == 6.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 8;
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        int int55 = jFreeChart53.getSubtitleCount();
        try {
            java.awt.image.BufferedImage bufferedImage58 = jFreeChart53.createBufferedImage(4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (4) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D3.setFixedAutoRange(0.0d);
        java.awt.Shape shape6 = numberAxis3D3.getDownArrow();
        numberAxis3D3.setAutoTickUnitSelection(false, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer10);
        float float12 = categoryPlot11.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        xYPlot0.setDomainCrosshairVisible(true);
        xYPlot0.setDomainCrosshairValue(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.plot.Plot plot6 = ringPlot2.getRootPlot();
        java.awt.Paint paint7 = ringPlot2.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        java.awt.Stroke stroke4 = ringPlot2.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = piePlot0.getURLGenerator();
        double[] doubleArray8 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray13 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray29 = new double[][] { doubleArray8, doubleArray13, doubleArray18, doubleArray23, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setIncludeBaseInRange(false);
        java.awt.Paint paint37 = stackedBarRenderer3D33.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D33);
        categoryPlot38.mapDatasetToRangeAxis(0, (int) (byte) 1);
        java.awt.Paint paint42 = categoryPlot38.getDomainGridlinePaint();
        piePlot0.setBaseSectionOutlinePaint(paint42);
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.BOTTOM", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 6.0d, 0.0d);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Stroke stroke18 = stackedBarRenderer3D0.getItemStroke(2, 0);
        stackedBarRenderer3D0.setItemMargin((double) (byte) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100.0f, 2.6784E11d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D44.setIncludeBaseInRange(false);
        java.awt.Paint paint48 = stackedBarRenderer3D44.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = stackedBarRenderer3D44.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = stackedBarRenderer3D44.getPositiveItemLabelPositionFallback();
        boolean boolean53 = stackedBarRenderer3D44.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D44.setBaseFillPaint(paint54);
        categoryPlot36.setOutlinePaint(paint54);
        boolean boolean57 = categoryPlot36.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertNull(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) false);
        double[] doubleArray13 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D38.setIncludeBaseInRange(false);
        java.awt.Paint paint42 = stackedBarRenderer3D38.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D38);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D38);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str47 = categoryAxis46.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font51 = categoryAxis46.getTickLabelFont((java.lang.Comparable) simpleTimePeriod50);
        legendTitle44.setItemFont(font51);
        stackedBarRenderer3D0.setSeriesItemLabelFont(0, font51, false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke10 = piePlot9.getLabelLinkStroke();
        stackedBarRenderer3D0.setBaseOutlineStroke(stroke10);
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray38 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray39 = new double[][] { doubleArray18, doubleArray23, doubleArray28, doubleArray33, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        boolean boolean41 = stackedBarRenderer3D0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (-1L), (java.lang.Number) 255);
        defaultKeyedValues0.clear();
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setRange(1.0d, (double) 3);
        numberAxis3D1.setPositiveArrowVisible(true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        float float2 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        float float4 = piePlot3.getBackgroundAlpha();
        boolean boolean5 = piePlot3.isCircular();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot3.setLabelOutlineStroke(stroke6);
        piePlot1.setBaseSectionOutlineStroke(stroke6);
        boolean boolean9 = rangeType0.equals((java.lang.Object) piePlot1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.image.BufferedImage bufferedImage56 = jFreeChart53.createBufferedImage(1, (int) ' ');
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent57 = null;
        try {
            jFreeChart53.titleChanged(titleChangeEvent57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(bufferedImage56);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean9 = lineBorder7.equals((java.lang.Object) stackedBarRenderer3D8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.lang.String str14 = textTitle13.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle13.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17);
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        lineBorder7.draw(graphics2D10, rectangle2D15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D21.setBaseItemLabelPaint((java.awt.Paint) color22);
        double double24 = stackedBarRenderer3D21.getUpperClip();
        java.awt.Shape shape27 = stackedBarRenderer3D21.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape27);
        java.lang.Object obj29 = textTitle2.draw(graphics2D6, rectangle2D15, (java.lang.Object) chartEntity28);
        java.lang.String str30 = chartEntity28.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("rect");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        try {
            java.lang.Object obj5 = defaultIntervalCategoryDataset4.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        java.lang.Object obj5 = labelBlock2.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D10 = blockContainer7.arrange(graphics2D8, rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.data.Range range12 = rectangleConstraint11.getHeightRange();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis14.setRange(range15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint11.toRangeWidth(range15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedHeight(0.0d);
        try {
            org.jfree.chart.util.Size2D size2D20 = labelBlock2.arrange(graphics2D6, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Stroke stroke18 = stackedBarRenderer3D0.getItemStroke(2, 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray37 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray42 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray47 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray48 = new double[][] { doubleArray27, doubleArray32, doubleArray37, doubleArray42, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        java.awt.Paint paint56 = stackedBarRenderer3D52.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D52);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D52);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str61 = categoryAxis60.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font65 = categoryAxis60.getTickLabelFont((java.lang.Comparable) simpleTimePeriod64);
        legendTitle58.setItemFont(font65);
        boolean boolean67 = chartChangeEventType20.equals((java.lang.Object) font65);
        stackedBarRenderer3D0.setSeriesItemLabelFont(9999, font65);
        java.awt.Font font70 = null;
        stackedBarRenderer3D0.setSeriesItemLabelFont(1, font70, true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        textBlock2.draw(graphics2D3, (float) 9999, 1.0f, textBlockAnchor7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setIncludeBaseInRange(false);
        java.awt.Paint paint14 = stackedBarRenderer3D10.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D10.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition17.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str21 = categoryLabelWidthType20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor7, textAnchor18, (double) 10, categoryLabelWidthType20, (float) 3);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick29 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor26, textAnchor27, (double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor18, textAnchor27, 6.0d);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot32.setRenderer(100, xYItemRenderer34);
        xYPlot32.setDomainCrosshairValue((double) 900000L);
        boolean boolean38 = textAnchor27.equals((java.lang.Object) 900000L);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str21.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot8.setRenderer(100, xYItemRenderer10);
        xYPlot8.clearRangeMarkers(0);
        xYPlot8.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot8.getDomainAxisLocation((int) (byte) 100);
        xYPlot0.setRangeAxisLocation(0, axisLocation17);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        java.util.Map map2 = plotState0.getSharedAxisStates();
        java.util.Map map3 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
        org.junit.Assert.assertNotNull(map2);
        org.junit.Assert.assertNotNull(map3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        boolean boolean4 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.Object obj1 = null;
        boolean boolean2 = rangeType0.equals(obj1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D10.setBaseItemLabelPaint((java.awt.Paint) color11);
        double double13 = stackedBarRenderer3D10.getUpperClip();
        java.awt.Shape shape16 = stackedBarRenderer3D10.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        stackedBarRenderer3D0.setSeriesShape((int) (short) 10, shape16, false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset40);
        boolean boolean42 = defaultCategoryDataset39.hasListener((java.util.EventListener) ringPlot41);
        boolean boolean43 = stackedBarRenderer3D31.equals((java.lang.Object) defaultCategoryDataset39);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class48 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean53 = simpleTimePeriod51.equals((java.lang.Object) 9999);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone55);
        java.util.Date date57 = dateTickUnit47.addToDate(date54);
        defaultCategoryDataset39.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date54, (java.lang.Comparable) 4.0d);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        int int62 = xYPlot61.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis64 = xYPlot61.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot61.getDomainAxisForDataset(0);
        defaultCategoryDataset39.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot61);
        try {
            java.lang.Comparable comparable69 = defaultCategoryDataset39.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 4.0d + "'", number60.equals(4.0d));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(valueAxis64);
        org.junit.Assert.assertNull(valueAxis66);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        size2D3.setWidth(8.0d);
        java.lang.Object obj6 = size2D3.clone();
        double double7 = size2D3.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font6);
        org.jfree.chart.plot.PlotState plotState8 = new org.jfree.chart.plot.PlotState();
        java.util.Map map9 = plotState8.getSharedAxisStates();
        boolean boolean10 = textTitle7.equals((java.lang.Object) map9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = lineBorder12.equals((java.lang.Object) stackedBarRenderer3D13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        java.lang.String str19 = textTitle18.getURLText();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor21, textBlockAnchor22);
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        lineBorder12.draw(graphics2D15, rectangle2D20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D26.setBaseItemLabelPaint((java.awt.Paint) color27);
        double double29 = stackedBarRenderer3D26.getUpperClip();
        java.awt.Shape shape32 = stackedBarRenderer3D26.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        java.lang.Object obj34 = textTitle7.draw(graphics2D11, rectangle2D20, (java.lang.Object) chartEntity33);
        try {
            java.lang.Object obj36 = labelBlock2.draw(graphics2D4, rectangle2D20, (java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(map9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(obj34);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        categoryAxis1.setLabelURL("");
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setCategoryMargin(Double.NaN);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        xYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot8.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot8.getDomainAxisForDataset(0);
        xYPlot8.setDomainCrosshairVisible(true);
        double double16 = xYPlot8.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot8.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D3.setFixedAutoRange(0.0d);
        java.awt.Shape shape6 = numberAxis3D3.getDownArrow();
        numberAxis3D3.setAutoTickUnitSelection(false, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot11.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot11.getInsets();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D1.setRange(range5, false, true);
        boolean boolean9 = numberAxis3D1.isTickMarksVisible();
        boolean boolean10 = numberAxis3D1.isNegativeArrowVisible();
        double double11 = numberAxis3D1.getUpperBound();
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        piePlot0.setLabelLinkMargin((double) (byte) 100);
        piePlot0.setNoDataMessage("12/31/69");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.LegendItem legendItem5 = stackedBarRenderer3D0.getLegendItem(0, 9);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        stackedBarRenderer3D0.setSeriesFillPaint(0, paint7, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setIncludeBaseInRange(false);
        java.awt.Paint paint14 = stackedBarRenderer3D10.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D10.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setCategoryLabelPositionOffset(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        java.lang.String str8 = month6.toString();
        int int9 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot3D0.getLabelDistributor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100.0f, paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(false);
        piePlot3D0.setDepthFactor((double) (byte) 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = statisticalBarRenderer0.getDrawingSupplier();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean3 = statisticalBarRenderer0.equals((java.lang.Object) chartChangeEventType2);
        org.junit.Assert.assertNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(10, axisLocation38);
        xYPlot0.setForegroundAlpha((float) (byte) -1);
        int int42 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle2.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, 6.0d, 0.0d);
        textTitle2.setTextAlignment(horizontalAlignment7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setIncludeBaseInRange(false);
        java.awt.Paint paint40 = stackedBarRenderer3D36.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D36);
        categoryPlot41.mapDatasetToRangeAxis(0, (int) (byte) 1);
        java.awt.Paint paint45 = categoryPlot41.getDomainGridlinePaint();
        boolean boolean46 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot41);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot41.getDomainAxis((int) (short) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(categoryAxis48);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double5 = rectangleConstraint4.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D6 = centerArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot3.setRenderer(100, xYItemRenderer5);
        xYPlot3.clearRangeMarkers(0);
        java.awt.Paint paint9 = xYPlot3.getRangeGridlinePaint();
        ringPlot1.setLabelShadowPaint(paint9);
        java.awt.Paint paint11 = ringPlot1.getBaseSectionPaint();
        java.awt.Paint paint12 = ringPlot1.getShadowPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint3);
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        org.jfree.chart.plot.PlotState plotState6 = new org.jfree.chart.plot.PlotState();
        java.util.Map map7 = plotState6.getSharedAxisStates();
        boolean boolean8 = textTitle5.equals((java.lang.Object) map7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean12 = lineBorder10.equals((java.lang.Object) stackedBarRenderer3D11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font15);
        java.lang.String str17 = textTitle16.getURLText();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        lineBorder10.draw(graphics2D13, rectangle2D18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D24.setBaseItemLabelPaint((java.awt.Paint) color25);
        double double27 = stackedBarRenderer3D24.getUpperClip();
        java.awt.Shape shape30 = stackedBarRenderer3D24.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape30);
        java.lang.Object obj32 = textTitle5.draw(graphics2D9, rectangle2D18, (java.lang.Object) chartEntity31);
        double[] doubleArray39 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray60 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray60);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D64 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D64.setIncludeBaseInRange(false);
        java.awt.Paint paint68 = stackedBarRenderer3D64.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D64);
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot69.setRangeAxisLocation(axisLocation70, false);
        org.jfree.chart.axis.AxisSpace axisSpace73 = null;
        categoryPlot69.setFixedDomainAxisSpace(axisSpace73);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent75 = null;
        categoryPlot69.datasetChanged(datasetChangeEvent75);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot69.getDomainAxisEdge(2);
        double double79 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D18, rectangleEdge78);
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = null;
        java.awt.geom.Point2D point2D82 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D80, rectangleAnchor81);
        org.jfree.chart.plot.PlotState plotState83 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        try {
            multiplePiePlot1.draw(graphics2D2, rectangle2D18, point2D82, plotState83, plotRenderingInfo84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(map7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNull(paint68);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(point2D82);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) 0);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer8.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer8.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer8.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        statisticalLineAndShapeRenderer8.setBaseShapesVisible(false);
        boolean boolean20 = statisticalLineAndShapeRenderer8.getAutoPopulateSeriesPaint();
        boolean boolean21 = numberTick5.equals((java.lang.Object) statisticalLineAndShapeRenderer8);
        boolean boolean22 = statisticalLineAndShapeRenderer8.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers(9999, layer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot0.datasetChanged(datasetChangeEvent7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getRowKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleEdge.LEFT", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        textBlock0.draw(graphics2D1, (float) 9999, 1.0f, textBlockAnchor5);
        java.lang.Object obj8 = null;
        boolean boolean9 = textBlock0.equals(obj8);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.general.WaferMapDataset waferMapDataset10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset10);
        org.jfree.data.general.WaferMapDataset waferMapDataset12 = null;
        waferMapPlot11.setDataset(waferMapDataset12);
        waferMapPlot11.setNoDataMessage("VerticalAlignment.BOTTOM");
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        java.lang.String str20 = textTitle19.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke23 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        int int25 = xYPlot22.indexOf(xYDataset24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot22.getOrientation();
        java.awt.Graphics2D graphics2D27 = null;
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray39 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D59 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D59.setIncludeBaseInRange(false);
        java.awt.Paint paint63 = stackedBarRenderer3D59.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D59);
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D59);
        java.awt.Paint paint66 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle65.setItemPaint(paint66);
        boolean boolean68 = legendTitle65.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = legendTitle65.getLegendItemGraphicPadding();
        java.awt.geom.Rectangle2D rectangle2D70 = legendTitle65.getBounds();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = null;
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D71, rectangleAnchor72);
        org.jfree.chart.plot.PlotState plotState74 = new org.jfree.chart.plot.PlotState();
        java.util.Map map75 = plotState74.getSharedAxisStates();
        java.util.Map map76 = plotState74.getSharedAxisStates();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        xYPlot22.draw(graphics2D27, rectangle2D70, point2D73, plotState74, plotRenderingInfo77);
        org.jfree.chart.plot.PlotState plotState79 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        waferMapPlot11.draw(graphics2D16, rectangle2D21, point2D73, plotState79, plotRenderingInfo80);
        boolean boolean82 = unitType9.equals((java.lang.Object) rectangle2D21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D83 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D83.setIncludeBaseInRange(false);
        stackedBarRenderer3D83.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        stackedBarRenderer3D83.setItemMargin((double) '4');
        java.lang.Object obj91 = textTitle2.draw(graphics2D8, rectangle2D21, (java.lang.Object) '4');
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(point2D73);
        org.junit.Assert.assertNotNull(map75);
        org.junit.Assert.assertNotNull(map76);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(obj91);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(0.0d);
        blockParams0.setTranslateY(0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.plot.Plot plot44 = categoryPlot36.getParent();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot36.setRangeGridlineStroke(stroke45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot36.getDataset();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(categoryDataset47);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset40);
        boolean boolean42 = defaultCategoryDataset39.hasListener((java.util.EventListener) ringPlot41);
        boolean boolean43 = stackedBarRenderer3D31.equals((java.lang.Object) defaultCategoryDataset39);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class48 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean53 = simpleTimePeriod51.equals((java.lang.Object) 9999);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone55);
        java.util.Date date57 = dateTickUnit47.addToDate(date54);
        defaultCategoryDataset39.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date54, (java.lang.Comparable) 4.0d);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39);
        java.lang.Comparable comparable61 = null;
        try {
            defaultCategoryDataset39.removeColumn(comparable61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 4.0d + "'", number60.equals(4.0d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRange(range4);
        boolean boolean6 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int10 = dateTickUnit9.getRollCount();
        dateAxis3.setTickUnit(dateTickUnit9);
        keyedObjects2D0.removeColumn((java.lang.Comparable) dateTickUnit9);
        try {
            java.lang.Comparable comparable14 = keyedObjects2D0.getColumnKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) 192, (float) (short) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setIncludeBaseInRange(false);
        java.awt.Paint paint41 = stackedBarRenderer3D37.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D37);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot42.setRangeAxisLocation(axisLocation43, false);
        int int46 = categoryPlot42.getBackgroundImageAlignment();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot42);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        int int49 = categoryPlot42.getDomainAxisIndex(categoryAxis48);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.lang.Comparable comparable8 = null;
        try {
            java.lang.Number number9 = defaultIntervalCategoryDataset4.getStartValue((java.lang.Comparable) 0, comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean5 = simpleTimePeriod3.equals((java.lang.Object) 9999);
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("hi!", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        java.util.Date date7 = simpleTimePeriod3.getStart();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        xYPlot0.setDomainCrosshairVisible(true);
        double double8 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color5, stroke7);
        categoryMarker8.setLabel("RectangleAnchor.TOP_RIGHT");
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        xYPlot0.clearRangeAxes();
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray36 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray41 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray42 = new double[][] { doubleArray21, doubleArray26, doubleArray31, doubleArray36, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setIncludeBaseInRange(false);
        java.awt.Paint paint50 = stackedBarRenderer3D46.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D46);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot51.setRangeAxisLocation(axisLocation52, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot51.getDomainAxisForDataset(0);
        categoryPlot51.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection60 = categoryPlot51.getDomainMarkers(layer59);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection62 = categoryPlot51.getRangeMarkers(layer61);
        java.util.Collection collection63 = xYPlot0.getDomainMarkers((int) (short) 1, layer61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(categoryAxis56);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNull(collection63);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        boolean boolean6 = categoryAxis4.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis4.getTickLabelInsets();
        double double9 = rectangleInsets7.calculateLeftInset((double) 10);
        double double10 = rectangleInsets7.getRight();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj13 = null;
        boolean boolean14 = dateAxis12.equals(obj13);
        java.awt.Color color15 = java.awt.Color.cyan;
        dateAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        org.jfree.chart.plot.PlotState plotState20 = new org.jfree.chart.plot.PlotState();
        java.util.Map map21 = plotState20.getSharedAxisStates();
        boolean boolean22 = textTitle19.equals((java.lang.Object) map21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean26 = lineBorder24.equals((java.lang.Object) stackedBarRenderer3D25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.Font font29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font29);
        java.lang.String str31 = textTitle30.getURLText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor34 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor33, textBlockAnchor34);
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        lineBorder24.draw(graphics2D27, rectangle2D32);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D38.setBaseItemLabelPaint((java.awt.Paint) color39);
        double double41 = stackedBarRenderer3D38.getUpperClip();
        java.awt.Shape shape44 = stackedBarRenderer3D38.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity(shape44);
        java.lang.Object obj46 = textTitle19.draw(graphics2D23, rectangle2D32, (java.lang.Object) chartEntity45);
        dateAxis12.setUpArrow((java.awt.Shape) rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets7.createInsetRectangle(rectangle2D32, true, true);
        try {
            java.awt.GradientPaint gradientPaint51 = standardGradientPaintTransformer1.transform(gradientPaint2, (java.awt.Shape) rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(map21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(textBlockAnchor34);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        boolean boolean7 = statisticalLineAndShapeRenderer2.getItemLineVisible(6, 4);
        java.awt.Color color8 = java.awt.Color.WHITE;
        int int9 = color8.getGreen();
        java.awt.Color color10 = color8.darker();
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str7 = categoryAxis6.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font11 = categoryAxis6.getTickLabelFont((java.lang.Comparable) simpleTimePeriod10);
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod10);
        task2.removeSubtask(task12);
        org.jfree.data.time.TimePeriod timePeriod14 = null;
        task2.setDuration(timePeriod14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.awt.Paint paint37 = categoryPlot36.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ChartEntity: tooltip = null", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Comparable comparable4 = keyedObjects0.getKey((int) ' ');
        java.lang.Object obj5 = keyedObjects0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) "http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int3 = dateTickUnit2.getUnit();
        java.lang.String str5 = dateTickUnit2.valueToString((double) 255);
        int int6 = dateTickUnit2.getUnit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D1.setRange(range5, false, true);
        boolean boolean9 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D1.getPlot();
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot36.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot36.getFixedRangeAxisSpace();
        int int42 = categoryPlot36.getRangeAxisCount();
        boolean boolean43 = categoryPlot36.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            xYPlot0.handleClick((-1), (int) (byte) 10, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D1.setBaseItemLabelPaint((java.awt.Paint) color2);
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 9, (short) -1 };
        try {
            float[] floatArray8 = color0.getComponents(colorSpace4, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        int int39 = legendItemCollection38.getItemCount();
        int int40 = legendItemCollection38.getItemCount();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 5 + "'", int40 == 5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        textTitle2.setExpandToFitSpace(true);
        boolean boolean7 = textTitle2.getNotify();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 6, paint5, stroke7);
        double double9 = valueMarker8.getValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker8.getLabelOffsetType();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.0d + "'", double9 == 6.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font7 = categoryAxis2.getTickLabelFont((java.lang.Comparable) simpleTimePeriod6);
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle45.setItemPaint(paint46);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint46, (float) 10, 3, textMeasurer50);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        stackedBarRenderer3D52.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem60 = stackedBarRenderer3D52.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke62 = piePlot61.getLabelLinkStroke();
        stackedBarRenderer3D52.setBaseOutlineStroke(stroke62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str66 = categoryAxis65.getLabelToolTip();
        boolean boolean67 = categoryAxis65.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryAxis65.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder(paint46, stroke62, rectangleInsets68);
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D71 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D71.setIncludeBaseInRange(false);
        java.awt.Paint paint75 = stackedBarRenderer3D71.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = stackedBarRenderer3D71.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = stackedBarRenderer3D71.getPositiveItemLabelPositionFallback();
        boolean boolean80 = stackedBarRenderer3D71.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint81 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D71.setBaseFillPaint(paint81);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot();
        int int84 = xYPlot83.getSeriesCount();
        java.awt.Paint paint85 = xYPlot83.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer86 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint46, (java.awt.Paint) color70, paint81, paint85);
        java.awt.Paint paint87 = waterfallBarRenderer86.getPositiveBarPaint();
        java.awt.Paint paint88 = waterfallBarRenderer86.getLastBarPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset89 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset89.validateObject();
        defaultCategoryDataset89.validateObject();
        boolean boolean92 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset89);
        org.jfree.data.Range range93 = waterfallBarRenderer86.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset89);
        java.awt.Color color94 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        waterfallBarRenderer86.setPositiveBarPaint((java.awt.Paint) color94);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(itemLabelPosition78);
        org.junit.Assert.assertNull(itemLabelPosition79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNull(range93);
        org.junit.Assert.assertNotNull(color94);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor6, textAnchor7, (double) 0);
        textLine0.draw(graphics2D1, 10.0f, (float) (byte) 100, textAnchor6, (float) 9, 0.0f, (double) (byte) 10);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getBaseLinesVisible();
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot36.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot36.getFixedRangeAxisSpace();
        int int42 = categoryPlot36.getDatasetCount();
        java.lang.String str43 = categoryPlot36.getPlotType();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Category Plot" + "'", str43.equals("Category Plot"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Color color1 = java.awt.Color.lightGray;
        levelRenderer0.setBaseOutlinePaint((java.awt.Paint) color1, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setIncludeBaseInRange(false);
        org.jfree.chart.LegendItem legendItem9 = stackedBarRenderer3D4.getLegendItem(0, 9);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator11 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D4.setSeriesToolTipGenerator(5, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator11);
        levelRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) 0);
        double double6 = numberTick5.getValue();
        java.lang.Number number7 = numberTick5.getNumber();
        java.lang.String str8 = numberTick5.toString();
        java.lang.Number number9 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 10 + "'", number9.equals((byte) 10));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        java.lang.Object obj5 = numberAxis3D1.clone();
        boolean boolean6 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D8.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis3D8.getMarkerBand();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D8.setRange(range12, false, true);
        java.lang.String str16 = range12.toString();
        numberAxis3D1.setRangeWithMargins(range12, true, true);
        boolean boolean22 = range12.intersects((double) 86400000L, (double) 12);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[0.0,1.0]" + "'", str16.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        boolean boolean3 = categoryAxis1.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getTickLabelInsets();
        double double6 = rectangleInsets4.calculateLeftInset((double) 10);
        double double7 = rectangleInsets4.getRight();
        double double8 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-16777216), serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        textTitle2.setToolTipText("Category Plot");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) 0);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer8.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer8.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer8.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        statisticalLineAndShapeRenderer8.setBaseShapesVisible(false);
        boolean boolean20 = statisticalLineAndShapeRenderer8.getAutoPopulateSeriesPaint();
        boolean boolean21 = numberTick5.equals((java.lang.Object) statisticalLineAndShapeRenderer8);
        org.jfree.chart.text.TextAnchor textAnchor22 = numberTick5.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation((int) (byte) 100);
        int int10 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot11.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection13);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("12/31/69", "", "ERROR : Relative To String", "SerialDate.weekInMonthToString(): invalid code.", "RectangleAnchor.TOP_RIGHT");
        basicProjectInfo5.setVersion("");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        java.awt.Color color12 = java.awt.Color.lightGray;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color12, true);
        boolean boolean17 = stackedBarRenderer3D0.isItemLabelVisible(6, (int) (byte) 100);
        stackedBarRenderer3D0.setMaximumBarWidth((double) 0.5f);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot36.getDomainGridlinePosition();
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray43 = null;
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset45 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray42, numberArray43, numberArray44);
        java.util.List list46 = defaultIntervalCategoryDataset45.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup47 = defaultIntervalCategoryDataset45.getGroup();
        categoryPlot36.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset45);
        int int49 = categoryPlot36.getRangeAxisCount();
        categoryPlot36.clearAnnotations();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(datasetGroup47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int2 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        float[] floatArray6 = null;
        float[] floatArray7 = java.awt.Color.RGBtoHSB(9, 0, 12, floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB(11, 0, 4, floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        lineAndShapeRenderer2.setUseOutlinePaint(true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class4 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean9 = simpleTimePeriod7.equals((java.lang.Object) 9999);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone11);
        java.util.Date date13 = dateTickUnit3.addToDate(date10);
        keyedObjects2D0.setObject((java.lang.Object) date10, (java.lang.Comparable) 0.05d, (java.lang.Comparable) "hi!");
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
        projectInfo17.addLibrary((org.jfree.chart.ui.Library) projectInfo18);
        java.awt.Image image20 = null;
        projectInfo18.setLogo(image20);
        projectInfo18.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str28 = categoryAxis27.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font32 = categoryAxis27.getTickLabelFont((java.lang.Comparable) simpleTimePeriod31);
        org.jfree.data.gantt.Task task33 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod31);
        keyedObjects2D0.addObject((java.lang.Object) projectInfo18, (java.lang.Comparable) (-16777216), (java.lang.Comparable) simpleTimePeriod31);
        java.lang.Object obj35 = null;
        java.lang.Class class36 = null;
        java.lang.Class class37 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean42 = simpleTimePeriod40.equals((java.lang.Object) 9999);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone44);
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date43, timeZone46);
        java.lang.Class class48 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean53 = simpleTimePeriod51.equals((java.lang.Object) 9999);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone55);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date43, date54);
        keyedObjects2D0.setObject(obj35, (java.lang.Comparable) date54, (java.lang.Comparable) "December 1969");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertNotNull(projectInfo18);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        categoryPlot36.clearRangeMarkers();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        textBlock0.draw(graphics2D1, (float) 9999, 1.0f, textBlockAnchor5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = null;
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D8, (float) 8, (float) (-1L), textBlockAnchor11, 10.0f, (float) 1, 1.0d);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = textBlock0.calculateDimensions(graphics2D16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textBlockAnchor21.toString();
        textBlock0.draw(graphics2D18, (float) 86400000L, (float) 3600000L, textBlockAnchor21, (float) (-1L), (float) (-1), (double) 1969);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine();
        java.lang.Object obj7 = null;
        boolean boolean8 = textLine6.equals(obj7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine6.draw(graphics2D9, (float) ' ', (float) (short) 1, textAnchor12, (float) (byte) 100, (float) 3, (double) (byte) 100);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.BOTTOM_RIGHT", graphics2D1, (float) 8, 1.0f, textAnchor4, (double) 2, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D1.setRange(range5, false, true);
        boolean boolean9 = numberAxis3D1.isPositiveArrowVisible();
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.lang.String str54 = multiplePiePlot2.getPlotType();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Multiple Pie Plot" + "'", str54.equals("Multiple Pie Plot"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) (short) 100, (float) '#', (float) 1L);
        numberAxis3D1.setLeftArrow(shape7);
        double double13 = numberAxis3D1.getFixedDimension();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        xYPlot0.mapDatasetToRangeAxis(15, 0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) (short) 100, (float) '#', (float) 1L);
        numberAxis3D1.setLeftArrow(shape7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D1.getTickLabelInsets();
        java.awt.Stroke stroke14 = numberAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str42 = categoryAxis41.getLabelToolTip();
        categoryAxis41.setCategoryLabelPositionOffset((int) (byte) 0);
        int int45 = categoryPlot36.getDomainAxisIndex(categoryAxis41);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj48 = null;
        boolean boolean49 = dateAxis47.equals(obj48);
        java.awt.Color color50 = java.awt.Color.cyan;
        dateAxis47.setAxisLinePaint((java.awt.Paint) color50);
        dateAxis47.setAutoRange(false);
        org.jfree.data.Range range54 = categoryPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        java.awt.Stroke stroke55 = categoryPlot36.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        java.awt.Paint paint42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle41.setItemPaint(paint42);
        ringPlot2.setSeparatorPaint(paint42);
        ringPlot2.setCircular(false, true);
        java.lang.Comparable comparable48 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 9999, (double) 3, true);
        java.awt.Stroke stroke55 = stackedBarRenderer3D52.getItemOutlineStroke((int) '4', (int) (byte) 10);
        try {
            ringPlot2.setSectionOutlineStroke(comparable48, stroke55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setRangeAxisLocation(axisLocation46, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot45.getDomainAxisForDataset(0);
        categoryPlot45.setNoDataMessage("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D54.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = numberAxis3D54.getMarkerBand();
        java.awt.Color color59 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke61 = piePlot60.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color59, stroke61);
        java.awt.Paint paint63 = categoryMarker62.getLabelPaint();
        java.awt.Font font65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font65);
        java.lang.String str67 = textTitle66.getURLText();
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        stackedBarRenderer3D1.drawRangeMarker(graphics2D8, categoryPlot45, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, (org.jfree.chart.plot.Marker) categoryMarker62, rectangle2D68);
        try {
            categoryPlot45.zoom((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNull(markerAxisBand57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        piePlot0.setLabelLinkMargin((double) (byte) 100);
        double double5 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        java.lang.Object obj5 = numberAxis3D1.clone();
        boolean boolean6 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D8.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis3D8.getMarkerBand();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D8.setRange(range12, false, true);
        java.lang.String str16 = range12.toString();
        numberAxis3D1.setRangeWithMargins(range12, true, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D21.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = numberAxis3D21.getMarkerBand();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D21.setRange(range25, false, true);
        org.jfree.data.Range range29 = org.jfree.data.Range.combine(range12, range25);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[0.0,1.0]" + "'", str16.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNull(markerAxisBand24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperBound((double) 192);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot36.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot36.getRangeAxisForDataset((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot36.getDomainAxisLocation((int) '4');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(categoryItemRenderer42);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedBarRenderer3D0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = stackedBarRenderer3D0.getSeriesPositiveItemLabelPosition(192);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        java.awt.Font font5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        labelBlock2.setFont(font5);
        java.lang.String str8 = labelBlock2.getURLText();
        java.awt.Paint paint9 = labelBlock2.getPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("12/31/69");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        labelBlock11.setPadding(rectangleInsets12);
        labelBlock2.setPadding(rectangleInsets12);
        double double16 = rectangleInsets12.calculateRightInset((double) 4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setIncludeBaseInRange(false);
        java.awt.Shape shape5 = stackedBarRenderer3D1.getSeriesShape(0);
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setIncludeBaseInRange(false);
        java.awt.Paint paint41 = stackedBarRenderer3D37.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D37);
        org.jfree.data.Range range43 = stackedBarRenderer3D1.findRangeBounds(categoryDataset34);
        org.jfree.data.Range range44 = groupedStackedBarRenderer0.findRangeBounds(categoryDataset34);
        java.lang.Object obj45 = groupedStackedBarRenderer0.clone();
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        boolean boolean3 = categoryAxis1.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getTickLabelInsets();
        double double6 = rectangleInsets4.calculateLeftInset((double) 10);
        double double7 = rectangleInsets4.getRight();
        double double9 = rectangleInsets4.calculateTopInset((double) (-1));
        double double11 = rectangleInsets4.calculateBottomOutset(0.0d);
        double double13 = rectangleInsets4.calculateRightOutset((double) 4);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        float float17 = piePlot16.getBackgroundAlpha();
        int int18 = piePlot16.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = null;
        piePlot16.setLabelGenerator(pieSectionLabelGenerator19);
        boolean boolean21 = stackedBarRenderer3D0.hasListener((java.util.EventListener) piePlot16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = stackedBarRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        java.awt.Stroke stroke14 = statisticalLineAndShapeRenderer2.getBaseStroke();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.JFreeChart jFreeChart54 = multiplePiePlot2.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset55 = multiplePiePlot2.getDataset();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(jFreeChart54);
        org.junit.Assert.assertNotNull(categoryDataset55);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod5);
        java.lang.String str7 = task6.getDescription();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font15 = categoryAxis10.getTickLabelFont((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod14);
        task6.removeSubtask(task16);
        task2.addSubtask(task16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean23 = simpleTimePeriod21.equals((java.lang.Object) 9999);
        java.util.Date date24 = simpleTimePeriod21.getEnd();
        task16.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod21);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str29 = categoryAxis28.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font33 = categoryAxis28.getTickLabelFont((java.lang.Comparable) simpleTimePeriod32);
        org.jfree.data.gantt.Task task34 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod32);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer35 = new org.jfree.chart.renderer.category.LevelRenderer();
        boolean boolean36 = simpleTimePeriod32.equals((java.lang.Object) levelRenderer35);
        task16.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str7.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        int int3 = plotRenderingInfo2.getSubplotCount();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.lang.String str2 = areaRendererEndType1.toString();
        areaRenderer0.setEndType(areaRendererEndType1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        boolean boolean8 = dateAxis5.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = null;
        dateAxis5.setStandardTickUnits(tickUnitSource9);
        boolean boolean11 = areaRenderer0.equals((java.lang.Object) tickUnitSource9);
        org.junit.Assert.assertNotNull(areaRendererEndType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str2.equals("AreaRendererEndType.LEVEL"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray7 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setIncludeBaseInRange(false);
        java.awt.Paint paint36 = stackedBarRenderer3D32.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D32.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = stackedBarRenderer3D32.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot(pieDataset41);
        boolean boolean43 = defaultCategoryDataset40.hasListener((java.util.EventListener) ringPlot42);
        boolean boolean44 = stackedBarRenderer3D32.equals((java.lang.Object) defaultCategoryDataset40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class49 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean54 = simpleTimePeriod52.equals((java.lang.Object) 9999);
        java.util.Date date55 = simpleTimePeriod52.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date55, timeZone56);
        java.util.Date date58 = dateTickUnit48.addToDate(date55);
        defaultCategoryDataset40.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date55, (java.lang.Comparable) 4.0d);
        org.jfree.data.Range range61 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double63 = rectangleConstraint62.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = rectangleConstraint62.toFixedHeight((double) 1);
        boolean boolean66 = groupedStackedBarRenderer0.equals((java.lang.Object) rectangleConstraint62);
        double double67 = groupedStackedBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(rectangleConstraint62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot36.setFixedDomainAxisSpace(axisSpace40);
        java.awt.Paint paint42 = categoryPlot36.getDomainGridlinePaint();
        boolean boolean43 = categoryPlot36.isDomainGridlinesVisible();
        double[] doubleArray50 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray55 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray60 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray65 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray70 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray71 = new double[][] { doubleArray50, doubleArray55, doubleArray60, doubleArray65, doubleArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray71);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D75 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D75.setIncludeBaseInRange(false);
        java.awt.Paint paint79 = stackedBarRenderer3D75.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset72, categoryAxis73, valueAxis74, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D75);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator81 = stackedBarRenderer3D75.getLegendItemToolTipGenerator();
        categoryPlot36.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D75, true);
        org.jfree.chart.util.Layer layer84 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection85 = categoryPlot36.getRangeMarkers(layer84);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNull(paint79);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator81);
        org.junit.Assert.assertNotNull(layer84);
        org.junit.Assert.assertNotNull(collection85);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle37.getLegendItemGraphicPadding();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D43.setBaseItemLabelPaint((java.awt.Paint) color44);
        statisticalBarRenderer42.setErrorIndicatorPaint((java.awt.Paint) color44);
        legendTitle37.setBackgroundPaint((java.awt.Paint) color44);
        java.awt.Graphics2D graphics2D48 = null;
        try {
            org.jfree.chart.util.Size2D size2D49 = legendTitle37.arrange(graphics2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str45 = categoryAxis44.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font49 = categoryAxis44.getTickLabelFont((java.lang.Comparable) simpleTimePeriod48);
        java.awt.Paint paint50 = categoryAxis44.getAxisLinePaint();
        categoryPlot36.setDomainAxis(categoryAxis44);
        boolean boolean52 = categoryPlot36.isRangeCrosshairLockedOnData();
        categoryPlot36.clearRangeMarkers();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        jFreeChart53.setBorderVisible(true);
        org.jfree.chart.entity.EntityCollection entityCollection60 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo(entityCollection60);
        try {
            java.awt.image.BufferedImage bufferedImage62 = jFreeChart53.createBufferedImage((-16777216), (int) (byte) 0, (int) (byte) 10, chartRenderingInfo61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16777216) and height (0) must be > 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.Object obj41 = null;
        boolean boolean42 = plotOrientation40.equals(obj41);
        categoryPlot36.setOrientation(plotOrientation40);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot36.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Category Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        categoryPlot36.mapDatasetToRangeAxis(0, (int) (byte) 1);
        java.awt.Stroke stroke40 = categoryPlot36.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean11 = simpleTimePeriod9.equals((java.lang.Object) 9999);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        java.util.Date date15 = dateTickUnit5.addToDate(date12);
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj21 = null;
        boolean boolean22 = dateAxis20.equals(obj21);
        java.util.Date date23 = dateAxis20.getMinimumDate();
        java.util.Date date24 = dateTickUnit5.rollDate(date23);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        double[] doubleArray7 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setIncludeBaseInRange(false);
        java.awt.Paint paint36 = stackedBarRenderer3D32.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D32.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = stackedBarRenderer3D32.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot(pieDataset41);
        boolean boolean43 = defaultCategoryDataset40.hasListener((java.util.EventListener) ringPlot42);
        boolean boolean44 = stackedBarRenderer3D32.equals((java.lang.Object) defaultCategoryDataset40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class49 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean54 = simpleTimePeriod52.equals((java.lang.Object) 9999);
        java.util.Date date55 = simpleTimePeriod52.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date55, timeZone56);
        java.util.Date date58 = dateTickUnit48.addToDate(date55);
        defaultCategoryDataset40.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date55, (java.lang.Comparable) 4.0d);
        org.jfree.data.Range range61 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        int int63 = defaultCategoryDataset40.getColumnIndex((java.lang.Comparable) "TextBlockAnchor.BOTTOM_RIGHT");
        java.lang.Comparable comparable65 = null;
        try {
            defaultCategoryDataset40.setValue((java.lang.Number) 2, comparable65, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str1 = blockContainer0.getID();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.lang.Object obj5 = blockContainer0.draw(graphics2D2, rectangle2D3, (java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        java.awt.Paint paint4 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("12/31/69", graphics2D1, 4.0d, (float) (-1L), (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setIncludeBaseInRange(false);
        java.awt.Paint paint13 = stackedBarRenderer3D9.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D9.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D9.getPositiveItemLabelPositionFallback();
        boolean boolean18 = stackedBarRenderer3D9.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D9.setBaseFillPaint(paint19);
        stackedBarRenderer3D1.setSeriesOutlinePaint(3, paint19);
        stackedBarRenderer3D1.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        java.lang.Object obj2 = null;
        boolean boolean3 = stackedBarRenderer1.equals(obj2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setIncludeBaseInRange(false);
        java.awt.Shape shape8 = stackedBarRenderer3D4.getSeriesShape(0);
        java.awt.Shape shape9 = stackedBarRenderer3D4.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D4.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean14 = categoryAxis13.isTickLabelsVisible();
        float float15 = categoryAxis13.getTickMarkInsideLength();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis13.setTickMarkStroke(stroke16);
        stackedBarRenderer3D4.setSeriesStroke(0, stroke16, false);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        float float21 = piePlot20.getBackgroundAlpha();
        int int22 = piePlot20.getBackgroundImageAlignment();
        boolean boolean23 = stackedBarRenderer3D4.hasListener((java.util.EventListener) piePlot20);
        java.awt.Paint paint24 = piePlot20.getShadowPaint();
        boolean boolean25 = stackedBarRenderer1.equals((java.lang.Object) paint24);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.setNotify(false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        stackedBarRenderer3D0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedBarRenderer3D0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 6.0d, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str6 = blockContainer5.getID();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D9 = flowArrangement4.arrange(blockContainer5, graphics2D7, rectangleConstraint8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        boolean boolean13 = categoryAxis11.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis11.getTickLabelInsets();
        double double16 = rectangleInsets14.calculateBottomInset((double) 100);
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray38 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray43 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray44 = new double[][] { doubleArray23, doubleArray28, doubleArray33, doubleArray38, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D48.setIncludeBaseInRange(false);
        java.awt.Paint paint52 = stackedBarRenderer3D48.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D48);
        categoryPlot53.mapDatasetToRangeAxis(0, (int) (byte) 1);
        double double57 = categoryPlot53.getRangeCrosshairValue();
        boolean boolean58 = rectangleInsets14.equals((java.lang.Object) double57);
        boolean boolean59 = blockContainer5.equals((java.lang.Object) rectangleInsets14);
        double double61 = rectangleInsets14.calculateRightOutset((double) (short) -1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 6, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        valueMarker4.setLabel("JFreeChart");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.0d + "'", double5 == 6.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        int int14 = statisticalLineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge((-16777216));
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str4 = categoryAxis3.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font8 = categoryAxis3.getTickLabelFont((java.lang.Comparable) simpleTimePeriod7);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D40);
        java.awt.Paint paint47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle46.setItemPaint(paint47);
        org.jfree.chart.text.TextMeasurer textMeasurer51 = null;
        org.jfree.chart.text.TextBlock textBlock52 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint47, (float) 10, 3, textMeasurer51);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D53.setIncludeBaseInRange(false);
        stackedBarRenderer3D53.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem61 = stackedBarRenderer3D53.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke63 = piePlot62.getLabelLinkStroke();
        stackedBarRenderer3D53.setBaseOutlineStroke(stroke63);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str67 = categoryAxis66.getLabelToolTip();
        boolean boolean68 = categoryAxis66.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = categoryAxis66.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder70 = new org.jfree.chart.block.LineBorder(paint47, stroke63, rectangleInsets69);
        java.awt.Color color71 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D72 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D72.setIncludeBaseInRange(false);
        java.awt.Paint paint76 = stackedBarRenderer3D72.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = stackedBarRenderer3D72.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition80 = stackedBarRenderer3D72.getPositiveItemLabelPositionFallback();
        boolean boolean81 = stackedBarRenderer3D72.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint82 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D72.setBaseFillPaint(paint82);
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot();
        int int85 = xYPlot84.getSeriesCount();
        java.awt.Paint paint86 = xYPlot84.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer87 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint47, (java.awt.Paint) color71, paint82, paint86);
        java.awt.Paint paint88 = waterfallBarRenderer87.getPositiveBarPaint();
        org.jfree.chart.text.TextBlock textBlock89 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D90 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor93 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor94 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition95 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor93, textBlockAnchor94);
        textBlock89.draw(graphics2D90, (float) 9999, 1.0f, textBlockAnchor94);
        java.awt.Stroke stroke97 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean98 = textBlockAnchor94.equals((java.lang.Object) stroke97);
        org.jfree.chart.plot.CategoryMarker categoryMarker99 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.5f, paint88, stroke97);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(textBlock52);
        org.junit.Assert.assertNull(legendItem61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNull(paint76);
        org.junit.Assert.assertNotNull(itemLabelPosition79);
        org.junit.Assert.assertNull(itemLabelPosition80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(rectangleAnchor93);
        org.junit.Assert.assertNotNull(textBlockAnchor94);
        org.junit.Assert.assertNotNull(stroke97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultIntervalCategoryDataset4.getGroup();
        java.util.List list7 = defaultIntervalCategoryDataset4.getColumnKeys();
        try {
            java.lang.Object obj8 = defaultIntervalCategoryDataset4.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        int int6 = xYPlot0.getDomainAxisCount();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setYOffset((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Stroke stroke18 = stackedBarRenderer3D0.getItemStroke(2, 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray37 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray42 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray47 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray48 = new double[][] { doubleArray27, doubleArray32, doubleArray37, doubleArray42, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        java.awt.Paint paint56 = stackedBarRenderer3D52.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D52);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D52);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str61 = categoryAxis60.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font65 = categoryAxis60.getTickLabelFont((java.lang.Comparable) simpleTimePeriod64);
        legendTitle58.setItemFont(font65);
        boolean boolean67 = chartChangeEventType20.equals((java.lang.Object) font65);
        stackedBarRenderer3D0.setSeriesItemLabelFont(9999, font65);
        stackedBarRenderer3D0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj7 = null;
        boolean boolean8 = dateAxis6.equals(obj7);
        java.util.Date date9 = dateAxis6.getMinimumDate();
        xYPlot0.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font7 = categoryAxis2.getTickLabelFont((java.lang.Comparable) simpleTimePeriod6);
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle45.setItemPaint(paint46);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint46, (float) 10, 3, textMeasurer50);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        stackedBarRenderer3D52.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem60 = stackedBarRenderer3D52.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke62 = piePlot61.getLabelLinkStroke();
        stackedBarRenderer3D52.setBaseOutlineStroke(stroke62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str66 = categoryAxis65.getLabelToolTip();
        boolean boolean67 = categoryAxis65.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryAxis65.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder(paint46, stroke62, rectangleInsets68);
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D71 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D71.setIncludeBaseInRange(false);
        java.awt.Paint paint75 = stackedBarRenderer3D71.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = stackedBarRenderer3D71.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = stackedBarRenderer3D71.getPositiveItemLabelPositionFallback();
        boolean boolean80 = stackedBarRenderer3D71.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint81 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D71.setBaseFillPaint(paint81);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot();
        int int84 = xYPlot83.getSeriesCount();
        java.awt.Paint paint85 = xYPlot83.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer86 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint46, (java.awt.Paint) color70, paint81, paint85);
        java.awt.Stroke stroke87 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder89 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color70, stroke87, rectangleInsets88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(itemLabelPosition78);
        org.junit.Assert.assertNull(itemLabelPosition79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.lang.String str2 = taskSeries1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        org.jfree.chart.plot.PlotState plotState5 = new org.jfree.chart.plot.PlotState();
        java.util.Map map6 = plotState5.getSharedAxisStates();
        boolean boolean7 = textTitle4.equals((java.lang.Object) map6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean11 = lineBorder9.equals((java.lang.Object) stackedBarRenderer3D10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.Font font14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!", font14);
        java.lang.String str16 = textTitle15.getURLText();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle15.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor18, textBlockAnchor19);
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        lineBorder9.draw(graphics2D12, rectangle2D17);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D23.setBaseItemLabelPaint((java.awt.Paint) color24);
        double double26 = stackedBarRenderer3D23.getUpperClip();
        java.awt.Shape shape29 = stackedBarRenderer3D23.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        java.lang.Object obj31 = textTitle4.draw(graphics2D8, rectangle2D17, (java.lang.Object) chartEntity30);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle4);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle4.getBounds();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(map6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation3 = xYPlot0.getRangeAxisLocation(9999);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str4 = categoryAxis3.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font8 = categoryAxis3.getTickLabelFont((java.lang.Comparable) simpleTimePeriod7);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D40);
        java.awt.Paint paint47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle46.setItemPaint(paint47);
        org.jfree.chart.text.TextMeasurer textMeasurer51 = null;
        org.jfree.chart.text.TextBlock textBlock52 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint47, (float) 10, 3, textMeasurer51);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor54 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick56 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 9999, textBlock52, textBlockAnchor53, textAnchor54, (double) (-16777216));
        org.jfree.chart.text.TextBlock textBlock57 = categoryTick56.getLabel();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(textBlock52);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNotNull(textBlock57);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.getCopyright();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = categoryAxis47.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font52 = categoryAxis47.getTickLabelFont((java.lang.Comparable) simpleTimePeriod51);
        legendTitle45.setItemFont(font52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock55 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font52, (java.awt.Paint) color54);
        boolean boolean56 = multiplePiePlot6.equals((java.lang.Object) labelBlock55);
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot6);
        java.awt.Paint paint58 = jFreeChart57.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj62 = chartRenderingInfo61.clone();
        java.awt.image.BufferedImage bufferedImage63 = jFreeChart57.createBufferedImage(12, (int) (short) 10, chartRenderingInfo61);
        projectInfo0.setLogo((java.awt.Image) bufferedImage63);
        java.util.List list65 = null;
        projectInfo0.setContributors(list65);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str3.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(bufferedImage63);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj39 = null;
        boolean boolean40 = dateAxis38.equals(obj39);
        java.awt.Color color41 = java.awt.Color.cyan;
        dateAxis38.setAxisLinePaint((java.awt.Paint) color41);
        java.awt.Font font44 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!", font44);
        org.jfree.chart.plot.PlotState plotState46 = new org.jfree.chart.plot.PlotState();
        java.util.Map map47 = plotState46.getSharedAxisStates();
        boolean boolean48 = textTitle45.equals((java.lang.Object) map47);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean52 = lineBorder50.equals((java.lang.Object) stackedBarRenderer3D51);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.Font font55 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("hi!", font55);
        java.lang.String str57 = textTitle56.getURLText();
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle56.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor60 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition61 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor59, textBlockAnchor60);
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor59);
        lineBorder50.draw(graphics2D53, rectangle2D58);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D64 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D64.setBaseItemLabelPaint((java.awt.Paint) color65);
        double double67 = stackedBarRenderer3D64.getUpperClip();
        java.awt.Shape shape70 = stackedBarRenderer3D64.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity71 = new org.jfree.chart.entity.ChartEntity(shape70);
        java.lang.Object obj72 = textTitle45.draw(graphics2D49, rectangle2D58, (java.lang.Object) chartEntity71);
        dateAxis38.setUpArrow((java.awt.Shape) rectangle2D58);
        boolean boolean74 = xYPlot0.equals((java.lang.Object) dateAxis38);
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot();
        int int76 = xYPlot75.getSeriesCount();
        java.awt.Paint paint77 = xYPlot75.getRangeCrosshairPaint();
        xYPlot0.setDomainTickBandPaint(paint77);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(map47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(textBlockAnchor60);
        org.junit.Assert.assertNotNull(point2D62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNull(obj72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setIncludeBaseInRange(false);
        stackedBarRenderer3D1.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem9 = stackedBarRenderer3D1.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray36 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D41.setIncludeBaseInRange(false);
        java.awt.Paint paint45 = stackedBarRenderer3D41.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D41);
        stackedBarRenderer3D1.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot46);
        java.awt.Paint paint48 = stackedBarRenderer3D1.getBasePaint();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        int int50 = xYPlot49.getSeriesCount();
        java.awt.Paint paint51 = xYPlot49.getRangeCrosshairPaint();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        xYPlot49.setRangeGridlineStroke(stroke52);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D54.setBaseItemLabelPaint((java.awt.Paint) color55);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer59 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint60 = statisticalLineAndShapeRenderer59.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer59.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer59.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalLineAndShapeRenderer59.setBaseOutlineStroke(stroke69);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "rect", paint48, stroke52, (java.awt.Paint) color55, stroke69, (float) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNull(paint60);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj58 = chartRenderingInfo57.clone();
        java.awt.image.BufferedImage bufferedImage59 = jFreeChart53.createBufferedImage(12, (int) (short) 10, chartRenderingInfo57);
        boolean boolean60 = jFreeChart53.isNotify();
        jFreeChart53.setNotify(true);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(bufferedImage59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D6.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis3D6.getMarkerBand();
        java.lang.Object obj10 = numberAxis3D6.clone();
        boolean boolean11 = numberAxis3D6.getAutoRangeIncludesZero();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) stackedBarRenderer3D0, (java.lang.Object) numberAxis3D6);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double14 = range13.getLength();
        numberAxis3D6.setRange(range13, false, true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke11);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo1.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 8, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", 0.2d };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "Range[0.0,1.0]" };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 8.0d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 8.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 8.0d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 8.0d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 8.0d };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray9, numberArray11, numberArray13, numberArray15 };
        java.lang.Number[][] numberArray17 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray3, comparableArray5, numberArray16, numberArray17);
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        boolean boolean6 = dateAxis1.isInverted();
        java.util.TimeZone timeZone7 = null;
        try {
            dateAxis1.setTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        boolean boolean18 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke19 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        try {
            java.lang.Comparable comparable6 = defaultIntervalCategoryDataset4.getSeriesKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        java.lang.Object obj3 = dataPackageResources0.handleGetObject("JFreeChart");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot36.setFixedDomainAxisSpace(axisSpace40);
        int int42 = categoryPlot36.getBackgroundImageAlignment();
        int int43 = categoryPlot36.getDatasetCount();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        int int46 = categoryPlot36.getRangeAxisCount();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) "VerticalAlignment.BOTTOM", (double) (-1.0f));
        java.lang.Comparable comparable4 = null;
        try {
            defaultKeyedValues0.addValue(comparable4, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("CategoryAnchor.START", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Color color1 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color1, stroke3);
        categoryMarker4.setLabel("RectangleAnchor.TOP_RIGHT");
        java.lang.String str7 = categoryMarker4.getLabel();
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle45.setItemPaint(paint46);
        boolean boolean48 = legendTitle45.getNotify();
        double double49 = legendTitle45.getWidth();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D50.setBaseItemLabelPaint((java.awt.Paint) color51);
        legendTitle45.setItemPaint((java.awt.Paint) color51);
        categoryMarker4.setPaint((java.awt.Paint) color51);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str7.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj3 = null;
        boolean boolean4 = dateAxis2.equals(obj3);
        java.awt.Color color5 = java.awt.Color.cyan;
        dateAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font8);
        org.jfree.chart.plot.PlotState plotState10 = new org.jfree.chart.plot.PlotState();
        java.util.Map map11 = plotState10.getSharedAxisStates();
        boolean boolean12 = textTitle9.equals((java.lang.Object) map11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean16 = lineBorder14.equals((java.lang.Object) stackedBarRenderer3D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.lang.String str21 = textTitle20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        lineBorder14.draw(graphics2D17, rectangle2D22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D28.setBaseItemLabelPaint((java.awt.Paint) color29);
        double double31 = stackedBarRenderer3D28.getUpperClip();
        java.awt.Shape shape34 = stackedBarRenderer3D28.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape34);
        java.lang.Object obj36 = textTitle9.draw(graphics2D13, rectangle2D22, (java.lang.Object) chartEntity35);
        dateAxis2.setUpArrow((java.awt.Shape) rectangle2D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D39.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = numberAxis3D39.getMarkerBand();
        numberAxis3D39.setFixedAutoRange((double) 8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer45);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder47 = xYPlot46.getSeriesRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(map11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(markerAxisBand42);
        org.junit.Assert.assertNotNull(seriesRenderingOrder47);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        boolean boolean4 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj7 = null;
        boolean boolean8 = dateAxis6.equals(obj7);
        java.awt.Color color9 = java.awt.Color.cyan;
        dateAxis6.setAxisLinePaint((java.awt.Paint) color9);
        java.lang.String str11 = dateAxis6.getLabelToolTip();
        org.jfree.data.Range range12 = dateAxis6.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range12, false, false);
        try {
            dateAxis1.setRangeWithMargins(6.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = plotOrientation0.equals(obj1);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues3 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues3.setValue((java.lang.Comparable) "VerticalAlignment.BOTTOM", (double) (-1.0f));
        boolean boolean7 = plotOrientation0.equals((java.lang.Object) defaultKeyedValues3);
        java.lang.String str8 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotOrientation.VERTICAL" + "'", str8.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        java.lang.Object obj2 = keyedObjects2D0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj3 = null;
        boolean boolean4 = dateAxis2.equals(obj3);
        java.awt.Color color5 = java.awt.Color.cyan;
        dateAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font8);
        org.jfree.chart.plot.PlotState plotState10 = new org.jfree.chart.plot.PlotState();
        java.util.Map map11 = plotState10.getSharedAxisStates();
        boolean boolean12 = textTitle9.equals((java.lang.Object) map11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean16 = lineBorder14.equals((java.lang.Object) stackedBarRenderer3D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.lang.String str21 = textTitle20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        lineBorder14.draw(graphics2D17, rectangle2D22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D28.setBaseItemLabelPaint((java.awt.Paint) color29);
        double double31 = stackedBarRenderer3D28.getUpperClip();
        java.awt.Shape shape34 = stackedBarRenderer3D28.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape34);
        java.lang.Object obj36 = textTitle9.draw(graphics2D13, rectangle2D22, (java.lang.Object) chartEntity35);
        dateAxis2.setUpArrow((java.awt.Shape) rectangle2D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D39.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = numberAxis3D39.getMarkerBand();
        numberAxis3D39.setFixedAutoRange((double) 8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer45);
        dateAxis2.setAutoRangeMinimumSize((double) (byte) 10, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(map11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(markerAxisBand42);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        try {
            defaultCategoryDataset0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.clearRangeMarkers();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset43 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot(pieDataset44);
        boolean boolean46 = defaultCategoryDataset43.hasListener((java.util.EventListener) ringPlot45);
        double[] doubleArray53 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray58 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray63 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray68 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray73 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray74 = new double[][] { doubleArray53, doubleArray58, doubleArray63, doubleArray68, doubleArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray74);
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D78 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D78.setIncludeBaseInRange(false);
        java.awt.Paint paint82 = stackedBarRenderer3D78.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset75, categoryAxis76, valueAxis77, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D78);
        org.jfree.chart.title.LegendTitle legendTitle84 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D78);
        java.awt.Paint paint85 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle84.setItemPaint(paint85);
        ringPlot45.setSeparatorPaint(paint85);
        ringPlot45.setCircular(false, true);
        org.jfree.data.general.Dataset dataset91 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent92 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) ringPlot45, dataset91);
        categoryPlot36.datasetChanged(datasetChangeEvent92);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNull(paint82);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        boolean boolean18 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot20.setRenderer(100, xYItemRenderer22);
        xYPlot20.clearRangeMarkers(0);
        xYPlot20.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot20.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot20.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation(0, axisLocation30);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.lang.String str7 = textTitle6.getURLText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        lineBorder0.draw(graphics2D3, rectangle2D8);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.UnitType unitType15 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.general.WaferMapDataset waferMapDataset16 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset16);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        waferMapPlot17.setDataset(waferMapDataset18);
        waferMapPlot17.setNoDataMessage("VerticalAlignment.BOTTOM");
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.Font font24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font24);
        java.lang.String str26 = textTitle25.getURLText();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle25.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke29 = xYPlot28.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        int int31 = xYPlot28.indexOf(xYDataset30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = xYPlot28.getOrientation();
        java.awt.Graphics2D graphics2D33 = null;
        double[] doubleArray40 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray45 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray50 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray55 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray60 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray61 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D65.setIncludeBaseInRange(false);
        java.awt.Paint paint69 = stackedBarRenderer3D65.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis64, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D65);
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D65);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle71.setItemPaint(paint72);
        boolean boolean74 = legendTitle71.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = legendTitle71.getLegendItemGraphicPadding();
        java.awt.geom.Rectangle2D rectangle2D76 = legendTitle71.getBounds();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = null;
        java.awt.geom.Point2D point2D79 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D77, rectangleAnchor78);
        org.jfree.chart.plot.PlotState plotState80 = new org.jfree.chart.plot.PlotState();
        java.util.Map map81 = plotState80.getSharedAxisStates();
        java.util.Map map82 = plotState80.getSharedAxisStates();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        xYPlot28.draw(graphics2D33, rectangle2D76, point2D79, plotState80, plotRenderingInfo83);
        org.jfree.chart.plot.PlotState plotState85 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        waferMapPlot17.draw(graphics2D22, rectangle2D27, point2D79, plotState85, plotRenderingInfo86);
        boolean boolean88 = unitType15.equals((java.lang.Object) rectangle2D27);
        lineBorder0.draw(graphics2D14, rectangle2D27);
        java.awt.Paint paint90 = lineBorder0.getPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(point2D79);
        org.junit.Assert.assertNotNull(map81);
        org.junit.Assert.assertNotNull(map82);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(paint90);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str42 = categoryAxis41.getLabelToolTip();
        categoryAxis41.setCategoryLabelPositionOffset((int) (byte) 0);
        int int45 = categoryPlot36.getDomainAxisIndex(categoryAxis41);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj48 = null;
        boolean boolean49 = dateAxis47.equals(obj48);
        java.awt.Color color50 = java.awt.Color.cyan;
        dateAxis47.setAxisLinePaint((java.awt.Paint) color50);
        dateAxis47.setAutoRange(false);
        org.jfree.data.Range range54 = categoryPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis47.getTickUnit();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(dateTickUnit55);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D34);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str43 = categoryAxis42.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font47 = categoryAxis42.getTickLabelFont((java.lang.Comparable) simpleTimePeriod46);
        legendTitle40.setItemFont(font47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font47, (java.awt.Paint) color49);
        boolean boolean51 = multiplePiePlot1.equals((java.lang.Object) labelBlock50);
        multiplePiePlot1.setBackgroundImageAlpha(1.0f);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        numberAxis3D1.setFixedAutoRange((double) 8);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range9);
        boolean boolean11 = dateAxis8.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj14 = null;
        boolean boolean15 = dateAxis13.equals(obj14);
        java.awt.Color color16 = java.awt.Color.cyan;
        dateAxis13.setAxisLinePaint((java.awt.Paint) color16);
        java.lang.String str18 = dateAxis13.getLabelToolTip();
        org.jfree.data.Range range19 = dateAxis13.getDefaultAutoRange();
        dateAxis8.setRangeWithMargins(range19, false, false);
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range19, (double) (byte) 1);
        numberAxis3D1.setRange(range24);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        org.jfree.chart.plot.PlotState plotState9 = new org.jfree.chart.plot.PlotState();
        java.util.Map map10 = plotState9.getSharedAxisStates();
        boolean boolean11 = textTitle8.equals((java.lang.Object) map10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean15 = lineBorder13.equals((java.lang.Object) stackedBarRenderer3D14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        java.lang.String str20 = textTitle19.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23);
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor22);
        lineBorder13.draw(graphics2D16, rectangle2D21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D27.setBaseItemLabelPaint((java.awt.Paint) color28);
        double double30 = stackedBarRenderer3D27.getUpperClip();
        java.awt.Shape shape33 = stackedBarRenderer3D27.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape33);
        java.lang.Object obj35 = textTitle8.draw(graphics2D12, rectangle2D21, (java.lang.Object) chartEntity34);
        dateAxis1.setUpArrow((java.awt.Shape) rectangle2D21);
        double double37 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(map10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        textBlock5.draw(graphics2D6, (float) 9999, 1.0f, textBlockAnchor10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D13.setIncludeBaseInRange(false);
        java.awt.Paint paint17 = stackedBarRenderer3D13.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedBarRenderer3D13.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition20.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str24 = categoryLabelWidthType23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor10, textAnchor21, (double) 10, categoryLabelWidthType23, (float) 3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class31 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean36 = simpleTimePeriod34.equals((java.lang.Object) 9999);
        java.util.Date date37 = simpleTimePeriod34.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date37, timeZone38);
        java.util.Date date40 = dateTickUnit30.addToDate(date37);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick48 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 12.0d, "12/31/69", textAnchor45, textAnchor46, (double) 15);
        org.jfree.chart.axis.DateTick dateTick50 = new org.jfree.chart.axis.DateTick(date37, "CategoryLabelWidthType.RANGE", textAnchor42, textAnchor45, (double) 0.5f);
        try {
            java.awt.Shape shape51 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.BOTTOM", graphics2D1, 0.0f, (float) (byte) -1, textAnchor21, (double) 900000L, textAnchor45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str24.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(textAnchor46);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D6.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis3D6.getMarkerBand();
        java.lang.Object obj10 = numberAxis3D6.clone();
        boolean boolean11 = numberAxis3D6.getAutoRangeIncludesZero();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) stackedBarRenderer3D0, (java.lang.Object) numberAxis3D6);
        double double13 = stackedBarRenderer3D0.getBase();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setXOffset((double) 2958465);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str7 = categoryAxis6.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font11 = categoryAxis6.getTickLabelFont((java.lang.Comparable) simpleTimePeriod10);
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod10);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer13 = new org.jfree.chart.renderer.category.LevelRenderer();
        boolean boolean14 = simpleTimePeriod10.equals((java.lang.Object) levelRenderer13);
        defaultStatisticalCategoryDataset0.add((double) 0.5f, (double) 5, (java.lang.Comparable) false, (java.lang.Comparable) simpleTimePeriod10);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedBarRenderer3D0.setSeriesURLGenerator(11, categoryURLGenerator13);
        boolean boolean15 = stackedBarRenderer3D0.isDrawBarOutline();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        boolean boolean4 = xYPlot0.isDomainZoomable();
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("LGPL");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation3 = xYPlot0.getRangeAxisLocation(9999);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font6);
        org.jfree.chart.plot.PlotState plotState8 = new org.jfree.chart.plot.PlotState();
        java.util.Map map9 = plotState8.getSharedAxisStates();
        boolean boolean10 = textTitle7.equals((java.lang.Object) map9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = lineBorder12.equals((java.lang.Object) stackedBarRenderer3D13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        java.lang.String str19 = textTitle18.getURLText();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor21, textBlockAnchor22);
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        lineBorder12.draw(graphics2D15, rectangle2D20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D26.setBaseItemLabelPaint((java.awt.Paint) color27);
        double double29 = stackedBarRenderer3D26.getUpperClip();
        java.awt.Shape shape32 = stackedBarRenderer3D26.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        java.lang.Object obj34 = textTitle7.draw(graphics2D11, rectangle2D20, (java.lang.Object) chartEntity33);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "");
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(map9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(obj34);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.2d, (double) (short) -1);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getMean();
        java.lang.Number number5 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.2d + "'", number3.equals(0.2d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.2d + "'", number4.equals(0.2d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.2d + "'", number5.equals(0.2d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle37.getLegendItemGraphicPadding();
        double double43 = rectangleInsets41.extendHeight((double) 10L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 14.0d + "'", double43 == 14.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setRange(1.0d, (double) 3);
        org.jfree.data.RangeType rangeType5 = numberAxis3D1.getRangeType();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        int int7 = xYPlot6.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot6.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot6.getDomainAxisForDataset(0);
        xYPlot6.setDomainCrosshairVisible(true);
        double double14 = xYPlot6.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot6.getDomainAxisLocation();
        boolean boolean16 = rangeType5.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        xYPlot6.setRenderer(11, xYItemRenderer18);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot36.setDomainGridlinePaint(paint40);
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray64 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray69 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray70 = new double[][] { doubleArray49, doubleArray54, doubleArray59, doubleArray64, doubleArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray70);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D74 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D74.setIncludeBaseInRange(false);
        java.awt.Paint paint78 = stackedBarRenderer3D74.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, valueAxis73, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D74);
        org.jfree.chart.axis.AxisLocation axisLocation80 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot79.setRangeAxisLocation(axisLocation80, false);
        categoryPlot36.setDomainAxisLocation(9, axisLocation80, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder85 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot36.setDatasetRenderingOrder(datasetRenderingOrder85);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNull(paint78);
        org.junit.Assert.assertNotNull(axisLocation80);
        org.junit.Assert.assertNotNull(datasetRenderingOrder85);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Number number3 = null;
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        java.util.List list9 = textBlock8.getLines();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 192, (java.lang.Number) 6, (java.lang.Number) 86400000L, number3, (java.lang.Number) 86400000L, (java.lang.Number) 100L, (java.lang.Number) (short) 1, (java.lang.Number) 0.0d, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMedian();
        java.lang.Number number12 = boxAndWhiskerItem10.getMaxOutlier();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean15 = lineBorder13.equals((java.lang.Object) stackedBarRenderer3D14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D17.setBaseItemLabelPaint((java.awt.Paint) color18);
        stackedBarRenderer3D14.setSeriesPaint(0, (java.awt.Paint) color18);
        boolean boolean21 = boxAndWhiskerItem10.equals((java.lang.Object) color18);
        java.lang.Number number22 = boxAndWhiskerItem10.getQ3();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 6 + "'", number11.equals(6));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace10 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot11.getRangeAxisForDataset(0);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = xYPlot11.getRangeMarkers(9999, layer16);
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer16);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        int int40 = categoryPlot36.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D42.setIncludeBaseInRange(false);
        java.awt.Shape shape46 = stackedBarRenderer3D42.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D47.setBaseItemLabelPaint((java.awt.Paint) color48);
        double double50 = stackedBarRenderer3D47.getUpperClip();
        java.awt.Shape shape53 = stackedBarRenderer3D47.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D42.setBaseShape(shape53);
        categoryPlot36.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot36.getDomainAxisEdge(11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
        org.junit.Assert.assertNull(shape46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray4, numberArray5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.LEFT", "", numberArray5);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 900000L, (-1), 1.0d };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray11 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray5, numberArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.String str8 = chartEntity7.getShapeType();
        java.lang.String str9 = chartEntity7.toString();
        java.lang.String str10 = chartEntity7.getShapeCoords();
        java.lang.Object obj11 = null;
        boolean boolean12 = chartEntity7.equals(obj11);
        java.lang.String str13 = chartEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "rect" + "'", str8.equals("rect"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = null" + "'", str9.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-3,-3,3,3" + "'", str10.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-3,-3,3,3" + "'", str13.equals("-3,-3,3,3"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean5 = simpleTimePeriod3.equals((java.lang.Object) 9999);
        java.util.Date date6 = simpleTimePeriod3.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        java.lang.Number number9 = null;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue10 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) regularTimePeriod8, number9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        java.awt.Graphics2D graphics2D3 = null;
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot40.getDomainAxisForDataset(0);
        categoryPlot40.setNoDataMessage("hi!");
        org.jfree.chart.plot.Plot plot48 = categoryPlot40.getParent();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        categoryPlot40.setFixedRangeAxisSpace(axisSpace49);
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.Font font54 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("hi!", font54);
        java.lang.String str56 = textTitle55.getURLText();
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle55.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor59 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition60 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor58, textBlockAnchor59);
        java.awt.geom.Point2D point2D61 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D57, rectangleAnchor58);
        lineBorder51.draw(graphics2D52, rectangle2D57);
        try {
            boxAndWhiskerRenderer0.drawOutline(graphics2D3, categoryPlot40, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNull(plot48);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(textBlockAnchor59);
        org.junit.Assert.assertNotNull(point2D61);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRenderer();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean6 = simpleTimePeriod4.equals((java.lang.Object) 9999);
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", (org.jfree.data.time.TimePeriod) simpleTimePeriod4);
        boolean boolean8 = waterfallBarRenderer0.equals((java.lang.Object) task7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        double double41 = legendTitle37.getWidth();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D42.setBaseItemLabelPaint((java.awt.Paint) color43);
        legendTitle37.setItemPaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = legendTitle37.getItemPaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        double double4 = categoryLabelPosition3.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str11 = categoryLabelWidthType10.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7, textAnchor8, (double) 2958465, categoryLabelWidthType10, (float) 2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions5, categoryLabelPosition13);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str11.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.Object obj41 = null;
        boolean boolean42 = plotOrientation40.equals(obj41);
        categoryPlot36.setOrientation(plotOrientation40);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot36.setDomainAxisLocation(axisLocation44);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
        categoryPlot36.datasetChanged(datasetChangeEvent46);
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot36.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(sortOrder48);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        int int40 = categoryPlot36.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D42.setIncludeBaseInRange(false);
        java.awt.Shape shape46 = stackedBarRenderer3D42.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D47.setBaseItemLabelPaint((java.awt.Paint) color48);
        double double50 = stackedBarRenderer3D47.getUpperClip();
        java.awt.Shape shape53 = stackedBarRenderer3D47.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D42.setBaseShape(shape53);
        categoryPlot36.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot36.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
        org.junit.Assert.assertNull(shape46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D6.setFixedAutoRange(0.0d);
        java.awt.Shape shape9 = numberAxis3D6.getDownArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int15 = lineAndShapeRenderer14.getPassCount();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setIncludeBaseInRange(false);
        java.awt.Paint paint20 = stackedBarRenderer3D16.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = stackedBarRenderer3D16.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedBarRenderer3D16.getPositiveItemLabelPositionFallback();
        boolean boolean25 = stackedBarRenderer3D16.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D16.setBaseFillPaint(paint26);
        java.awt.Color color28 = java.awt.Color.lightGray;
        stackedBarRenderer3D16.setBasePaint((java.awt.Paint) color28, true);
        lineAndShapeRenderer14.setBasePaint((java.awt.Paint) color28, true);
        java.awt.Color color34 = java.awt.Color.blue;
        java.awt.Color color35 = color34.brighter();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = stackedBarRenderer3D36.getPlot();
        stackedBarRenderer3D36.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = null;
        stackedBarRenderer3D36.setBaseItemLabelGenerator(categoryItemLabelGenerator40, false);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D36.setBaseStroke(stroke43);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer46 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double47 = levelRenderer46.getItemMargin();
        java.awt.Shape shape48 = levelRenderer46.getBaseShape();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        int int50 = xYPlot49.getSeriesCount();
        java.awt.Paint paint51 = xYPlot49.getRangeCrosshairPaint();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        xYPlot49.setRangeGridlineStroke(stroke52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj56 = null;
        boolean boolean57 = dateAxis55.equals(obj56);
        java.awt.Color color58 = java.awt.Color.cyan;
        dateAxis55.setAxisLinePaint((java.awt.Paint) color58);
        java.awt.Color color60 = java.awt.Color.BLACK;
        dateAxis55.setTickLabelPaint((java.awt.Paint) color60);
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "Preceding", "Multiple Pie Plot", "JFreeChart", true, shape9, false, (java.awt.Paint) color28, true, (java.awt.Paint) color35, stroke43, false, shape48, stroke52, (java.awt.Paint) color60);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 11, (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(true);
        boolean boolean7 = statisticalLineAndShapeRenderer2.getItemLineVisible(6, 4);
        try {
            statisticalLineAndShapeRenderer2.setSeriesShapesVisible((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setIncludeBaseInRange(false);
        java.awt.Paint paint41 = stackedBarRenderer3D37.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D37);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot42.setRangeAxisLocation(axisLocation43, false);
        int int46 = categoryPlot42.getBackgroundImageAlignment();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot42);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = null;
        categoryPlot42.notifyListeners(plotChangeEvent48);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 1.0f, comparable2);
        int int4 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        java.lang.Object obj5 = numberAxis3D1.clone();
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray37 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray38 = new double[][] { doubleArray17, doubleArray22, doubleArray27, doubleArray32, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D42.setIncludeBaseInRange(false);
        java.awt.Paint paint46 = stackedBarRenderer3D42.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D42);
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D42);
        java.awt.Font font49 = legendTitle48.getItemFont();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.TOP_RIGHT", font49);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) 0L, (double) (byte) 0, (double) 100L, (double) 0.5f, font49);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray32 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D37.setIncludeBaseInRange(false);
        java.awt.Paint paint41 = stackedBarRenderer3D37.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D37);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot42.setRangeAxisLocation(axisLocation43, false);
        int int46 = categoryPlot42.getBackgroundImageAlignment();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot42);
        categoryAxis1.setLowerMargin(0.5d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.red;
        piePlot0.setShadowPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj3 = null;
        boolean boolean4 = dateAxis2.equals(obj3);
        java.awt.Color color5 = java.awt.Color.cyan;
        dateAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font8);
        org.jfree.chart.plot.PlotState plotState10 = new org.jfree.chart.plot.PlotState();
        java.util.Map map11 = plotState10.getSharedAxisStates();
        boolean boolean12 = textTitle9.equals((java.lang.Object) map11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean16 = lineBorder14.equals((java.lang.Object) stackedBarRenderer3D15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.lang.String str21 = textTitle20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        lineBorder14.draw(graphics2D17, rectangle2D22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D28.setBaseItemLabelPaint((java.awt.Paint) color29);
        double double31 = stackedBarRenderer3D28.getUpperClip();
        java.awt.Shape shape34 = stackedBarRenderer3D28.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape34);
        java.lang.Object obj36 = textTitle9.draw(graphics2D13, rectangle2D22, (java.lang.Object) chartEntity35);
        dateAxis2.setUpArrow((java.awt.Shape) rectangle2D22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D39.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = numberAxis3D39.getMarkerBand();
        numberAxis3D39.setFixedAutoRange((double) 8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = dateAxis2.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(map11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(markerAxisBand42);
        org.junit.Assert.assertNotNull(rectangleInsets47);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.image.BufferedImage bufferedImage56 = jFreeChart53.createBufferedImage(1, (int) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection59 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo(entityCollection59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = chartRenderingInfo60.getPlotInfo();
        java.awt.image.BufferedImage bufferedImage62 = jFreeChart53.createBufferedImage((int) (byte) 1, (int) 'a', chartRenderingInfo60);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(bufferedImage56);
        org.junit.Assert.assertNotNull(plotRenderingInfo61);
        org.junit.Assert.assertNotNull(bufferedImage62);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        try {
            int int5 = defaultIntervalCategoryDataset4.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue(0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        boolean boolean16 = stackedBarRenderer3D0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        org.jfree.chart.entity.EntityCollection entityCollection58 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo(entityCollection58);
        chartRenderingInfo59.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = chartRenderingInfo59.getPlotInfo();
        java.awt.image.BufferedImage bufferedImage62 = jFreeChart53.createBufferedImage(9, 255, 9, chartRenderingInfo59);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(plotRenderingInfo61);
        org.junit.Assert.assertNotNull(bufferedImage62);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        java.awt.Font font42 = legendTitle41.getItemFont();
        java.awt.Font font44 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("hi!", font44);
        java.lang.String str46 = labelBlock45.getToolTipText();
        java.awt.Font font48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("hi!", font48);
        labelBlock45.setFont(font48);
        java.lang.String str51 = labelBlock45.getURLText();
        java.awt.Paint paint52 = labelBlock45.getPaint();
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("", font42, paint52);
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        int int55 = xYPlot54.getSeriesCount();
        java.awt.Paint paint56 = xYPlot54.getRangeCrosshairPaint();
        org.jfree.chart.text.TextBlock textBlock57 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.TOP_RIGHT", font42, paint56);
        org.jfree.chart.text.TextFragment textFragment58 = new org.jfree.chart.text.TextFragment("Size2D[width=8.0, height=0.0]", font42);
        java.awt.Font font59 = textFragment58.getFont();
        java.awt.Color color60 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextBlock textBlock61 = org.jfree.chart.text.TextUtilities.createTextBlock("December 1969", font59, (java.awt.Paint) color60);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(textBlock57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(textBlock61);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Class class4 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean10 = simpleTimePeriod8.equals((java.lang.Object) 9999);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date11, timeZone14);
        java.lang.Class class16 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean21 = simpleTimePeriod19.equals((java.lang.Object) 9999);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date22, timeZone23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) simpleTimePeriod25, (double) '#', (int) (byte) 10);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(pieDataset28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        java.awt.Shape shape4 = numberAxis3D1.getDownArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = defaultCategoryDataset6.hasListener((java.util.EventListener) ringPlot8);
        java.lang.Object obj10 = defaultCategoryDataset6.clone();
        legendItemEntity5.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset6);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setAutoPopulateSeriesShape(false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) 1L);
        java.awt.Font font3 = ringPlot0.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str44 = categoryAxis43.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font48 = categoryAxis43.getTickLabelFont((java.lang.Comparable) simpleTimePeriod47);
        legendTitle41.setItemFont(font48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font48, (java.awt.Paint) color50);
        boolean boolean52 = multiplePiePlot2.equals((java.lang.Object) labelBlock51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("AreaRendererEndType.LEVEL", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj58 = chartRenderingInfo57.clone();
        java.awt.image.BufferedImage bufferedImage59 = jFreeChart53.createBufferedImage(12, (int) (short) 10, chartRenderingInfo57);
        boolean boolean60 = jFreeChart53.isNotify();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D61.setBaseItemLabelPaint((java.awt.Paint) color62);
        double double64 = stackedBarRenderer3D61.getUpperClip();
        stackedBarRenderer3D61.setSeriesVisible(6, (java.lang.Boolean) true, true);
        java.awt.Paint paint69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        stackedBarRenderer3D61.setBaseFillPaint(paint69);
        jFreeChart53.setBorderPaint(paint69);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(bufferedImage59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        ringPlot2.setSeparatorsVisible(false);
        double double6 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        ringPlot2.setToolTipGenerator(pieToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        xYPlot1.setRenderer(100, xYItemRenderer3);
        xYPlot1.clearRangeMarkers(0);
        xYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot1.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot1.getFixedDomainAxisSpace();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot1.setDomainGridlineStroke(stroke12);
        boolean boolean14 = textAnchor0.equals((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke2 = xYPlot1.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot1.indexOf(xYDataset3);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot1.getOrientation();
        xYPlot1.setRangeZeroBaselineVisible(false);
        java.awt.Color color8 = java.awt.Color.black;
        xYPlot1.setDomainGridlinePaint((java.awt.Paint) color8);
        boolean boolean10 = centerArrangement0.equals((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) 'a', 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot6.getLabelDistributor();
        ringPlot2.setLabelDistributor(abstractPieLabelDistributor7);
        double double9 = ringPlot2.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Shape shape5 = stackedBarRenderer3D0.getBaseShape();
        double double6 = stackedBarRenderer3D0.getItemMargin();
        java.awt.Paint paint7 = stackedBarRenderer3D0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D8.setIncludeBaseInRange(false);
        java.awt.Paint paint12 = stackedBarRenderer3D8.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedBarRenderer3D8.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation3 = xYPlot0.getRangeAxisLocation(9999);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        double double5 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        boolean boolean4 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int8 = dateTickUnit7.getRollCount();
        dateAxis1.setTickUnit(dateTickUnit7);
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray36 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray37 = new double[][] { doubleArray16, doubleArray21, doubleArray26, doubleArray31, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D41.setIncludeBaseInRange(false);
        java.awt.Paint paint45 = stackedBarRenderer3D41.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D41);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot46.setRangeAxisLocation(axisLocation47, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.Object obj51 = null;
        boolean boolean52 = plotOrientation50.equals(obj51);
        categoryPlot46.setOrientation(plotOrientation50);
        int int54 = dateTickUnit7.compareTo((java.lang.Object) categoryPlot46);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        java.util.List list4 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        textBlock0.draw(graphics2D1, (float) 9999, 1.0f, textBlockAnchor5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = null;
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D8, (float) 8, (float) (-1L), textBlockAnchor11, 10.0f, (float) 1, 1.0d);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = textBlock0.calculateDimensions(graphics2D16);
        double double18 = size2D17.height;
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        double double4 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.Number number3 = null;
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        java.util.List list9 = textBlock8.getLines();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 192, (java.lang.Number) 6, (java.lang.Number) 86400000L, number3, (java.lang.Number) 86400000L, (java.lang.Number) 100L, (java.lang.Number) (short) 1, (java.lang.Number) 0.0d, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMedian();
        java.lang.Number number12 = boxAndWhiskerItem10.getMean();
        java.util.List list13 = boxAndWhiskerItem10.getOutliers();
        java.lang.Number number14 = boxAndWhiskerItem10.getMedian();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 6 + "'", number11.equals(6));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 192 + "'", number12.equals(192));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 6 + "'", number14.equals(6));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Shape shape5 = stackedBarRenderer3D0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean10 = categoryAxis9.isTickLabelsVisible();
        float float11 = categoryAxis9.getTickMarkInsideLength();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis9.setTickMarkStroke(stroke12);
        stackedBarRenderer3D0.setSeriesStroke(0, stroke12, false);
        int int16 = stackedBarRenderer3D0.getPassCount();
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 11);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        areaRenderer0.setEndType(areaRendererEndType1);
        org.jfree.chart.LegendItem legendItem5 = areaRenderer0.getLegendItem((int) (byte) 0, 2958465);
        org.jfree.chart.LegendItem legendItem8 = areaRenderer0.getLegendItem(192, (int) (byte) 10);
        java.awt.Stroke stroke10 = areaRenderer0.lookupSeriesOutlineStroke(4);
        org.junit.Assert.assertNotNull(areaRendererEndType1);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.lang.Object obj2 = taskSeries1.clone();
        java.lang.String str3 = taskSeries1.getDescription();
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot40.getDomainGridlinePosition();
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray47 = null;
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset49 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray46, numberArray47, numberArray48);
        java.util.List list50 = defaultIntervalCategoryDataset49.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup51 = defaultIntervalCategoryDataset49.getGroup();
        categoryPlot40.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset49);
        taskSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultIntervalCategoryDataset49);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertNotNull(datasetGroup51);
    }
}

