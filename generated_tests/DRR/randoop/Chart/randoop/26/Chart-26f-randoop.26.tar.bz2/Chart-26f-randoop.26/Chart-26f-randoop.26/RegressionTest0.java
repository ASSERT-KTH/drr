import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, (float) (byte) -1, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.util.Date date3 = null;
        try {
            java.lang.String str4 = dateTickUnit2.dateToString(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 0, 10L, 1.0f, (-1L) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0, 10L, 1.0f, (-1L) };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0, 10L, 1.0f, (-1L) };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] {};
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset17 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray15, numberArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = null;
        stackedBarRenderer3D0.setSeriesStroke((int) (short) 0, stroke2, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D0.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (byte) 10, (float) 0L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int3 = java.awt.Color.HSBtoRGB((float) 100, (float) 1L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setIncludeBaseInRange(false);
        java.awt.Paint paint5 = stackedBarRenderer3D1.getSeriesFillPaint((int) (byte) 0);
        boolean boolean6 = unitType0.equals((java.lang.Object) paint5);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke1 = null;
        try {
            stackedBarRenderer3D0.setBaseOutlineStroke(stroke1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.util.Date date3 = null;
        try {
            java.util.Date date4 = dateTickUnit2.addToDate(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = null;
        stackedBarRenderer3D0.setSeriesStroke((int) (short) 0, stroke2, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        try {
            stackedBarRenderer3D0.setPlot(categoryPlot5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.red;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = textBlockAnchor0.equals(obj2);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        try {
            categoryPlot36.handleClick((int) '4', (int) ' ', plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) color8);
        try {
            stackedBarRenderer3D0.setSeriesItemLabelPaint((-1), (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextBlockAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextBlockAnchor.BOTTOM_RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color3, (float) ' ', (int) (short) 100, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.lang.Object obj37 = stackedBarRenderer3D31.clone();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        double double7 = stackedBarRenderer3D4.getUpperClip();
        java.awt.Shape shape10 = stackedBarRenderer3D4.getItemShape((int) '4', (int) (byte) -1);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "", "SerialDate.weekInMonthToString(): invalid code.", "", shape10, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "hi!", textAnchor2, textAnchor3, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) '#');
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D6.setIncludeBaseInRange(false);
        java.awt.Paint paint10 = stackedBarRenderer3D6.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D6.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        try {
            stackedBarRenderer3D0.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Number[] numberArray0 = new java.lang.Number[] {};
        java.lang.Number[] numberArray1 = new java.lang.Number[] {};
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray0, numberArray1, numberArray2, numberArray3, numberArray4, numberArray5 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (byte) 100 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) 100 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (byte) 100 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray8, numberArray10, numberArray12, numberArray14, numberArray16 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray6, numberArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.plot.Marker marker40 = null;
        try {
            categoryPlot36.addRangeMarker(marker40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset28);
        try {
            java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextBlockAnchor.BOTTOM_RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot36.setDomainGridlinePaint(paint40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = null;
        try {
            categoryPlot36.setAxisOffset(rectangleInsets42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getParent();
        try {
            java.lang.Object obj3 = plot2.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        org.jfree.chart.plot.Marker marker47 = null;
        try {
            categoryPlot45.addRangeMarker(marker47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color5);
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color5 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D8.setIncludeBaseInRange(false);
        java.awt.Shape shape12 = stackedBarRenderer3D8.getSeriesShape(0);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D8.setBasePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setIncludeBaseInRange(false);
        java.awt.Shape shape19 = stackedBarRenderer3D15.getSeriesShape(0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D15.setBasePaint((java.awt.Paint) color20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color13, color20, color22 };
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray23, paintArray24, strokeArray25, strokeArray26, shapeArray27);
        try {
            java.awt.Stroke stroke29 = defaultDrawingSupplier28.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D5.setBaseItemLabelPaint((java.awt.Paint) color6);
        double double8 = stackedBarRenderer3D5.getUpperClip();
        java.awt.Shape shape11 = stackedBarRenderer3D5.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D0.setBaseShape(shape11);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        boolean boolean4 = stackedBarRenderer3D0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("TextBlockAnchor.BOTTOM_RIGHT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setIncludeBaseInRange(false);
        java.awt.Paint paint40 = stackedBarRenderer3D36.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D36);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot41.setRangeAxisLocation(axisLocation42, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot41.getDomainAxisForDataset(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        double[] doubleArray55 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray60 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray65 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray70 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray75 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray76 = new double[][] { doubleArray55, doubleArray60, doubleArray65, doubleArray70, doubleArray75 };
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray76);
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = null;
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D80 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D80.setIncludeBaseInRange(false);
        java.awt.Paint paint84 = stackedBarRenderer3D80.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot(categoryDataset77, categoryAxis78, valueAxis79, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D80);
        try {
            stackedBarRenderer1.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot41, categoryAxis47, valueAxis48, categoryDataset77, (int) (byte) 1, (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
        org.junit.Assert.assertNull(paint84);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 9, (double) ' ', true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            textTitle2.setPadding(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getURLText();
        textTitle2.setNotify(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        boolean boolean6 = labelBlock2.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) '#', (double) 100, paint2, stroke3, (java.awt.Paint) color4, stroke5, (float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Paint paint2 = null;
        try {
            categoryAxis1.setTickLabelPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        java.awt.Shape shape6 = stackedBarRenderer3D2.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D7.setBaseItemLabelPaint((java.awt.Paint) color8);
        double double10 = stackedBarRenderer3D7.getUpperClip();
        java.awt.Shape shape13 = stackedBarRenderer3D7.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D2.setBaseShape(shape13);
        try {
            java.awt.GradientPaint gradientPaint15 = standardGradientPaintTransformer0.transform(gradientPaint1, shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock2.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        java.awt.Graphics2D graphics2D8 = null;
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setRangeAxisLocation(axisLocation46, false);
        java.awt.Paint paint49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot45.setDomainGridlinePaint(paint49);
        double[] doubleArray58 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray63 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray68 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray73 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray78 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray79 = new double[][] { doubleArray58, doubleArray63, doubleArray68, doubleArray73, doubleArray78 };
        org.jfree.data.category.CategoryDataset categoryDataset80 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray79);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = null;
        org.jfree.chart.axis.ValueAxis valueAxis82 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D83 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D83.setIncludeBaseInRange(false);
        java.awt.Paint paint87 = stackedBarRenderer3D83.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot(categoryDataset80, categoryAxis81, valueAxis82, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D83);
        org.jfree.chart.axis.AxisLocation axisLocation89 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot88.setRangeAxisLocation(axisLocation89, false);
        categoryPlot45.setDomainAxisLocation(9, axisLocation89, false);
        java.awt.geom.Rectangle2D rectangle2D94 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D8, categoryPlot45, rectangle2D94, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(categoryDataset80);
        org.junit.Assert.assertNull(paint87);
        org.junit.Assert.assertNotNull(axisLocation89);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(categoryPlot1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getURLText();
        java.lang.Object obj4 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(255, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        try {
            categoryPlot36.drawBackground(graphics2D44, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        boolean boolean7 = stackedBarRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.darker();
        float[] floatArray3 = new float[] { 100L };
        try {
            float[] floatArray4 = color1.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = null;
        try {
            legendTitle37.setMargin(rectangleInsets38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 100.0f, (java.lang.Number) 1L, (java.lang.Number) (short) 10, (java.lang.Number) (short) 1, (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMedian();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0f + "'", number10.equals(10.0f));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            categoryPlot36.addRangeMarker(11, marker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.darker();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        java.awt.Color color12 = java.awt.Color.lightGray;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color12, true);
        int int15 = color12.getRed();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 192 + "'", int15 == 192);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 11, (double) 10L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        try {
            dateAxis1.zoomRange((double) 'a', (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        boolean boolean7 = defaultCategoryDataset4.hasListener((java.util.EventListener) ringPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState10 = piePlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 255, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject((int) ' ', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        java.awt.Shape shape4 = numberAxis3D1.getDownArrow();
        try {
            numberAxis3D1.zoomRange((double) 9999, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9999.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedBarRenderer3D0.getBasePositiveItemLabelPosition();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer48 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer48);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) ' ', 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Shape shape43 = stackedBarRenderer3D39.getSeriesShape(0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D39.setBasePaint((java.awt.Paint) color44);
        java.awt.Shape shape47 = stackedBarRenderer3D39.lookupSeriesShape((int) (short) 0);
        boolean boolean48 = stackedBarRenderer3D31.equals((java.lang.Object) shape47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = null;
        try {
            dateAxis1.setRange(range4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            defaultCategoryDataset0.removeRow(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Category Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "RangeType.NEGATIVE");
        java.lang.Object obj4 = keyedObjects0.getObject(192);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        dateAxis1.setRangeWithMargins((double) 1.0f, (double) 255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        statisticalLineAndShapeRenderer2.setBaseShapesFilled(true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalLineAndShapeRenderer2.setBaseOutlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray36 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray41 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray42 = new double[][] { doubleArray21, doubleArray26, doubleArray31, doubleArray36, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setIncludeBaseInRange(false);
        java.awt.Paint paint50 = stackedBarRenderer3D46.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D46);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot51.setRangeAxisLocation(axisLocation52, false);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        try {
            statisticalLineAndShapeRenderer2.drawBackground(graphics2D14, categoryPlot51, rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Comparable comparable2 = null;
        try {
            java.lang.String str3 = categoryAxis1.getCategoryLabelToolTip(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        try {
            levelRenderer0.setSeriesItemLabelsVisible((-1), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        java.awt.Paint paint47 = stackedBarRenderer3D0.getBasePaint();
        java.awt.Paint paint49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            stackedBarRenderer3D0.setSeriesOutlinePaint((int) (byte) -1, paint49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        try {
            lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        java.awt.Paint paint47 = stackedBarRenderer3D0.getBasePaint();
        java.awt.Paint paint52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 100, (double) (byte) -1, (double) 100, paint52);
        stackedBarRenderer3D0.setBaseFillPaint(paint52, true);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getLegendItemGraphicEdge();
        java.lang.String str39 = rectangleEdge38.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.LEFT" + "'", str39.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.clearRangeMarkers();
        categoryPlot36.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNotNull(classLoader0);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray7 = null;
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray6, numberArray7, numberArray8);
        try {
            defaultIntervalCategoryDataset4.setSeriesKeys((java.lang.Comparable[]) strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(numberArray8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Category Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        try {
            java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        task2.setPercentComplete((java.lang.Double) 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) simpleTimePeriod5);
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 6);
        int int9 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        piePlot0.setOutlineVisible(true);
        piePlot0.setPieIndex(100);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke10 = piePlot9.getLabelLinkStroke();
        stackedBarRenderer3D0.setBaseOutlineStroke(stroke10);
        double double12 = stackedBarRenderer3D0.getMinimumBarLength();
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight((double) 1);
        org.jfree.data.Range range4 = rectangleConstraint0.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        ringPlot1.setLabelGenerator(pieSectionLabelGenerator2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("VerticalAlignment.BOTTOM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        java.lang.String str3 = projectInfo0.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str3.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextBlockAnchor.BOTTOM_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke7);
        java.lang.Boolean boolean10 = stackedBarRenderer3D0.getSeriesVisible((int) '4');
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        ringPlot2.setSeparatorsVisible(false);
        org.jfree.chart.plot.Plot plot6 = ringPlot2.getRootPlot();
        org.jfree.chart.util.Rotation rotation7 = null;
        try {
            ringPlot2.setDirection(rotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.validateObject();
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.incrementValue(0.0d, (java.lang.Comparable) (-1L), comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Font font6 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) true, font6);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue(100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        levelRenderer0.setMaximumItemWidth((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultIntervalCategoryDataset4.getGroup();
        try {
            java.lang.Number number9 = defaultIntervalCategoryDataset4.getStartValue((int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.getCopyright();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str3.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LGPL" + "'", str4.equals("LGPL"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke6 = piePlot5.getLabelLinkStroke();
        stackedBarRenderer3D0.setSeriesOutlineStroke((int) '4', stroke6, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color5, stroke7);
        categoryMarker8.setLabel("RectangleAnchor.TOP_RIGHT");
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(4, false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) true);
        java.lang.String str3 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.awt.Image image3 = null;
        projectInfo1.setLogo(image3);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 'a', (double) (short) 1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 100, (double) (byte) -1, (double) 100, paint4);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedBarRenderer3D0.setSeriesURLGenerator(11, categoryURLGenerator13);
        stackedBarRenderer3D0.setMinimumBarLength((double) 10L);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int3 = dateTickUnit2.getCalendarField();
        java.util.Date date4 = null;
        try {
            java.util.Date date5 = dateTickUnit2.addToDate(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        task2.setPercentComplete((java.lang.Double) 2.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D1.setBaseItemLabelPaint((java.awt.Paint) color2);
        double double4 = stackedBarRenderer3D1.getUpperClip();
        java.awt.Shape shape7 = stackedBarRenderer3D1.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape7);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape7, 0.0d, (float) 3, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str2.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        java.awt.Paint paint3 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.lang.String str5 = textTitle4.getURLText();
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle4.getBounds();
        try {
            java.awt.GradientPaint gradientPaint7 = standardGradientPaintTransformer0.transform(gradientPaint1, (java.awt.Shape) rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        double[] doubleArray8 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray13 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray29 = new double[][] { doubleArray8, doubleArray13, doubleArray18, doubleArray23, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setIncludeBaseInRange(false);
        java.awt.Paint paint37 = stackedBarRenderer3D33.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D33);
        java.awt.Graphics2D graphics2D39 = null;
        double[] doubleArray46 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray51 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray56 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray61 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray66 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray67 = new double[][] { doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray67);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D71 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D71.setIncludeBaseInRange(false);
        java.awt.Paint paint75 = stackedBarRenderer3D71.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis69, valueAxis70, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D71);
        categoryPlot76.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = categoryPlot76.getDomainAxis(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator82 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D84 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D84.setFixedAutoRange(0.0d);
        boolean boolean87 = standardCategorySeriesLabelGenerator82.equals((java.lang.Object) numberAxis3D84);
        java.awt.Color color89 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot90 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke91 = piePlot90.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker92 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color89, stroke91);
        java.awt.Font font94 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle95 = new org.jfree.chart.title.TextTitle("hi!", font94);
        java.lang.String str96 = textTitle95.getURLText();
        java.awt.geom.Rectangle2D rectangle2D97 = textTitle95.getBounds();
        stackedBarRenderer3D33.drawRangeMarker(graphics2D39, categoryPlot76, (org.jfree.chart.axis.ValueAxis) numberAxis3D84, (org.jfree.chart.plot.Marker) categoryMarker92, rectangle2D97);
        shapeList0.setShape(12, (java.awt.Shape) rectangle2D97);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNull(categoryAxis81);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(font94);
        org.junit.Assert.assertNull(str96);
        org.junit.Assert.assertNotNull(rectangle2D97);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
        waferMapPlot1.setNoDataMessage("VerticalAlignment.BOTTOM");
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection6 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setAutoPopulateSeriesShape(true);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleAnchor.TOP_RIGHT");
        stackedBarRenderer3D0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        try {
            java.lang.String str12 = standardCategorySeriesLabelGenerator7.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        int int6 = color4.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("SerialDate.weekInMonthToString(): invalid code.", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        categoryPlot36.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxis(0);
        try {
            categoryPlot36.zoom((double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categoryAxis41);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 11, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (11.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("AreaRendererEndType.LEVEL", graphics2D1, 8.0d, (float) 12, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1, (double) 10L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setIncludeBaseInRange(false);
        java.awt.Shape shape50 = stackedBarRenderer3D46.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D51.setBaseItemLabelPaint((java.awt.Paint) color52);
        double double54 = stackedBarRenderer3D51.getUpperClip();
        java.awt.Shape shape57 = stackedBarRenderer3D51.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D46.setBaseShape(shape57);
        double double59 = stackedBarRenderer3D46.getItemMargin();
        int int60 = categoryPlot36.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D46);
        double double61 = stackedBarRenderer3D46.getLowerClip();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(shape50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.2d + "'", double59 == 0.2d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("TextBlockAnchor.BOTTOM_RIGHT", timePeriod1);
        java.lang.String str3 = task2.getDescription();
        org.jfree.data.time.TimePeriod timePeriod4 = task2.getDuration();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str3.equals("TextBlockAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNull(timePeriod4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color5);
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color5 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D8.setIncludeBaseInRange(false);
        java.awt.Shape shape12 = stackedBarRenderer3D8.getSeriesShape(0);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D8.setBasePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setIncludeBaseInRange(false);
        java.awt.Shape shape19 = stackedBarRenderer3D15.getSeriesShape(0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D15.setBasePaint((java.awt.Paint) color20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color13, color20, color22 };
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray23, paintArray24, strokeArray25, strokeArray26, shapeArray27);
        java.lang.Object obj29 = defaultDrawingSupplier28.clone();
        try {
            java.awt.Stroke stroke30 = defaultDrawingSupplier28.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 6, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker4.getLabelOffsetType();
        java.lang.Object obj7 = valueMarker4.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.0d + "'", double5 == 6.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle5.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9);
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray38 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray39 = new double[][] { doubleArray18, doubleArray23, doubleArray28, doubleArray33, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D43.setIncludeBaseInRange(false);
        java.awt.Paint paint47 = stackedBarRenderer3D43.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D43);
        categoryPlot48.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = categoryPlot48.getDomainAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str56 = categoryAxis55.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D58.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = numberAxis3D58.getMarkerBand();
        java.lang.Object obj62 = numberAxis3D58.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset63 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset64 = null;
        org.jfree.chart.plot.RingPlot ringPlot65 = new org.jfree.chart.plot.RingPlot(pieDataset64);
        boolean boolean66 = defaultCategoryDataset63.hasListener((java.util.EventListener) ringPlot65);
        java.lang.Object obj67 = defaultCategoryDataset63.clone();
        try {
            areaRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D7, categoryPlot48, categoryAxis55, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset63, 0, (int) (byte) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(categoryAxis53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(markerAxisBand61);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(obj67);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        piePlot0.setLabelLinkPaint(paint5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = java.awt.Color.cyan;
        float[] floatArray6 = new float[] { 4, (byte) 0, (-1L), (-1) };
        float[] floatArray7 = color1.getComponents(floatArray6);
        float[] floatArray8 = color0.getRGBComponents(floatArray7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer3 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Color color4 = java.awt.Color.lightGray;
        levelRenderer3.setBaseOutlinePaint((java.awt.Paint) color4, true);
        piePlot0.setSectionPaint((java.lang.Comparable) 0.05d, (java.awt.Paint) color4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth((int) 'a');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, true);
        java.awt.Paint paint6 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.2d, (double) (short) -1);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.2d + "'", number3.equals(0.2d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke7);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setRange(1.0d, (double) 3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font8);
        java.lang.String str10 = textTitle9.getURLText();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle9.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            org.jfree.chart.axis.AxisState axisState19 = numberAxis3D1.draw(graphics2D5, (double) ' ', rectangle2D11, rectangle2D16, rectangleEdge17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot40.getDomainAxisForDataset(0);
        categoryPlot40.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection49 = categoryPlot40.getDomainMarkers(layer48);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection51 = categoryPlot40.getRangeMarkers(layer50);
        java.util.Collection collection52 = xYPlot0.getRangeMarkers(layer50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D44.setIncludeBaseInRange(false);
        java.awt.Paint paint48 = stackedBarRenderer3D44.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = stackedBarRenderer3D44.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = stackedBarRenderer3D44.getPositiveItemLabelPositionFallback();
        boolean boolean53 = stackedBarRenderer3D44.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D44.setBaseFillPaint(paint54);
        categoryPlot36.setOutlinePaint(paint54);
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        xYPlot57.setRenderer(100, xYItemRenderer59);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis62.setRange(range63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj67 = null;
        boolean boolean68 = dateAxis66.equals(obj67);
        java.awt.Color color69 = java.awt.Color.cyan;
        dateAxis66.setAxisLinePaint((java.awt.Paint) color69);
        java.awt.Color color71 = java.awt.Color.BLACK;
        dateAxis66.setTickLabelPaint((java.awt.Paint) color71);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray73 = new org.jfree.chart.axis.ValueAxis[] { dateAxis62, dateAxis66 };
        xYPlot57.setDomainAxes(valueAxisArray73);
        categoryPlot36.setRangeAxes(valueAxisArray73);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertNull(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(valueAxisArray73);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) dateTickUnit3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color1 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color1, stroke3);
        categoryMarker4.setLabel("RectangleAnchor.TOP_RIGHT");
        java.lang.String str7 = categoryMarker4.getLabel();
        java.lang.String str8 = categoryMarker4.getLabel();
        java.lang.Object obj9 = categoryMarker4.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str7.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str8.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        stackedBarRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D0.getLegendItem(1, (int) (byte) 0);
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D40.setIncludeBaseInRange(false);
        java.awt.Paint paint44 = stackedBarRenderer3D40.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot45);
        java.awt.Paint paint47 = stackedBarRenderer3D0.getBasePaint();
        java.awt.Paint paint49 = stackedBarRenderer3D0.getSeriesFillPaint(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = null;
        try {
            stackedBarRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(paint49);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) (short) 1, (java.lang.Comparable) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        java.awt.Paint paint46 = null;
        try {
            categoryPlot36.setRangeCrosshairPaint(paint46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers(11);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxisForDataset(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getLegendItemGraphicEdge();
        java.lang.Object obj39 = null;
        boolean boolean40 = rectangleEdge38.equals(obj39);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        double[] doubleArray7 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray12 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray17 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray22 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray27 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setIncludeBaseInRange(false);
        java.awt.Paint paint36 = stackedBarRenderer3D32.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = stackedBarRenderer3D32.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = stackedBarRenderer3D32.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot(pieDataset41);
        boolean boolean43 = defaultCategoryDataset40.hasListener((java.util.EventListener) ringPlot42);
        boolean boolean44 = stackedBarRenderer3D32.equals((java.lang.Object) defaultCategoryDataset40);
        try {
            java.lang.String str47 = standardCategoryURLGenerator0.generateURL((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, (int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke4 = piePlot3.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 6, paint2, stroke4);
        double double6 = valueMarker5.getValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker5.getLabelOffsetType();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker5.setStroke(stroke8);
        boolean boolean10 = categoryLabelPositions0.equals((java.lang.Object) stroke8);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.0d + "'", double6 == 6.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultIntervalCategoryDataset4.getGroup();
        java.util.List list7 = defaultIntervalCategoryDataset4.getColumnKeys();
        try {
            int int8 = defaultIntervalCategoryDataset4.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        int int2 = piePlot0.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot0.setLabelGenerator(pieSectionLabelGenerator3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot5.setRenderer(100, xYItemRenderer7);
        xYPlot5.clearRangeMarkers(0);
        java.awt.Paint paint11 = xYPlot5.getRangeGridlinePaint();
        piePlot0.setBackgroundPaint(paint11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        try {
            java.lang.Number number7 = defaultIntervalCategoryDataset4.getValue((int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class4 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean9 = simpleTimePeriod7.equals((java.lang.Object) 9999);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone11);
        java.util.Date date13 = dateTickUnit3.addToDate(date10);
        keyedObjects2D0.setObject((java.lang.Object) date10, (java.lang.Comparable) 0.05d, (java.lang.Comparable) "hi!");
        try {
            keyedObjects2D0.removeColumn((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777216");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Class class1 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean6 = simpleTimePeriod4.equals((java.lang.Object) 9999);
        java.util.Date date7 = simpleTimePeriod4.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot36.setDomainGridlinePaint(paint40);
        categoryPlot36.setRangeCrosshairValue((double) 1.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean45 = categoryAxis44.isTickLabelsVisible();
        float float46 = categoryAxis44.getTickMarkInsideLength();
        double[] doubleArray53 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray58 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray63 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray68 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray73 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray74 = new double[][] { doubleArray53, doubleArray58, doubleArray63, doubleArray68, doubleArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray74);
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D78 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D78.setIncludeBaseInRange(false);
        java.awt.Paint paint82 = stackedBarRenderer3D78.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset75, categoryAxis76, valueAxis77, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D78);
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot83.setRangeAxisLocation(axisLocation84, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis88 = categoryPlot83.getDomainAxisForDataset(0);
        categoryAxis44.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot83);
        java.util.List list90 = categoryPlot36.getCategoriesForAxis(categoryAxis44);
        float float91 = categoryPlot36.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNull(paint82);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNull(categoryAxis88);
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertTrue("'" + float91 + "' != '" + 0.5f + "'", float91 == 0.5f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D8.setFixedAutoRange(0.0d);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis3D8.setNumberFormatOverride(numberFormat11);
        numberAxis3D8.configure();
        try {
            xYPlot0.setDomainAxis((-16777216), (org.jfree.chart.axis.ValueAxis) numberAxis3D8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        java.awt.Paint paint6 = ringPlot5.getSeparatorPaint();
        lineAndShapeRenderer2.setSeriesOutlinePaint((int) ' ', paint6, true);
        lineAndShapeRenderer2.setSeriesShapesFilled(9, false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color2 = java.awt.Color.getColor("TextBlockAnchor.BOTTOM_RIGHT", 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        try {
            lineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Range[0.0,1.0]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        org.jfree.chart.block.BlockFrame blockFrame4 = labelBlock2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        piePlot0.setBackgroundAlpha((float) (short) 10);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot40.getDomainAxisForDataset(0);
        categoryPlot40.setNoDataMessage("hi!");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D48.setIncludeBaseInRange(false);
        java.awt.Paint paint52 = stackedBarRenderer3D48.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = stackedBarRenderer3D48.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = stackedBarRenderer3D48.getPositiveItemLabelPositionFallback();
        boolean boolean57 = stackedBarRenderer3D48.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D48.setBaseFillPaint(paint58);
        categoryPlot40.setOutlinePaint(paint58);
        piePlot0.setOutlinePaint(paint58);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertNull(itemLabelPosition56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("VerticalAlignment.BOTTOM");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 10, (-1), dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D34);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str43 = categoryAxis42.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font47 = categoryAxis42.getTickLabelFont((java.lang.Comparable) simpleTimePeriod46);
        legendTitle40.setItemFont(font47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font47, (java.awt.Paint) color49);
        boolean boolean51 = multiplePiePlot1.equals((java.lang.Object) labelBlock50);
        org.jfree.chart.util.TableOrder tableOrder52 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Class class1 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean6 = simpleTimePeriod4.equals((java.lang.Object) 9999);
        java.util.Date date7 = simpleTimePeriod4.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint4.toRangeWidth(range8);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset(0.2d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlinePaint(false);
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray40 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray41 = new double[][] { doubleArray20, doubleArray25, doubleArray30, doubleArray35, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray41);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D45.setIncludeBaseInRange(false);
        java.awt.Paint paint49 = stackedBarRenderer3D45.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D45);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(axisLocation51, false);
        boolean boolean54 = stackedBarRenderer3D0.equals((java.lang.Object) axisLocation51);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        double double41 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle37.getLegendItemGraphicPadding();
        double double43 = rectangleInsets42.getLeft();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        textBlock0.draw(graphics2D1, (float) 9999, 1.0f, textBlockAnchor5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = null;
        java.awt.Shape shape15 = textBlock0.calculateBounds(graphics2D8, (float) 8, (float) (-1L), textBlockAnchor11, 10.0f, (float) 1, 1.0d);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock0.draw(graphics2D16, (float) (byte) 10, 1.0f, textBlockAnchor19, (float) 5, 0.0f, (double) (short) -1);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer24 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double25 = levelRenderer24.getItemMargin();
        boolean boolean26 = textBlock0.equals((java.lang.Object) levelRenderer24);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = levelRenderer24.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setIncludeBaseInRange(false);
        java.awt.Paint paint40 = stackedBarRenderer3D36.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D36);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator42 = stackedBarRenderer3D36.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = stackedBarRenderer3D36.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot(pieDataset45);
        boolean boolean47 = defaultCategoryDataset44.hasListener((java.util.EventListener) ringPlot46);
        boolean boolean48 = stackedBarRenderer3D36.equals((java.lang.Object) defaultCategoryDataset44);
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class53 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean58 = simpleTimePeriod56.equals((java.lang.Object) 9999);
        java.util.Date date59 = simpleTimePeriod56.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date59, timeZone60);
        java.util.Date date62 = dateTickUnit52.addToDate(date59);
        defaultCategoryDataset44.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) date59, (java.lang.Comparable) 4.0d);
        java.lang.Class class65 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean70 = simpleTimePeriod68.equals((java.lang.Object) 9999);
        java.util.Date date71 = simpleTimePeriod68.getEnd();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date71, timeZone72);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date71);
        try {
            dateAxis1.setRange(date59, date71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(serialDate74);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D34);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str43 = categoryAxis42.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font47 = categoryAxis42.getTickLabelFont((java.lang.Comparable) simpleTimePeriod46);
        legendTitle40.setItemFont(font47);
        boolean boolean49 = chartChangeEventType2.equals((java.lang.Object) font47);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart51 = null;
        chartChangeEvent50.setChart(jFreeChart51);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickLabelsVisible();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot39.setRangeAxisLocation(axisLocation40, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot39.getDomainAxisForDataset(0);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot39.getDomainAxisForDataset(192);
        categoryPlot39.setAnchorValue((double) 15, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNull(categoryAxis44);
        org.junit.Assert.assertNull(categoryAxis47);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int5 = dateTickUnit4.getRollCount();
        dateAxis1.setTickUnit(dateTickUnit4, false, false);
        boolean boolean9 = dateAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font7 = categoryAxis2.getTickLabelFont((java.lang.Comparable) simpleTimePeriod6);
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray34 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D39.setIncludeBaseInRange(false);
        java.awt.Paint paint43 = stackedBarRenderer3D39.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D39);
        java.awt.Paint paint46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle45.setItemPaint(paint46);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint46, (float) 10, 3, textMeasurer50);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D52.setIncludeBaseInRange(false);
        stackedBarRenderer3D52.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem60 = stackedBarRenderer3D52.getLegendItem(1, (int) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke62 = piePlot61.getLabelLinkStroke();
        stackedBarRenderer3D52.setBaseOutlineStroke(stroke62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str66 = categoryAxis65.getLabelToolTip();
        boolean boolean67 = categoryAxis65.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryAxis65.getTickLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder69 = new org.jfree.chart.block.LineBorder(paint46, stroke62, rectangleInsets68);
        double double71 = rectangleInsets68.calculateLeftOutset((double) 1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNull(legendItem60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 4.0d + "'", double71 == 4.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String[] strArray2 = dataPackageResources0.getStringArray("12/31/69");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key 12/31/69");
        } catch (java.util.MissingResourceException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str3 = projectInfo0.getInfo();
//        java.awt.Image image4 = null;
//        projectInfo0.setLogo(image4);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str3.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        boolean boolean4 = categoryAxis2.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis2.getTickLabelInsets();
        double double7 = rectangleInsets5.calculateLeftInset((double) 10);
        double double8 = rectangleInsets5.getRight();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj11 = null;
        boolean boolean12 = dateAxis10.equals(obj11);
        java.awt.Color color13 = java.awt.Color.cyan;
        dateAxis10.setAxisLinePaint((java.awt.Paint) color13);
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!", font16);
        org.jfree.chart.plot.PlotState plotState18 = new org.jfree.chart.plot.PlotState();
        java.util.Map map19 = plotState18.getSharedAxisStates();
        boolean boolean20 = textTitle17.equals((java.lang.Object) map19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean24 = lineBorder22.equals((java.lang.Object) stackedBarRenderer3D23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.Font font27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        java.lang.String str29 = textTitle28.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor31, textBlockAnchor32);
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        lineBorder22.draw(graphics2D25, rectangle2D30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D36.setBaseItemLabelPaint((java.awt.Paint) color37);
        double double39 = stackedBarRenderer3D36.getUpperClip();
        java.awt.Shape shape42 = stackedBarRenderer3D36.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity(shape42);
        java.lang.Object obj44 = textTitle17.draw(graphics2D21, rectangle2D30, (java.lang.Object) chartEntity43);
        dateAxis10.setUpArrow((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets5.createInsetRectangle(rectangle2D30, true, true);
        try {
            boolean boolean49 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(map19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean44 = categoryAxis43.isTickLabelsVisible();
        float float45 = categoryAxis43.getTickMarkInsideLength();
        int int46 = categoryPlot36.getDomainAxisIndex(categoryAxis43);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        textTitle2.setWidth((double) 100.0f);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle2.arrange(graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        textTitle2.setID("RangeType.NEGATIVE");
        textTitle2.setToolTipText("ERROR : Relative To String");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.plot.Plot plot44 = categoryPlot36.getParent();
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot36.setFixedRangeAxisSpace(axisSpace45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot36.getDomainAxisForDataset((-16777216));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertNull(categoryAxis48);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 6.0d, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str6 = blockContainer5.getID();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D9 = flowArrangement4.arrange(blockContainer5, graphics2D7, rectangleConstraint8);
        double double10 = size2D9.width;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        textTitle2.setWidth((double) 100.0f);
        double double10 = textTitle2.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 10, 192);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.String str8 = chartEntity7.getShapeType();
        java.lang.String str9 = chartEntity7.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = chartEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "rect" + "'", str8.equals("rect"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartEntity: tooltip = null" + "'", str9.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        piePlot0.setDataset(pieDataset1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getDomainAxisEdge();
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getLabelLinkStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean12 = lineBorder10.equals((java.lang.Object) stackedBarRenderer3D11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D14.setBaseItemLabelPaint((java.awt.Paint) color15);
        stackedBarRenderer3D11.setSeriesPaint(0, (java.awt.Paint) color15);
        java.awt.Graphics2D graphics2D18 = null;
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray35 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray40 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray45 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray46 = new double[][] { doubleArray25, doubleArray30, doubleArray35, doubleArray40, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D50.setIncludeBaseInRange(false);
        java.awt.Paint paint54 = stackedBarRenderer3D50.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D50);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot55.setRangeAxisLocation(axisLocation56, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = categoryPlot55.getDomainAxisForDataset(0);
        categoryPlot55.setNoDataMessage("hi!");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D64.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = numberAxis3D64.getMarkerBand();
        java.awt.Color color69 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke71 = piePlot70.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color69, stroke71);
        java.awt.Paint paint73 = categoryMarker72.getLabelPaint();
        java.awt.Font font75 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle("hi!", font75);
        java.lang.String str77 = textTitle76.getURLText();
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle76.getBounds();
        stackedBarRenderer3D11.drawRangeMarker(graphics2D18, categoryPlot55, (org.jfree.chart.axis.ValueAxis) numberAxis3D64, (org.jfree.chart.plot.Marker) categoryMarker72, rectangle2D78);
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNull(categoryAxis60);
        org.junit.Assert.assertNull(markerAxisBand67);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(rectangle2D78);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
        java.util.ResourceBundle.Control control5 = null;
        try {
            java.util.ResourceBundle resourceBundle6 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, classLoader3, control5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            legendTitle37.draw(graphics2D39, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.lang.String str5 = textTitle4.getURLText();
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle4.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D6, rectangleAnchor7);
        lineBorder0.draw(graphics2D1, rectangle2D6);
        java.awt.Paint paint12 = lineBorder0.getPaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            lineBorder0.draw(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        java.awt.Graphics2D graphics2D3 = null;
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot40.getDomainAxisForDataset(0);
        categoryPlot40.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection49 = categoryPlot40.getDomainMarkers(layer48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj52 = null;
        boolean boolean53 = dateAxis51.equals(obj52);
        java.awt.Color color54 = java.awt.Color.cyan;
        dateAxis51.setAxisLinePaint((java.awt.Paint) color54);
        dateAxis51.setAutoRange(false);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D3, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D58, (double) (-1.0f));
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke63 = piePlot62.getLabelOutlineStroke();
        try {
            stackedBarRenderer3D1.setSeriesOutlineStroke((int) (byte) -1, stroke63, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = projectInfo0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Color color1 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color1, stroke3);
        categoryMarker4.setLabel("RectangleAnchor.TOP_RIGHT");
        java.lang.String str7 = categoryMarker4.getLabel();
        java.lang.String str8 = categoryMarker4.getLabel();
        java.awt.Stroke stroke9 = categoryMarker4.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str7.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str8.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        java.awt.Paint paint42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle41.setItemPaint(paint42);
        ringPlot2.setSeparatorPaint(paint42);
        ringPlot2.setCircular(false, true);
        boolean boolean48 = ringPlot2.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultIntervalCategoryDataset4.getGroup();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int13 = dateTickUnit12.getRollCount();
        dateAxis9.setTickUnit(dateTickUnit12, false, false);
        java.lang.Number number17 = null;
        try {
            defaultIntervalCategoryDataset4.setEndValue(10, (java.lang.Comparable) false, number17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.LegendItem legendItem5 = stackedBarRenderer3D0.getLegendItem(0, 9);
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        stackedBarRenderer3D0.setSeriesFillPaint(0, paint7, true);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint7, stroke10, rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        try {
            ringPlot1.setInteriorGap((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesPaint(1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        boolean boolean15 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("rect");
        dateAxis4.configure();
        boolean boolean6 = ringPlot1.equals((java.lang.Object) dateAxis4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.LEFT", "SerialDate.weekInMonthToString(): invalid code.", "TextBlockAnchor.BOTTOM_RIGHT", "http://www.jfree.org/jfreechart/index.html", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint7 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "http://www.jfree.org/jfreechart/index.html", (double) (short) 100);
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        java.awt.Shape shape5 = stackedBarRenderer3D0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean10 = categoryAxis9.isTickLabelsVisible();
        float float11 = categoryAxis9.getTickMarkInsideLength();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis9.setTickMarkStroke(stroke12);
        stackedBarRenderer3D0.setSeriesStroke(0, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = stackedBarRenderer3D0.getSeriesToolTipGenerator(4);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle2.getMargin();
        double double8 = rectangleInsets6.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray4, numberArray5);
        java.util.List list7 = defaultIntervalCategoryDataset6.getRowKeys();
        try {
            org.jfree.data.Range range8 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNull(categoryPlot1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("-3,-3,3,3");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: -3,-3,3,3" + "'", str2.equals("org.jfree.data.UnknownKeyException: -3,-3,3,3"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str3 = projectInfo0.getInfo();
//        java.lang.String str4 = projectInfo0.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str3.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart" + "'", str4.equals("JFreeChart"));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 100.0f, (java.lang.Number) 1L, (java.lang.Number) (short) 10, (java.lang.Number) (short) 1, (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinOutlier();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 0 + "'", number10.equals((short) 0));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke3);
        org.jfree.chart.util.Rotation rotation5 = piePlot0.getDirection();
        boolean boolean6 = piePlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 6.0d, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str6 = blockContainer5.getID();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D9 = flowArrangement4.arrange(blockContainer5, graphics2D7, rectangleConstraint8);
        java.lang.Object obj10 = blockContainer5.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset40);
        boolean boolean42 = defaultCategoryDataset39.hasListener((java.util.EventListener) ringPlot41);
        boolean boolean43 = stackedBarRenderer3D31.equals((java.lang.Object) defaultCategoryDataset39);
        try {
            stackedBarRenderer3D31.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Image image40 = categoryPlot36.getBackgroundImage();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(image40);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYPlot0.rendererChanged(rendererChangeEvent37);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        try {
            xYPlot0.setQuadrantPaint((-1), paint40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean3 = numberTickUnit1.equals((java.lang.Object) categoryAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D4 = blockContainer1.arrange(graphics2D2, rectangleConstraint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toUnconstrainedWidth();
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        boolean boolean7 = standardGradientPaintTransformer0.equals((java.lang.Object) range6);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 9999);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        int int7 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = stackedBarRenderer3D0.getBaseToolTipGenerator();
        boolean boolean4 = stackedBarRenderer3D0.isDrawBarOutline();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        boolean boolean40 = legendTitle37.getNotify();
        double double41 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle37.getLegendItemGraphicPadding();
        legendTitle37.setPadding((double) 1, (double) '4', 0.0d, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        java.awt.Paint paint4 = ringPlot2.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        categoryAxis1.setTickMarkOutsideLength(10.0f);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot36.getDomainGridlinePosition();
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray43 = null;
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset45 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray42, numberArray43, numberArray44);
        java.util.List list46 = defaultIntervalCategoryDataset45.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup47 = defaultIntervalCategoryDataset45.getGroup();
        categoryPlot36.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset45);
        try {
            java.lang.Object obj49 = defaultIntervalCategoryDataset45.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(datasetGroup47);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle2.setPaint((java.awt.Paint) color3);
        java.lang.String str5 = textTitle2.getText();
        double[] doubleArray13 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D38.setIncludeBaseInRange(false);
        java.awt.Paint paint42 = stackedBarRenderer3D38.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D38);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D38);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str47 = categoryAxis46.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font51 = categoryAxis46.getTickLabelFont((java.lang.Comparable) simpleTimePeriod50);
        legendTitle44.setItemFont(font51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.BOTTOM", font51, (java.awt.Paint) color53);
        textTitle2.setFont(font51);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled((int) ' ');
        boolean boolean3 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        textBlock0.draw(graphics2D1, (float) 9999, 1.0f, textBlockAnchor5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock0.setLineAlignment(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset9.validateObject();
        defaultCategoryDataset9.validateObject();
        defaultCategoryDataset9.validateObject();
        org.jfree.data.Range range13 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder3.getInsets();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke3);
        org.jfree.chart.util.Rotation rotation5 = piePlot0.getDirection();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        try {
            piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        boolean boolean9 = stackedBarRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D0.setBaseFillPaint(paint10);
        java.awt.Color color12 = java.awt.Color.lightGray;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color12, true);
        stackedBarRenderer3D0.setBaseSeriesVisible(true);
        stackedBarRenderer3D0.setIncludeBaseInRange(true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRange(range4);
        boolean boolean6 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int10 = dateTickUnit9.getRollCount();
        dateAxis3.setTickUnit(dateTickUnit9);
        keyedObjects2D0.removeColumn((java.lang.Comparable) dateTickUnit9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        int int14 = xYPlot13.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot13.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot13.getDomainAxisForDataset(0);
        xYPlot13.setDomainCrosshairVisible(true);
        double double21 = xYPlot13.getRangeCrosshairValue();
        keyedObjects2D0.setObject((java.lang.Object) double21, (java.lang.Comparable) 4.0d, (java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setMaximumBarWidth((double) (-1L));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        int int7 = stackedBarRenderer3D0.getPassCount();
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot36.getDomainGridlinePosition();
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray43 = null;
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset45 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray42, numberArray43, numberArray44);
        java.util.List list46 = defaultIntervalCategoryDataset45.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup47 = defaultIntervalCategoryDataset45.getGroup();
        categoryPlot36.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset45);
        try {
            int int50 = defaultIntervalCategoryDataset45.getSeriesIndex((java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(datasetGroup47);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.lang.String str7 = textTitle6.getURLText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        lineBorder0.draw(graphics2D3, rectangle2D8);
        java.awt.Stroke stroke14 = lineBorder0.getStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem3 = boxAndWhiskerRenderer0.getLegendItem(100, 6);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        org.jfree.data.KeyToGroupMap keyToGroupMap4 = null;
        try {
            org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, keyToGroupMap4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        double[] doubleArray9 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray14 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray19 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray24 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray29 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setIncludeBaseInRange(false);
        java.awt.Paint paint38 = stackedBarRenderer3D34.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D34);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D34);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str43 = categoryAxis42.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font47 = categoryAxis42.getTickLabelFont((java.lang.Comparable) simpleTimePeriod46);
        legendTitle40.setItemFont(font47);
        boolean boolean49 = chartChangeEventType2.equals((java.lang.Object) font47);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer0, jFreeChart1, chartChangeEventType2);
        java.lang.String str51 = chartChangeEvent50.toString();
        java.lang.String str52 = chartChangeEvent50.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        java.lang.String str4 = labelBlock2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        java.lang.Object obj3 = dataPackageResources0.handleGetObject("");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D31);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle37.setItemPaint(paint38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = null;
        try {
            legendTitle37.setSources(legendItemSourceArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = stackedBarRenderer3D0.getPlot();
        stackedBarRenderer3D0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleAnchor.TOP_RIGHT");
        stackedBarRenderer3D0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryPlot1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean11 = simpleTimePeriod9.equals((java.lang.Object) 9999);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        java.util.Date date15 = dateTickUnit5.addToDate(date12);
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        java.text.DateFormat dateFormat19 = null;
        dateAxis1.setDateFormatOverride(dateFormat19);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = stackedBarRenderer3D0.getDrawingSupplier();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(drawingSupplier8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        boolean boolean3 = categoryAxis1.isTickLabelsVisible();
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class8 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean13 = simpleTimePeriod11.equals((java.lang.Object) 9999);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
        java.util.Date date17 = dateTickUnit7.addToDate(date14);
        keyedObjects2D4.setObject((java.lang.Object) date14, (java.lang.Comparable) 0.05d, (java.lang.Comparable) "hi!");
        java.awt.Paint paint21 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 0.05d);
        categoryAxis1.setUpperMargin((double) 2);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "-3,-3,3,3", "JFreeChart", "CategoryLabelWidthType.RANGE", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 8.0d, (java.lang.Number) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = defaultKeyedValue2.equals(obj3);
        java.lang.Object obj5 = defaultKeyedValue2.clone();
        java.lang.Number number6 = defaultKeyedValue2.getValue();
        java.lang.Object obj7 = defaultKeyedValue2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 5 + "'", number6.equals(5));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Number) 100.0f, (java.lang.Number) 1L, (java.lang.Number) (short) 10, (java.lang.Number) (short) 1, (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMaxOutlier();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setUseFillPaint(false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        categoryAxis1.setLabelURL("");
        double double4 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "http://www.jfree.org/jfreechart/index.html", (double) (short) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) 10.0d, 2.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj10 = null;
        boolean boolean11 = dateAxis9.equals(obj10);
        java.awt.Color color12 = java.awt.Color.cyan;
        dateAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.BLACK;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis5, dateAxis9 };
        xYPlot0.setDomainAxes(valueAxisArray16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot18.setRenderer(100, xYItemRenderer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("rect");
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj28 = null;
        boolean boolean29 = dateAxis27.equals(obj28);
        java.awt.Color color30 = java.awt.Color.cyan;
        dateAxis27.setAxisLinePaint((java.awt.Paint) color30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        dateAxis27.setTickLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, dateAxis27 };
        xYPlot18.setDomainAxes(valueAxisArray34);
        xYPlot0.setDomainAxes(valueAxisArray34);
        java.awt.Paint paint38 = xYPlot0.getQuadrantPaint(0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot3.setRenderer(100, xYItemRenderer5);
        xYPlot3.clearRangeMarkers(0);
        java.awt.Paint paint9 = xYPlot3.getRangeGridlinePaint();
        ringPlot1.setLabelShadowPaint(paint9);
        double double11 = ringPlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.25d + "'", double11 == 0.25d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke3 = piePlot2.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 6, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker4.getLabelOffsetType();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker4.setLabelTextAnchor(textAnchor7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.0d + "'", double5 == 6.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D0.setBaseItemLabelPaint((java.awt.Paint) color1);
        double double3 = stackedBarRenderer3D0.getUpperClip();
        java.awt.Shape shape6 = stackedBarRenderer3D0.getItemShape((int) '4', (int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setIncludeBaseInRange(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D7.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        float float17 = piePlot16.getBackgroundAlpha();
        int int18 = piePlot16.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = null;
        piePlot16.setLabelGenerator(pieSectionLabelGenerator19);
        boolean boolean21 = stackedBarRenderer3D0.hasListener((java.util.EventListener) piePlot16);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = piePlot16.getLegendItems();
        java.lang.Object obj23 = legendItemCollection22.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelGenerator(8, categoryItemLabelGenerator15, true);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Paint paint4 = stackedBarRenderer3D0.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D0.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer8 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer8.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        ganttRenderer8.setBaseItemLabelGenerator(categoryItemLabelGenerator11, true);
        boolean boolean14 = stackedBarRenderer3D0.equals((java.lang.Object) ganttRenderer8);
        double double15 = stackedBarRenderer3D0.getBase();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        java.lang.Object obj5 = numberAxis3D1.clone();
        boolean boolean6 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D8.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis3D8.getMarkerBand();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D8.setRange(range12, false, true);
        java.lang.String str16 = range12.toString();
        numberAxis3D1.setRangeWithMargins(range12, true, true);
        double double20 = range12.getCentralValue();
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[0.0,1.0]" + "'", str16.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot36.setDomainGridlinePaint(paint40);
        categoryPlot36.setRangeCrosshairValue((double) 1.0f);
        java.awt.Font font44 = categoryPlot36.getNoDataMessageFont();
        java.awt.Color color45 = java.awt.Color.blue;
        java.awt.Color color46 = color45.brighter();
        categoryPlot36.setRangeCrosshairPaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        double[] doubleArray10 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray15 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray20 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray25 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray30 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray31 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setIncludeBaseInRange(false);
        java.awt.Paint paint39 = stackedBarRenderer3D35.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D35);
        java.awt.Paint paint42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendTitle41.setItemPaint(paint42);
        ringPlot2.setSeparatorPaint(paint42);
        ringPlot2.setCircular(false, true);
        double double48 = ringPlot2.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        size2D3.setWidth(8.0d);
        java.lang.String str6 = size2D3.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=8.0, height=0.0]" + "'", str6.equals("Size2D[width=8.0, height=0.0]"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = lineBorder0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D4.setBaseItemLabelPaint((java.awt.Paint) color5);
        stackedBarRenderer3D1.setSeriesPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setIncludeBaseInRange(false);
        java.awt.Paint paint13 = stackedBarRenderer3D9.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D9.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D9.getPositiveItemLabelPositionFallback();
        boolean boolean18 = stackedBarRenderer3D9.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D9.setBaseFillPaint(paint19);
        stackedBarRenderer3D1.setSeriesOutlinePaint(3, paint19);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        boolean boolean26 = stackedBarRenderer3D1.getItemCreateEntity(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str2 = rectangleAnchor1.toString();
        boolean boolean3 = unitType0.equals((java.lang.Object) str2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str2.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.lang.String str6 = textTitle5.getURLText();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle5.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9);
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray38 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray39 = new double[][] { doubleArray18, doubleArray23, doubleArray28, doubleArray33, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D43.setIncludeBaseInRange(false);
        java.awt.Paint paint47 = stackedBarRenderer3D43.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot48.setRangeAxisLocation(axisLocation49, false);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace52);
        java.awt.Paint paint54 = categoryPlot48.getDomainGridlinePaint();
        boolean boolean55 = categoryPlot48.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str58 = categoryAxis57.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font62 = categoryAxis57.getTickLabelFont((java.lang.Comparable) simpleTimePeriod61);
        java.awt.Font font64 = categoryAxis57.getTickLabelFont((java.lang.Comparable) 6);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj67 = null;
        boolean boolean68 = dateAxis66.equals(obj67);
        java.awt.Color color69 = java.awt.Color.cyan;
        dateAxis66.setAxisLinePaint((java.awt.Paint) color69);
        java.awt.Color color71 = java.awt.Color.BLACK;
        dateAxis66.setTickLabelPaint((java.awt.Paint) color71);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset73 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset73.validateObject();
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset73);
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState2, rectangle2D7, categoryPlot48, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis66, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset73, (-1), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNull(range75);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setIncludeBaseInRange(false);
        java.awt.Paint paint8 = stackedBarRenderer3D4.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D4.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedBarRenderer3D4.getPositiveItemLabelPositionFallback();
        boolean boolean13 = stackedBarRenderer3D4.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        stackedBarRenderer3D4.setBaseFillPaint(paint14);
        java.awt.Color color16 = java.awt.Color.lightGray;
        stackedBarRenderer3D4.setBasePaint((java.awt.Paint) color16, true);
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color16, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        int int3 = dateTickUnit2.getCalendarField();
        java.lang.Class class4 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean10 = simpleTimePeriod8.equals((java.lang.Object) 9999);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date11, timeZone14);
        java.util.Date date16 = dateTickUnit2.rollDate(date11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) Double.NaN, jFreeChart1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        boolean boolean3 = categoryAxis1.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getTickLabelInsets();
        double double6 = rectangleInsets4.calculateBottomInset((double) 100);
        java.lang.String str7 = rectangleInsets4.toString();
        java.lang.String str8 = rectangleInsets4.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str7.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str8.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalLineAndShapeRenderer2.setBaseOutlineStroke(stroke12);
        try {
            java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Preceding", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        float float1 = piePlot0.getBackgroundAlpha();
        boolean boolean2 = piePlot0.isCircular();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot0.setLabelOutlineStroke(stroke3);
        org.jfree.chart.util.Rotation rotation5 = piePlot0.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot0.setURLGenerator(pieURLGenerator6);
        piePlot0.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.String str6 = dateAxis1.getLabelToolTip();
        dateAxis1.setUpperBound((double) 8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(100, xYItemRenderer2);
        xYPlot0.clearRangeMarkers(0);
        java.awt.Paint paint6 = xYPlot0.getRangeGridlinePaint();
        double[] doubleArray13 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray18 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray23 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray28 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray33 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D38.setIncludeBaseInRange(false);
        java.awt.Paint paint42 = stackedBarRenderer3D38.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D38);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot43.setRangeAxisLocation(axisLocation44, false);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot43.setDomainGridlinePaint(paint47);
        double[] doubleArray56 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray61 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray66 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray71 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray76 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray77 = new double[][] { doubleArray56, doubleArray61, doubleArray66, doubleArray71, doubleArray76 };
        org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray77);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = null;
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D81 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D81.setIncludeBaseInRange(false);
        java.awt.Paint paint85 = stackedBarRenderer3D81.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot86 = new org.jfree.chart.plot.CategoryPlot(categoryDataset78, categoryAxis79, valueAxis80, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D81);
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot86.setRangeAxisLocation(axisLocation87, false);
        categoryPlot43.setDomainAxisLocation(9, axisLocation87, false);
        boolean boolean93 = axisLocation87.equals((java.lang.Object) (short) -1);
        xYPlot0.setRangeAxisLocation(axisLocation87, false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(categoryDataset78);
        org.junit.Assert.assertNull(paint85);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("SerialDate.weekInMonthToString(): invalid code.");
        projectInfo0.setLicenceName("http://www.jfree.org/jfreechart/index.html");
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray7 = null;
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray6, numberArray7, numberArray8);
        java.util.List list10 = defaultIntervalCategoryDataset9.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultIntervalCategoryDataset9.getGroup();
        java.util.List list12 = defaultIntervalCategoryDataset9.getColumnKeys();
        projectInfo0.setContributors(list12);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        textTitle2.setExpandToFitSpace(true);
        textTitle2.setToolTipText("RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("rect");
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis1.equals(obj2);
        java.awt.Color color4 = java.awt.Color.cyan;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Font font6 = dateAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, true);
        boolean boolean6 = ganttRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 12.0d, "12/31/69", textAnchor2, textAnchor3, (double) 15);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryAxis8.getLabelToolTip();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        java.awt.Font font13 = categoryAxis8.getTickLabelFont((java.lang.Comparable) simpleTimePeriod12);
        org.jfree.data.gantt.Task task14 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod12);
        task14.setPercentComplete((double) (-1));
        boolean boolean17 = textAnchor3.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        java.lang.Object obj8 = textTitle2.clone();
        textTitle2.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color1 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D5.setBaseItemLabelPaint((java.awt.Paint) color6);
        double double8 = stackedBarRenderer3D5.getUpperClip();
        java.awt.Shape shape11 = stackedBarRenderer3D5.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D0.setBaseShape(shape11);
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean14 = stackedBarRenderer3D0.hasListener((java.util.EventListener) piePlot3D13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setIncludeBaseInRange(false);
        java.awt.Paint paint20 = stackedBarRenderer3D16.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = stackedBarRenderer3D16.getPositiveItemLabelPosition((int) '#', (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedBarRenderer3D16.getPositiveItemLabelPositionFallback();
        boolean boolean25 = stackedBarRenderer3D16.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = stackedBarRenderer3D16.getItemShape(5, 0);
        stackedBarRenderer3D0.setSeriesShape(4, shape28);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getLegendItems();
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke7 = piePlot6.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color5, stroke7);
        categoryMarker8.setLabel("RectangleAnchor.TOP_RIGHT");
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        xYPlot0.clearRangeAxes();
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray36 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray41 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray42 = new double[][] { doubleArray21, doubleArray26, doubleArray31, doubleArray36, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D46.setIncludeBaseInRange(false);
        java.awt.Paint paint50 = stackedBarRenderer3D46.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D46);
        java.awt.Color color53 = java.awt.Color.RED;
        int int54 = color53.getBlue();
        stackedBarRenderer3D46.setSeriesItemLabelPaint(0, (java.awt.Paint) color53, true);
        try {
            xYPlot0.setQuadrantPaint(192, (java.awt.Paint) color53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.PlotState plotState3 = new org.jfree.chart.plot.PlotState();
        java.util.Map map4 = plotState3.getSharedAxisStates();
        boolean boolean5 = textTitle2.equals((java.lang.Object) map4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle2.setBackgroundPaint(paint6);
        java.lang.Object obj8 = textTitle2.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str11 = categoryAxis10.getLabelToolTip();
        boolean boolean12 = categoryAxis10.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis10.getTickLabelInsets();
        double double15 = rectangleInsets13.calculateLeftInset((double) 10);
        double double16 = rectangleInsets13.getRight();
        double double18 = rectangleInsets13.calculateTopInset((double) (-1));
        double double20 = rectangleInsets13.calculateBottomOutset(0.0d);
        textTitle2.setPadding(rectangleInsets13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(map4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChart", "ChartEntity: tooltip = null", "SerialDate.weekInMonthToString(): invalid code.", "Size2D[width=8.0, height=0.0]", "ThreadContext");
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
        size2D3.setWidth(8.0d);
        java.lang.Object obj6 = size2D3.clone();
        java.lang.Object obj7 = size2D3.clone();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.awt.Graphics2D graphics2D37 = null;
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray64 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray65 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray65);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D69.setIncludeBaseInRange(false);
        java.awt.Paint paint73 = stackedBarRenderer3D69.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D69);
        categoryPlot74.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = categoryPlot74.getDomainAxis(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator80 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D82 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D82.setFixedAutoRange(0.0d);
        boolean boolean85 = standardCategorySeriesLabelGenerator80.equals((java.lang.Object) numberAxis3D82);
        java.awt.Color color87 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot88 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke89 = piePlot88.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker90 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color87, stroke89);
        java.awt.Font font92 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle("hi!", font92);
        java.lang.String str94 = textTitle93.getURLText();
        java.awt.geom.Rectangle2D rectangle2D95 = textTitle93.getBounds();
        stackedBarRenderer3D31.drawRangeMarker(graphics2D37, categoryPlot74, (org.jfree.chart.axis.ValueAxis) numberAxis3D82, (org.jfree.chart.plot.Marker) categoryMarker90, rectangle2D95);
        java.awt.Shape shape97 = stackedBarRenderer3D31.getBaseShape();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertNull(categoryAxis79);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(rectangle2D95);
        org.junit.Assert.assertNotNull(shape97);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxisForDataset(0);
        xYPlot0.setDomainCrosshairVisible(true);
        double double8 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D10.setFixedAutoRange(0.0d);
        java.text.NumberFormat numberFormat13 = null;
        numberAxis3D10.setNumberFormatOverride(numberFormat13);
        numberAxis3D10.configure();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean5 = simpleTimePeriod3.equals((java.lang.Object) 9999);
        java.util.Date date6 = simpleTimePeriod3.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(4);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = defaultCategoryDataset0.hasListener((java.util.EventListener) ringPlot2);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        float float6 = piePlot5.getBackgroundAlpha();
        boolean boolean7 = piePlot5.isCircular();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot5.setLabelOutlineStroke(stroke8);
        java.awt.Paint paint10 = piePlot5.getBaseSectionOutlinePaint();
        boolean boolean11 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        java.util.Date date2 = dateRange1.getUpperDate();
        try {
            org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) date2, 0.5d, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str42 = categoryAxis41.getLabelToolTip();
        categoryAxis41.setCategoryLabelPositionOffset((int) (byte) 0);
        int int45 = categoryPlot36.getDomainAxisIndex(categoryAxis41);
        boolean boolean46 = categoryPlot36.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot36.getRangeAxisEdge(1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis3D1.getMarkerBand();
        numberAxis3D1.configure();
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("rect");
        dateAxis2.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class7 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 9999);
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date13, timeZone14);
        java.util.Date date16 = dateTickUnit6.addToDate(date13);
        dateAxis2.setTickUnit(dateTickUnit6, false, false);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) dateTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Shape shape4 = stackedBarRenderer3D0.getSeriesShape(0);
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray31 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D36.setIncludeBaseInRange(false);
        java.awt.Paint paint40 = stackedBarRenderer3D36.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D36);
        org.jfree.data.Range range42 = stackedBarRenderer3D0.findRangeBounds(categoryDataset33);
        org.jfree.data.Range range44 = org.jfree.data.Range.expandToInclude(range42, Double.NaN);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (-1.0d), 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot36.getDomainAxisForDataset(0);
        categoryPlot36.setNoDataMessage("hi!");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot36.getDomainAxisForDataset((int) '4');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(categoryAxis47);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double2 = rectangleConstraint1.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint1.toFixedHeight((double) 1);
        boolean boolean5 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        java.util.List list5 = defaultIntervalCategoryDataset4.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultIntervalCategoryDataset4.getGroup();
        int int7 = defaultIntervalCategoryDataset4.getCategoryCount();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("rect");
        dateAxis9.configure();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit((int) (short) 1, 100);
        java.lang.Class class14 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        boolean boolean19 = simpleTimePeriod17.equals((java.lang.Object) 9999);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        java.util.Date date23 = dateTickUnit13.addToDate(date20);
        dateAxis9.setTickUnit(dateTickUnit13, false, false);
        try {
            java.lang.Number number28 = defaultIntervalCategoryDataset4.getValue((java.lang.Comparable) false, (java.lang.Comparable) "Range[0.0,1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.setKey((java.lang.Comparable) "ChartEntity: tooltip = null");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelWidthType.RANGE", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = stackedBarRenderer3D31.getLegendItemToolTipGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = stackedBarRenderer3D31.getLegendItems();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot(pieDataset40);
        boolean boolean42 = defaultCategoryDataset39.hasListener((java.util.EventListener) ringPlot41);
        boolean boolean43 = stackedBarRenderer3D31.equals((java.lang.Object) defaultCategoryDataset39);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = null;
        stackedBarRenderer3D0.setSeriesStroke((int) (short) 0, stroke2, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D5.setIncludeBaseInRange(false);
        org.jfree.chart.LegendItem legendItem10 = stackedBarRenderer3D5.getLegendItem(0, 9);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D5.setSeriesToolTipGenerator(5, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator12);
        stackedBarRenderer3D0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator12, true);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 6.0d, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str6 = blockContainer5.getID();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D9 = flowArrangement4.arrange(blockContainer5, graphics2D7, rectangleConstraint8);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = flowArrangement4.arrange(blockContainer10, graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(size2D9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        float float2 = piePlot1.getBackgroundAlpha();
        int int3 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator4);
        boolean boolean6 = paintList0.equals((java.lang.Object) pieSectionLabelGenerator4);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean8 = paintList0.equals((java.lang.Object) shape7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean6 = plotOrientation4.equals((java.lang.Object) shape5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setIncludeBaseInRange(false);
        java.awt.Shape shape5 = stackedBarRenderer3D1.getSeriesShape(0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D1.setBasePaint((java.awt.Paint) color6);
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color6 };
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D9.setIncludeBaseInRange(false);
        java.awt.Shape shape13 = stackedBarRenderer3D9.getSeriesShape(0);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D9.setBasePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setIncludeBaseInRange(false);
        java.awt.Shape shape20 = stackedBarRenderer3D16.getSeriesShape(0);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D16.setBasePaint((java.awt.Paint) color21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color14, color21, color23 };
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray24, paintArray25, strokeArray26, strokeArray27, shapeArray28);
        boolean boolean30 = unitType0.equals((java.lang.Object) strokeArray27);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double[] doubleArray6 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray11 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray16 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray21 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray26 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setIncludeBaseInRange(false);
        java.awt.Paint paint35 = stackedBarRenderer3D31.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D31);
        java.awt.Graphics2D graphics2D37 = null;
        double[] doubleArray44 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray49 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray54 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray59 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[] doubleArray64 = new double[] { 1.0f, 100.0f, '#', (-1) };
        double[][] doubleArray65 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray65);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D69.setIncludeBaseInRange(false);
        java.awt.Paint paint73 = stackedBarRenderer3D69.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D69);
        categoryPlot74.mapDatasetToRangeAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = categoryPlot74.getDomainAxis(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator80 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D82 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D82.setFixedAutoRange(0.0d);
        boolean boolean85 = standardCategorySeriesLabelGenerator80.equals((java.lang.Object) numberAxis3D82);
        java.awt.Color color87 = java.awt.Color.RED;
        org.jfree.chart.plot.PiePlot piePlot88 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke89 = piePlot88.getLabelOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker90 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color87, stroke89);
        java.awt.Font font92 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle("hi!", font92);
        java.lang.String str94 = textTitle93.getURLText();
        java.awt.geom.Rectangle2D rectangle2D95 = textTitle93.getBounds();
        stackedBarRenderer3D31.drawRangeMarker(graphics2D37, categoryPlot74, (org.jfree.chart.axis.ValueAxis) numberAxis3D82, (org.jfree.chart.plot.Marker) categoryMarker90, rectangle2D95);
        categoryMarker90.setLabel("LGPL");
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertNull(categoryAxis79);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(rectangle2D95);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setIncludeBaseInRange(false);
        java.awt.Shape shape5 = stackedBarRenderer3D1.getSeriesShape(0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        stackedBarRenderer3D6.setBaseItemLabelPaint((java.awt.Paint) color7);
        double double9 = stackedBarRenderer3D6.getUpperClip();
        java.awt.Shape shape12 = stackedBarRenderer3D6.getItemShape((int) '4', (int) (byte) -1);
        stackedBarRenderer3D1.setBaseShape(shape12);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean15 = stackedBarRenderer3D1.hasListener((java.util.EventListener) piePlot3D14);
        boolean boolean16 = lengthAdjustmentType0.equals((java.lang.Object) boolean15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }
}

